<?php
/* * *****************************************************************************
 * @author      	Deepak Pande
 * @created date	2019-03-21
 * @Disc            verify User OTP
 * **************************************************************************** */
$applicationPath = rtrim(dirname(__FILE__), "/\\") . DIRECTORY_SEPARATOR;
require_once "common/auto_load.php";
require_once "common/include_header.php";   
fileRequire("lib/system/pluginFileRequire.php");
fileRequire('common/auto_load.php');
fileRequire("lib/system/decryptValues.php");
fileRequire("lib/system/fileWrite.php");
fileRequire("classes/class.common.php");

class verifyOtp{
    
    
    private $_OdataBase;
    public $_IinputData;
     
    public function __construct(){
       $this->_IinputData = $this->_getRequestData();
       $this->_OdataBase = $this->_getConnection();
    }

    public function _checkRequest(){
        
        if($this->_IinputData['otpInfo'] == ''){
            $string = file_get_contents(HOST_URL . 'view/common/twig/invalidAccess.html');
            $message = "This page can't be displayed";
            $stringReplaced = str_replace("MESSAGE",$message,$string);
            $linkMessage = "The URL which you've provided is incorect";
            $template = str_replace("LINK",$linkMessage,$stringReplaced);
            echo $template;
            exit();
        }
        $objLogin = new employee();
        $user = explode("$$",base64_decode($this->_IinputData['otpInfo']));
        $linkExpireStatus = $objLogin->_getLinkExpireStatus($user[3]);
        if($linkExpireStatus == 'Y'){
             $string = file_get_contents(HOST_URL . 'view/common/twig/invalidAccess.html');
             $message = "Link has been Expired"; 
             $stringReplaced = str_replace("MESSAGE",$message,$string); 
             $linkMessage = "";
             $template = str_replace("LINK",$linkMessage,$stringReplaced);
            echo $template;
            exit();
        }
        $employee = $objLogin->_getEmployeeInfo(0,$user[0]);
        $smsFlow = 'REG';
        $objLogin->_generateAuthOTP($employee,$smsFlow);
        $pwdResetLink = $user[2];
        $mobileNo = str_split($employee['mobile_no']);
        $mobileNo = $mobileNo[7].$mobileNo[8].$mobileNo[9];
        return array('userId' => $employee['employee_id'],'corporateId'=>$employee['r_corporate_id'],'pwdResetLink' =>$pwdResetLink,'mobileNo'=>$employee['mobile_no'],'encrytMobileNo'=>$mobileNo);

    }

 //To get request level data during post/get
    private function _getRequestData(){        
        //sanitize the input
        $_OauthToken = new authToken();  
        $requestDetails['otpInfo'] = $_OauthToken->_purifyInputData($_GET['otpInfo']);     
        return $requestDetails;
    }  

    //To get the connection object
    private function _getConnection(){
         return dataBase::_createDBO();
    }  
    
}

//Initialize the class
$ajaxObj = new verifyOtp();
$data = $ajaxObj->_checkRequest();

if(is_array($data)){
    $user['userId']       = $data['userId'];
    $user['pwdResetLink'] = $data['pwdResetLink'];
    $user['corporateId']  = $data['corporateId'];
    $user['corporateId']  = $data['corporateId'];
    $user['encrytMobileNo'] = $data['encrytMobileNo'];

} 
else{
    $user['error'] = true;
}

$twig = init();
$temp = $twig->render('verifyOTP.tpl',$user);
echo $temp;
?>