<?php

fileRequire("classes/class.commonDBO.php");
fileRequire("lib/system/authToken.php");

class commonMethods {

    public function __construct() {
        $this->_OcommonDBO = new commonDBO();
    }

    /* Function : readExternalWebservice
     * Description : this method is to get/post the data from the external webservice
     * Argument : String type which holds url of the External webservices
     * return type : Will be a xml which is the response webservices
     * created date : 27 JUN 2016
     * Author : Thirumal
     */

    public function _readExternalWebservice($url,$corporateId = '') {

        filewrite($url, 'resultmsg_'.$corporateId, 'a+');

        // Open connection
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, trim($url));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
        // Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $result = curl_exec($ch);
        // Close connection
        curl_close($ch);

        filewrite($result, 'resultmsg', 'a+');

        return $result;
    }

    public function _curlRequest($url, $type = 'GET', $postFields = false, $responsetype = 'text', $connectiontimeout = 30, $timeout = 60, $serverResponse = true) {

        $rawdata = false;
        if (!empty($url)) {
            $ch = curl_init();

            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        filewrite("postFields : ".print_r($postFields,1),"queryAPILogs","a+");

            if ($type == 'POST' && !empty($postFields)) {
                fileWrite('Curl Request: ' . print_r($postFields, 1), 'curlRequest');
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
            }

            if ($responsetype == 'json' && $this->_SagencyMailSetting == 'API') {
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    'Content-Type: application/json',
                    'Accept: application/json',
                    "api_key: c41441c58057c14dad9ab06864193e0c"
                ));
            }
             if ($responsetype == 'json' && $this->_SagencyMailSetting == 'SMTP') {
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    'Content-Type: application/json',
                    'Accept: application/json',
                ));
            }
            if ($responsetype == 'urlEncoded') {
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                     "cache-control: no-cache",
                    "content-type: application/x-www-form-urlencoded",
                ));
            }


            //curl_setopt($ch, CURLOPT_USERAGENT , "Mozilla/4.0 (compatible; MSIE8.0; Windows NT 6.1)");
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, $serverResponse);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $connectiontimeout);
            curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);

            $rawdata = curl_exec($ch);
            fileWrite('Curl Response: ' . print_r($rawdata, 1), 'curlRequest');

            if ($rawdata === false) {
                fileWrite('Curl url  : ' . $url, 'curlError');
                fileWrite('Curl error: ' . curl_error($ch), 'curlError');
            }

            curl_close($ch);

            return $rawdata;
        } else {
            fileWrite('Curl error: Empty url specified', 'curlError');
        }
    }

    public function _fileInformation($filename, $type = 'FILEINFO_MIME_TYPE') {

        $result = new finfo();

        if (is_resource($result) === true) {
            return $result->file($filename, constant($type));
        }

        return false;
    }

    /*
     * @functionName    :   _getDataFromXML()
     * @description     :   method to get policies from XML
     */

    public function _getDataFromXML() {

        $xml = simplexml_load_file($this->_Sfile);

        $data = xmlToArray($xml);

        if ($this->_SreturnType == "JSON") {
            $data = json_encode($data);
        }

        return $data;
    }

    public function _Email($mailid, $from, $subject = 'www.atyourprice.net', $msg = 'Corporate mail testing ', $headers = '') {

        $headers = "";
        $eol = "\n";
        $now = "";

        $headers .= "Reply-To: <" . $from . ">" . $eol;
        $headers .= "Return-Path: " . $from . " " . $eol;    // these two to set reply address
        $headers .= "Message-ID: <" . $now . " " . $from . "" . ">" . $eol;
        $headers .= "X-Mailer: PHP v" . phpversion() . $eol;          // These two to help avoid spam-filters
        $headers .= "MIME-Version: 1.0" . $eol;
        $headers .= "From:<$from>" . $eol;
        $headers .= "Content-Type:text/html;charset=utf-8" . $eol;

        //Normal PHP mail function call
        mail($mailid, $subject, $msg, $headers, "-f$from");
    }

    //Soap mail function call for local servers
    public function soapMail($mailid, $subject = 'www.atyourprice.net', $msg = 'Mail from atyourprice.net', $headers = '') {
        //$endpoint='http://166.78.251.239/corporate2.0/soapMail.php'; // REPLICA SEVER
        //$endpoint='http://182.18.161.230/corporate3.0/soapMail.php'; // DEMO SERVER

        $endpoint = 'http://198.101.243.32/soapMail.php'; // EXPENSEOUT SERVER

        $wsdl = false;
        $proxyhost = false;
        $proxyport = false;
        $proxyusername = false;
        $proxypassword = false;
        $timeout = 0;
        $response_timeout = 360;

        $client = new nusoap_client($endpoint, $wsdl, $proxyhost, $proxyport, $proxyusername, $proxypassword, $timeout, $response_timeout);

        $details['fetchTpl'] = $msg;
        $details['emailId'] = $mailid;
        $details['headers'] = $headers;
        $details['subject'] = $subject;
        $details['CorporateLoginId'] = $mailid;

        $result = $client->call('soapMail', array('details' => $details));
        fileWrite($result, 'final');
        if ($result) {
            fileWrite($mailid . " file : yam1 Loginid : " . $_SESSION['emailId'] . " ", "EmailAction", "a+");
        }
    }

    /**
     * @Description To validate the email id
     * @param type $email
     * @return boolean
     */
    public function _doEmailValidation($email = '') {
        $email = trim(htmlspecialchars($email));
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * @Description To validate the empty form values
     * @param type $values
     * @return boolean
     */
    public function _doEmptyValidation($values = array()) {
        $valuesCount = count($values);
        if (is_array($values) && $valuesCount > 0) {
            for ($i = 0; $i < $valuesCount; $i++) {
                if (empty(trim($valuesCount[$i]))) {
                    return false;
                }
                return true;
            }
        } else {
            return false;
        }
    }

    public function _trimRecursiveArray(&$arr) {
        foreach ($arr as $key => &$val) {
            if (is_array($val) || is_object($val)) {
                trimRecursiveArray($val);
            } else {
                $val = trim($val);
            }
        }
    }

    public function _assignAlertMessage($_ATwigAlertOutput, $_Otwig) {
        if ($_ATwigAlertOutput['type'] == 0) { //danger bootstrap alert
            $twigOutputTemplate = 'default/fail.tpl';
        } else if ($_ATwigAlertOutput['type'] == 1) { //warning bootstrap alert
            $twigOutputTemplate = 'default/warning.tpl';
        } else if ($_ATwigAlertOutput['type'] == 2) { //information bootstrap alert
            $twigOutputTemplate = 'default/information.tpl';
        } else if ($_ATwigAlertOutput['type'] == 3) { //success bootstrap alert
            $twigOutputTemplate = 'default/success.tpl';
        }

        $_SBSAlertMsg = $_Otwig->render($twigOutputTemplate, $_ATwigAlertOutput);
        return $_SBSAlertMsg;
    }

    public function _sopaClientCall($endpoint, $method, $modulename, $formname) {

        fileRequire('classes/class.nusoap.php');

        /* if endpoint not defined in service use webservicewrapper.php */
        if ($endpoint == '') {
            $endpoint = CORPORATE_URL . 'services/webservicewrapper.php';
        }

        /* if method not defined user webservice wrapper method */
        if ($method == '') {
            $method = 'webservicewrapper';
        }

        $wsdl = false;
        $proxyhost = false;
        $proxyport = false;
        $proxyusername = false;
        $proxypassword = false;
        $timeout = 0;
        $responseTimeout = 360;

        $formname['modulename'] = $modulename;

        $client = new nusoap_client($endpoint, $wsdl, $proxyhost, $proxyport, $proxyusername, $proxypassword, $timeout, $responseTimeout);
        $this->_trimRecursiveArray($formname);
        $response = $client->call($method, array('details' => $formname));

        return $response;
    }

    /*
     * @Description _nuSoapRequest method handles all the transaction that are made through nusoap_client.
     * @param array|$endpoint,$requestMethod,$requestData,$wsdl, $proxyhost, $proxyport, $proxy, $proxy, $timeout, $response_timeout
     * @return array / json |$response
     */

    public function _nuSoapRequest($endpoint, $requestMethod, $requestData, $wsdl = false, $proxyhost = false, $proxyport = false, $proxyusername = false, $proxypassword = fals, $timeout = 0, $response_timeout = 360) {
        fileRequire('classes/class.nusoap.php');

        $client = new nusoap_client($endpoint, $wsdl, $proxyhost, $proxyport, $proxyusername, $proxypassword, $timeout, $response_timeout);

        $result = $client->call($requestMethod, array('details' => $requestData));
        return $result;
        if ($result) {
            return $result;
        } else {
            return "Error : " . $client->getError();
        }
    }

    public function _encriptValue($initialValue) {

        $randomkey = "0.101492156064763tmjnni45idjc3455jdpeqz45";

        if (strlen($initialValue) > 1) {
            $randomString1 = $this->_randomString(4);
            $positionNumber = $this->_getRandomizer(1, strlen($initialValue) - 1);

            $strArray = str_split($initialValue);
            $randArray[] = $randomString1;

            array_splice($strArray, $positionNumber, 0, $randArray);

            $str = implode("", $strArray) . $positionNumber;
        } else {
            $str = $initialValue;
        }

        $encoded = base64_encode($str);

        return $encoded;
    }

    public function _randomString($len) {

        $charSet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

        $randomString = '';

        for ($i = 0; $i < $len; $i++) {
            $randomString .= substr($charSet, mt_rand(0, strlen($charSet) - 1), 1);
        }

        return $randomString;
    }

    public function _getRandomizer($bottom, $top) {

        $a = rand($bottom, $top);

        if ($a > 9) {
            $a = $a % 10;
            if ($a == 0) {
                $a = 1;
            }
        }

        return $a;
    }

    /*
     * @Description It is used for send many attachment in a single mail,
     * @param array|$to,$from,$subject,$message, $attachment, $mimetype
     * @return array / json |$response
     */

    public function _sendMail($mailid, $from = 'support@atyourprice.in', $subject, $msg = 'Corporate mail testing ', $attachment = '', $mailCc = '', $mailBcc = '',$fileName) {
        ##d add from mail id for loreal corporate

        if (array_search('YES', $_SESSION['userApplicationSettings']['OVERRIDE_PLUGIN_NAME']) == 'loreal') {
            $from = LOREAL_FROM_EMAILID;
        }
        $agencyMailSetting = $this->_OcommonDBO->_select('dm_agency','mail_setting','agency_name','Balmer lawrie')[0]['mail_setting'];
        //if (ENVIRONMENT_NAME == 'PRODUCTION') {
            // $mailBcc = TOMAILID;
        //}
        
        // if (DUMMY_MAIL == 'Y'){
        //     $mailid = TOMAILID;
        //     $mailCc = '';
        // }
       
        ### to mail ids if multiple with the semicolon then replaced with comma and form an array of to mail ids
        $mailid      = str_replace(';', ',', $mailid);
        $mailidMulti = explode(',', $mailid);

        if ($mailCc != '') {
            $mailCc = str_replace(';', ',', $mailCc);
            $mailCcMulti = explode(',', $mailCc);
        }
        if ($mailBcc != '') {
            $mailBcc = str_replace(';', ',', $mailBcc);
            $mailBccMulti = explode(',', $mailBcc);
        }
        $this->_SagencyMailSetting = $_SESSION['agencyMailSetting'] != '' ? $_SESSION['agencyMailSetting'] : $agencyMailSetting;
        ## Condition to send mail through API or PHP Mailer
        if($this->_SagencyMailSetting == 'API' &&  ENVIRONMENT_NAME != 'LOCALHOST'){
             ### set SMTP configuration details
        $from = ($from == BALMER_SMTP_TICKET_MAIL_FROM)? BALMER_API_TICKET_MAIL_FROM :BALMER_API_MAIL_FROM;
            $result = json_decode($this->_mailApi($mailidMulti,$msg,$subject,$attachment,$from,$mailCcMulti,$mailBccMulti,$fileName),1);
             $statusBool = $result['message'] == 'Success' ? 1 : 0;
        }else{
            ### set SMTP configuration details
            $from = ($from == BALMER_SMTP_TICKET_MAIL_FROM)? $from :BALMER_SMTP_MAIL_FROM;
                require_once 'lib/PHPMailer/PHPMailerAutoload.php';
                $mail = new PHPMailer();
                
                ### customization for balmer corporates
                //if (array_search('YES', $_SESSION['userApplicationSettings']['OVERRIDE_PLUGIN_NAME']) == 'ongc') {
                    
                    ### for balmer mail to as per senthil sir request
                    //$mailBcc = 'balmer.agencyauto@gmail.com';
                    $mail->isSMTP();

                    ###Enable SMTP debugging  0 = off (for production use)  1 = client messages  2 = client and server messages
                    $mail->SMTPDebug = 0;

                    $mail->SMTPOptions = array(
                        'ssl' => array(
                            'verify_peer' => false,
                            'verify_peer_name' => false,
                            'allow_self_signed' => true
                        )
                    );

                    ### Set the hostname of the mail server
                    $mail->Host = BALMER_SMTP_HOST;
                    
                    ### Set the SMTP port number - likely to be 25, 465 or 587
                    $mail->Port = BALMER_SMTP_PORT;
                    
                    ### Whether to use SMTP authentication
                    $mail->SMTPAuth = BALMER_SMTP_AUTHORIZATION;

                    ### Whether to use SMTP secure
                    $mail->SMTPSecure = BALMER_SMTP_SECURE;
                    
                    $userName = ($from == BALMER_SMTP_TICKET_MAIL_FROM) ? BALMER_SMTP_TICKET_USERNAME : BALMER_SMTP_USERNAME;
                    
                    ### Username to use for SMTP authentication
                    $mail->Username = $userName;
                    
                    ### Password to use for SMTP authentication
                    $mail->Password = ($from == BALMER_SMTP_TICKET_MAIL_FROM) ? BALMER_SMTP_TICKET_HASH : BALMER_SMTP_HASH;
                    
                    ### Set who the message is to be sent from
                    $mail->setFrom($from, $userName);
                    
                    ### Set an alternative reply-to address
                    $mail->addReplyTo($from, $userName);

                    ###  set add reply-to address
                    $mail->AddReplyTo($from);
                //}

                $mail->SetFrom($from);

                ### mailCc if multiple with the semicolon then replaced with comma and form an array of cc mail ids
                foreach ($mailCcMulti as $value) {
                    $mail->AddCC($value);
                }
                
                ### mailBcc if multiple with the semicolon then replaced with comma and form an array of bcc mail ids
                foreach ($mailBccMulti as $value) {
                    $mail->AddBCC($value);
                }              

                foreach ($mailidMulti as $value) {
                    $mail->AddAddress($value);
                }

                ### assign the subject to php mailer
                $mail->Subject = $subject;
                $mail->AltBody = $msg; // optional, comment out and test

                $mail->MsgHTML($msg);

                ### for attachment with the mails
                if (count($attachment) > 0 && $attachment != '') {
                    if (is_array($attachment)) {
                        foreach ($attachment as $attach) {
                            $mail->AddAttachment($attach);
                        }
                    } else {
                        $mail->AddAttachment($attachment);
                    }
                }

                if (ENVIRONMENT_NAME == 'PRODUCTION' || ENVIRONMENT_NAME == 'PREPRODUCTION' || ENVIRONMENT_NAME == 'STAGING') {
                    ###trigger the mail send and if error log file write in the name of PHPMailerError
                    if (!$mail->Send()) {
                        filewrite($mail->ErrorInfo, 'PHPMailerError', 'a+');
                        fileWrite('Mail ID:' . $mailid . 'from:' . $from . 'subject:' . $subject, 'failureMail', 'a+');
                        $mailStatus = "failure";
                    } else {
                        fileWrite('Sucess Mail ID:' . $mailid . 'from:' . $from . 'subject:' . $subject . 'message:' . $msg, 'sendMail', 'a+');
                        $mailStatus = "success";
                    }
                } else {
                  ### create mail log object
                  $_OMailLog = new mailLog();
                  fileWrite('IN Mail log table  ON ENter Mail ID:'.$mailid.'from:'.$from.'subject:'.$subject.'message:'.$msg, 'sendMail','a+');
                  $_OMailLog->_logMail($mailid, $from, $subject, $msg, $attachment, $mailCc, $statusBool);
                  $mailStatus = "success";
                }

                $statusBool = $mailStatus == 'success' ? 1 : 0;
                fileWrite('Mail status: '.$mailid.'from:'.$from.'subject:'.$subject.'status:'.$statusBool, 'sendMail','a+');
            }
        return $statusBool;
    }

    public function _encodeArrayToJSON($array) {
        if (is_array($array)) {
            $data = json_encode($array);
        }
        return $data;
    }

    public function _decodeJSONToArray($jsonData) {

        $data = json_decode($jsonData, 1);

        return $data;
    }


    public function prepareCall($callType, $path, $request) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $callType);
        curl_setopt($ch, CURLOPT_VERBOSE, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        switch ($callType) {
            case 'POST':
                curl_setopt($ch, CURLOPT_URL, $path);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $request);
                break;
        }

        return $ch;
        curl_close($ch);
    }

    public function _callTokenSyncMethod($agencyUrl, $userName, $hashword, $agencyToken, $tokenValidity, $agencyId) {

        if ((time() >= strtotime($tokenValidity)) || empty($agencyToken)) {

            $request = array("userName" => $userName, "password" => $hashword);
            $handler = $this->prepareCall('POST', $agencyUrl, $request);
            $result = curl_exec($handler);
            $resultData = (array) json_decode($result);

            fileWrite('Request URL:' . $agencyUrl, 'syncResponse', 'a+');
            fileWrite('Request:' . print_r($request, 1), 'syncResponse', 'a+');
            fileWrite('Response:' . print_r($resultData, 1), 'syncResponse', 'a+');

            //update service token in dm_agency table
            if (!empty($resultData['serviceToken'])) {
                $sql = "UPDATE dm_agency SET sync_token='" . $resultData['serviceToken'] . "', token_validity = DATE_ADD(NOW(), INTERVAL 2 HOUR) WHERE dm_agency_id = " . $agencyId . "";
                $result = $this->_OcommonDBO->_executeQuery($sql);
            } else {
                fileWrite('Response: Token not generated' . print_r($resultData, 1), 'syncResponse', 'a+');
            }
        } else {
            $resultData['serviceToken'] = $agencyToken;
        }
        return $resultData;
    }

    public function _callSyncMethod($agencyUrl, $requestMethod, $_AairRequestData, $packageId, $serviceToken) {

        $result = false;

        $request = array("data" => $_AairRequestData, "serviceToken" => $serviceToken, "method" => $requestMethod);
        $handler = $this->prepareCall('POST', $agencyUrl, $request);
        $result = curl_exec($handler);

        fileWrite('Request URL:' . $agencyUrl, 'syncResponse', 'a+');
        fileWrite('Request:' . print_r($request, 1), 'syncResponse', 'a+');

        if (!$result) {
            $error = curl_error($handler);
            fileWrite('Error:' . print_r($error, 1), 'syncResponse', 'a+');
        } else {
            fileWrite('Response:' . print_r($result, 1), 'syncResponse', 'a+');
        }
        return $result;
    }

    /**
     *  do module post based 
     * @param string|$applicationPath
     * @param array|$_AairRequestData
     * @return array|$result
     */
    function _doModulePost($applicationPath, $_AairRequestData) {

        pluginFileRequire('common/', "classAjax/class.ajax.commonRequest.php");

        $twig = init($applicationPath);
        $_OdataBase = dataBase::_createDBO();
        $ajaxObject = new commonRequest();
        $ajaxObject->_Oconnection = $_OdataBase->_Oconnection;
        $ajaxObject->_SpackageName = $_AairRequestData['packageName']; //harinim
        $ajaxObject->_Otwig = init();

        $formValues = array();
        $formValues['encrypt'] = 'N';

        //Decrypting class tpl name
        //$objDecryptValues = new decryptValues($_OdataBase);
        //$objDecryptValues->_decrypt($_AairRequestData['tplClassName'], $formValues);
        $ajaxObject->_StplClassName = $_AairRequestData['classTpl'];

        //Check for decoded classtpl name
        if ($ajaxObject->_StplClassName != '') {
            //Assigning the input data
            $ajaxObject->_IinputData = $_AairRequestData;

            $ajaxObject->_Otwig = $twig;
            //Calling default ajax method
            $ajaxObject->_callAjaxFunction();
            $response = $ajaxObject->_Aresponse;

            $result = array('status' => 1, 'message' => 'Success', 'displayTpl' => $response['result']['displayTemplate']);
        } else {
            //$ajaxObject->_Aresponse['error'] = 'class tpl name not found';
            $result = array('status' => 0, 'message' => 'class tpl name not found');
        }

        return $result;
    }

    /**
     * Creates compressed image file
     * @param array | $filesArray
     * @param int | $newWidth
     * @param int | $newHeight
     * @param string | $uploadDir
     * @param string | $newFileName
     * @param int | $qulityCompression
     * @return array|$responseArray
     */
    public function compressImage($filesArray, $newWidth = 100, $newHeight = 30, $uploadDir = '', $newFileName = 'test.jpg', $outputformat = 'jpg', $qulityCompression = 100) {
        fileWrite(" newWidth " . $newWidth . " newHeight" . $newHeight, "sizeSet");
        if ($uploadDir == '') {
            $uploadDir = APP_BASE_PATH . 'userUpload/logo/';
        }
        // get the file name from the temp location that is set in _Afile
        $filename = $filesArray['tmp_name'];
        $info = getimagesize($filename);
        fileWrite(print_r($info, true), "sizeSet", "a+");
        $width = $info[0];
        $height = $info[1];
        // to check the type of file set in the temp location
        if ($info['mime'] == 'image/jpeg') {
            $image = imagecreatefromjpeg($filename);
        } elseif ($info['mime'] == 'image/gif') {
            $image = imagecreatefromgif($filename);
        } elseif ($info['mime'] == 'image/png') {
            $image = imagecreatefrompng($filename);
        } else {
            $responseArray = array('status' => 0, 'message' => 'File Format not supported');
        }

        // check if width is greater than height and is greater than 500 and check if width is less than 100 then leave
        $dimension = $this->_checkNewWidth($width, $height);
        $finalwidth = $dimension[0];
        $finalheight = $dimension[1];
        fileWrite('$finalwidth ' . $finalwidth . ' $finalheight' . $finalheight, "sizeSet", "a+");

        // source for the image
        $imagesrc = imagecreatetruecolor($finalwidth, $finalheight);
        // to set the background colour of the image
        $white = imagecolorallocate($imagesrc, 0xFF, 0xFF, 0xFF);
        imagefill($imagesrc, 0, 0, $white);    // this goes hand in hand with imagecolorallocate
        // after the image is set copy it to the set location
        imagecopyresampled($imagesrc, $image, 0, 0, 0, 0, $finalwidth, $finalheight, $width, $height);
        // check for the type of response array
        if ($outputformat == 'jpg') {
            imagejpeg($imagesrc, $uploadDir . $newFileName, $qulityCompression);
        } else if ($outputformat == 'png') {
            imagepng($imagesrc, $uploadDir . $newFileName, $qulityCompression);
        } else if ($outputformat == 'gif') {
            imagegif($imagesrc, $uploadDir . $newFileName, $qulityCompression);
        } else {
            imagejpeg($imagesrc, $uploadDir . $newFileName, $qulityCompression);
        }

        $responseArray = array('status' => 1, 'message' => 'Image resizing completed', 'name' => $uploadDir . $newFileName);

        return $responseArray;
    }

    /* check and initialize if corporate customization exists
     * @param 
     * @return bool|$returnValue
     */

    public function _initCorporateCustomization($type = 1, $dynamicId) {

        //corporate id is passed
        if ($type == 1) {
            $corporateId = $dynamicId;
        } else if ($type == 2) {
            //order id is passed
            $fieldsArray = 'r_corporate_id';
            $resultArray = $this->_OcommonDBO->_select('fact_booking_details', $fieldsArray, 'r_order_id', $dynamicId, 'OBJECT')[0];
            $corporateId = $resultArray['r_corporate_id'];
        }
         else if ($type == 3) {
            //order id is passed
            $sql = "SELECT r_corporate_id FROM trip_request_details trd
                        INNER JOIN dm_employee dme ON dme.email_id = trd.requested_by 
                        INNER JOIN fact_employee fe ON fe.r_employee_id = dme.employee_id WHERE trd.trip_request_details_id = ".$dynamicId;
            $corporateId = $this->_OcommonDBO->_getResult($sql)[0]['r_corporate_id'];
            
        }

        $_Ologin = new login();

        //set default return value
        $returnValue = false;

        $userApplicationSettings = $_Ologin->_getCorporateAppSettings($corporateId);
        
        if (isset($userApplicationSettings['OVERRIDE_PLUGIN_NAME'])) {

            define('OVERRIDE_PACKAGE_NAME', array_search('YES', $userApplicationSettings['OVERRIDE_PLUGIN_NAME']));
            //override plugin name is present hence  respone as true for identification
            $returnValue = true;
        } else {
            define('OVERRIDE_PACKAGE_NAME', 'harinim');
        }
        
        //set package name constants for customization
        if (OVERRIDE_PACKAGE_NAME != 'harinim') {
            define('PLUGIN_NAME', 'corporate/');
            define('DEFAULT_PACKAGE_NAME', 'harinim');
        }

        if (isset($userApplicationSettings['OVERRIDE_PLUGIN_NAME'])) {

            $overRidePackageName = OVERRIDE_PACKAGE_NAME;

            if (trim(DEFAULT_PACKAGE_NAME, '/') != $overRidePackageName) {
                $this->_BOverRidePlugin = true;
                $this->_SoverRidePackageName = $overRidePackageName;
                $this->_SoverRidePluginPathName = PLUGIN_NAME . '/' . $overRidePackageName;
            }
        }

        return $returnValue;
    }

    /**
     * to resize the image
     * @param type $width
     * @param type $height
     * @return type
     */
    public function _checkNewWidth($width, $height) {
        fileWrite('height ' . $height . " width" . $width, "height");
        $widthSet = $heightSet = '';
        if ($width < $height) {
            // reduce the width to 500
            if ($width > 500) {
                // percentage of width reduced
                fileWrite('One height ' . $height . " width" . $width, "height", "a+");
                $widthPercent = round((($width - ($width - 150)) / $width) * 100);
                $widthSet = 150;
                // percentage of width reduced
                $heightSet = round($height - ($height - ($height * $widthPercent) / 100));
                $width = $widthSet;
                $height = $heightSet;
            } else if ($height < 70) {
                // percentage of height increased
                fileWrite('two height ' . $height . " width" . $width, "height", "a+");

                $heightPercent = round(((70 - $height) / 70) * 100);
                $widthSet = round($width + (($width * $heightPercent) / 100));
                $height = 70;
                $width = $widthSet;
            } else {
                // use normal method for resizing   
                fileWrite('three height ' . $height . " width" . $width, "height", "a+");
                $height = round($height / $width * $newWidth);
                $width = round($width / $height * $newHeight);
            }
        }
        fileWrite('height ' . $height . " width" . $width, "height", "a+");
        return array($width, $height);
    }

    /**
     * The function is_date() validates the date and returns true or false
     * @param $str sting expected valid date format
     * @return bool returns true if the supplied parameter is a valid date otherwise false
     */
    function validateDate($str) {
        try {
            $dt = new DateTime(trim($str));
        } catch (Exception $e) {
            return false;
        }
        $month = $dt->format('m');
        $day = $dt->format('d');
        $year = $dt->format('Y');
        if (checkdate($month, $day, $year)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Validate time
     * @param time $time Time
     * @return boolean
     */
    public function validateTime($time) {
        return preg_match("/(2[0-3]|[01][0-9]):([0-5][0-9])/", $time);
    }
    /**
    * function to combine the all the css into single file 
    **/
    function loadCombinedCSS() 
    {
        global $CFG;
        #Checking Combined CSS exists
       $combinedCssFiles = glob(APP_BASE_PATH . "lib/css/common/combined2*.css");
        if (!empty($combinedCssFiles)) {
            $combinedCSS=$combinedCssFiles[0];
        }
        else
        {
            #Compress the css file into single combined css file
            $combinedCSS = $this->createCombinedCSS();
        }
        return $combinedCSS;
    }
    /**
    * function to create the combined css  
    **/

    function createCombinedCSS()
    {
        global $CFG;
        $cssScript = "";
        $_OauthToken = new authToken();
        $filePath = $_OauthToken->_purifyInputData(COMBINEDCSSPATH);
        $_AcssFile = json_decode(file_get_contents($filePath),1);
            foreach($_AcssFile as $file)
                {
                    $cssScript.= file_get_contents(APP_BASE_PATH . $file);
                }
            fileRequire("lib/common/class.compressor.php");
            $css = Minify_CSS_Compressor::process($cssScript);

        $combinedCSS= APP_BASE_PATH . "lib/css/common/combined".date("YmdHi").".css";
        file_put_contents($combinedCSS, $css);
        return $combinedCSS;
    }
     /* To combine the js files
     * @param 
     * @return bool|$combinedJS
     */
    public function loadCombinedJS() 
    {
        global $CFG;
        
        #Checking Combined JS exists
        $combinedFiles = glob(APP_BASE_PATH . "lib/script/combined2*.js");
        if (!empty($combinedFiles)) {
            $combinedJS=$combinedFiles[0];
        }
        else
        {
            #Compress the javascript file into single combined js file
            $combinedJS = $this->createCombinedJS();
        }
        return $combinedJS;
    }
    
    /*
     * Usage: To generate the combined Js
     * Compress all the JS files and encrypt the files based on condition
    */
    private function createCombinedJS(){
       
        fileRequire("lib/common/jsmin.php");
        global $CFG;
        $_OauthToken = new authToken();
        $filePath = $_OauthToken->_purifyInputData(COMBINEDJSPATH);

        $fileName = json_decode(file_get_contents($filePath),1);     
        $_Sscript = "";
        $js = "";
        foreach($fileName as $fileDir) {
                    $_Sscript.= file_get_contents(APP_BASE_PATH . $fileDir);   
        }
        $js = JSMin::minify($_Sscript);     
        //Create the combined Js file
        $combinedJS=APP_BASE_PATH . "lib/script/combined".date("YmdHi").".js";
        file_put_contents($combinedJS, $js);
        return $combinedJS;
    }
    
    public function _getCapchaCodeURL($params){

     require_once 'lib/common/securimage/securimage.php';
       
        $object = new Securimage();
        $html = $object->getCaptchaHtml($params);
    
     return $html;
    }

    public function removeSpecialChar($value){
       $result  = preg_replace('/[^a-zA-Z0-9_ -]/s','',$value);
        return $result;
    }

    /*
    * @functionName    :   _mailApi()
    * @param           :   $maailid,$msg,$subject,$attachment,$from,$mailCcMulti
    ,$mailBccMulti,$fileName
    * @description     :   Function to send mail through API
    * @return          :   $response
    * @date            :   22.10.2019
    * @author          :   Muruganandham M
    */
    public function _mailApi($mailid,$msg,$subject,$attachment,$from,$mailCcMulti,$mailBccMulti,$fileName){

        $mailRequest = array();
        $files = array();
        $personalizations = array();
        /*Personalization*/
        $personalizations['recipient_bcc'] = $mailBccMulti;
        $personalizations['recipient_cc'] = $mailCcMulti;
        $mailRequest['personalizations'] = array($personalizations);
        foreach ($mailid as $key => $value) {
            $mailRequest['personalizations'][$key]['recipient'] = $value;
        }
        /*from Address*/
        $mailRequest['from']['fromName'] = "Balmer Lawrie";
        $mailRequest['from']['fromEmail'] = $from;
        /*subject*/
        $mailRequest['subject'] = $subject;
        /*content */
        $mailRequest['content'] = $msg;        
        /*settings */
        $mailRequest['settings']['footer'] = "1" ;
        $mailRequest['settings']['clicktrack'] = "1" ;
        $mailRequest['settings']['opentrack'] = "1" ;
        /*attachment */
        if($attachment != ''){
            if(gettype($attachment) == 'array'){
                $files['fileContent'] = base64_encode(file_get_contents($attachment[0]));
            }else{
                $files['fileContent'] = base64_encode(file_get_contents($attachment));
            }
            $files['fileName'] = $fileName;
            $mailRequest['attachments'] = array($files);
        }
        /*JSON encoded $_Request*/
        $_REQUEST = json_encode($mailRequest);
        filewrite("API_REQUEST: ".$_REQUEST,"mailAPILogs","a+");
        $response = $this->_curlRequest(API_URL, 'POST', $_REQUEST,'json');
        filewrite("API_Response: ".$response,"mailAPILogs","a+");
        return $response; 
    }
}
?>
