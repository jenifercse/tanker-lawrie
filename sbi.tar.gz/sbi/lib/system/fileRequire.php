<?php

require_once ("fileWrite.php");
function fileRequire($fileName)
{
	global $CFG;
	if(file_exists($CFG['path']['basePath'].$fileName)) 
	{
		require_once $CFG['path']['basePath'].$fileName;
		return true;
	}
	else
	{
		fileWrite($fileName,"RequireFileError","a+");
		return false;
	}
}
?>