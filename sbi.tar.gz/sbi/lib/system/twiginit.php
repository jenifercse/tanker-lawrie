<?php

function init($applicationPath = '') {

    ### assign default plugin name to variable
    $applicationPath = $applicationPath != '' ? $applicationPath : APPLICATION_BASE_PATH;

    ### get the secondary plugin name if exists
    $secondaryPluginName = constant('SECONDARY_PLUGIN_NAME');

    ### get multi-level override settings based on namespace
    $_AOverRideNameSpace   = include($applicationPath."config/overridePlugin.php");
    $_AoverRidePackageName = $_AOverRideNameSpace['OVERRIDE_PLUGIN_NS_ORDER'][OVERRIDE_PACKAGE_NAME];

    ### prepage failover file loading fro twig
    $twigFileLoaderArray = array();

    ### apply multi-level plugin override is exists
    if (is_array($_AoverRidePackageName) && count($_AoverRidePackageName) > 0) {
        foreach($_AoverRidePackageName as $key => $value) {
            $twigPath = $applicationPath.'view/'.PLUGIN_NAME . $value.'/twig';
            if(file_exists($twigPath)) {
                $twigFileLoaderArray[] = $twigPath;
            }
        }
    }

    ### below twig loading are for single level plugin override
    $twigFileLoaderArray[] = $applicationPath . 'view/' . PLUGIN_NAME . OVERRIDE_PACKAGE_NAME . '/twig';        ### overide package name ex. corporate/loreal/*
    $twigFileLoaderArray[] = $applicationPath . 'view/' . PLUGIN_NAME . DEFAULT_PACKAGE_NAME . '/twig';         ### default package name ex. corporate/harinim/*
    $twigFileLoaderArray[] = $applicationPath . 'view/' . PLUGIN_NAME;                                          ### main pluing name corporate/*
    $twigFileLoaderArray[] = $applicationPath . 'view/common/twig';                                             ### main twig folder view/common/twig/*
    ### condtion added to check is secondary plugin name exists for personal booking namespace
    if (isset($secondaryPluginName) && !empty($secondaryPluginName)) {
        $twigFileLoaderArray[] = $applicationPath . 'view/' . SECONDARY_PLUGIN_NAME . DEFAULT_PACKAGE_NAME . 'twig'; ### secondary plugin name view/persona/harinim/twig/*
    }
    $twigFileLoaderArray[] = $applicationPath . 'view/common/html';                                             ### html folder path view/common/html/*
    $twigFileLoaderArray[] = $applicationPath . 'designer';                                                     ### design folder for desing check designer/*
    ### autoload twig
    require_once $applicationPath . 'Twig/Autoloader.php';

    Twig_Autoloader::register(true);

    ### load build array to tiwg loader filesystem
    $loader = new Twig_Loader_Filesystem($twigFileLoaderArray);

    ### define core template directory
    $coreTemplateDir      = $applicationPath . 'view/common/twig/';
    $corporateTemplateDir = $applicationPath . 'view/corporate/harinim/twig/';
    $personalTemplateDir = $applicationPath . 'view/personal/harinim/twig/';

    ### define core template directory namespace for usage within over paths for easy usage
    $loader->addPath($coreTemplateDir, 'coreViewTwig');
    $loader->addPath($corporateTemplateDir, 'corporateViewTwig');
    $loader->addPath($personalTemplateDir, 'personalViewTwig');

    ### define the twi environemnt
    $twig = new Twig_Environment($loader, array(
        'cache' => $applicationPath . 'Twig/cache',
        'auto_reload' => true
    ));

    ### add necessary extensioins and functions
    $twig->addExtension(new Twig_Extension_Debug());
    $twig->addFilter('var_dump', new Twig_Filter_Function('var_dump'));
    $twig->addFilter('print_r', new Twig_Filter_Function('print_r'));

    ### call the twig custom functions
    require_once $applicationPath . 'Twig/userfunctions/customfunctions.php';

    ### return twig object
    return $twig;
}

?>