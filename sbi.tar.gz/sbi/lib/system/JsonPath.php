<?php

/* * *****************************************************************************
 * @class               JsonPath
 * @author      	Maliah Rajan M
 * @created date	2015-09-02
 * **************************************************************************** */
ini_set("display_errors", 0);
require_once("xmlToJson.php");
require_once("authToken.php");

class JsonPath{

    var $_AmoduleDetails;

    function __construct() {
        $this->_AmoduleDetails = array();
    }

    function _getModuleDetails($moduleName){
        
        $_OauthToken = new authToken();

        global $CFG;
        $CFG['path']['basePath'];
        $_Sfilename = $CFG['path']['basePath'] . 'lib/system/pathJson.json';
        if(file_exists($_Sfilename)){     
            $json = file_get_contents($_Sfilename);    
            $json = $_OauthToken->_purifyInputData($json);
            $pathDetails = json_decode($json);
            foreach ($pathDetails->path as $path){
                if(isset($path->$moduleName) && !empty($path->$moduleName)) {
                    $this->_AmoduleDetails['pathName'] = isset($path->$moduleName->moduleName_path) && !empty($path->$moduleName->moduleName_path) ? $path->$moduleName->moduleName_path : '';
                    $this->_AmoduleDetails['className'] = $path->$moduleName->moduleName_className;
                    $this->_AmoduleDetails['divName'] = $path->$moduleName->moduleName_divName;
                    $this->_AmoduleDetails['scriptFunction'] = isset($path->$moduleName->script_functionName) && !empty($path->$moduleName->script_functionName) ? $path->$moduleName->script_functionName : '';
                    $this->_AmoduleDetails['type'] = $path->$moduleName->type;
                    $this->_AmoduleDetails['pluginName'] = $path->$moduleName->pluginName;
                    fclose($pathFille);
                    return $this->_AmoduleDetails;
                }
            }
        } else {
            $xmlNode = simplexml_load_file($CFG['path']['basePath'] . 'lib/system/path.xml');

            fileWrite($xmlNode, "SqlError", "a+");
            $arrayData = xmlToArray($xmlNode);
            $pathXml = json_encode($arrayData);
            $createJson = fopen($_Sfilename, "wb");
            chmod($_Sfilename, 0777);
            $pathJson = fopen($_Sfilename, "w");
            fwrite($pathJson, $pathXml);
            fclose($pathJson);
            $this->_getModuleDetails($moduleName);
        }
    }

}

?>