<?php

/* * **********************************************************************
 * @Class Name      :   authToken.php
 * @Description     :   This file is used to create and maintain cross site scripting token
 * @Author          :   Taslim
 * @Created Date    :   28 November 2016
 * ************************************************************************ */
fileRequire("lib/system/portability.php");

class authToken {

    public function __construct() {

        ### check IP and Block ip in application side
        $this->_checkBlockedIP();
    }

    /*
     * @description     : check IP is blocked and sent 403
     * @params          :   
     * @returnType      :  
     */

    public function _checkBlockedIP() {
        
        ## insert entry to application log
        $_Odb   = new commonDBO();
        $userIP = trim($this->getUserIP());

        ### check if IP exists in blocked IP list
        //$result = $_Odb->_select('block_ip', 'block_id', 'ip_address', $userIP);
        $sql    = "SELECT * FROM block_ip WHERE status = 'Y' AND ip_address = '".$userIP."' ";
        $result = $_Odb->_getResult($sql);

        // if ($result && count($result) >0) {
        //     common::_setHeaderResponseCode(403);
        //     exit();
        // }
    }

    /*
     * @description     : insert request to applicaiton log
     * @params          :   mixed|$request
     * @returnType      :  
     */

    public function _insertApplicationRequestLog($request) {

        if ($request != '') {

            ## insert entry to application log
            $_Odb = new commonDBO();
        
            $appInsertArray = array();
            $appInsertArray['ip_address'] = $this->getUserIP();
            
            $appInsertArray['request_param'] = base64_encode(gzcompress(json_encode($request)));
            $request_log_id = $_Odb->_insert('user_request_log', $appInsertArray);
            return $request_log_id;
        }
    }


    public function _updateUserLoginCredentials($parameter){
        $_Odb = new commonDBO();
         if($parameter == '')
        {
            $updateSql = "UPDATE user_login_details SET login_time = NOW(), status = 'Y'  WHERE login_email ='" .$_SESSION['employeeEmailId']."'";
        }
        else if($parameter == 'browserUnLoad')
        {   
            $updateSql = "UPDATE user_login_details SET status = 'N' WHERE login_email ='" .$_SESSION['employeeEmailId']."'";
        }
        $updateId = $_Odb->_getResult($updateSql);
        return true;
    } 

    

    /*
     * @description     :  get the user IP address
     * @params          :   
     * @returnType      :   string|$ip
     */

    public function getUserIP() {

        //check ip from share internet
         //check ip from share internet
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        //to check ip is pass from proxy
        elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        } 
        return $ip;
    }

    /*
     * @description     :   To check if the xss token is valid
     * @params          :   
     * @returnType      :   boolean|$response
     */

    public function _validateRequestHeader() {

        $requestHeaders = apache_request_headers();

        $authHeaderArray = explode(" ", $requestHeaders['Authorization']);
        $xcssrfToken     = $authHeaderArray[1];

        $_AExistingTokenArray = array_column($_SESSION['xctaa'], 'token');

        if (in_array($xcssrfToken, $_AExistingTokenArray) || $_SESSION['loginType'] == 'SSO') {

            if ($_SESSION['loginType'] == 'SSO') {
                fileWrite('Token match -  since SSO Request' . $xcssrfToken, 'requestHeaders', 'a+');
            }

            //clear timedout csrf tokens
            $this->_clearExpiredToken();

            //set new token for next request
            $this->_setAuthToken();

            $response = true;
        } else {
            fileWrite('Unauthorized access received from IP:' . $remoteIP, 'UnauthorizedAccess', 'a+');
            fileWrite(print_r($_AExistingTokenArray, 1), 'UnauthorizedAccess', 'a+');
            fileWrite($xcssrfToken, 'UnauthorizedAccess', 'a+');
            $response = false;
        }

        return $response;
    }

    /*
     * @description     :   set authorization token to session
     * @params          :   
     * @returnType      :   string|$xcssrfToken
     */

    public function _setAuthToken() {

        //reset old token before setting new token
        $xcssrfToken = $this->_generateToken();

        //check if 
        if (is_array($_SESSION['xctaa'])) {
            $_SESSION['xctaa'][] = array('token' => $xcssrfToken, 'validity' => microtime(true));
        } else {
            $existingCSRF = $_SESSION['xctaa'];
            unset($_SESSION['xctaa']);
            $_SESSION['xctaa'][] = $existingCSRF;
            $_SESSION['xctaa'][] = array('token' => $xcssrfToken, 'validity' => microtime(true));
            ;
        }

        //store CSRF token in js file to access later
        common::_createCSRFFile($xcssrfToken);

        fileWrite(print_r($_SESSION['xctaa'], 1), 'generatedNewToken', 'a+');

        return $xcssrfToken;
    }

    /*
     * @description     :  clear valiated token from array
     * @params          :  string|$token
     * @returnType      :  
     */

    private function _clearValidatedToken($token) {

        if (isset($token) && !empty($token)) {
            $tokenArray = array_column($_SESSION['xctaa'], 'token');
            $key = array_search($token, $tokenArray);
            //unset($_SESSION['xctaa'][$key]);
        }
    }

    /*
     * @description     :  clear all exiting token from session array
     * @params          :  
     * @returnType      :  
     */

    public function _clearAllToken() {

        if (isset($_SESSION['xctaa']) && !empty($_SESSION['xctaa'])) {
            $finalToken = end($_SESSION['xctaa']);
            unset($_SESSION['xctaa']);
            $_SESSION['xctaa'][] = $finalToken;
        }
    }

    /*
     * @description     :  clear timed out token
     * @params          :  
     * @returnType      :  
     */

    private function _clearExpiredToken() {

        $currentTime = microtime(true);

        ###preserving last 5 csrf tokens since the user may be idle for long time 
        ### when user again does any action the last token should be in active status

        $lastCSRFTokens = array_slice($_SESSION['xctaa'], -5);

        foreach ($_SESSION['xctaa'] as $key => $val) {

            $diff = intval($currentTime - $val['validity']);
            fileWrite($diff, 'timeDiff', 'a+');
            ## token validity is more than 30 secs and not the last 2 tokens set then clear the tokens
            if ($diff > 180 && !in_array($_SESSION['xctaa'][$key], $lastCSRFTokens)) {
                unset($_SESSION['xctaa'][$key]);
            }
        }
    }

    /*
     * @description     :   generate XSCRF token logic
     * @params          :   
     * @returnType      :   string|$token
     */

    private function _generateToken() {

        $headerArray['alg'] = "HS256";
        $headerArray['typ'] = "CUS";

        $contentArray['currLogin'] = $_SESSION['employeeEmailId'];
        $contentArray['ts'] = time();

        $header  = json_encode($headerArray);
        $content = json_encode($contentArray);

        $key           = 'agencyAutoFrontEndApplicationSecurity';
        $unsignedToken = base64_encode($header) . base64_encode($content);

        $token = hash_hmac('sha256', $unsignedToken, $key);

        return $token;
    }

    /*
     * @description     :   function check and geneate autho token and return token
     * @params          :   
     * @returnType      :   string|$authToken
     */

    public function _getAuthToken() {

        if (isset($_SESSION['authToken']) && !empty($_SESSION['authToken'])) {
            $authToken = $_SESSION['authToken'];
        } else {
            $authToken = $this->_setAuthToken();
        }

        return $authToken;
    }

    /*
     * @Description check session is active
     * @param 
     * @return array|$returnValue
     */

    public function _checkSessionIsActive() {

        if (isset($_SESSION['userId']) && !empty($_SESSION['userId'])) {
            $returnValue = $this->_OResponse['session_state'] = true;
            
        } else {
            $returnValue = $this->_OResponse['session_state'] = false;
        }
        return $returnValue;
    }

    protected function _addResponseHeader($type = '') {

        ### add optimizaton header
        ob_clean();
        //ob_start('ob_gzhandler');

        ## json response header 
        if ($type == 'json') {
            //Content-Encoding: gzip
            header('Content-Type: application/json; charset=utf-8;');
        }

        ### add security header
        header('cache-control: no-cache="set-cookie"');
        header('X-Frame-Options: SAMEORIGIN');
        header("X-XSS-Protection: 1; mode=block");
        header('X-Content-Type-Options: nosniff');
        header("X-Content-Security-Policy: allow 'self'; options inline-script eval-script; frame-ancestors 'self'");
    }
    
    /*
    * @Description purify the input data
    * @param $untrustedHtml
    * @return array|$returnValue
    */
    public function _purifyInputData($untrustedHtml){
        
        //Basic setup without a cache
        $config = HTMLPurifier_Config::createDefault();
        $config->set('Core.Encoding', 'UTF-8'); 
        $config->set('HTML.Doctype', 'HTML 4.01 Transitional');       
        $config->set('HTML.Allowed', 'p,b,a[href],i'); 
        
        $sanitiser = new HTMLPurifier($config);
        return $sanitiser->purify($untrustedHtml);
    }
    
    /*
    * @Description purify the input data
    * @param $requestData
    * @return array|$inputData
    */
    public function _sanitiseInputData($_Arequest){        
        array_walk_recursive($_Arequest,function(&$value,$key){
            $value = $this->_purifyInputData($value);            
        });        
        return $_Arequest;
    }
    
    /*
    * @Description purify the input data
    * @param $untrustedHtml
    * @return array|$returnValue
    */
    static function _purifyData($untrustedHtml){
        //Basic setup without a cache
        $config = HTMLPurifier_Config::createDefault();
        $config->set('Core.Encoding', 'UTF-8'); 
        $config->set('HTML.Doctype', 'HTML 4.01 Transitional');       
        $config->set('HTML.Allowed', 'p,b,a[href],i'); 
        
        $sanitiser = new HTMLPurifier($config);
        return $sanitiser->purify($untrustedHtml);
    }
}