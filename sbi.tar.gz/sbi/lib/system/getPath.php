<?php
	function getPath($xmlName="path.xml")
	{
		global $CFG;
		fileRequire("lib/system/serializerConnect.php");
		
		$userFileName = $CFG['path']['basePath']."lib/script/system/".$xmlName;
		if(!($fp=@fopen($userFileName, "r")))
		{
			die ("Couldn't open XML.");				
		}
		$userData=array();
		$fileStore='';
		while( $userData = fread($fp, 4096))
		{
			$fileStore = $fileStore.$userData;
		}
		$unSerializer = new XML_Unserializer();
		$status = $unSerializer->unserialize($fileStore);
		
		if (PEAR::isError($status)) 
		{
		   die($status->getMessage());
		} 
		$userData = $unSerializer->getUnserializedData();
		return $userData;	
	}		
?>
