<?php
	chdir('../');
    require_once "authentication.php";

	//Require Files
	require_once "config/config.inc.php";
	require_once "lib/system/fileRequire.php";
	require_once "lib/system/pluginFileRequire.php";
	require_once "classes/class.commonDBO.php";
	require_once "classes/class.common.php";

	class BookingTracking
	{
		var $objDataBase;
		var $_Oconnection;
		var $markfields;
		var $marktagopen;
		var $marktagclose;
		
		function __construct()
		{	
			$this->objDataBase = dataBase::_createDBO();
			$this->_Oconnection = $objDataBase->_Oconnection;
		}

		function getEmployeeData(){
			$sqlData = " SELECT employee_id,employee_code,email_id,trip_approval_status,ticket_approval_status,band_name 
					FROM dm_employee dme INNER JOIN employee_details ed ON dme.employee_id = ed.r_employee_id
					INNER JOIN fact_employee fe ON fe.r_employee_id = dme.employee_id
					INNER JOIN sap_employee_dependent_details sedd ON sedd.r_employee_id = dme.employee_id
					INNER JOIN dm_band dmb ON dmb.band_id = ed.r_band_id
					WHERE fe.r_corporate_id = 2 ";
			$this->results = $this->objDataBase->_Oconnection->query($sqlData);
			return $this->results->fetchAll(PDO::FETCH_ASSOC);
		}

		function getApproverData($resData){
			foreach ($resData as $key => $value) {

				$resData[$key]['tripapprovalStatus'] = $resData[$key]['trip_approval_status'];
				$resData[$key]['tripApprover'] = '';
				$resData[$key]['ticketapprovalStatus'] = $resData[$key]['ticket_approval_status'];
				$resData[$key]['ticketApprover'] = '';
				$resData[$key]['guestticketApprover'] = '';
				$resData[$key]['noShowApprover'] = '';				


				$resData[$key]['tripApproverController'] = '';
				$resData[$key]['ticketApproverController']  = '';
				$resData[$key]['guesttcketApproverController'] = '';
				$resData[$key]['noShowController'] = '';

				
				$data = $this->sqlTrip($value['employee_id']);
				
				$dataTicket = $this->sqlTicket($value['employee_id']);
				
				$dataNoshow = $this->sqlNoshow($value['employee_id']);


				foreach ($data as $Imkey => $value) {

					if($value['validation_string'] == 1){
						if($value['approval_type'] == 'NA'){
							$resData[$key]['tripApprover'] = $this->sqlEmployeeCode($value['email_id'])[0]['code'];
						}
						if($value['approval_type'] == 'IA'){
							$resData[$key]['tripApproverController'] = $this->sqlEmployeeCode($value['email_id'])[0]['code'];
						} 
					}

					if($value['validation_string'] != 1){
						if($value['approval_type'] == 'NA'){
							$resData[$key]['guesttripApprover'] = $this->sqlEmployeeCode($value['email_id'])[0]['code'];
						}
						if($value['approval_type'] == 'IA'){
							$resData[$key]['guesttripApproverController'] = $this->sqlEmployeeCode($value['email_id'])[0]['code'];
						} 
					}
				}

				foreach ($dataNoshow as $Imkey => $value) {

					if($value['validation_string'] == 1){
						if($value['approval_type'] == 'NA'){
							$resData[$key]['noShowApprover'] = $this->sqlEmployeeCode($value['email_id'])[0]['code'];
						}
						if($value['approval_type'] == 'IA'){
							$resData[$key]['noShowController'] = $this->sqlEmployeeCode($value['email_id'])[0]['code'];
						} 
					}
				}

				foreach ($dataTicket as $Imtkey => $value) {

					if($value['validation_string'] == 1){
						if($value['approval_type'] == 'NA'){
							$resData[$key]['ticketApprover'] = $this->sqlEmployeeCode($value['email_id'])[0]['code'];
						}
						if($value['approval_type'] == 'IA'){
							$resData[$key]['ticketApproverController'] = $this->sqlEmployeeCode($value['email_id'])[0]['code'];
						} 
					}

					if($value['validation_string'] != 1){
						if($value['approval_type'] == 'NA'){
							$resData[$key]['guestticketApprover'] = $this->sqlEmployeeCode($value['email_id'])[0]['code'];
						}
						if($value['approval_type'] == 'IA'){
							$resData[$key]['guesttcketApproverController'] = $this->sqlEmployeeCode($value['email_id'])[0]['code'];
						} 
					}
				}
			}
			return $resData;
		}

		function sqlTrip($employeeId){
			$sqlTrip = "SELECT am.r_approval_settings_id,dms.r_travel_mode_id,dms.validation_string,am.approver_id,am.approval_type,dme.email_id
                FROM
                    dm_approval_settings dms
                    INNER JOIN approval_parameter_mapping apm ON apm.r_approval_settings_id = dms.approval_settings_id
                    INNER JOIN approval_mapping am ON  dms.approval_settings_id = am.r_approval_settings_id
                    INNER JOIN dm_employee dme ON am.approver_id = dme.employee_id
                    LEFT JOIN dm_aggregate da ON apm.parameter_id = da.aggregate_id AND apm.parameter_type = 'category'
                WHERE
                    dms.status = 'Y' AND dms.r_agency_id =1 AND dms.r_corporate_id = 2 AND
                    dms.process_type ='Booking' AND dms.r_travel_mode_id IN (7,3) AND IF(apm.parameter_type = 'employee',apm.parameter_id IN ('".$employeeId."'),'')";
            $this->results = $this->objDataBase->_Oconnection->query($sqlTrip);
			return $this->results->fetchAll(PDO::FETCH_ASSOC);
		}

		function sqlTicket($employeeId){
			$sqlTicket = "
					SELECT am.r_approval_settings_id,dms.r_travel_mode_id,dms.validation_string,am.approver_id,am.approval_type,dme.email_id
                FROM
                    dm_approval_settings dms
                    INNER JOIN approval_parameter_mapping apm ON apm.r_approval_settings_id = dms.approval_settings_id
                    INNER JOIN approval_mapping am ON  dms.approval_settings_id = am.r_approval_settings_id
                    INNER JOIN dm_employee dme ON am.approver_id = dme.employee_id
                    LEFT JOIN dm_aggregate da ON apm.parameter_id = da.aggregate_id AND apm.parameter_type = 'category'
                WHERE
                    dms.status = 'Y' AND dms.r_agency_id = 1 AND dms.r_corporate_id = 2
                    AND dms.process_type ='Booking' AND dms.r_travel_mode_id IN (1,7) AND IF(apm.parameter_type = 'employee',apm.parameter_id IN ('".$employeeId."'),'') ";
            $this->results = $this->objDataBase->_Oconnection->query($sqlTicket);
			return $this->results->fetchAll(PDO::FETCH_ASSOC);
		}
		

		function sqlNoshow($employeeId){
			$sqlTicket = "
					SELECT am.r_approval_settings_id,dms.r_travel_mode_id,dms.validation_string,am.approver_id,am.approval_type,dme.email_id
                FROM
                    dm_approval_settings dms
                    INNER JOIN approval_parameter_mapping apm ON apm.r_approval_settings_id = dms.approval_settings_id
                    INNER JOIN approval_mapping am ON  dms.approval_settings_id = am.r_approval_settings_id
                    INNER JOIN dm_employee dme ON am.approver_id = dme.employee_id
                    LEFT JOIN dm_aggregate da ON apm.parameter_id = da.aggregate_id AND apm.parameter_type = 'category'
                WHERE
                    dms.status = 'Y' AND dms.r_agency_id = 1 AND dms.r_corporate_id = 2
                    AND dms.process_type ='NoShowApprover' AND dms.r_travel_mode_id IN (1,7) AND IF(apm.parameter_type = 'employee',apm.parameter_id IN ('".$employeeId."'),'') ";
            $this->results = $this->objDataBase->_Oconnection->query($sqlTicket);
			return $this->results->fetchAll(PDO::FETCH_ASSOC);
		}

		function outputCsv($fileName, $assocDataArray)
		{
		    ob_clean();
		    header('Pragma: public');
		    header('Expires: 0');
		    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
		    header('Cache-Control: private', false);
		    header('Content-Type: text/csv');
		    header('Content-Disposition: attachment;filename=' . $fileName);    
		    if(isset($assocDataArray['0'])){
		        $fp = fopen('php://output', 'w');
		        fputcsv($fp, array_keys($assocDataArray['0']));
		        foreach($assocDataArray AS $values){
		            fputcsv($fp, $values);
		        }
		        fclose($fp);
		    }
		    ob_flush();
		}


		function sqlEmployeeCode($employeeId){
			$sqlEmployeeCode = "
					SELECT employee_code  as code
                FROM
                    dm_employee 
                WHERE
                   email_id = '".$employeeId."'";
            $this->results = $this->objDataBase->_Oconnection->query($sqlEmployeeCode);
			return $this->results->fetchAll(PDO::FETCH_ASSOC);
		}
	}

	$btObj = new BookingTracking();
	$resData = $btObj->getEmployeeData();
	$resDataAll = $btObj->getApproverData($resData);
	$btObj->outputCsv("IOCL.csv",$resDataAll);
?>
