<?php

require_once "../authentication.php";

//start the session.
session_start();

if($_REQUEST['action'] == 'Submit'){
    
    //validating csrf token with current session csrf token.
    if($_REQUEST['csrf-token-fdownload'] != $_SESSION['csrf_token']['fileDownload']) die("I'm sorry, you may not download that file.");

    //get the file name.
    $filename = $_REQUEST['filename'];

    $download_path = $_SERVER['DOCUMENT_ROOT'];

    if(eregi("\.\.", $filename)) die("I'm sorry, you may not download that file.");

    $file = str_replace("..", "", $filename);


    if(eregi("\.hta.+", $filename)) die("I'm sorry, you may not download  files with this extension.");

    $file = "$download_path$file";


    if(!file_exists($file)) die("I'm sorry, the file doesn't seem to exist.");

    $type = filetype($file);

    $today = date("F j, Y, g:i a");

    $time = time();

    header("Content-type: $type");

    header("Content-Disposition: attachment;filename=$filename");

    header("Content-Transfer-Encoding: binary");

    header('Pragma: no-cache');

    header('Expires: 0');

    set_time_limit(0);

    readfile($file);
    
    //destroy the session
    session_destroy();
    exit;
}
else{
    
    //generate the random token for forgot password.
    $fileDownloadCsrf = 'forgotPwd_'.rand();

    //set the token into the session
    $_SESSION['csrf_token']['fileDownload'] = $fileDownloadCsrf;
}
?>

<form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>"  >
    <input type = "hidden" name="csrf-token-fdownload" value="<?php echo $fileDownloadCsrf ?>" id="fileDownloadCSRF">
    Enter file name: <input type="text"  name="filename" value=""  >  
    <input type="submit" name="action" value="Submit">
</form>
