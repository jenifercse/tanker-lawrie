<?php

/*************************** WEBSEERVICE URL **********************/
$CFG['SERVICE_AGENCY_IDS'] = array('123' => 106);

//ser version code
define('VERSION_CODE','V5.0.1');

//agency id for service
if(isset($CFG['SERVICE_AGENCY_IDS'][$_SESSION['corporateId']]) && $CFG['SERVICE_AGENCY_IDS'][$_SESSION['corporateId']] != ''){
	define('SERVICE_AGENCY_ID',$CFG['SERVICE_AGENCY_IDS'][$_SESSION['corporateId']]);
}
else{
	define('SERVICE_AGENCY_ID',102);
}
/***     webservice url   ***/
//service auth and response key
define('SERVICE_AGENCY_AUTHKEY','ttApXaM3ky0g7VXFUSj7RccmRlWxmwfFOFTBDvsORjUO4FkMlrH1rJd8VXv5izBW4ilyDCajJSXBn5dxkIoBhpA0dTUlil5btgxUIx3hfPIqKJNVh1mnfKbgsVpA4kzlqW4XjX2oABFb8gUe64rbDqhVcwj4EJgSvaFDVyRmXklTp3XlXckotr9tLjnfQrXbprCbNilyswhFn5Qa70pofmHOtTR9aF9oUBpxJyV0S2v5Va3RYg52tDEKkmKkPHwz');

define('SERVICE_AGENCY_RESPONSEKEY','q1TrJu0K2C0d4lIiRTTd7Gv3mWPzHWaXNTcmd1V3tL7lUDsAm9DjFYbRIQeeAe1dV2oWT7QaGLjpeBPpAgy62xLzcODCQsECkQo1N2ZhB9wEy9TZffT6DsvD6Y5NgzdpfpgQg6YH3kbriSenYVjrcCU8qNJxdMKg0QV6KHDBPDRXlVb9FioHL6DZKdkLNUPDzyx951zLsgyDZxBuEN1dKv2kwbT7VyzkXWiQLHr3NOvCbUVDxMG75xfpyYnjlMs6');

//flight search and sap url
define('SERVICE_AGENCY_URL','https://test.service.balmerlawrie-sbt.com/webSearch2.2/webServiceSearch.php');
define('SERVICE_AGENCY_URL_2T','https://test.service.balmerlawrie-sbt.com/CommonWebServices1.0/index.php');
define('SERVICE_AGENCY_SAP_URL','https://test.service.balmerlawrie-sbt.com/CommonWebServices1.0/index.php');

//fare check Url
define('NAVIATARE_FARE_CHECK_URL','https://test.service.balmerlawrie-sbt.com/navitaireWebServices2.2/flightWebServices/services/serviceWrapper.php');
define('ABACUS_FARE_CHECK_URL','https://test.service.balmerlawrie-sbt.com/sabreWebServices2.2/flightWebServices/services/serviceWrapper.php');
define('ACE_FARE_CHECK_URL', 'https://test.service.balmerlawrie-sbt.com/aceWebServices2.0/flightWebServices/services/serviceWrapper.php');

//service name
define('WEB_SERVICE_CALL_METHOD', 'serviceWrapper');
define('CORPORATE_FARE_CHECK_METHOD_2T', 'BaseController._checkServiceDetails');

//fare check method
define('CORPORATE_FARE_CHECK_METHOD', 'serviceWrapper');

//GDS booking Service URL
define('WEB_SERVICE_GDS_BOOKING_PNR_URL', "http://preprodaws.atyourprice.net/AllWebServices2.0/sabreWebServices2.0/flightWebServices/services/serviceWrapper.php");

define('TRIP_EXPENSE_STATUS','EXPENSESTATUS_SAP_IOCL_RF_V1');
define('EMPLOYEE_STATUS','EMPLOYEEVALIDATE_SAP_IOCL_RF_V1');