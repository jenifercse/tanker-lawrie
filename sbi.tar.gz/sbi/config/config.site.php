<?php

/* * **************************************************************
 * @File				config.site.php
 * @Description  	For configure the site settings
 * @Author      		Balaji
 * @Created Date		24-Oct-2013
 * *************************************************************** */
if ((MENU_PROJECT_CODE == 0)) {
    $CFG['site']['site_name'] = 'Personal Booking';
    $CFG['site']['site_title'] = 'Personal Booking';
    $CFG['site']['key_words'] = 'Personal Booking';
    $CFG['site']['description'] = 'Personal Booking';
} else {
    $CFG['site']['site_name'] = SITE_NAME;
    $CFG['site']['site_title'] = SITE_NAME;
    $CFG['site']['key_words'] = SITE_NAME;
    $CFG['site']['description'] = SITE_NAME;
    $CFG['site']['fav_icon'] = FAV_ICON;
}
?>
