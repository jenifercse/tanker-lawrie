<?php
/************************************************************
* @File			config.database.php
* @Description  	Declaring the config common variables 
* @Author      		Kalaiselvi
* @Created Date		23-01-2012
*************************************************************/
//Database connection type
define('DB_TYPE', 'mysql');