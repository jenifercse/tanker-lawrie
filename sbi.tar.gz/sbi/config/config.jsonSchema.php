<?php
/**
 * @File Name   : config.jsonSchema.php
 * @Created on  : 2018-01-25
 * @Created By  : Karthika.M,Siva Prakash.M
 * @Description : This config used to declare the json schema with respect to the rmethod name.
 **/

//json schema for air cancellation fullfilment.
$CFG['airCancellationFullfilment'] = '{"type":"object","properties":{"cancellationInfo":{"type":"array","items":{"type":"object","properties":{"syncItineraryId":{"type":["string","integer"],"minLength":1},"syncPassengerId":{"type":["string","integer"],"minLength":1},"penalityAmount":{"type":["string","integer","number"],"minLength":1},"refundAmount":{"type":["string","integer","number"],"minLength":1}}}},"syncCancellationId":{"type":["string","integer"],"minLength":1},"syncCreditNoteId":{"type":["string","integer"],"minLength":1}}}';

//json schema for resend eticket.
$CFG['resendEticket'] = '{"type":"object","properties":{"orderId":{"type":"string","minLength":1},"reciepientEmail":{"type":"array","items":{"type":"string","minLength":1}}}}';

//json schema for cancellation request sync to backend,
$CFG['cancellationRequest'] = '{"type":"object","properties":{"cancellationId":{"type":["string","integer"],"minLenght":1},"cancelDate":{"type":"string","minLenght":1},"orderId":{"type":["string","integer"],"minLenght":1},"syncOrderId":{"type":["string","integer"],"minLenght":1},"cancelReason":{"type":"string","minLenght":1},"cancelRequestedEmail":{"type":"string","minLenght":1},"cancelInfo":{"type":"array","items":{"type":"object","properties":{"passengerId":{"type":["string","integer"],"minLenght":1},"syncPassengerId":{"type":"string","minLenght":1},"itineraryId":{"type":"string","minLength":1},"syncItineraryId":{"type":["string","integer"],"minLength":1},"tripType":{"type":["string","integer"],"minLength":1}}},"corporateId":{"type":["string","integer"],"minLength":1},"syncCorporateId":{"type":["string","integer"],"minLength":1}}}}';

//json schema for corporate GST details.
$CFG['corporateGSTDetails'] = '{"type":"object","properties":{"corporateId":{"type":["string","integer"],"minLength":1},"processType":{"type":"string","minLength":1},"processValue":{"type":"string","minLength":1},"gstInfo":{"type":"array","items":{"type":"object","properties":{"gstStateId":{"type":["string","integer"],"minLength":1},"gstNumber":{"type":["string","integer"],"minLength":1},"gstCompanyName":{"type":"string","minLength":1},"gstEmail":{"type":"string","minLength":1},"gstMobileNumber":{"type":["string","integer"],"minLength":1},"gstAddress":{"type":"string","minLength":1},"defaultGST":{"type":"string","minLength":1},"gstId":{"type":["string","integer"],"minLength":1}}}}}}';
?>