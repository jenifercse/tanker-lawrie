<?php
/* * **************************************************************************
 * @File            create Agency class file
 * @Description     This class file holds all agency related functionalities
 * @Author          Baskar
 * @Created Date    07/06/2016
 * @Tables used     dm_agency, agency_corporate_mapping
 * *************************************************************************** */
fileRequire("./lib/common/commonMethods.php");
class dynamicFormElementMethods
{
    public function __construct()
    {
        
        $this->_OcommonDBO=new commonDBO();
    }
/*****************************  *************************************************
 * @Method Name      : _insertFormContainerValues
 * @Description      : This method is used to container details from database
 * @Tables Affected  : form_container_mapping, dm_container
 * @Author           : Baskar V P
 * @Created Date     : 27/12/2016
 * @Modified Date    : 
 * ****************************************************************************/
    public function _setArrayValueForFunction(){
        $elementMappedValue = array("employeeData" => array( 
                                        'variableName' =>'employeeData',
                                        'Description'=>'Employee Code',
                                        'function_name' =>'getEmployeeCode',
                                        'value_text' =>'key_id',
                                        'display_text' =>'display_name'),
                                    "businessAreaData" => array( 
                                        'variableName' =>'businessAreaData',
                                        'Description'=>'Business Area - Loreal',
                                        'function_name' =>'getBusinessData',
                                        'value_text' =>'key_id',
                                        'display_text' =>'display_name'),
                                    "purposeOfTravel" => array( 
                                        'variableName' =>'purposeOfTravel',
                                        'Description'=>'Purpose Of Travel',
                                        'function_name' =>'getPurposeTravel',
                                        'value_text' =>'key_id',
                                        'display_text' =>'display_name'),
                                    
            );
        return $elementMappedValue;
    }
    
    
    public function _getVariable($var,$funcExe='N',$fieldId){

        $variables = $this->_setArrayValueForFunction();
        $required =$variables[$var];
        if($funcExe=== 'Y')
        {
            $result = $this->$required['function_name']($required['value_text'],$required['display_text'],$fieldId);
            $required['function_vals'] = $result;
        }
        return $required;
    }
    
    // to get business area data from master table
    public function getBusinessData($key,$values,$fieldId){
        $sql = "SELECT  cost_center_code as cost "
                . "FROM dm_cost_center_code "
                . "WHERE r_corporate_id = ".$_SESSION['corporateId']." and parent_id = 0 ";
        $result = $this->_OcommonDBO->_getResult($sql);
        foreach ($result as $keyValue => $displayValue) {
            $resultMappedvalue[$keyValue][$key] = $displayValue[cost];
            $resultMappedvalue[$keyValue][$values] = $displayValue[cost]; 
        }
        return $resultMappedvalue;
    }
    
  // to get purpose of travel from master table 
    public function getPurposeTravel($key,$values,$fieldId){
        $sql = "SELECT  purpose_text as purpose "
                . " FROM purpose_of_travel "
                . " WHERE r_corporate_id =".$_SESSION['corporateId'];
        $result = $this->_OcommonDBO->_getResult($sql);
        foreach ($result as $keyValue => $displayValue) {
            $resultMappedvalue[$keyValue][$key] = $displayValue[purpose];
            $resultMappedvalue[$keyValue][$values] = $displayValue[purpose]; 
        }
        return $resultMappedvalue;
    }

    //function for dynamic field value
    public function getDynamicFunctionData($data){
         $sql = "SELECT  cost_center_code as cost "
                . "FROM dm_cost_center_code "
                . "WHERE r_corporate_id = ".$_SESSION['corporateId']." and parent_id =".$this->getParentId($data);
        $result = $this->_OcommonDBO->_getResult($sql);
        foreach ($result as $keyValue => $displayValue) {
            $resultMappedvalue[$keyValue]['key_id'] = $displayValue[cost];
            $resultMappedvalue[$keyValue]['display_name'] = $displayValue[cost]; 
        }
        return $resultMappedvalue;
    }

    // to get parent id for the cost center code
    public function getParentId($param) {
        $costCenterCode = $param['id'];
        $sql = "SELECT  cost_center_code_id as id "
                . "FROM dm_cost_center_code "
                . "WHERE r_corporate_id = ".$_SESSION['corporateId']." and cost_center_code = '".$costCenterCode."'";
        $result = $this->_OcommonDBO->_getResult($sql)[0];
        return $result['id'];
    }
    
    
    
}
?>
