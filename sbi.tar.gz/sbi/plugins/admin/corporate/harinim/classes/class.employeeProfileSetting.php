<?php
class employeeProfileSetting {
    
    public function __construct() {
        $this->db = new commonDBO();
    }
    
     /*
     * @Description get employee fields for corporate and agency
     * @param int|$agencyId
     * @param int|$corporateId
     * @return mixed|$result
     */
    public function _getEmployeeFields($sessionId) {
        
        $result = false;
        
        if((!empty($sessionId['agencyId']) && !empty($sessionId['corporateId']))) {
            
            $sql = "SELECT de.emp_fields_id, de.field_type, de.field_label, de.type,fe.fact_employee_fields_id, fe.r_emp_fields_id, fe.validation_type, fe.mandatory, efc.category_name FROM dm_employee_fields de
                    LEFT JOIN fact_employee_fields fe ON de.emp_fields_id = fe.r_emp_fields_id AND (fe.r_corporate_id = ".$sessionId['corporateId']." OR fe.r_corporate_id = 0 OR ISNULL(fe.r_corporate_id)) 
                    AND (fe.r_agency_id = ".$sessionId['agencyId']." OR fe.r_agency_id = 0 OR ISNULL(fe.r_agency_id ))
                    INNER JOIN dm_employee_fields_category efc ON de.category = efc.emp_fields_category_id
                    WHERE de.status = 'Y' ORDER BY efc.sorting, de.emp_fields_id";
            $result = $this->db->_getResult($sql);
            
        }
        
        return $result;
        
    }
    
     /*
     * @Description check fact_employee_fields table and insert in data not exist other remove data
     * @param int|$fieldId
     * @param int|$agencyId
     * @param int|$corporateId
     * @param int|$groupId
     * @param int|$validationType
     * @param string|$mandatory
     * @return mixed|$result
     */
    public function _checkFactEmployeeValueExistAndUpdate($fieldId, $agencyId, $corporateId, $groupId = 0, $validationType = 0, $mandatory = 'N') {
        
        $result = array(status => 1, 'result' => false);
        
        $sql = "SELECT * FROM fact_employee_fields WHERE r_emp_fields_id = ".$fieldId."";
        $result = $this->db->_getResult($sql);
        
        if(isset($result[0]['r_emp_fields_id']) && !empty($result[0]['r_emp_fields_id'])) {
            //value already exists remove the value from db and update deletiion
            $this->_removeFactEmployeeData($fieldId);
            $response = array('status_code' => 2, 'error_alert' => 'values removed successfully');
        } else {
            //value does not exist add new value
            $this->_addFactEmployeeData($fieldId, $agencyId, $corporateId, $groupId, $validationType, $mandatory);
            $response = array('status_code' => 2, 'error_alert' => 'values added successfully');
        }
        
        return $response;
    }
    
     /*
     * @Description remove data from fact_employee_fields table
     * @param int|$fieldId
     * @param int|$agencyId
     * @return mixed|$result
     */
    public function _removeFactEmployeeData($fieldId) {
        
        $result = false;
        
        if($fieldId !='') {
            $result = $this->db->_delete('fact_employee_fields', 'r_emp_fields_id', $fieldId);
        }
        return $result;
        
    }
    
     /*
     * @Description add data to fact_employee_fields table
     * @param int|$fieldId
     * @return mixed|$result
     */
    public function _addFactEmployeeData($fieldId, $agencyId, $corporateId, $groupIds = array(), $validationType = 0, $mandatory = 'N') {
        
        $result = false;
                $insertArray = array();
                $insertArray['r_emp_fields_id'] = $fieldId;
                $insertArray['r_corporate_id']  = $corporateId;
                $insertArray['r_agency_id']     = $agencyId;
                $insertArray['deleted']         = 'N';
                $insertArray['validation_type'] = $validationType;
                $insertArray['mandatory']       = $mandatory;
                $insertArray['created_date']    = date('Y-m-d H:i:s');        
        if($fieldId !='') {
            if(is_array($groupIds)){
            foreach ($groupIds as $key => $groupId) {
                $insertArray['r_group_id']      = $groupId;
                $result = $this->db->_insert('fact_employee_fields', $insertArray);
                unset($insertArray['r_group_id']);
            }
            }
            else{                
                $insertArray['r_group_id']      = $groupId;
                $result = $this->db->_insert('fact_employee_fields', $insertArray);
            }
        }
        
        return $result;
    }
    
     /*
     * @Description get employee field values
     * @param int|$fieldId
     * @return mixed|$result
     */
    public function _getEmployeeFieldValues($fieldId) {
        
        $result = false;
        
        if($fieldId !='') {
            $sql = "SELECT * FROM employee_field_values WHERe r_emp_field_id = ".$fieldId."";
            $result = $this->db->_getResult($sql);
        }
        
        return $result;
    }
    
     /*
     * @Description get employee field validation values
     * @param int|$validationId
     * @return mixed|$result
     */
    public function _getEmployeeFieldValidation($validationId) {
        
        $result = false;

        if($validationId !='') {
            $sql = "SELECT validation_type, validation_func FROM dm_employee_field_validation WHERE emp_field_validation = ".$validationId."";
            $result = $this->db->_getResult($sql);
        }
        
        return $result;
    }
    
    /*
     * @Description get employee field validation values
     * @param int|$agencyId
     * @param int|$corporateId
     * @return mixed|$result
     */
    public function _getEmployeeFieldsElements($agencyId, $corporateId) {

        $employeeFields = $this->_getEmployeeFields($agencyId, $corporateId);
        
        foreach($employeeFields as $res) {
            
        }
    }
    
    public function _getFieldTypeElement($fieldType = 1, $fieldUniqueId, $fieldLabel, $validationFunc='', $viewType = 'preview') {
        
        if($validationFunc !='') {
            $htmlFunc = ' onlick="'.$validationFunc.'" ';
        }
        
        
        switch($fieldType) {
            
            case 1: // text field

                $html .= $fieldLabel;
                $html .= '<input type="text" name="'.$fieldUniqueId.'" id="'.$fieldUniqueId.'" value="" "'.$htmlFunc.'" />';
                
                break;
            
            case 2: //checkbox
                $html .= $fieldLabel;
                $html .= '<input type="checkbox" name="'.$fieldUniqueId.'" id="'.$fieldUniqueId.'" />';
                break;
            
            case 3: //radio
                
                break;
            
            case 4: //combo
                
                break;
            
            default:
        }
        
        return $html;
    }
    
    public function _getCategoryList() {
        
        $result = false;
        
        $sql    = "SELECT * FROM dm_employee_fields_category WHERE status='Y'";
        $result = $this->db->_getResult($sql);
        
        return $result;
    }
    
    /**
     * Gets all avaliable field types
     * 
     * @return array
     */
    public function _getFieldTypes() {
        
        $result = false;
        
        $sql    = "SELECT * FROM dm_field_type";
        $result = $this->db->_getResult($sql);
        
        return $result;
    }
    
    /**
     * Gets validation types for a field
     * 
     * @return array
     */
    public function _getValidationTypes() {
        
        $result = false;
        
        $sql    = "SELECT * FROM dm_employee_field_validation";
        $result = $this->db->_getResult($sql);
        
        return $result;
    }
    
    /**
     * Gets all user types
     * 
     * @return array
     */
    public function _getUserTypes() {
        
        $result = false;
        
        $sql    = "SELECT * FROM  dm_user_type";
        $result = $this->db->_getResult($sql);
        
        return $result;
    }
    
    /**
     * Inserts employee fields record
     * 
     * @param string $fieldLabel Field name
     * @param int $fieldType Type of a field like radio, select, text,etc.,
     * @param int $category Field category
     * @return array
     */
    public function _insertEmployeeFields($fieldLabel, $fieldType, $category) {
        
        $result = false;
        
        $insertArray = array();
        $insertArray['field_label'] = $fieldLabel;
        $insertArray['field_type']  = $fieldType;
        $insertArray['category']    = $category;
        $insertArray['type']        = '2';
        $insertArray['status']      = 'Y';
        $insertArray['created_date']= date('Y-m-d H:i:s');

        $result = $this->db->_insert('dm_employee_fields', $insertArray);
        
        return $result;
    }
    public function _getFieldData($fieldIdArray) {
        
        $fieldQuery = "SELECT fef.mandatory, fef.validation_type, fef.r_emp_fields_id, def.emp_fields_id, def.field_label, def.type,def.field_type, def.category, fef.r_group_id
                       FROM  fact_employee_fields fef
                       INNER JOIN dm_employee_fields def ON fef.r_emp_fields_id = def.emp_fields_id AND def.status ='Y'
                       INNER JOIN dm_employee_fields_category defc ON def.category = defc.emp_fields_category_id AND defc.status ='Y'
                       WHERE fef.r_group_id = '".$fieldIdArray['groupId']."' AND fef.r_corporate_id = '".$fieldIdArray['corporateId']."'
                       AND fef.r_agency_id = '".$fieldIdArray['agencyId']."' AND fef.r_emp_fields_id = '".$fieldIdArray['fieldId']."' ";
        $result = $this->db->_getResult($fieldQuery);
        return $result[0] ? $result[0] : FALSE;
    }
    public function _deleteFieldData($deleteArray) {
        
        $deleteField = "DELETE FROM fact_employee_fields WHERE r_emp_fields_id = '".$deleteArray['fieldId']."' AND
                        r_corporate_id = '".$deleteArray['corporateId']."' AND r_agency_id = '".$deleteArray['agencyId']."' ";
        $result = $this->db->_getResult($deleteField);
        return $result ? $result : FALSE;
    }
}
?>