<?php
/* * **************************************************************************
 * @File             : class.headerApproval.php
 * @Description      : This file is used to insert,select,update the header approval details in tables
 * @Author           : 
 * @Created Date     : 25/02/2017
 * ****************************************************************************/
//fileRequire('classes/class.commonDBO.php');
class headerApproval{  
  
    
    public function __construct() {
       $this->db = new commonDBO();  
    }    
   
    //this function is use to get the approval setting name 
   public function _getApprovalSettingName($input=''){
       
       $sql = 'SELECT
                dpas.approval_settings_id,dpas.approval_settings_name
               FROM
                dm_profile_approval_settings dpas
               WHERE 1';
       
        if(isset($input['r_agency_id']) && $input['r_agency_id']!=0){ 
            $sql .= ' AND dpas.r_agency_id ='.$input['r_agency_id'];
        }
        if(isset($input['r_corporate_id']) && $input['r_corporate_id']!=0)
        { 
            $sql .= ' AND dpas.r_corporate_id='.$input['r_corporate_id'];
        }
        
        $data = $this->db->_getResult($sql);
        
        return $data;
   }
   
   //this function is use to get the data for "dm_profile_approval_settings" table
   public function _getProfileHeaderSettingDetails($input='') {
       
       $sql = 'SELECT * FROM dm_profile_approval_settings WHERE 1 ';
       
       if(isset($input['r_agency_id']) && $input['r_agency_id']!=0){ 
            $sql .= ' AND r_agency_id ='.$input['r_agency_id'];
        }
        if(isset($input['r_corporate_id']) && $input['r_corporate_id']!=0)
        { 
            $sql .= ' AND r_corporate_id='.$input['r_corporate_id'];
        }
        if(isset($input['processType'])!= '')
        { 
            $sql .= ' AND process_type='. "'" . $input['processType'] . "'";
        }
        if(isset($input['approval_settings_name']) && $input['approval_settings_name']!=0)
        { 
            $sql .= ' AND approval_settings_id='.$input['approval_settings_name'];
        }
        if(isset($input['approval_setting_name']) != '')
        { 
            $sql .= ' AND approval_settings_name ='."'".$input['approval_setting_name']."'";
        }
        $data = $this->db->_getResult($sql,'',1);
        
        return $data;
   }
   
   //this function is use to insert "dm_profile_approval_settings"," profile_approval_mapping"," profile_approval_parameter_mapping" tables
   public function _insertProfileHeaderSettings($input,$selectedCriteria,$headerValue) {
       
       $valueInput['travel_mode'] = $input['r_travel_mode_id'] = $input['travel_mode']; 
       unset($input['travel_mode']);
       $insertId = $this->db->_insert('dm_profile_approval_settings',$input);
       $processParameter = array();
        if($input['process_type']== 'Booking'){
            
            $processParameter['parameter_id'] = 1;
            
        }
        else{
            
            $processParameter['parameter_id'] = 2;
        }
        //Array to insert processtype parameter mapping
        $processParameter['r_approval_settings_id']= $insertId;
        $processParameter['r_operator_id']=1;
        $processParameter['parameter_type']='processtype';
        $processParameter['parameter_value'] = $input['process_type'];
        //Function call to insert approval parameter mapping with processtype parameter
        $resultApprovalMappingId  = $this->db->_insert('profile_approval_parameter_mapping', $processParameter);
        
        //Array to insert travel mode parameter mapping
        $travelParameter = array();
        $travelParameter['r_approval_settings_id']= $insertId;
        $travelParameter['parameter_id'] = $valueInput['travel_mode'];
        $travelParameter['r_operator_id']=1;
        $travelParameter['parameter_type']='travelmode';
        //$travelParameter['created_date']=date("Y-m-d");
        $travelParameter['parameter_value']=$valueInput['travel_mode'];
        //Function call to insert approval parameter mapping with travelmode parameter
        $resultApprovalMappingId  = $this->db->_insert('profile_approval_parameter_mapping', $travelParameter);
        
       foreach($selectedCriteria as $key => $selectArr){
            $selectArr['r_approval_settings_id'] = $insertId;
            if($key==0){
                $cols = implode(",",array_keys($selectArr));
            }
            $vals .= $comma."('".implode("','",array_values($selectArr))."')";
            $comma = ',';
        }
        
        $sql = "INSERT INTO profile_approval_parameter_mapping (".$cols.") VALUES ".$vals;
        $criteriaInsertId = $this->db->_executeQuery($sql);
        
        //Find highest level approver
        $appVal = array_column($headerValue, "approval_level");
        $maxLevel = max($appVal);
        
        foreach ($headerValue as $key => $value) {
            $headerValueInput['r_approval_settings_id'] = $insertId;
            $headerValueInput['header_name'] = $value['header_name'];
            $headerValueInput['approval_level'] = $value['approval_level'];
            $headerValueInput['approval_order'] = $value['approval_order'];
            $headerValueInput['approval_type'] = $value['approval_type'];
            if($maxLevel>$value['approval_level']){
                $headerValueInput['next_level_status'] = 'Y';
            } else {
                $headerValueInput['next_level_status'] = 'N';
            }
            $this->db->_insert('profile_approval_mapping',$headerValueInput);
        }
        return $insertId ;
   }
   
    public function _getProfileHeaderSettingsInfo($approvalSettingsId = ''){      
            $sql = "SELECT
                         dpas.approval_settings_id,
                         dpas.approval_settings_name, dpas.r_agency_id, dpas.r_corporate_id,dpas.process_type,dpas.priority,
                         papm.parameter_id, papm.r_operator_id,papm.parameter_value, papm.parameter_type
                    FROM
                         dm_profile_approval_settings dpas
                         INNER JOIN profile_approval_parameter_mapping papm ON dpas.approval_settings_id = papm.r_approval_settings_id 
                    WHERE 1=1";
            if($approvalSettingsId != '')
            {
                $sql .= " AND dpas.approval_settings_id = ".$approvalSettingsId;
            }
            
            $result = $this->db->_getResult($sql); 
            return $result;
    }
    
    public function _getHeaderInfo($approvalSettingsId) {
        
        $sql = "SELECT
                     pam.approval_mapping_id,pam.header_name,pam.approval_level,pam.approval_order,pam.approval_type
                FROM profile_approval_mapping pam
                WHERE 
                     pam.r_approval_settings_id = ".$approvalSettingsId;
       
       if($approverType != '')
       {
           $sql = $sql."  AND pam.approval_type = '".$approverType."'";
       }
       
        $result = $this->db->_getResult($sql); 
        return $result;
    }
    
    public function _updateProfileHeaderSettings($updateArr,$selectedCriteria,$updateheaderValue,$approvalSettingsId) {
        
        $updateId = $this->db->_update('dm_profile_approval_settings',$updateArr,'approval_settings_id',$approvalSettingsId);
        $sql = "DELETE FROM profile_approval_parameter_mapping WHERE r_approval_settings_id = ".$approvalSettingsId ." AND parameter_type = "."'".$selectedCriteria[0]['parameter_type']."'";
        $criteriaDeleteId = $this->db->_executeQuery($sql); 
        foreach($selectedCriteria as $key => $selectArr){
            $selectArr['r_approval_settings_id'] = $approvalSettingsId;
            if($key==0){
                $cols = implode(",",array_keys($selectArr));
            }
            $vals .= $comma."('".implode("','",array_values($selectArr))."')";
            $comma = ',';
        }
        
        $sql = "INSERT INTO profile_approval_parameter_mapping (".$cols.") VALUES ".$vals;
        $updateId = $this->db->_executeQuery($sql);
        $this->db->_delete('profile_approval_mapping','r_approval_settings_id',$approvalSettingsId);
        
        //Find highest level approver
        $appVal = array_column($updateheaderValue, "approval_level");
        $maxLevel = max($appVal);
        
        foreach ($updateheaderValue as $key => $value) {
            $headerValueInput['r_approval_settings_id'] = $approvalSettingsId;
            $headerValueInput['header_name'] = $value['header_name'];
            $headerValueInput['approval_level'] = $value['approval_level'];
            $headerValueInput['approval_order'] = $value['approval_order'];
            $headerValueInput['approval_type'] = $value['approval_type'];
            if($maxLevel>$value['approval_level']){
                $headerValueInput['next_level_status'] = 'Y';
            } else {
                $headerValueInput['next_level_status'] = 'N';
            }
            $updateId = $this->db->_insert('profile_approval_mapping',$headerValueInput);
        }
        return $updateId;
        
    }
}
?>