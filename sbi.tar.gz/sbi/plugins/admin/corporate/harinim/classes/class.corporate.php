<?php
/****************************************************************************
 * @File            corporate
 * @Description     This class file holds all corporate plane related functionalities
 * @Author          Taslim
 * @Created Date    08/06/2016
 * @Tables used     dm_corporate, corporate_fee_master
 *****************************************************************************/
require_once 'classes/class.common.php';

class corporate{

    public function __construct(){
        $this->db = new commonDBO();
        $this->_Ocommon = new common();
    }

   /*
    * @functionName    :   _getCorporateInformation()
    * @description     :   method to get details of one or more corporates
    */
    public function _getCorporateInformation(){

        $sql = "SELECT 
                        dc.corporate_id,
                        dc.corporate_name,
                        cd.address,
                        cd.r_city_id,
                        dcm.city_name,
                        cd.zipcode,
                        cd.contact_number,
                        cd.employee_count,
                        cd.website,
                        cd.annual_travel_spend,
                        cd.comments,
                        dc.admin_account_id,
                        dc.status
                FROM
                        dm_corporate dc INNER JOIN corporate_details cd 
                        ON dc.corporate_id = cd.r_corporate_id INNER JOIN dm_city dcm ON dcm.city_id = cd.r_city_id WHERE 1 AND ";

        if (isset($this->_IcorporateId)){
            $sql .= " dc.corporate_id =  $this->_IcorporateId AND ";
        }
        if (isset($this->_Sstatus)){
            $sql .= " dc.status = '" . $this->_Sstatus . "' AND ";
        }
        $sql = substr($sql, 0, -4);
        return $this->db->_getResult($sql);
    }

   /*
    * @Description  function handles fee mapping request from agency auto backend thorugh API
    * @param 
    * @return 
    */
    public function _handleFeeMappingRequest(){

        if($this->_Arequest['method'] == 'registeragency' && $this->_validatBackEndCorporateId()){
            unset($this->_Arequest['method']);
            unset($this->_Arequest['corporateid']);
            $this->_Arequest['r_corporate_id'] = $this->_IcorporateId;
            $this->_corporateFeeMapping();
        }else{
            $this->_Sresult = 'Invalid method called';
            $this->_Istatus = 0;
        }
    }

    /*
    * @Description  function handles fee mapping response to agency auto backend thorugh API
    * @param 
    * @return 
    */
    public function _handleFeeMappingResponse(){
        $result = array('status' => $this->_Istatus, 'result' => $this->_Sresult);
        $result = json_encode($result);
        $this->_Jresult = $result;
    }

    /*
    * @Description  function handles insertion of values to corpoarete_fee_master table
    * @param 
    * @return 
    */
    public function _corporateFeeMapping(){
        //corporateid
        $tablename = 'corporate_fee_master';
        $insertValues = $this->_Arequest;
        $this->_IcorporateFeeId = $this->db->_insert($tablename, $insertValues);
        if($this->_IcorporateFeeId > 0){
            $this->_Sresult = 'Values inserted successfully';
            $this->_Istatus = 1;
        }else{
            $this->_Sresult = 'Values insertion  unsuccessfull';
            $this->_Istatus = 0;
        }
    }

   /*
    * @Description  function validated the backend corporate id is existing in dm_corporate table and return values
    * @param 
    * @return boolean|$returnValue
    */
    public function _validatBackEndCorporateId(){
        $backendCorporateId = $this->_Arequest['corporateid'];
        $fieldsArray = array('corporate_id');
        $wherekey = 'corporate_uid';
        $wherevalue = $backendCorporateId;
        $corporateresult = $this->db->_select('dm_corporate', $fieldsArray, $wherekey, $wherevalue);
        if($corporateresult){
            $returnValue = true;
            $this->_IcorporateId = $corporateresult[0]['corporate_id'];
        }else{
            $returnValue = false;
            $this->_Sresult = 'corporate ID not exists';
            $this->_Istatus = 0;
        }
        return $returnValue;
    }

   /*
    * @Description get uploaded logo details for the corporate
    * @param int|$corporateId
    * @return boolean|$returnValue
    */
    public function _getUploadedLogo($corporateId){

        $returnValue = false;
        if($corporateId > 0){
            $sql = "SELECT dm_corporate_logo_id, image_path FROM dm_corporate_logo WHERE r_corporate_id = " . $corporateId . " AND `status` = 'Y'";
            $result = $this->db->_getResult($sql);
            $this->_corporateLogo = $result[0]['image_path'];
            $this->_corpoirateLogId = $result[0]['dm_corporate_logo_id'];
            $returnValue = true;
        }
        return $returnValue;
    }

   /*
    * @Description get name of the corporate
    * @param int|$corporateId
    * @return string|$returnValue
    */
    public function _getCorporateName($corporateId){
        
        $returnValue = '';
        if(!empty($corporateId)){
            $result = $this->db->_select('dm_corporate', array('corporate_name'), 'corporate_id', $corporateId);
            $returnValue = $result[0]['corporate_name'];
        }
        return $returnValue;
    }

   /*
    * @Description function used to check the corporate whether exist or not.
    * @param string|$corporateName
    * @return array|$returnValue
    */
    public function _checkCorporateExists($corporateName){
        return $this->db->_select('dm_corporate', array('corporate_id', 'corporate_name'), 'corporate_name', $corporateName);        
    }

   /*
    * @Description function used to insert the corpoate details
    * @param array|$corporateDetailsArray
    * @return int|$corporateId
    */
    public function _insertCorporate($corporateDetailsArray){
        
        //set company name
        $corporateDetailsArray['company_name'] = trim($corporateDetailsArray['company_name']);
        
        //insert into dm_corporate
        $insert = array();
        
        //checking the corporate already exist or not.
        $corporateExistArray = $this->_checkCorporateExists($corporateDetailsArray['company_name']);
        
        if(!isset($corporateExistArray[0]['corporate_id'])){
            
            $insert['corporate_name'] = $corporateDetailsArray['company_name'];
            $insert['created_by'] = 0;
            $insert['approved_by'] = 0;
            $insert['status'] = 'Y';
            
            //set the embedded link flag.            
            if($corporateDetailsArray['embeddedLink'] == 'Y' || $corporateDetailsArray['embeddedCorporateAdminLink'] == 'Y'){
                $insert['embedded_link'] = 'Y';
            }
            
            //set the booking type enabled for the corporate.
            if($corporateDetailsArray['bookingType'] == 'Corporate'){
                $insert['corporate_booking_enable'] = 'Y';
            }
            else{
                $insert['personal_booking_enable'] = 'Y';
            }
            
            //optional
            $insert['approved_date'] = $insert['created_date'] = date('Y-m-d H:i:s');
            
            //insert the corporate info
            $corporateId = $this->db->_insert('dm_corporate', $insert);
        } 
        else{
            $corporateId = false;
        }
        return $corporateId;
    }
    

    /*
    * @Description function used to insert the booking link details
    * @param array|$corporateDetailsArray
    * @return array|$embeddedLinkArray
    */
    public function _insertEmbeddedLink($corporateDetailsArray,$corporateId,$userType){
        
        //insert into dm_booking_link
        $insert = array();
        $booking_link = array();
        $updateArray = array();
       
        //to check the link exists
        $employeeExistArray = $this->_checkEmployeeLinkExists($corporateDetailsArray['admin_emailid'],$userType);

        if(!$employeeExistArray){            
            //form array
            $insert['r_corporate_id'] =  $corporateId;
            $insert['reference_type'] ='employee_id';
            $insert['reference_id'] = $this->db->_select("dm_employee","employee_id","email_id",$corporateDetailsArray['admin_emailid'])[0]['employee_id'];
            $insert['booking_link'] = '';
            $insert['process_type'] = 'B';
            $insert['link_type'] =  $userType;
            $insert['status'] = 'Y';
            $insert['created_by'] = $this->_getCorporateAdminAccountId($corporateDetailsArray['created_by'],$corporateId,$corporateDetailsArray)['employee_id'];
            $insert['created_date'] = date('Y-m-d H:i:s');
            $insert['updated_date'] = "0000-00-00 00:00:00";
            //insert the booking link info
            $bookingLinkId = $this->db->_insert('dm_booking_link', $insert);

             //Details Assign
             $booking_link['data'] = 'B:'.$bookingLinkId;

            //encode the values
             $jsonDetails = json_encode($booking_link);

             //encryption
             $encodedBookingLink = strtr(base64_encode(gzdeflate($jsonDetails)),'+/', '-_');

             //form the booking link.
            $encodedBookingLink = HTTP_TYPE.HTTP_HOST.'/'.PROJECT_BASE_URL."/controller/ssoLogInRedirect.php?data=".$encodedBookingLink;

             //update Embedded Link in dm_booking_link table
             $updateArray['booking_link'] = $encodedBookingLink;
             $result = $this->db->_update('dm_booking_link',$updateArray,'booking_link_id', $bookingLinkId );
             
        }
        else{           
            $this->_updateEmbeddedLink($corporateDetailsArray,$userType);
        }
        return $encodedBookingLink;
    }

    public function _checkEmployeeLinkExists($emailId,$userType){
        
        //get employee id
        $employeeId = $this->db->_select("dm_employee","employee_id","email_id",$emailId)[0]['employee_id'];

        $sql = "SELECT * FROM dm_booking_link WHERE reference_type = 'employee_id' AND reference_id = ".$employeeId." AND link_type = '".$userType."'";
        return $this->db->_getResult($sql);
    }

    /*
    * @Description function used to update dm_booking_link (status and date)
    * @param  array| $corporateDetails
    * @return --
    */
    public function _updateEmbeddedLink($corporateDetails,$userType){
        
        //get the employee info
        $empId  = $this->db->_select("dm_employee","employee_id","email_id",$corporateDetails['admin_emailid'])[0]['employee_id'];

        if($userType == 4){
            $status = $corporateDetails['embeddedLink'];
        }
        else{
            $status = $corporateDetails['embeddedCorporateAdminLink'];
        }
        
        return $this->_changeBookingLinkStatus('employee_id',$empId,$userType,$status);
    }

    /*
    * @Description function used to insert the corpoate details
    * @param int,array|$corporateId,$corporateDetailsArray
    * @return int|$corporateId
    */
    public function _insertCorporateDetails($corporateId, $corporateDetailsArray) {

        //object creation.
        $location    = new location();
        $appSettings = new applicationSettings();

        //insert into corporate_details
        $insert = array();

        //get city info
        $cityDetails = $location->_getCityId($corporateDetailsArray['city']);
        //get currency info.
        $currencyDetails = $appSettings->_getCurrencyDetails('', $corporateDetailsArray['currency']);        
        //prepare corporate array
        $insert['r_corporate_id']           = $corporateId;
        $insert['address']                  = $corporateDetailsArray['address'];
        $insert['r_city_id']                = $cityDetails[0]['city_id'];
        $insert['r_currency_id']            = $currencyDetails[0]['currency_id'];
        $insert['zipcode']                  = $corporateDetailsArray['zip'];
        $insert['contact_number']           = $corporateDetailsArray['contact_number'];
        $insert['employee_count']           = $corporateDetailsArray['employee_count'];
        $insert['website']                  = $corporateDetailsArray['website'];
        $insert['comments']                 = $corporateDetailsArray['comments'];
        $insert['floating_balance']         = $corporateDetailsArray['floating_balance'];
        $insert['annual_travel_spend']      = $corporateDetailsArray['annual_travel_spend'];
        $insert['corporate_credit_limit']   = $corporateDetailsArray['corporate_credit_limit'];
        $insert['total_available_balance']  = $corporateDetailsArray['total_available_balance'];
        $insert['created_date']             = date('Y-m-d H:i:s');

        //insert corporate SAP details if present
        if(isset($corporateDetailsArray['sapDetails']) && !empty($corporateDetailsArray['sapDetails'])) {
            $otherDetails['sapDetails'] = $corporateDetailsArray['sapDetails'];
        }
        $otherDetails['applyPromocodePersonal'] = $corporateDetailsArray['applyPromocodePersonal'];
        $otherDetails['powerSuiteSplitupRequired'] = $corporateDetailsArray['powerSuiteSplitupRequired'];        
        $insert['other_details'] = json_encode($otherDetails);
        //insert the data.
        $corporateId = $this->db->_insert('corporate_details', $insert);
        return $corporateId;
    }

    /*@Description function used to isert the promo code info with respect to the corporate id,
    * @param int,array|$corporateId,$promoCodeDetailsArray
    * @return int|$promoCodeInsertedIds
    */
    public function _insertPromoCode($corporateId, $promoCodeDetailsArray) {
        
        //object creation.
        $_OAirline = new airline();

        foreach($promoCodeDetailsArray as $key => $val){
            //get airline info
            $airLineIdArray = $_OAirline->_getAirlineCodeInfo($val['marketing_airline_code']);
            $cabinClassId = $this->db->_select('dm_travel_class', 'travel_class_id', 'class_code', $val['cabin_class'])[0]['travel_class_id'];
            //prepare new id insert array
            $insert = $val;
            $insert['r_airline_id'] = $airLineIdArray[0]['airline_id'];
            // to set travel type and cabin class.
            $insert['cabin_class'] = $cabinClassId;
            $insert['travel_type'] =  $insert['travel_type'] == 'IN' ? 9 : 1;
            //remove unwanted array keys
            $syncPromoCodeId = $insert['promo_code_id'];
            unset($insert['promo_code_id']);
            unset($insert['sync_promo_code_id']);
            unset($insert['operating_airline_code']);
            unset($insert['promo_code_mapping_id']);
            unset($insert['corporate_id']);
            $promoCodeId = $this->db->_insert('dm_promo_code', $insert);
            $promoCodeInsertedIds[$syncPromoCodeId] = $promoCodeId;
        }
        return $promoCodeInsertedIds;
    }

   /*@Description function used to update the promo code info with respect to the corporate id,
    * @param int,array|$corporateId,$promoCodeDetailsArray
    * @return int|$promoCodeInsertedIds
    */
    public function _updatePromoCode($corporateId, $promoCodeDetailsArray,$bookingMode){

        $travelTypeArray = array('IN' => 9,'DO' => 1 ,'*' => 0);

        //object creation.
        $_OAirline = new airline();      

        foreach($promoCodeDetailsArray['promoCodeDetails'] as $key => $val){
            
            //get the airline info.
            $airLineIdArray = $_OAirline->_getAirlineCodeInfo($val['marketing_airline_code']);
            $cabinClassId = $this->db->_select('dm_travel_class', 'travel_class_id', 'class_code', $val['cabin_class'])[0]['travel_class_id'];
            
            //prepare new id insert array
            $insert = $val;
            $insert['r_airline_id'] = $airLineIdArray[0]['airline_id'];
            
            //to set travel type and cabin class.
            $insert['cabin_class'] = $cabinClassId;
            $insert['travel_type'] =  $travelTypeArray[$insert['travel_type']];
            
            //remove unwanted array keys
            unset($insert['promo_code_id']);
            unset($insert['operating_airline_code']);
            unset($insert['promo_code_mapping_id']);
            unset($insert['corporate_id']);
            $wherValue = $insert['sync_promo_code_id'];
            unset($insert['sync_promo_code_id']);

            $result = $this->db->_update('dm_promo_code',$insert,'promo_code_id',$wherValue);
        }
        return $result;
    }

    /*@Description function used to map the promocode for particular corporate.
    * @param int,array|$corporateId,$promoCodeIds
    * @return array|result
    */
    public function _mapPromoCodeToCorporate($corporateId,$promoCodeIds,$bookingMode){
        
        if($corporateId != '' && count($promoCodeIds) > 0){
            //$bookingMode = $this->_getBookingMode($corporateId);
            $insertArray = array();
            foreach($promoCodeIds as $res){
                $insertArray[] = "(" . $corporateId . ", " . $res . ", 'Y', 'Y','".$bookingMode."')";
            }
            $insertValues = implode(",", $insertArray);
            $sql = "INSERT INTO promo_code_mapping (r_corporate_id,r_promo_code_id,search_status,status,booking_mode) VALUES " . $insertValues;
            return $this->db->_getResult($sql);
        }
    }

    /*@Description function used to check the promocode already exist or not for the corporate.
    * @param array|$promoCodeArray
    * @return int|$returnValue
    */
    public function _checkPromoCodeExists($promoCodeArray){

        $returnValue = array();
        if($promoCodeArray[0]['promo_code']){
            $promoCodeCSV = implode("','", $promoCodeArray);
            //get the promocode info.
            $sql = "SELECT promo_code_id, promo_code_value FROM dm_promo_code WHERE promo_code_value IN ('" . $promoCodeCSV . "')";
            $result = $this->db->_getResult($sql);
            if($result && $result[0]['promo_code_id']){
                $returnValue = array_column($result, 'promo_code_value', 'promo_code_id');
            }
        }
        return $returnValue;
    }

    
   /*@Description function used to mapping the agency fee.
    * @param array,int,string|$corporateId,$corporateId,$travelMode
    * @return array|$result
    */
    public function _agentFeeMapping($corporateId,$bookingFeeDetails,$travelMode = 'D'){

        //get the master table ids for mapping
        $sql = "SELECT agent_fee_id, sync_fee_name FROM dm_agent_fee";
        $result = $this->db->_getResult($sql);
        $agentFeeArray = array_column($result, 'agent_fee_id', 'sync_fee_name');

        $sql = "SELECT travel_mode_id, travel_mode_code FROM dm_travel_mode";
        $result = $this->db->_getResult($sql);
        $travelModeArray = array_column($result, 'travel_mode_id', 'travel_mode_code');

        $sql = "SELECT r_travel_mode_id, class_code,class_name,travel_class_id FROM dm_travel_class dtc,dm_travel_mode dtm WHERE dtc.r_travel_mode_id = dtm.travel_mode_id and dtm.travel_mode_code='" . $travelMode . "'";

        $result = $this->db->_getResult($sql);
        $travelClassArray = array();
        if ($travelMode == 'H') {
            foreach ($result as $res) {
                $travelClassArray[$res['r_travel_mode_id']][$res['class_name']] = $res['travel_class_id'];
            }
        } else {
            foreach ($result as $res) {
                $travelClassArray[$res['r_travel_mode_id']][$res['class_code']] = $res['travel_class_id'];
            }
        }
        $insert = array();
        foreach ($agentFeeMappingArray as $res) {
            if (isset($travelModeArray[$res['type_code']]) && !empty($travelModeArray[$res['type_code']])) {

                foreach ($agentFeeArray as $key => $val) {

                    if ($res[$key] > 0) {
                        $insert = array();
                        $insert['r_corporate_id'] = $corporateId;
                        $insert['r_agent_fee_id'] = $val;
                        $insert['fee_type'] = $val != 3 ? "'" . $res[$key . '_type'] . "'" : "'" . $res['system_usage_type'] . "'";
                        $insert['calc_based_on'] = "'" . $res[$key . '_assign'] . "'";
                        $insert['fee_value'] = "'" . $res[$key] . "'";
                        $insert['r_travel_class_id'] = $res['class'] == 'ALL' ? 0 : $travelClassArray[$travelModeArray[$res['type_code']]][$res['class']];
                        $insert['r_travel_mode_id'] = $travelModeArray[$res['type_code']];
                        if ($insert['r_corporate_id'] != '' && $insert['r_agent_fee_id'] != '' && $insert['fee_type'] != '' && $insert['calc_based_on'] != '' && $insert['fee_value'] != '' && $insert['r_travel_class_id'] != '' && $insert['r_travel_mode_id'] != '') {
                            $valuesArray[] = implode(",", $insert);
                        }
                    }
                }
            }
        }
        if (count($valuesArray) > 0) {
            $insertValues = "(" . implode("),(", $valuesArray) . ")";
            $sql = "INSERT INTO agent_fee_mapping (r_corporate_id, r_agent_fee_id, fee_type, calc_based_on, fee_value, r_travel_class_id, r_travel_mode_id) VALUES " . $insertValues;
            $result = $this->db->_getResult($sql);
        }
    }

   /*@Description function used to mapping the payment type with respect to the corporate.
    * @param int|$corporateId
    * @return array|$result
    */
    public function _paymentTypeMapping($corporateId, $bookingMode){

        $allowedGroupIds = array(1, 2, 3, 6);
        $allowedPaymetType = array(5);
        foreach ($allowedGroupIds as $key => $val){
            foreach ($allowedPaymetType as $res){
                $insert = array();
                $insert[] = $corporateId;
                $insert[] = $val;
                $insert[] = $res;
                $insert[] = 0;
                $insert[] = $bookingMode;
                $records[] = implode(",", $insert);
            }
            $values = implode("),(", $records);
        }
        $sql = "INSERT INTO payment_type_mapping (r_corporate_id, r_group_id, r_payment_type_id, r_airline_id, booking_mode ) VALUES (" . $values . ")";
        $this->db->_getResult($sql);
    }

   /*@Description function used to get the corporate list.
    * @param int|$corporateId,$syncCorporateId
    * @return array|$result
    */
    public function _getCorporateList($corporateId = '',$syncCorporateId = ''){

        $where = ' AND dc.corporate_id != 1';
        
        if($corporateId != ''){
            $where = " AND dc.corporate_id =  " . $corporateId . " ";
        }
        if($syncCorporateId != ''){
            $where = " AND am.sync_corporate_id =  " . $syncCorporateId . " ";
        }
        $sql = "SELECT am.agency_id, dc.corporate_id, dc.corporate_name FROM dm_corporate dc 
                   INNER JOIN  agency_corporate_mapping am ON dc.corporate_id = am.corporate_id
                   WHERE dc.status = 'Y' ORDER BY  dc.corporate_name  " . $where . "";
        $result = $this->db->_getResult($sql);
        return $result;
    }

    /*
     * @Description  This method returns the sub corporate list
     * @param int|$corporateId
     * @return array|$result
     * @date|27.12.2016 
     * @author|Karthika.M
     */
    public function _getSubCorporateName($corporateId = 0){
        $sql = "SELECT sub_corporate_id
                 FROM 
                    subcorporate_mapping scm
                WHERE
                    scm.status = 'Y'";

        if(isset($corporateId) && $corporateId != 0) {
            $sql = $sql . " AND scm.r_corporate_id = " . $corporateId;
        }
        $result = $this->db->_getResult($sql);
        if($result != ""){
            foreach ($result as $value){
                $subCorporateName = $this->_getCorporateName($value['sub_corporate_id']);
                $value['subCorporateName'] = $subCorporateName;
                $row[] = $value;
            }
            return $row;
        }
    }

    /*
     * @Description  This method returns the corporate info
     * @param int|$empId
     * @return array|$result
     * @date|27.12.2016 
     * @author|Karthika.M
     */
    public function _getCorporateNameInfo($empId){
        $sql = "SELECT
                    fe.r_corporate_id,fe.r_employee_id,dc.corporate_name
              FROM
                    fact_employee fe
                    INNER JOIN dm_corporate dc ON fe.r_corporate_id = dc.corporate_id
              WHERE
                    fe.r_employee_id = " . $empId;
        $result = $this->db->_getResult($sql);
        return $result;
    }

    /*
     * @functionName    : _getCorporateBalance()
     * @description     : method to get available balance of a input corporate id
     * @param           : int|$corporateId
     * @return          : array|$result
     * @author          : Lakshmi.S
     */
    public function _getCorporateBalance($corporateId){

        $sql = "SELECT
                        cd.total_available_balance
                FROM
                        dm_corporate dc INNER JOIN corporate_details cd 
                        ON dc.corporate_id = cd.r_corporate_id WHERE dc.status ='Y' AND ";

        if ($corporateId != '' && $corporateId > 0) {
            $sql .= " dc.corporate_id =  $corporateId ";
        }
        $result = $this->db->_getResult($sql);
        return $result;
    }

    /*
     * @functionName    : _checkCorporateAvailableBalance()
     * @description     : method to get available balance of a input corporate id
     * @param           : int|$orderId
     * @return          : int|$corporateBalance
     * @author          : Lakshmi.S
     */
    public function _checkCorporateAvailableBalance($orderId,$corporateDetails,$flag){
        $this->_db = new commonDBO();
        $this->_Opackage = new package();
        $corporateDetails = $corporateDetails!='' ? $corporateDetails : $this->_Opackage->_getCorporateAdminDetails($orderId)[0];
        $checkBal['corporateAvailableBalance']['requestInfo']['corporateId'] = $corporateDetails['r_corporate_id'];
        $checkBal['corporateAvailableBalance']['syncCorporateId'] = $corporateDetails['sync_corporate_id'];
        $checkBal['corporateAvailableBalance']['requestInfo']['syncCorporateId'] = $corporateDetails['sync_corporate_id'];
        $checkBal['corporateAvailableBalance']['SBICorporate'] = OVERRIDE_PACKAGE_NAME;
        fileRequire('classes/class.sync.php');
        $this->_BSync = new sync();
           $corporateBalance = $this->_BSync->_checkCorporateAvailableBalance($checkBal);
            $corporateBalance = 1000000000;    
        return $corporateBalance;
    }
    
    /*@Description function used to get the corporate details.
    * @param int|$agencyId
    * @return array|$result
    */
    public function _getCorporateDetails($agencyId = ''){

        $where = ' AND dc.corporate_id != 1';

        if($agencyId != ''){
            $where = " AND am.agency_id =  " . $agencyId . " ";
        }
        $sql = "SELECT am.agency_id, dc.corporate_id, dc.corporate_name FROM dm_corporate dc 
                   JOIN  agency_corporate_mapping am ON dc.corporate_id = am.corporate_id
                   JOIN corporate_details cd ON dc.corporate_id = cd.r_corporate_id
                   WHERE dc.status = 'Y' " . $where . "";
        $result = $this->db->_getResult($sql);
        return $result;
    }

    /*
     * @functionName    : _getCorporateAccessByPermission()
     * @description     : method to get the corporate data for accessing in drop down list by access permission 
     * @param           : int|$corporateId
     * @return          : array|$result
     * @author          : sivaprakash.M
     */
    public function _getCorporateAccessByPermission($corporateId = '', $agencyId){

        $sql = " SELECT corporate_id, corporate_name FROM dm_corporate dc   ";
        $where = '';
        if($agencyId !='') {
            $sql .= " INNER JOIN agency_corporate_mapping acm ON acm.corporate_id = dc.corporate_id";
            $where = " AND agency_id = ".$agencyId." ";
        }
        $sql .= " WHERE dc.status = 'Y' ".$where." ";
        
        $corporateId != '' ? $sql .= " AND corporate_id IN ($corporateId) " : '';
        $sql .= " ORDER BY corporate_name ";
        return $result = $this->db->_getResult($sql);
    }

    /*
     * @functionName    : _setCorporateDetailsOnRegistration()
     * @description     : method to set the corporate details on registration
     * @param           : 
     * @return          : array|$result
     * @author          : sivaprakash.M
     */
    public function _setCorporateDetailsOnRegistration($corporateId = ''){
        $sql = " SELECT cd.r_city_id, cd.address as address, cd.contact_number as contactNumber,
                        cd.zipcode, cd.employee_count as employeeCount, cd.website, 
                        cd.annual_travel_spend as annualTravelSpend,
                        dc.corporate_name as corporateName, dc.corporate_id as corporateId,
                        de.title as title, de.first_name as firstName, de.last_name as lastName, de.email_id as emailid,
                        de.mobile_no as mobileNumber,
                        em.r_designation_id, em.r_department_id
                 FROM corporate_details cd 
                        INNER JOIN dm_corporate dc ON cd.r_corporate_id = dc.corporate_id AND dc.status = 'Y'
                        INNER JOIN fact_employee fe ON dc.admin_account_id = fe.r_account_id 
                        INNER JOIN dm_employee de ON fe.r_employee_id = de.employee_id AND de.status = 'Y'
                        INNER JOIN employee_details em ON em.r_employee_id = de.employee_id
                 WHERE  dc.corporate_id = " . $corporateId . " ";
        return $result = $corporateId ? $this->db->_getResult($sql)[0] : '';
    }

    /*@Description function used to insert the paymet type mapping with respect to the corporate.
    * @param int|$agencyId
    * @return array|$result
    */
    public function _paymentTypeMappingDetails($corporateId,$paymentCode,$bookingMode){
        $allowedGroupIds = array(1, 2, 3, 4, 6, 8);
        foreach ($paymentCode as $keyPay => $valPay) {
            $res = $this->db->_select('dm_payment_type', 'payment_type_id', 'payment_type_code', $valPay)[0]['payment_type_id'];
            foreach ($allowedGroupIds as $key => $val) {

                $insert = array();
                $insert['r_corporate_id'] = $corporateId;
                $insert['r_group_id'] = $val;
                $insert['r_payment_type_id'] = $res;
                $insert['r_airline_id'] = 0;
                $insert['booking_mode'] = $bookingMode;
                $this->db->_insert('payment_type_mapping', $insert);
            }
        }
    }

    /*
    * @functionName    :   _getAgencyCorporateInformation()
    * @description     :   method to get details of one or more corporates
    */
    public function _getAgencyCorporateInformation($inputData){

        $sql = "SELECT 
                        dc.corporate_id,
                        dc.corporate_name,
                        cd.address,
                        cd.r_city_id,
                        dcm.city_name,
                        cd.zipcode,
                        cd.contact_number,
                        cd.employee_count,
                        cd.website,
                        cd.annual_travel_spend,
                        cd.comments,
                        dc.admin_account_id,
                        dc.status
                FROM
                        dm_corporate dc INNER JOIN corporate_details cd 
                        ON dc.corporate_id = cd.r_corporate_id INNER JOIN dm_city dcm ON dcm.city_id = cd.r_city_id WHERE 1 AND ";

        if (isset($this->$inputData['agencyId'])){
            $sql .= " dc.corporate_id =  $this->_IcorporateId AND ";
        }
        if (isset($this->_Sstatus)){
            $sql .= " dc.status = '" . $this->_Sstatus . "' AND ";
        }
        $sql = substr($sql, 0, -4);
        return $this->db->_getResult($sql);
    }

    /*@Description function used to get the corporate
    * @param array|$input
    * @return array|$result
    */
    public function _getCorporateInformationOnChange($input){
        $sql = "SELECT 
                        dc.corporate_id,
                        dc.corporate_name,
                        cd.address,
                        cd.r_city_id,
                        dcm.city_name,
                        cd.zipcode,
                        cd.contact_number,
                        cd.employee_count,
                        cd.website,
                        cd.annual_travel_spend,
                        cd.comments,
                        dc.admin_account_id,
                        dc.status
                FROM
                        dm_corporate dc 
                        INNER JOIN corporate_details cd ON dc.corporate_id = cd.r_corporate_id 
                        INNER JOIN dm_city dcm ON dcm.city_id = cd.r_city_id 
                        INNER JOIN agency_corporate_mapping acm ON dc.corporate_id = acm.corporate_id  WHERE 1 AND ";
        if(isset($input['agencyId']) && $input['agencyId'] != ''){
            $sql .= " acm.agency_id =" . $input['agencyId'] . " AND ";
        }
        if(isset($input['corporateId']) && $input['corporateId'] != ''){
            $sql .= " acm.corporate_id =" . $input['corporateId'] . " AND ";
        }
        $sql = substr($sql, 0, -4);
        return $this->db->_getResult($sql, '', 1);
    }

   /*
    * @Description function used to get the corporate list.
    */
    public function _getMigrateCorporateList($corporateId = ''){
        $sql = " SELECT dmc.corporate_id, dmc.corporate_name , acm.sync_corporate_id FROM dm_corporate dmc "
                . " INNER JOIN agency_corporate_mapping acm ON acm.corporate_id = dmc.corporate_id "
                . " WHERE dmc.status='Y' AND acm.status='Y' ";

        if($corporateId !='') {
            $sql .= "  AND acm.corporate_id = ".$corporateId."";
        }

        return $this->db->_getResult($sql);
    }
    
    
    /*
     * @functionName    : _getCorporateAccessByPermission()
     * @description     : method to get the corporate data for accessing in drop down list by access permission 
     * @param           : int|$corporateId
     * @return          : array|$result
     * @author          : sivaprakash.M
     */
    public function _checkCorporateAlreadyExists($corporateName){
        if($corporateName !=''){
            $sql = " SELECT corporate_id, corporate_name FROM dm_corporate WHERE status = 'Y'  AND corporate_name = '".$corporateName."' ";
            $result = $this->db->_getResult($sql);
            
            if(isset($result[0]['corporate_name']) && !empty($result[0]['corporate_name'])) {
                $result = array('status' => 1, 'message' => 'corporate already exists');
            } else {
                $result = array('status' => 0, 'message' => 'corporate does not exists');
            }
        }else{
             $result = array('status' => 2, 'message' => 'corporate name is empty');
        }        
        return $result;
    }
    
    /*
     * @functionName    : _getCorporateIdInfo()
     * @description     : method to get the corporate info with respect to the sync agency id and sync corporate id
     * @param           : int|$AgencyId,$syncCorporateId
     * @return          : array|$result
     * @author          : Karthika.M
     */
    public function _getCorporateIdInfo($agencyId,$syncCorporateId,$bookingType){
        
        //get corporate id with respect to the sync_corporate_id and sync_agency_id.
        $FEagencyId =  $this->db->_select('dm_agency','dm_agency_id','sync_agency_id',$agencyId)[0]['dm_agency_id'];
        
        $whereKey = ($bookingType == 'Corporate') ? 'sync_corporate_id' : 'sync_personal_id';
        
        //get corporate id
        $sql = "SELECT * FROM agency_corporate_mapping WHERE agency_id = ".$FEagencyId." AND ".$whereKey." = ".$syncCorporateId;
        return  $this->db->_getResult($sql);        
    }
    
    /*
     * @functionName    : _updateCorporateDetails()
     * @description     : method to update the corporate info with respect to corporate id
     * @param           : int,array|$corporateId,$corporateDetailsArray
     * @return          : array|$result
     * @author          : Karthika.M
     */
    public function _updateCorporateDetails($corporateId,$corporateDetailsArray){        
        
        $location    = new location();
        $appSettings = new applicationSettings(); 
        
        //prepare corporate array
        $corporateDetailsArray['address'] ? $update['address'] = $corporateDetailsArray['address']:'';
        $corporateDetailsArray['city'] ? $update['r_city_id'] =  $location->_getCityId($corporateDetailsArray['city'])[0]['city_id']:'';
        $corporateDetailsArray['currency'] ? $update['r_currency_id']= $appSettings->_getCurrencyDetails('', $corporateDetailsArray['currency'])[0]['currency_id']:'';
        $corporateDetailsArray['zip'] ? $update['zipcode'] = $corporateDetailsArray['zip']:'';
        $corporateDetailsArray['contact_number'] ? $update['contact_number'] = $corporateDetailsArray['contact_number']:'';
        $corporateDetailsArray['employee_count'] ? $update['employee_count'] = $corporateDetailsArray['employee_count']:'';
        $corporateDetailsArray['website'] ? $update['website']  = $corporateDetailsArray['website']:'';
        $corporateDetailsArray['comments'] ? $update['comments'] = $corporateDetailsArray['comments']:'';
        $corporateDetailsArray['floating_balance'] ? $update['floating_balance'] = $corporateDetailsArray['floating_balance']:'';
        $corporateDetailsArray['annual_travel_spend'] ? $update['annual_travel_spend'] = $corporateDetailsArray['annual_travel_spend']:'';
        $corporateDetailsArray['corporate_credit_limit'] ? $update['corporate_credit_limit'] = $corporateDetailsArray['corporate_credit_limit']:'';
        $corporateDetailsArray['total_available_balance'] ? $update['total_available_balance'] = $corporateDetailsArray['total_available_balance']:'';
        
        //insert corporate SAP details if present
        $corporateOtherDetails = $this->db->_select('corporate_details','other_details','r_corporate_id',$corporateId)[0]['other_details'];
        $_OauthToken = new authToken();
        $corporateOtherDetails = $_OauthToken->_purifyInputData($corporateOtherDetails);
        $prevSapDetails = json_decode($corporateOtherDetails,1);  
        
        $otherDetails['sapDetails']['sapId'] = $corporateDetailsArray['sapDetails']['sapId'] ? $corporateDetailsArray['sapDetails']['sapId']:$prevSapDetails['sapDetails']['sapId'];
        $otherDetails['sapDetails']['sapOfficeId'] = $corporateDetailsArray['sapDetails']['sapOfficeId'] ? $corporateDetailsArray['sapDetails']['sapOfficeId']:$prevSapDetails['sapDetails']['sapOfficeId'];
        $otherDetails['sapDetails']['sapUrl'] = $corporateDetailsArray['sapDetails']['sapUrl'] ? $corporateDetailsArray['sapDetails']['sapUrl']:$prevSapDetails['sapDetails']['sapUrl'];
        //get other_details.
        $otherDetails['applyPromocodePersonal'] = isset($corporateDetailsArray['applyPromocodePersonal']) ? $corporateDetailsArray['applyPromocodePersonal'] :$prevSapDetails['applyPromocodePersonal'];
        $otherDetails['powerSuiteSplitupRequired'] = isset($corporateDetailsArray['powerSuiteSplitupRequired']) ? $corporateDetailsArray['powerSuiteSplitupRequired'] :$prevSapDetails['powerSuiteSplitupRequired'];
        $update['other_details'] = json_encode($otherDetails);
        $update['updated_date'] = date('Y-m-d H:i:s'); 
        if(count($update > 0)){
            $updatedCorporateDetails = $this->db->_update('corporate_details',$update,'r_corporate_id',$corporateId);
        }
        return $updatedCorporateDetails;
    }
    
    /*
     * @functionName    : _getCorporateAdminAccountId()
     * @description     : method to get the admin account id  with respect to email id
     * @param           : string,int|$adminEmailId,$corporateId
     * @return          : array|$result
     * @author          : Karthika.M
     */
    public function _getCorporateAdminAccountId($adminEmailId,$corporateId,$corporateDetails=array()){
        
        $_Ocommon = new common();
        $_Oemployee = new employee();
        
        $employeeId = $this->db->_select('dm_employee','employee_id','email_id',$adminEmailId)[0]['employee_id'];       
        if($employeeId == ''){       
            
            //insert into dm_employee table.
            $empInfo['first_name'] = $corporateDetails['travel_mgr_name'];
            $empInfo['last_name'] = $corporateDetails['last_name'];
            $empInfo['title'] = $corporateDetails['type'];
            $empInfo['email_id'] = $adminEmailId;
            $empInfo['status'] = 'Y';
            $empInfo['mobile_no']=$corporateDetails['mobile_no'];
            $empInfo['created_date'] = date('Y-m-d H:i:s');

            $empDetails['employee_id'] = $this->db->_insert('dm_employee', $empInfo);
            
            //insert into dm_account.
            $param['r_user_type_id'] = 2;
            $param['login_password'] = $_Ocommon->_generateEncryptionString();
            $param['transaction_password'] = $_Ocommon->_generateEncryptionString();
            $empDetails['account_id'] = $this->db->_insert('dm_account', $param);
            
            //insert into fact_employee
            $factEmpInfo['r_employee_id'] = $empDetails['employee_id'];
            $factEmpInfo['r_account_id'] = $empDetails['account_id'];
            $factEmpInfo['r_user_type_id'] = 2;
            $factEmpInfo['r_corporate_id'] = $corporateId;
            $factEmpInfo['r_level_id'] = 5;
            $empDetails['fact_employee_id'] = $this->db->_insert('fact_employee', $factEmpInfo);
                        
            //send mail to corporate admin.
            $this->_IinputData['account_id'] = $empDetails['account_id'];;
            $this->_IinputData['email_id'] = $adminEmailId;
            $this->_IinputData['first_name'] = $empInfo['first_name'];
            $this->_IinputData['employee_id'] = $empDetails['employee_id'];
            
            $this->_Otwig = init();
            
            //send welcome mail to corporate admin.
            $this->_sentMailWithLoginId();
            
            //send mail to corproate admin
           //$this->_sendMailToCorporate();
            
            //send credentials to corpoate admin.
            //$_Oemployee->_Otwig = $this->_Otwig;
            //$_Oemployee->_sendCredentials($adminEmailId,$param,$empDetails['account_id'],$empInfo['first_name'],$empDetails['employee_id']);
        }
        else{            
            $empDetails['employee_id'] = $employeeId;
            $factEmpInfo = $this->db->_select('fact_employee','*','r_employee_id',$employeeId);
            $empDetails['account_id'] = $factEmpInfo[0]['r_account_id'];
            $empDetails['fact_employee_id'] = $factEmpInfo[0]['fact_employee_id'];
        }
        return $empDetails;
    }
    
    //This function will change the update status in list in corporate list
    public function updateStatus($input){
        $bookingMode = $this->db->_select('sync_corporate_details','booking_mode','sync_corporate_id',$input['syncCorporateId'])[0]['booking_mode'];
        // To check whether the booking mode is personal or corporate
        if($bookingMode == 0){
            $bookingType['personal_booking_enable'] = $input['status'];
            $sql = $this->db->_update('dm_corporate',$bookingType,'corporate_id',$input['corporateId']);
        }else{
            $bookingType['corporate_booking_enable'] = $input['status'];
            $sql = $this->db->_update('dm_corporate',$bookingType,'corporate_id',$input['corporateId']);
        }
        $corporateDetails =  $this->db->_select('dm_corporate','*','corporate_id',$input['corporateId'])[0];
        // Condition to change the corporate status whether the both booking mode is disabled
        if($corporateDetails['personal_booking_enable'] =='N' && $corporateDetails['corporate_booking_enable'] == 'N'){
            $data['status'] = "N";
             $query = $this->db->_update('dm_corporate',$data,'corporate_id',$input['corporateId']);
        }else{
            $data['status'] = "Y";
             $query = $this->db->_update('dm_corporate',$data,'corporate_id',$input['corporateId']);
        }
        return $query;
    }
    
    
    //function used to send the welcome mail to corporate admin.
    public function _sendMailToCorporate(){
        
        $_OcommonMethods = new commonMethods();
        
        $to   = $this->_IinputData['email_id'];
        $_Ssubject = "Welcome to Balmer lawrie";
        
        $twigOutputArray['firstname'] = $this->_IinputData['first_name'];
        $twigOutputArray['host'] = HOST_URL;
        $twigOutputArray['mailSignature'] = EMAIL_SIGNATURE;
        $_SmailContent = $this->_Otwig->render('corporateCreationMailTemp.tpl',$twigOutputArray);    
        
        //send mail.
        $mailResponse = $_OcommonMethods->_sendMail($to,$from,$_Ssubject,$_SmailContent);
        return $mailResponse;
    }
    
    //send login mail and reset pwd link to corporate admin.
    public function _sentMailWithLoginId(){
        
        //object creation
        $_OcommonMethods = new commonMethods();
        $_Oemployee = new employee();        
        
        // setting  link for employee creation  not to send in mail so added condition to set forget  
        $user = $_Oemployee->_generateForgotPwdLink($this->_IinputData['account_id'],$this->_IinputData['email_id'],$this->_IinputData['employee_id']);
        
        $to        = $this->_IinputData['email_id'];
        $_Ssubject = "Balmer lawrie login credentials";
        
        $twigOutputArray['firstname'] = $this->_IinputData['first_name'];
        $twigOutputArray['host'] = HOST_URL;
        $twigOutputArray['employeeId'] = $this->_IinputData['employee_id'];
        $twigOutputArray['loginId'] = $this->_IinputData['email_id'];
        $twigOutputArray['passwordChange'] = HOST_URL."/forgotPassword.php?user=".$user;
        $twigOutputArray['supportMailId'] = SUPPORT_EMAIL_ID;
        $twigOutputArray['mailSignature'] = EMAIL_SIGNATURE;        
        $_SmailContent = $this->_Otwig->render('corporateRegisterMailTemp.tpl',$twigOutputArray);             
        $mailResponse = $_OcommonMethods->_sendMail($to,$from,$_Ssubject,$_SmailContent);
        return $mailResponse;
    }
    
    /*
    * @functionName    : _getAgencyCorporateDetails()
    * @description     : method to get the agency corporate mapping
    * @return          : array|$result
    * @author          : Muruganandham.M
    */
    public function _getAgencyCorporateDetails(){
        $sql ='SELECT acm.corporate_id ,dc.corporate_name FROM agency_corporate_mapping acm INNER JOIN dm_corporate dc ON acm.corporate_id = dc.corporate_id WHERE acm.agency_id = '.$_SESSION['agencyId']; 
        $returnData = $this->db->_getResult($sql);
        return $returnData;
    }
    
    /*
    * @functionName    : _insertSyncCorporateDetails()
    * @description     : method to insert sync_corporate_details
    * @return          : array|$result
    * @author          : sandhiya.c
    */
    public function _insertSyncCorporateDetails($corporateDetails,$corporateId,$bookingMode = '1'){        
        $sql = "INSERT INTO sync_corporate_details (corporate_name,r_corporate_id,sync_corporate_id,booking_mode,additional_details)
                VALUES('".$corporateDetails['company_name']."',".$corporateId.",".$corporateDetails['corporate_id'].",'".$bookingMode."',
                "."COMPRESS('".json_encode($corporateDetails)."'))";
        return $this->db->_getResult($sql);
    }
    
    /*
    * @functionName    : _updateSyncCorporateDetails()
    * @description     : method to update sync_corporate_details
    * @return          : array|$result
    * @author          : sandhiya.c
    */
    public function _updateSyncCorporateDetails($corporateDetails,$corporateId,$bookingMode){
        $sql = "UPDATE 
                    sync_corporate_details 
                SET 
                    corporate_name = '".$corporateDetails['company_name']."', 
                    additional_details = COMPRESS('".json_encode($corporateDetails)."') 
                WHERE 
                    r_corporate_id = ".$corporateId." AND sync_corporate_id = ".$corporateDetails['corporate_id']." AND booking_mode = '".$bookingMode."'";
        return $this->db->_getResult($sql);
    }
    
    /*
    * @functionName    : _corporateSettingsInsertion()
    * @description     : method to insert the settings and payment type for the corporate.
    */
    public function _corporateSettingsInsertion($corporateDetails,$corporateId){
        
        $_OAppSettings = new applicationSettings();
        
        //set the booking mode.
        $bookingMode = $corporateDetails['bookingType'] == 'Corporate' ? '1' : '0';

        //set the payment code
        if($corporateDetails['paymentCode']){
            $this->_paymentTypeMappingDetails($corporateId,$corporateDetails['paymentCode'],$bookingMode);
        }
        else{//inser the the payment type as deposit for the corporate as default.
            $this->_paymentTypeMapping($corporateId,$bookingMode);
        }
                            
        //product default setting json creation for the corporate based on the booking mode.                           
        $_OAppSettings->_copyExistingApplicationSettings($corporateId,'',strtolower($corporateDetails['bookingType']));

        //insert the sync corporate details tables.
        $syncCorporateDetailsId = $this->_insertSyncCorporateDetails($corporateDetails,$corporateId,$bookingMode);
        
        //function call for inserting booking link details in dm_booking_link
        if($corporateDetails['embeddedLink'] == 'Y'){
            $bookingLink['userLink'] = $this->_insertEmbeddedLink($corporateDetails,$corporateId,4);
        }
        if($corporateDetails['embeddedCorporateAdminLink'] == 'Y'){
            $bookingLink['adminLink'] = $this->_insertEmbeddedLink($corporateDetails,$corporateId,2);
        }
        return $bookingLink;
    }
    
    /*
    * @functionName    : _deletePaymentBasedBookingMode()
    * @description     : delete the payment type details with respect to the booking mode and corporate id.
    */
    public function _deletePaymentBasedBookingMode($corporateId,$bookingMode){        
        $sql = "DELETE FROM payment_type_mapping  WHERE r_corporate_id = ".$corporateId." AND booking_mode = '".$bookingMode."'";
        return $this->db->_executeQuery($sql);
    }

    /*
    * @functionName    : _getBookingMode()
    * @description     : this method used to get booking mode
    * @return          : int| bookingMode
    * @author          : puroskhan.m
    */
    public function _getBookingMode($FEcoprorateId){
        $bookingMode = $this->db->_select("sync_corporate_details","booking_mode","r_corporate_id",$FEcoprorateId)[0]['booking_mode'];
        return $bookingMode;
    }

    /*
    * @functionName    : _getOrderCorporateId()
    * @description     : this method used to corporate id with respect to the sync order id
    * @return          : int| syncOrderId
    */
    public function _getOrderCorporateId($syncOrderId){

        $sql    =  "SELECT 
                        fb.r_corporate_id,
                        fb.r_package_id 
                    FROM 
                        order_details od 
                        INNER JOIN fact_booking_details fb ON od.order_id = fb.r_order_id
                    WHERE 
                        od.sync_order_id = ".$syncOrderId;

        return $this->db->_getResult($sql)[0]['r_corporate_id'];       
    }

    /*
    * @functionName    : _changeBookingLinkStatus()
    * @description     : this method used to update the status of the booking link with respect to the inputs
    */
    public function _changeBookingLinkStatus($reference_type,$reference_id,$userType,$status){

        //update the embedded link status.
        $sql = "UPDATE 
                    dm_booking_link 
                SET status = '".$status."' 
                WHERE 
                    reference_type = '".$reference_type."' AND reference_id = ".$reference_id." AND link_type = ".$userType;
        return $this->db->_executeQuery($sql);
    }

        /**
    * @description : this function used to get corporate mapped to the travel admin
    * @return array
    * @author Rajesh U
    */

    public function _getSyncCorporateDetails($bookingMode = '',$corporateFlag = 'N'){

        $sql = "SELECT 
                    scd.corporate_name,scd.sync_corporate_id ,scd.r_corporate_id
                FROM 
                    sync_corporate_details scd 
                WHERE scd.r_corporate_id IN " ."('" .implode("','", $_SESSION['permissions']['access']['corporateId']) . "')" ;

        if($corporateFlag == 'Y'){
            $sql .= " AND scd.r_corporate_id = ".$_SESSION['permissions']['r_corporate_id']." AND scd.booking_mode = '1'";   
        }
        if($bookingMode  != ''){
          $sql .= ' group by scd.r_corporate_id';  
        }        

        return $this->db->_getResult($sql);
    }
   
}
?>