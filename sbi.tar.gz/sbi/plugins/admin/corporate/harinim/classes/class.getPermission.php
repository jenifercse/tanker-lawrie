<?php
/* * **********************************************************************
 * @Class Name	: class.getPermission.php
 * @Created on	: 2016-08-23
 * @Created By	: Sivaprakash.M
 * @Description	: To get permission for user access data
 * ************************************************************************ */
class getPermission 
{
    public $_AaccessCorporateIds;
    public function __construct() 
    {
        $this->_OcommonDBO = new commonDBO();
        $this->_Aagency = new agency();
        $this->_Ccorporate = new corporate();
        $this->_AaccessCorporateIds = array();
    }
    /*
     * @functionName    :   _getDataAccessPermission()
     * @description     :   To get data access based on the user level id
     * @params          :   $_SESSION['levelId'] | Integer
     * @returnType      :   Array contains the user data to be accessed
     */
    public function _getDataAccessPermission($requestDetails)
    {
       if ($requestDetails!='') {
        $agencyId = $requestDetails['agency_id'];
        $corporateId =$requestDetails['r_corporate_id'];
        $levelId =$requestDetails['r_level_id'];
        $employeeId = $requestDetails['employee_id'];
       }else{
        $levelId = $_SESSION['levelId'];
        $corporateId = $_SESSION['corporateId'];
        $agencyId = $_SESSION['agencyId'];
        $employeeId = $_SESSION['employeeId'];

       }
 

      $getPermissionName = "SELECT 
                                    pm.permission_id, pm.permission_name , plm.permission_level_mapping_id
                            FROM 
                                    dm_permission pm
                                    INNER JOIN permission_level_mapping plm ON plm.r_permission_id = pm.permission_id
                            WHERE
                                    plm.r_level_id= '".$levelId."'";

        $permissionName = $this->_OcommonDBO->_getResult($getPermissionName);
        foreach ($permissionName as $key => $value)
        {
            switch ($value['permission_name']) 
            {
                case 'All':
                    $dataToAccess = array('permissionId'=>$value['permission_id'],'permissionName'=>$value['permission_name']);
                    $dataToAccess['fieldList']['agencyList']    = 'YES';
                    $dataToAccess['fieldList']['corporateList'] = 'YES';
                    
                    $agencyIds    = array_column($this->_Aagency->_getAgencyList('dm_agency_id'), 'dm_agency_id');
                    $corporateIds = array_column($this->_Ccorporate->_getCorporateList(), 'corporate_id');

                    //sort the array
                    sort($agencyIds);
                    sort($corporateIds);
                    
                    $dataToAccess['access']['agencyId']         =  $agencyIds;
                    $dataToAccess['access']['corporateId']      =  $corporateIds;
                    return $dataToAccess;
                    break;
                
                case 'Self':
                    $dataToAccess = array('permissionId'=>$value['permission_id'],'permissionName'=>$value['permission_name'],'r_employee_id'=>$employeeId);

                    $dataToAccess['fieldList']['agencyList']    = 'NO';
                    $dataToAccess['fieldList']['corporateList'] = 'NO';
                    
                    $dataToAccess['access']['agencyId']         =  array($agencyId);
                    $dataToAccess['access']['corporateId']      =  array($corporateId);
                    
                    return $dataToAccess;
                    break;
                
                case 'Other Corporate':
                    $dataToAccess = $this->_getOtherDataAccess($value['permission_level_mapping_id']);
                    
                    $dataToAccess['fieldList']['agencyList']    = 'NO';
                    $dataToAccess['fieldList']['corporateList'] = implode(",", $dataToAccess['r_corporate_id']);
                    
                    $dataToAccess['access']['agencyId']         =  array($agencyId);
                    $dataToAccess['access']['corporateId']      =  array_unique(array_merge($dataToAccess['r_corporate_id'], array($corporateId)));
                    
                    return $dataToAccess;
                    break;
                
                case 'Other Employee':
                    
                    $dataToAccess = $this->_getOtherDataAccess($value['permission_level_mapping_id']);
                    $dataToAccess['fieldList']['agencyList'] = 'NO';
                    $dataToAccess['fieldList']['corporateList'] = 'NO';
                    
                    $dataToAccess['access']['agencyId']         =  array($agencyId);
                    $dataToAccess['access']['corporateId']      =  array($corporateId);
                    $dataToAccess['access']['employeeId']       =  $dataToAccess['r_employee_id'];
                    
                    return $dataToAccess;
                    break;
                
                case 'Self Corporate':
                    $dataToAccess = array('permissionId'=>$value['permission_id'],'permissionName'=>$value['permission_name'],'r_corporate_id'=>$corporateId);
                    $dataToAccess['fieldList']['agencyList'] = $agencyId;
                    $dataToAccess['fieldList']['corporateList'] = implode(',', array_column($this->_Ccorporate->_getCorporateNameInfo($employeeId), 'r_corporate_id'));
                    $subCorporate = $this->_Ccorporate->_getSubCorporateName($corporateId);
                    $dataToAccess['fieldList']['corporateList'].= $subCorporate ? ','.implode(',', array_column($subCorporate, 'sub_corporate_id')) : '';
                    
                    $dataToAccess['access']['agencyId']         =  array($agencyId);
                    $dataToAccess['access']['corporateId']      =  array($corporateId);
                    
                    return $dataToAccess;
                    break;
                
                case 'Agency Corporate':
                    
                    $dataToAccess = array('permissionId'=>$value['permission_id'],'permissionName'=>$value['permission_name'],'r_corporate_id'=>$corporateId);
                    $dataToAccess['fieldList']['agencyList'] = $agencyId;
                    if(!empty($this->_AaccessCorporateIds)){
                        $corporateListArray = $this->_AaccessCorporateIds;
                    } else if(!empty($_SESSION['permissions']['access']['corporateId'])){
                        $corporateListArray = $_SESSION['permissions']['access']['corporateId'];
                    } else {
                        $corporateListArray = array_column($this->_Aagency->_getAgencyCorporateList($agencyId),'corporate_id');
                    }
                    sort($corporateListArray);
                    $dataToAccess['fieldList']['corporateList'] = implode(',', $corporateListArray);
                    
                    $dataToAccess['access']['agencyId']         =  array($agencyId);
                    $dataToAccess['access']['corporateId']      =  $corporateListArray;
                    
                    return $dataToAccess;
                    break;
                
                default:
                    return false;
                    break;
            }
        }
    }
    /*
     * @functionName    :   _getOtherDataAccess()
     * @description     :   To set data access for the other corporate and other employee
     * @returnType      :   $dataCanAccess array consist of data to be accessed
     */
    public function _getOtherDataAccess($permissionMapId)
    {
        $dataToAccess ="SELECT 
                                plmv.mapping_value , dm.permission_name , dl.level_name , dm.permission_id
                        FROM 
                                permission_level_mapping_value plmv
                                INNER JOIN permission_level_mapping plm ON plmv.permission_level_mapping_id = plm.permission_level_mapping_id
                                INNER JOIN dm_permission dm on plm.r_permission_id = dm.permission_id
                                INNER JOIN dm_level dl on plm.r_level_id = dl.level_id
                        WHERE 
                                plmv.permission_level_mapping_id = $permissionMapId";

         $toAccessData = $this->_OcommonDBO->_getResult($dataToAccess);

         foreach ($toAccessData as $accessKey => $dataValue) 
            {
                $dataCanAccess['permissionId'] = $dataValue['permission_id'];
                $dataCanAccess['permissionName'] = $dataValue['permission_name'];
                if($dataValue['permission_name'] == 'Other Corporate')  
                {
                    $dataIds = array_column($toAccessData, 'mapping_value');
                    sort($dataIds);
                    $dataCanAccess['r_corporate_id'] = $dataIds;
                }
                if($dataValue['permission_name'] == 'Other Employee')
                {
                    $dataIds = array_column($toAccessData, 'mapping_value');
                    sort($dataIds);
                    $dataCanAccess['r_employee_id']  = $dataIds;
                }
            }
    return $dataCanAccess;
    }
}
