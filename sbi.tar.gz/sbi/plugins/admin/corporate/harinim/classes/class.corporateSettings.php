<?php
/** **********************************************************************
 * @Class Name	: class.corporateSettings.php
 * @Created on	: 2016-06-02
 * @Created By	: Lakshmi
 * @Description	: This file is used to insert,update and get corporate based settings like (payment options,bill-to mapping,promocode details)
 * ************************************************************************ */
fileRequire('classes/class.commonDBO.php');

class corporateSettings
{
    private $_AfieldsArray=array();
    private $_Swherekey="";
    private $_Swherevalue="";
    private $_SoutputType="";
    private $_OcommonDBO;
    
    public function __construct() {
       $this->_OcommonDBO=new commonDBO();
    }
    /**
     * @Description :This function insert the payment options selected based on the input corporate id
     * @param :integer | $corporateId - holds corporate id
     * @param :array | $corporatePaymentOptions - holds selected payment options
     * @param :array | $corporateGroupId - holds group id mapped for the payment types
     * @return boolean|$return - return true 
     */  
    public function _insertCorporatePaymentOptions($corporateId,$corporatePaymentOptions,$corporateGroupId) {

        $insertValues=array();       
        $corporatePaymentCount=count($corporatePaymentOptions);
        $corporateGroupCount=count($corporateGroupId);
        // This is the default value 
        $insertValues['r_corporate_id']=$corporateId;
        
        for($paymentIndex=0;$paymentIndex<$corporatePaymentCount;$paymentIndex++){
            $insertValues['r_payment_type_id']=$corporatePaymentOptions[$paymentIndex];
            for($groupIndex=0;$groupIndex<$corporateGroupCount;$groupIndex++){
                $insertValues['r_group_id']=$corporateGroupId[$groupIndex];
                
                $result=$this->_OcommonDBO->_insert('payment_type_mapping', $insertValues);
            }
        }
        return true;
    }
    
    /**
     * @Description :This function get all payment types 
     * @param :
     * @return array|$return - return array of records
     */
    public function _getPaymentTypes() {
        $this->_AfieldsArray=array('payment_type_id','payment_type_code','payment_type_description');
        //Functiona call to get payment types
        $_ApaymentTypes=$this->_OcommonDBO->_select('dm_payment_type', $this->_AfieldsArray);
        
        return $_ApaymentTypes;
    }
    
     /**
     * @Description :This function get the payment types mapped for the input corporate id
     * @param :integer | $corporateId - holds corporate id
     * @return mixed|$return - return array of records or boolean if false
     */   
     public function _getcorporatePaymentOptions($corporateId) {
         //Query to get the payment types mapped for the corporate id
         $sqlCorporatePaymentOptions="SELECT r_payment_type_id FROM payment_type_mapping WHERE r_corporate_id=".$corporateId." GROUP BY r_payment_type_id";
         
         if($result = $this->_Oconnection->query($sqlCorporatePaymentOptions)){
                if ($result->rowCount() > 0) {
                   while($row = $result->fetch(PDO::FETCH_ASSOC)){
                        $resultArray[]=$row['r_payment_type_id'];
                    }
                }
                else {
                      $resultArray=0;  
                }
        }
        else { 
                $resultArray=-1; 
        }
        return $resultArray;
     }
     
     /**
     * @Description :This function delete the payment types mapped for the input corporate id
     * @param :integer | $corporateId - holds corporate id
     * @return boolean|$return - return true or false
     */ 
     public function _deleteCorporatePaymentOptions($corporateId,$billtoId=0) {
          
        // Query to get the billto-address mapped for the corporate id
         $sqldeletePaymentTypeMapping="DELETE FROM payment_type_mapping WHERE ";
         if($corporateId!=0){
                $sqldeletePaymentTypeMapping .=  " r_corporate_id=".$corporateId." AND";
         }
         if($billtoId!=0){
                 $sqldeletePaymentTypeMapping .=  " billto_id=".$billtoId." AND";
         }
         
         $sqldeletePaymentTypeMapping=substr($sqldeletePaymentTypeMapping,0,-4);
         $result = $this->_Oconnection->query($sqldeletePaymentTypeMapping);
           
            if (!$result) {
                $result = 0;
            } 
            else 
            {
                $result = $result->rowCount();
            }
        return $result;
     }
     
     /**
     * @Description :This function get the bill-to address mapped for the corporate
     * @param :integer | $corporateId - holds corporate id
     * @return array|$return - return array of records
     */
    public function _getBillToMapping($corporateId=0,$billtoId=0,$fieldsArray='',$status='') {
        
        if(!empty($fieldsArray)) {
            
            if(is_array($fieldsArray) && count($fieldsArray) > 0){
                $fieldsCSV = implode(", ", $fieldsArray);
                $fieldsCSV .= ',billto_id';
            } else {
                $fieldsCSV = $fieldsArray;
            }
            //Query to get the billto-address mapped for the corporate id
            $sqlCorporateBilltoMapping="SELECT ".$fieldsCSV." FROM billto_mapping WHERE ";
        }
        else{
        //Query to get the billto-address mapped for the corporate id
         $sqlCorporateBilltoMapping="SELECT billto_id,billto_name,status FROM billto_mapping WHERE ";
        }
        if($corporateId!=0){
                $sqlCorporateBilltoMapping .=  " r_corporate_id=".$corporateId." AND";
         }
         if($billtoId!=0){
                 $sqlCorporateBilltoMapping .=  " billto_id=".$billtoId." AND";
         }
        if($status!=''){
            $sqlCorporateBilltoMapping .= " status = '$status' AND";
        }
        
        $sqlCorporateBilltoMapping=substr($sqlCorporateBilltoMapping,0,-4);
        
         //Functiona call to get fetch the records 
         $result=$this->_OcommonDBO->_getResult($sqlCorporateBilltoMapping);
         
         return $result;
    }
    
    /**
     * @Description :This function is used to insert the bill-to address based on the corporate
     * @param :integer | $corporateId - holds corporate id
     * @param :array   | $billToAddress - holds array of bill-to address
     * @return boolean |$return - return true 
     */
    public function _insertBillToMapping($corporateId,$billToAddress) {
        $insertValues=array();
        $insertValues['billto_id']=0;
        $insertValues['r_corporate_id']=$corporateId;
        if(is_array($billToAddress) && count($billToAddress)>0)
        {
            $billtoAddressCount=count($billToAddress);
            for($billtoIndex=0;$billtoIndex<$billtoAddressCount;$billtoIndex++)
            {
                $insertValues['billto_name']=$billToAddress[$billtoIndex];
                //Functiona call to insert billto address
                $result = $this->_OcommonDBO->_insert('billto_mapping',$insertValues);
            }
        }
        else{
            $insertValues['billto_name']=$billToAddress;
            $result = $this->_OcommonDBO->_insert('billto_mapping',$insertValues);
        }
        return $result;
    }
    
    /**
     * @Description :This function is used to update the bill-to address based on the corporate
     * @param :integer | $corporateId - holds corporate id
     * @param :array   | $billToAddress - holds array of bill-to address
     * @param :array   | $billToId - holds array of bill-to ids
     * @return boolean |$return - return true 
     */
    public function _updateBillToMapping($corporateId,$billToAddress,$billToId) {
        $updateValues=array();
        if(is_array($billToAddress) && count($billToAddress)>0)
        {
            $billtoAddressCount=count($billToAddress);
            for($billtoIndex=0;$billtoIndex<$billtoAddressCount;$billtoIndex++)
            {
                $updateValues['billto_name']=$billToAddress[$billtoIndex];
                //Functiona call to update billto address
                $result = $this->_OcommonDBO->_update('billto_mapping',$updateValues,'billto_id',$billToId[$billtoIndex]);
            }
        }
        else{
            $updateValues['billto_name']=$billToAddress;
            //Functiona call to update billto address
            $result = $this->_OcommonDBO->_update('billto_mapping',$updateValues,'billto_id',$billToId);
        }
        return $result;
    }
    
     /**
     * @Description :This function delete the bill-to address mapped for the input corporate id
     * @param :integer | $corporateId - holds corporate id
     * @return boolean|$return - return true or false
     */ 
     public function _deleteBillToMapping($corporateId,$billtoId) {
         //Functiona call to delete the mapped bill-to address
         //Query to delete the promocode details mapped for the corporate id
         $sqlDeleteBilltoMapping="DELETE FROM billto_mapping WHERE ";
         
         if($corporateId!=0){
                $sqlDeleteBilltoMapping .=  " r_corporate_id=".$corporateId." AND";
         }
         if($billtoId!=0){
                 $sqlDeleteBilltoMapping .=  " billto_id =".$billtoId." AND";
         }
         $sqlDeleteBilltoMapping=substr($sqlDeleteBilltoMapping,0,-4);
                  
         $result = $this->_Oconnection->query($sqlDeleteBilltoMapping);
            if(!$result){
                fileWrite('Error in query:'.$sqlDeleteBilltoMapping, 'SqlError', 'a+');
                $result = false;
            } else {
                 $result = $result->rowCount();
            }
         return $result;
     }
     
     /**
     * @Description :This function insert the promocode details 
     * @param :array | $promocodeDetails - holds array of promocode details
     * @return integer|$promocodeId -return the newly inserted promocode id
     */  
    public function _insertPromocodeDetails($promocodeDetails) {
        $promocodeId=$this->_OcommonDBO->_insert('dm_promo_code', $promocodeDetails);
        return $promocodeId;
    }
    
    /**
     * @Description :This function insert the promocode id based on corporate and airline 
     * @param :array | $promoMappingDetails - holds array of promocode mapping details
     * @param :integer | $corporateId - holds the corporate id
     * @param :integer | $airlineId - holds the airline id
     * @param :integer | $promocodeId - holds the promocode id
     * @return integer|$promocodeId -return the newly inserted promocode id
     */  
    public function _insertPromocodeMapping($corporateId,$promocodeId) {
        $insertValues=array(); 
        $insertValues['r_corporate_id']=$corporateId;
        $insertValues['r_promo_code_id']=$promocodeId;
        $result=$this->_OcommonDBO->_insert('promo_code_mapping', $insertValues);
        return $result;
    }
    
    /**
     * @Description :This function is used to update the promocode details based on the corporate
     * @param :integer | $corporateId - holds corporate id
     * @param :array   | $promocodeDetails - holds array of promocode details
     * @param :array   | $promocodeId - holds promocode id
     * @return boolean |$return - return true 
     */
    public function _updatePromoCodeMapping($corporateId,$promocodeId,$promocodeDetails) {
        
        //Functiona call to update promocode details
        $result = $this->_OcommonDBO->_update('dm_promo_code',$promocodeDetails,'promo_code_id',$promocodeId);
            
        return $result;
    }
    
    /*
     * @Description :This function delete the promocode details mapped for the input corporate id
     * @param :integer | $corporateId - holds corporate id
     * @param :integer | $airlineId - holds airline id
     * @return boolean|$return - return true or false
     */ 
     public function _deletePromocodeDetails($corporateId=0,$promocodeId=0) {
         //Query to delete the promocode details mapped for the corporate id
         $sqlPromocodeMapping="DELETE pcm.*,pcmap.*  FROM dm_promo_code pcm,promo_code_mapping pcmap WHERE ";
         
         if($corporateId!=0){
                $sqlPromocodeMapping .=  " pcmap.r_corporate_id=".$corporateId." AND";
         }
         if($promocodeId!=0){
                 $sqlPromocodeMapping .=  " pcm.promo_code_id =".$promocodeId." AND";
         }
         $sqlPromocodeMapping .=" pcmap.r_promo_code_id = pcm.promo_code_id";
         $result=$this->_OcommonDBO->_getResult($sqlPromocodeMapping);
         return $result;
     }
     public function _getBandDetails(){
         $_AfieldsArray=array('band_id','band_name');
        //Functiona call to get payment types
        return  $this->_OcommonDBO->_select('band_details', $_AfieldsArray);
     }
     /*
     * @Description :This function get the promocode details mapped for the corporate
     * @param :integer | $corporateId - holds corporate id
     * @return array|$return - return array of records
     */
    public function _getPromocodeDetails($corporateId=0,$promocodeId=0,$fieldsArray,$airlineId=0,$promoCode='',$bookingClass='') {
         
        if(!empty($fieldsArray)) {
            
            if(is_array($fieldsArray) && count($fieldsArray) > 0){
                $fieldsCSV = implode(", ", $fieldsArray);
            } else {
                $fieldsCSV = $fieldsArray;
            }
            //Query to get the billto-address mapped for the corporate id
            //Query to get the promocode details mapped for the corporate id and airline id
         $sqlPromoCode="SELECT ".$fieldsCSV."  FROM dm_promo_code pcm,promo_code_mapping pcmap,dm_airline arln WHERE ";
        }
        else{ 
        //Query to get the promocode details mapped for the corporate id and airline id
         $sqlPromoCode="SELECT promo_code_id,promo_code_value,airline_name,DATE_FORMAT(start_date,'%d-%b-%Y'),DATE_FORMAT(end_date,'%d-%b-%Y'),pcm.status"
                                ."  FROM dm_promo_code pcm,promo_code_mapping pcmap,dm_airline arln WHERE ";
        }
        
         
        if($corporateId!=0){
                $sqlPromoCode .=  " pcmap.r_corporate_id=".$corporateId." AND";
         }
         if($airlineId!=0){
                 $sqlPromoCode .=  " pcm.r_airline_id =".$airlineId." AND";
         }
         if($promocodeId!=0){
                 $sqlPromoCode .=  " pcm.promo_code_id =".$promocodeId." AND";
         }
         if($promoCode!=''){
                 $sqlPromoCode .=  " pcm.promo_code_value ='".$promoCode."' AND";
         }
         if($bookingClass!=''){
                 $sqlPromoCode .=  " pcm.booking_class ='".$bookingClass."' AND";
         }
         $sqlPromoCode .=  " pcmap.r_promo_code_id =pcm.promo_code_id AND pcmap.status='Y' AND arln.airline_id=pcm.r_airline_id";
         //$sqlPromoCode=substr($sqlPromoCode,0,-4);
         //Functiona call to get fetch the records 
         $result=$this->_OcommonDBO->_getResult($sqlPromoCode);
         return $result;
    }
    
    public function _getBandId($bandCode,$corporateId,$type) {
        
        $sql = "SELECT band_id FROM band_details WHERE band_name = '".$bandCode."' and r_corporate_id = ".$corporateId;

        $resultArray = $this->_OcommonDBO->_getResult($sql);
        
        if(empty($resultArray) && $type == "INSERT") {
            
            $input['band_name'] = $bandCode;
            $input['r_corporate_id'] = $corporateId;
            $input['status'] = "Y";
            $bandId = $this->_OcommonDBO->_insert('band_details', $input);
            
        } else {
            $bandId = $resultArray[0]['band_id'];
        }
        
        return $bandId;
    }
    
    public function _getCostCenterCodeId($costCenter,$corporateId) {
        
        $categoryIdArray = $this->_OcommonDBO->_select('dm_category', array('category_id'), 'category_name', 'cost_center_code');
        $categoryId = $categoryIdArray[0]['category_id'];
        
        if($categoryId=='' || $categoryId==0){
            return false;
        }
        
        $sql = "SELECT 
                        category_value_id 
                    FROM 
                        category_value 
                    WHERE 
                        r_category_id = ".$categoryId." 
                        and category_value = '".$costCenter."'";

        $resultArray = $this->_OcommonDBO->_getResult($sql);
        
        if(empty($resultArray)) {
            $input = array();
            $input['category_value'] = $costCenter;
            $input['r_category_id'] = $categoryId;
            $categoryValueId = $this->_OcommonDBO->_insert('category_value', $input);
        } else {
            $categoryValueId = $resultArray[0]['category_value_id'];
        }
        $sqlFact = "SELECT 
                        fact_category_id 
                    FROM 
                        fact_category
                    WHERE 
                        r_category_id = ".$categoryId." 
                        and category_value_id = '".$categoryValueId."' 
                        and r_corporate_id = ".$corporateId;

        $factResultArray = $this->_OcommonDBO->_getResult($sqlFact);
        
        if(empty($factResultArray)) {
            $input = array();
            $input['r_category_id'] = $categoryId;
            $input['r_category_value_id'] = $categoryValueId;
            $input['r_corporate_id'] = $corporateId;
            $input['status'] = "Y";
            $factCategoryId = $this->_OcommonDBO->_insert('fact_category', $input);
        } else {
            $factCategoryId = $factResultArray['fact_category_id'];
        }
        
        return $categoryValueId;
    }
    
    public function _getCorporateCurrency() {
        
        $sql= "SELECT 
                            cm.currency_id,
                            cm.currency_symbol
                    FROM 
                            corporate_details cd LEFT JOIN dm_currency cm
                            ON cd.r_currency_id = cm.currency_id
                    WHERE 
                            cd.r_corporate_id = ".$this->_IcorporateId;

        $result = $this->_OcommonDBO->_getResult($sql);
        
        return $result;
    }
    
    public function _getCorporatePurposeOfTravel() {
        
        $sql= "SELECT 
                            purpose_id,
                            purpose_text,
                            display_order
                    FROM 
                            purpose_of_travel
                    WHERE 
                            r_corporate_id = ".$this->_IcorporateId;

        $result = $this->_OcommonDBO->_getResult($sql);
        
        return $result;
    }
    
    public function _getPromoCode($promoCodeId) {
        $sql= "SELECT 
                            promo_code_value
                    FROM 
                            dm_promo_code
                    WHERE 
                            promo_code_id = ".$promoCodeId;

        $result = $this->_OcommonDBO->_getResult($sql);
        
        return $result;
    }
    
    
}
?>