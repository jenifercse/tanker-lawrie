<?php

/**
 * Employee family profile upload through csv file will be imported into the database tables here
 * @author Deepak P
 * @package Employee Family profile
 * @created 11-Mar-2019
 * @since v1.0
 * @copyright (c) 2019, Inifiniti Software Solutions Pvt. Ltd
 */

class employeeFamliyProfile{
	
	public function __construct(){
		//gender array maintain in key value pair
		$this->_AgenderOption  = array(1 =>'M' ,2 => 'F');		
	}

	//common function for employee family insertion flow
	public function _employeeFamliyData(){

        //define standard CSV Header
        $this->_standardCSVHeader();

        //get the CSV Data
        $this->_getCSVData();

        //validate the CSV header
        $this->_validateCSVHeader();

        //validate insert data
        $this->_validateInsertInfo();
	}

	//function for setting the CSV header
	public function _standardCSVHeader(){
        $this->_AcsvHeader = array('EMPLOYEE_CODE','TYPE_OF_FAMILY_RECORD','FIRST_NAME','LAST_NAME','GENDER_KEY','DATE_OF_BIRTH');
        return TRUE;
	}
        
	//function to get the CSV data
	public function _getCSVData(){

        $profileName = PROFILE_UPLOAD_PATH.$this->_IinputData['uploadFiles']['profileupload1'];
        $delimiter  = $this->_IinputData['delimiter'];
        $fh = fopen($profileName, "r");
        $i = 0;
        while(($data = fgetcsv($fh, 1000, $delimiter)) !== FALSE) {
            if($i == 0) {
                $this->_AheaderData = $data;
            } 
            else {
                $this->_AemployeeFamliyData[] = $data;
            }
            $i++;
        }
        if(empty($this->_AemployeeFamliyData)){
            $error = 'No data availabale to load.';
            $this->_SerrorInfo[] = array('error' => $error, 'error_line' => 1);
            throw new Exception('No data availabale to load.');
        }
        fclose($fh);
    }

	//function to validate the CSV header
	public function _validateCSVHeader(){

        //Check for the mandatory headers availability
        $result = array_diff($this->_AcsvHeader, $this->_AheaderData);
        if(!empty($result)) {
            $errorHeaders = implode(', ', $result);
            $error = 'Missing mandatory headers ' . $errorHeaders . ' should be added.';
            $this->_SerrorInfo[] = array('error' => $error, 'error_line' => 1);
        }

        //Check for the unnecessary headers
        $result = array_diff($this->_AheaderData, $this->_AcsvHeader);
        if (!empty($result)){
            $errorHeaders = implode(', ', $result);
            $error = 'Unnecessary headers ' . $errorHeaders . ' should be removed.';
            $this->_SerrorInfo[] = array('error' => $error, 'error_line' => 1);
        }

        //Check for the duplocate headers
        foreach (array_count_values($this->_AheaderData) as $key => $value) {
            ($value > 1) ? $dupeKeys[] = $key : '';
        }

        if (!empty($dupeKeys)) {
            $errorHeaders = implode(', ', $dupeKeys);
            $error = 'Headers ' . $errorHeaders . ' can not be repeated.';
            $this->_SerrorInfo[] = array('error' => $error, 'error_line' => 1);
        }
        return TRUE;
    }

    //function to validate the CSV data before insertion 
    public function _validateInsertInfo(){

    	$this->_OemployeeProfile =  new employeeProfile();
    	$this->_Oemployee = new employee();    	
    	$this->_OcommonDBO =  new commonDBO();

    	$lineNo = 1;

    	$keys = $this->_getInfoKeys();

    	foreach ($this->_AemployeeFamliyData as $key => $employeeData) {

    		$lineNo = $lineNo + 1;

    		$isEmpty = $this->_isEmptyValue($employeeData,$lineNo);
    		if($isEmpty){
                continue;
            }

            $this->_getVariableandDataInfo($employeeData, $keys); 

            //Validate first name
            $isValidFname = $this->_OemployeeProfile->_isValidName($this->_AempData['FIRST_NAME']);
            if (!$isValidFname) {
                $employeeData['error'] = 'Invalid first name';
                $this->_SerrorInfo[] = array('error' => $employeeData['error'], 'error_line' => $lineNo);
                $this->_AempInvalidData[] = $employeeData;
                continue;
            }

            //Validate last name
            $isValidFname = $this->_OemployeeProfile->_isValidName($this->_AempData['LAST_NAME']);
            if (!$isValidFname) {
                $employeeData['error'] = 'Invalid last name';
                $this->_SerrorInfo[] = array('error' => $employeeData['error'], 'error_line' => $lineNo);
                $this->_AempInvalidData[] = $employeeData;
                continue;
            }

            if(strlen($this->_AempData['FIRST_NAME']) < 2){
                $employeeData['error'] = 'First name should have more than 2 letters';
                $this->_SerrorInfo[] = array('error' => $employeeData['error'], 'error_line' => $lineNo);
                $this->_AempInvalidData[] = $employeeData;
                continue;
            }

            if(strlen($this->_AempData['LAST_NAME']) < 2){
                $employeeData['error'] = 'Last name should have more than 2 letters';
                $this->_SerrorInfo[] = array('error' => $employeeData['error'], 'error_line' => $lineNo);
                $this->_AempInvalidData[] = $employeeData;
                continue;
            }
           
            //check whether the employee exist or not for the employee code
            $employeeIdExit = $this->_Oemployee->_checkEmployeeByCode($this->_AempData['EMPLOYEE_CODE']);
            if($employeeIdExit > 0){

                //insert the family details info
            	$this->_insertEmployeeFamilyInfo($employeeIdExit,$this->_AempData);

                //update the employee dependent details
                $this->_updateEmployeeDependentDetails();
            	
            	$this->_IinsProfileNos++;
            }
            else{
            	$this->_SerrorInfo[] = array('error' => 'INVALID EMPLOYEE CODE', 'error_line' => $lineNo);
            	$this->_AempInvalidData[] = $this->_AempData['EMPLOYEE_CODE'];
            }
    	}
    	return TRUE;

    }
    //function to insert the employee family info

    public function _insertEmployeeFamilyInfo($employeeId,$famliyInfo){
        //change the dob
        $dob = date_create($this->_AempData['DATE_OF_BIRTH']);  
        $dateOfBirth = date_format($dob,"Y-m-d");
    	if($this->_AempData['TYPE_OF_FAMILY_RECORD'] != 'X'){
            if(INDEXNAME == 'personal'){ 
                $bookingType =  $_SESSION['userApplicationSettings']['BOOKING_WISE_FAMILY_DEPENDENT_DETAILS'] == 'YES' ? 0 : 2;
            }else{
                $bookingType =  $_SESSION['userApplicationSettings']['BOOKING_WISE_FAMILY_DEPENDENT_DETAILS'] == 'YES' ? 1 : 2;
            }
            
            $checkFamilyDetailsExits = $this->_checkFamilyDetailsExits($employeeId,$this->_AempData['TYPE_OF_FAMILY_RECORD'],$this->_AempData['OBJECT_IDENTIFICATION']);
            if(empty($checkFamilyDetailsExits)){
        		$EmployeeFamliyData = array(
    	            'r_employee_id' => $employeeId,
                     'booking_type' => $bookingType,
    	            'famsa' => $this->_AempData['TYPE_OF_FAMILY_RECORD'],
    	            'first_name' => $this->_AempData['FIRST_NAME'],
    	            'last_name' => $this->_AempData['LAST_NAME'],
    	            'gender' => $this->_AgenderOption[$this->_AempData['GENDER_KEY']],
    	            'dob' => $dateOfBirth,
                    'age' => $this->_Oemployee->_getAge($this->_AempData['DATE_OF_BIRTH']),
    	            'passenger_type' => $this->_Oemployee->_getPaxType($this->_AempData['DATE_OF_BIRTH']),
    	            'created_date' => date('Y-m-d H:i:s'),
    	            'updated_date' => date('Y-m-d H:i:s')
            	);
                ($this->_AempData['OBJECT_IDENTIFICATION'] && $this->_AempData['OBJECT_IDENTIFICATION'] != '') ? $EmployeeFamliyData['objps'] = $this->_AempData['OBJECT_IDENTIFICATION'] : $EmployeeFamliyData['objps'] = 0;
                $this->_Oemployee->_insertEmployeeFamilyDetails($EmployeeFamliyData);
            }
            else{
                $EmployeeFamliyData = array(
                    'r_employee_id' => $employeeId,
                    'famsa' => $this->_AempData['TYPE_OF_FAMILY_RECORD'],
                    'objps' => $this->_AempData['OBJECT_IDENTIFICATION'],
                    'first_name' => $this->_AempData['FIRST_NAME'],
                    'last_name' => $this->_AempData['LAST_NAME'],
                    'gender' => $this->_AgenderOption[$this->_AempData['GENDER_KEY']],
                    'dob' => $dateOfBirth,
                    'age' => $this->_Oemployee->_getAge($this->_AempData['DATE_OF_BIRTH']),
                    'passenger_type' => $this->_Oemployee->_getPaxType($this->_AempData['DATE_OF_BIRTH']),
                    'created_date' => date('Y-m-d H:i:s'),
                    'updated_date' => date('Y-m-d H:i:s')
                );
                $this->_Oemployee->_updateEmployeeFamilyDetails($EmployeeFamliyData,$checkFamilyDetailsExits['familyId']);
            }
    	}
    	return TRUE;
    }

    //function to check the whether csv has data to insert or not
    public function _isEmptyValue($employeeData, $lineNo) {
        $emptyKeys = array_keys($employeeData, "");
        $errorKeys = array_intersect($this->_AcsvHeader, $emptyKeys);
        if (!empty($errorKeys)) {
            foreach ($errorKeys as $emptyKey) {
                $erroHeaderName[] = $this->_AheaderData[$emptyKey];
            }
            $errorHeaders = implode(',', $erroHeaderName);
            unset($erroHeaderName);
            //error message
            $employeeData['error'] = 'Invalid data. ' . $errorHeaders . ' values are empty';
            $this->_SerrorInfo[] = array('error' => $employeeData['error'], 'error_line' => $lineNo);
            //$this->_SerrorLine[] = $lineNo;
            $this->_AempInvalidData[] = $employeeData;
            return TRUE;
        }
        return FALSE;
    }


    //get variable and data info of the header
    public function _getVariableandDataInfo($employeeData, $keys){

    	foreach ($this->_AcsvHeader as $key => $mandatoryField) {
            $this->_AUploadedHeader[] = $mandatoryField;
            $this->_AempData[$mandatoryField] = $employeeData[$keys[$mandatoryField]];
        }
        return TRUE;
    }

    //get info header key
    public function _getInfoKeys(){

        $flipHeader = array_flip($this->_AheaderData); //here the the keys and values will be interchanged
        //Mandatory header data mapping
        foreach ($this->_AcsvHeader as $keyDef => $mandatoryField) {
            $keys[$mandatoryField] = $flipHeader[$mandatoryField];
        }
        return $keys;
    }

    public function _updateEmployeeDependentDetails(){
        return true;
    }

    // to check the family detail already exist or not
    public function _checkFamilyDetailsExits($employeeId,$famsa){
        $sql = "SELECT 
                    efd.r_employee_id,efd.first_name,efd.last_name,efd.employee_family_details_id
                FROM
                    employee_family_details efd
                WHERE 
                    efd.r_employee_id = " .$employeeId ." AND efd.famsa = " .$famsa;
        $returnValue = "";
        $result = $this->_OcommonDBO->_getResult($sql); 
        foreach ($result as $key => $value) {
            $paxName = trim($value['first_name']) . trim($value['last_name']);
            $checkName = trim($this->_AempData['FIRST_NAME']) . trim($this->_AempData['LAST_NAME']);
            if($checkName == $paxName){      
                $returnValue['familyId'] = $value['employee_family_details_id'];
            }
           
        }
        return $returnValue;
    }
}
?>