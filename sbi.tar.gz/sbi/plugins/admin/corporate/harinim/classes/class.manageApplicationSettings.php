<?php
/* ******************************************************************************************
 * @File             : class.manageApplicationSettings.php
 * @Description      : This file is used manage application settings query in one class file
 * @Author           : SatheesKumar . N
 * @Created Date     : 21/08/2017
 * *******************************************************************************************/

//Include the depentencies for this class
fileRequire('classes/class.commonDBO.php');

class manageApplicationSettings {

    public function __construct() {
        $this->_OcommonDBO = new commonDBO();
        $this->_AtravelMode = array('0'=>'All','1'=>'Domestic','9'=>'International');
        $this->_Atrip = array('0'=>'All','1'=>'One_Way','2'=>'Round_Trip','3'=>'Multi_City');
    }

    /*
     * @Description  This method is used to get application settings group name
     * @date|21.08.2017 
     * @author|SatheesKumar . N
     */
    public function _getApplicationSettingGroupName() {
        
        //Query for get all group name
        $sql = "SELECT 
        		* 
		FROM 
			dm_application_setting_group_name 
                WHERE 
                        display_status = 'Y'";
        
        //Return the query result
        return is_array($this->_OcommonDBO->_getResult($sql)) ? $this->_OcommonDBO->_getResult($sql) : array('NIL') ;	 
    }
    
    /**
     * gets the user types for user type drop down
     * @return type
     * @Author Vishwa Raj
     */
    public function _getUserType(){
       return $result = $this->_OcommonDBO->_select("dm_user_type","*");
    }
    
    /**
     * gets the travel mode for travel mode drop down
     * @return type
     * @Author :- VishwaRaj
     */
    public function _getAvailableTravelMode(){
        return $result = $this->_OcommonDBO->_select("dm_travel_mode","*");
    }
    
    /**
     * gets the form type
     * @return type
     * @Author Vishwa Raj
     */
    public function _getFormType(){
        return $result = $this->_OcommonDBO->_select("dm_form","*");
    }
    
    /**
     * gets the form type
     * @return type
     * @Author SatheesKumar . N
     */
    public function _checkTravelModeTripTypeMapping($input){
        
        //Query for check travel mode trip type
        $sql = "SELECT
                    asvd.setting_value,
                    fas.r_application_settings_value_id,
                    fas.default_value,
                    fas.r_agency_id,
                    fas.r_corporate_id,
                    fas.r_user_type_id,
                    fas.r_travel_mode_id,
                    fas.r_trip_id 
                FROM 
                    application_setting_value_details asvd,
                    fact_application_setting fas 
                WHERE 
                    asvd.r_application_setting_name_id = 0 
                    AND fas.r_application_settings_value_id = asvd.application_settings_value_id 
                    AND fas.r_agency_id  = ".$input['agencyId']."
                    AND fas.r_corporate_id = ".$input['corporateId']." 
                    AND fas.r_user_type_id = ".$input['userTypeId'];
                    
                if(isset($input['travelModeId'])) {
                    $sql = $sql." GROUP BY fas.r_trip_id ORDER BY fas.application_setting_id";
                } else {
                    $sql = $sql." GROUP BY asvd.setting_value ORDER BY fas.application_setting_id";
                }

        $result = $this->_OcommonDBO->_getResult($sql);
        
        //Check array is empty
        if(is_array($result)==false) {
            $this->_mapTravelMode($input);
            
            $result = $this->_OcommonDBO->_getResult($sql);
        }
        
        //Set trip type
        if(isset($input['travelModeId'])) {
            $tripType = array('0'=>'All','1'=>'One Way','2'=>'Round Trip','3'=>'Multi City');
            
            foreach($result AS $key => $value) {
                $result[$key]['trip_type_name'] = $tripType[$value['r_trip_id']];
            }
        }
        
        return $result;
    }
    
    /**
     * Map the travel mode to fare profile settings to new corporate
     * @params $input array
     * @author SATHEESKUMAR
     */
    function _mapTravelMode($input) {
        
                //Query for map travle mode to new corporate
                $sql = "INSERT INTO 
                            fact_application_setting 
                                (
                                    SELECT
                                        0,
                                        fas.r_application_settings_value_id,
                                        ".$input['corporateId'].",
                                        ".$input['agencyId'].",
                                        ".$input['userTypeId'].",
                                        0,
                                        'Y',
                                        '',
                                        'Y',
                                        fas.r_travel_mode_id,
                                        fas.r_trip_id 
                                    FROM 
                                        application_setting_value_details asvd,
                                        fact_application_setting fas 
                                    WHERE 
                                        asvd.r_application_setting_name_id = 0 
                                        AND fas.r_application_settings_value_id = asvd.application_settings_value_id 
                                        AND fas.r_agency_id  = 0 
                                        AND fas.r_corporate_id = 0   
                                        AND fas.r_user_type_id = 0 
                                        ORDER BY fas.r_travel_mode_id,fas.default_value, fas.r_trip_id, fas.r_user_type_id
                                )";

                $this->_OcommonDBO->_getResult($sql);
    }
    
    /**
     * Chnage status of fare profile settings access
     * @params $fareProfileSettingId int,$fareProfileSettingStatus char
     * @author SATHEESKUMAR
     */
    public function _changeFareProfileSettingStatus($fareProfileSettingId,$fareProfileSettingStatus) {
        
        //Query for get activation settings for specified settings
        $sql = "UPDATE 
                    dm_fare_profile_setting 
                SET 
                    status='".$fareProfileSettingStatus."' 
                WHERE 
                    fare_profile_setting_id = ".$fareProfileSettingId;
        
        $this->_OcommonDBO->_getResult($sql);
        
    }
    
    /**
     * Get the fare profile settings list for display
     * @params $workingMode string,$fareSettingId int,$agencyId int,$corporateId int
     * @author SATHEESKUMAR
     */
    public function _getApplicationSettingsList($workingMode,$fareSettingId,$agencyId=0,$corporateId=0,$bookingType=0) {
        
        //Query for get fare profile settings list
        $sql = "SELECT 
                    dfps.fare_profile_setting_id,
                    dfps.fare_profile_setting_name,
                    dfps.r_agency_id,
                    dfps.r_corporate_id,
                    dfps.status,
                    CASE dfps.application_type
                        WHEN 'C' THEN 'Corporate'
                        WHEN 'P' THEN 'Personal'
                    END AS booking_type,
                    fpum.user_mapping_type,
                    fpum.user_mapping_type_id,
                    fpttm.r_travel_mode_id,
                    fpttm.trip_type_id,
                    CASE fpttm.trip_type_id 
                        WHEN 1 THEN 'One Way' 
                        WHEN 2 THEN 'Round Trip' 
                        WHEN 3 THEN 'Multi City' 
                        ELSE 'NULL'
                    END AS trip_type, 
                    da.agency_name, 
                    dc.corporate_name, 
                    dtm.travel_mode  
                FROM 
                    dm_fare_profile_setting dfps 
                    INNER JOIN fare_profile_user_mapping fpum ON fpum.r_fare_profile_setting_id = dfps.fare_profile_setting_id 
                    INNER JOIN fare_profile_travel_type_mapping fpttm ON fpttm.r_fare_profile_setting_id = fpum.r_fare_profile_setting_id
                    LEFT JOIN dm_travel_mode dtm ON dtm.travel_mode_id = fpttm.r_travel_mode_id 
                    LEFT JOIN dm_agency da ON da.dm_agency_id = dfps.r_agency_id 
                    LEFT JOIN dm_corporate dc ON dc.corporate_id = dfps.r_corporate_id
                WHERE ";

        //if index name is set as personal fetch fare profile settings with application type = P
        $sqlAppType = ($bookingType == 'Corporate') ? " AND application_type = 'C'" : " AND application_type = 'P'";
    
        //Set join based on working type
        if($workingMode == 'FARE_SETTING_ID') {
            $sql .= "   dfps.fare_profile_setting_id = ".$fareSettingId."
                        AND fpttm.r_fare_profile_setting_id = dfps.fare_profile_setting_id ".$sqlAppType ."
                        ORDER BY dfps.r_corporate_id,dfps.r_corporate_id,fpttm.r_travel_mode_id,fpttm.trip_type_id";
        } elseif($workingMode == 'FARE_PROFILE_FILTER') {
            $sql = ($agencyId!=0) ? $sql." dfps.r_agency_id = ".$agencyId." AND " : $sql ;
            $sql = ($corporateId!=0) ? $sql." dfps.r_corporate_id = ".$corporateId." AND " : $sql ;
            $sql .= "   fpttm.r_fare_profile_setting_id = dfps.fare_profile_setting_id ".$sqlAppType;
            $sql .= "    ORDER BY dfps.r_corporate_id,dfps.r_corporate_id,fpttm.r_travel_mode_id,fpttm.trip_type_id";
        } else {
            $agencyId    = $_SESSION['agencyId'];
            $corporateId = $_SESSION['corporateId'];
            $groupId     = $_SESSION['groupId'];
            
            if($groupId=='1' || $groupId=='6') {
                $sql .= "   fpttm.r_fare_profile_setting_id = dfps.fare_profile_setting_id ".$sqlAppType."
                            ORDER BY dfps.r_corporate_id,dfps.r_corporate_id,fpttm.r_travel_mode_id,fpttm.trip_type_id";
            } elseif($groupId=='2' || $groupId=='7') {
                $sql .= "   dfps.r_agency_id = ".$agencyId."
                            AND dfps.r_corporate_id = ".$corporateId." 
                            AND fpttm.r_fare_profile_setting_id = dfps.fare_profile_setting_id ".$sqlAppType."
                            ORDER BY dfps.r_corporate_id,dfps.r_corporate_id,fpttm.r_travel_mode_id,fpttm.trip_type_id";
            } elseif($groupId=='3') {
                $sql .= "   dfps.r_agency_id = ".$agencyId."
                            AND fpttm.r_fare_profile_setting_id = dfps.fare_profile_setting_id ".$sqlAppType."
                            ORDER BY dfps.r_corporate_id,dfps.r_corporate_id,fpttm.r_travel_mode_id,fpttm.trip_type_id";
            }
            
        }

        $result = $this->_OcommonDBO->_getResult($sql);
        //Return the results
        return (is_array($result)==true) ? $result : "";
        
    }
    
    /**
     * Get the fare profile settings list and process the array for display settings
     * @params $workingMode string,$fpsList array
     * @author SATHEESKUMAR
     */
    public function _prepareFareProfileList($fpsList,$workingMode) {
        //Set array
        $editValues = array();
        //Process given array to set values
        foreach($fpsList AS $key => $value) {
            $fareProfileSettingId = $value['fare_profile_setting_id'];
            $editValues[$fareProfileSettingId]['fareProfileSettingId'] = $value['fare_profile_setting_id'];
            $editValues[$fareProfileSettingId]['corporateId'] = $value['r_corporate_id'];
            $editValues[$fareProfileSettingId]['corporateName'] = ($value['corporate_name']=="") ? 'All' : $value['corporate_name'] ;
            $editValues[$fareProfileSettingId]['agencyId'] = $value['r_agency_id'];
            $editValues[$fareProfileSettingId]['agencyName'] = ($value['agency_name']=="") ? 'All' : $value['agency_name'] ;
            $editValues[$fareProfileSettingId]['fareSettingName'] = $value['fare_profile_setting_name'];
            $editValues[$fareProfileSettingId]['status'] = $value['status'];
            $editValues[$fareProfileSettingId]['booking_type'] = $value['booking_type'];
            $editValues[$fareProfileSettingId]['flowType'] = ($value['user_mapping_type']=='U') ? 'User Type' : (($value['user_mapping_type']=='A') ? 'Aggregate' : 'Default') ;
            $editValues[$fareProfileSettingId]['flowTypeId'] = ($value['user_mapping_type']=='U') ? 1 : (($value['user_mapping_type']=='A') ? 2 : 0) ;
            $editValues[$fareProfileSettingId]['tripType'][$value['r_travel_mode_id']][] = $value['trip_type_id'];
            $editValues[$fareProfileSettingId]['travelModeIds'][] = $value['r_travel_mode_id'];
            $editValues[$fareProfileSettingId]['travelMode'][] = array('travelModeId'=>$value['r_travel_mode_id'],'traveModeName'=>$value['travel_mode']);
            $editValues[$fareProfileSettingId]['appliedTo'][$value['r_travel_mode_id']][$value['travel_mode']][$value['trip_type_id']] = $value['trip_type'];
            $editValues[$fareProfileSettingId]['tripTypeIds'][] = array('tripTypeId'=>$value['trip_type_id'],'tripTypeName'=>$value['trip_type']);
            $editValues[$fareProfileSettingId]['category'][] = $value['user_mapping_type_id'];
            $travelKey = ($value['r_travel_mode_id']==1) ? 'domestic' : 'international' ;
            $editValues[$fareProfileSettingId][$travelKey][] = $value['trip_type'];
        }
        //Set unique array keys
        $uniqueFieldKeys = array('travelModeIds','travelMode','tripTypeIds','category','domestic','international');

        //Remove duplications
        foreach($editValues AS $key => $value) {
            foreach($uniqueFieldKeys AS $dupKey => $dupValue) {
                $editValues[$key][$dupValue] =  array_values($this->_removeDuplicatesArrayValue($value[$dupValue])); 
            }
        }
        //get array unique to given array
        $fpsList = $this->_array_key_unique($fpsList, 'fare_profile_setting_id');

        foreach($fpsList AS $key => $value) {
            $fpsList[$key]['editValue'] = $editValues[$fpsList[$key]['fare_profile_setting_id']];
        }
        return ($workingMode == "FARE_SETTING_ID") ? $fpsList : $editValues ;
        
    }
    
    /**
     * Remove duplicates values from array
     * @params $arr array
     * @author SATHEESKUMAR
     */
    public function _removeDuplicatesArrayValue($arr) {
        
        return array_unique($arr,SORT_REGULAR);
        
    }
    
    /**
     * Array unique to given array
     * @params $arr array, $key string
     * @author SATHEESKUMAR
     */
    public function _array_key_unique($arr, $key) {
        
        //Set array
        $uniquekeys = array();
        $output     = array();
        
        //Set unique items
        foreach ($arr as $item) {
            if (!in_array($item[$key], $uniquekeys)) {
                $uniquekeys[] = $item[$key];
                $output[]     = $item;
            }
        }
        
        //return results
        return $output;
        
    }
    
    /**
     * Get fare profile settings id based agencyid and corporateid
     * @params $agencyId int,$corporateId int
     * @author SATHEESKUMAR
     */
    public function _getFareSettingId($agencyId=0,$corporateId=0,$bookingType){
        
        //Query for get fare profile settings id

        $appType = ($bookingType == 'Personal') ? 'P' : 'C';

        $sql ="SELECT 
                    fare_profile_setting_id 
               FROM 
                    dm_fare_profile_setting 
               WHERE 
                    r_agency_id = ".$agencyId."
                    AND r_corporate_id = ".$corporateId." AND application_type = '".$appType."' LIMIT 1";

        $result = $this->_OcommonDBO->_getResult($sql);
        
        return count($result) > 0 ? $result[0]['fare_profile_setting_id'] : 1;
        
    }
    
   /*
    * @Description  This method is used to get application settings list display
    * @date|22.08.2017 
    * @author|SatheesKumar . N
    */
    public function _getApplicationSettings($fareSettingId,$agencyId=0,$corporateId=0,$bookingType){
       
        //Query for get application settings
        $sql = "SELECT 
                    dfps.r_corporate_id,
                    dfps.r_agency_id,
                    dasgn.display_name AS group_name,
                    dasn.display_name AS setting_name,
                    asvd.display_name AS setting_value,
                    dasgn.group_name AS json_group_name,
                    dasn.setting_name AS json_setting_name,
                    asvd.setting_value AS json_setting_value,
                    dasn.input_type,
                    dasn.mandatory_status,
                    asvd.application_setting_value_id,   
                    ffps.default_value, 
                    ffps.text_box_value,
                    dasn.application_setting_name_id,
                    dfps.fare_profile_setting_id,
                    ffps.fact_fare_profile_setting_id
                    
                FROM 
                    dm_fare_profile_setting dfps,
                    fact_fare_profile_setting ffps,
                    application_setting_value_details asvd,
                    dm_application_setting_name dasn,
                    dm_application_setting_group_name dasgn 
                WHERE     
                    dfps.fare_profile_setting_id = ".$fareSettingId." 
                    AND ffps.r_fare_profile_setting_id = dfps.fare_profile_setting_id 
                    AND asvd.application_setting_value_id = ffps.r_application_setting_value_id 
                    AND asvd.display_status = 'Y'
                    AND dasn.application_setting_name_id = asvd.r_application_setting_name_id 
                    AND dasn.display_status = 'Y'";
        
        if($agencyId!=0 && $corporateId!=0) {
            $sql .= " AND dasn.r_application_setting_group_id = 10 ";
        } 

        //if index name is set as personal fetch fare profile settings with application type = P
        $sql .= ($bookingType == 'Personal') ? " AND dfps.application_type = 'P'" : " AND dfps.application_type = 'C'";
        
        $sql .= "   AND dasgn.application_setting_group_name_id = dasn.r_application_setting_group_id 
                    AND dasgn.display_status = 'Y'
                    ORDER BY dasgn.display_order, dasn.display_order, asvd.display_order";
        

        $result = $this->_OcommonDBO->_getResult($sql);
        
        //return results
        return count($result) > 0 ? $result : FALSE;
    }
    
    /**
     * Check activation status of fare profile settings
     * @params $input array
     * @author SATHEESKUMAR
     */
    public function _checkActivationStatus($input) {
        
        //query for get default value
        $sql = "SELECT 
                        default_value 
                FROM 
                        fact_application_setting 
                WHERE 
                        r_agency_id = ".$input['agencyId']."
                        AND r_corporate_id = ".$input['corporateId']."
                        AND r_user_type_id = ".$input['userTypeId']."
                        AND r_travel_mode_id = ".$input['travelModeId']." 
                        AND r_trip_id = ".$input['tripTypeId'];
        
        $result = $this->_OcommonDBO->_getResult($sql);
        
        //return results
        if($result[0]['default_value']=='N') {
            return true;
        } else {
            return false;
        }
        
    }
    
    /**
     * Get fare settings applied trip type
     * @params $input array
     * @author SATHEESKUMAR
     */
    public function _getAllAppliedTripTypes($input) {
        
        //Set array
        $settingArray = $this->_getFareProfileSettingFromFile($input['corporateId']."_".$input['userTypeId']);
        $travelType = $this->_AtravelMode[$input['travelModeId']];
        foreach($this->_Atrip AS $key => $tripType) {
            if($tripType!='All') {
                if($settingArray[$travelType][$tripType]['Working_Type']=='All') {
                    $settings[] = $key;
                }
            }
        }
        
        //return results
        return $settings;
    }
    
    /**
     * Get travel mode based application settings values
     * @params $travelModeId int
     * @author SATHEESKUMAR
     */
    public function _getTravelModeIdInValueDetails($travelModeId) {
        //set travel mode
        $applicationValueDetails = array('1'=>'Domestic - Air','9'=>'International - Air');
        
        //query for get application_settings_value_id
        $sql = "SELECT  
                        application_settings_value_id 
                FROM 
                        application_setting_value_details 
                WHERE 
                        setting_value = '".$applicationValueDetails[$travelModeId]."' 
                        AND r_application_setting_name_id = 0";
        
        $result = $this->_OcommonDBO->_getResult($sql);
        
        //retun results
        return isset($result[0]['application_settings_value_id']) ? $result[0]['application_settings_value_id'] : '0' ;
        
    }
    
    /**
     * Get activation status for fact application type
     * @params $input array
     * @author SATHEESKUMAR
     */
    public function _getActivationStatus($input) {
        //set activation status
        $activationStatus = "N";
        if($input['processType']=='Enable') {
            $activationStatus = "Y";
        }
        
        //set trip type
        if($input['tripTypeId']==0) {
            $updateTripType = $this->_getAllAppliedTripTypes($input);
            $updateTripType[] = 0;
        } else {
            $updateTripType[] = $input['tripTypeId'];
        }
        
        //set application value details id
        $applicationValueDetailsId = $this->_getTravelModeIdInValueDetails($input['travelModeId']);
        
        //Update activation status of application settings
        foreach($updateTripType AS $key=>$tripTypeId) {
            $sql = "UPDATE 
                            fact_application_setting 
                    SET 
                            default_value = '".$activationStatus."' 
                    WHERE 
                            r_agency_id = ".$input['agencyId']."
                            AND r_corporate_id = ".$input['corporateId']."
                            AND r_user_type_id = ".$input['userTypeId']."
                            AND r_travel_mode_id = ".$input['travelModeId']." 
                            AND r_trip_id = ".$tripTypeId."
                            AND r_application_settings_value_id = ".$applicationValueDetailsId;

            $result = $this->_OcommonDBO->_getResult($sql);
        }
        
        //set array for fare profile settings
        $fileName = $input['corporateId']."_".$input['userTypeId'];
        if(file_exists($this->_prepareFilePath($fileName))) {
            if($input['tripTypeId']>=1 && $activationStatus=='Y') {
                $input['agency_Id']=$input['agencyId'];
                $input['corporate_id']=$input['corporateId'];
                $input['user_type']=$input['userTypeId'];
                $this->_getDataForJson($input);
            }
            $preparedSetting = $this->_getFareProfileSettingFromFile($fileName);
            $travelKey = $this->_AtravelMode[$input['travelModeId']];
            $tripKey = $this->_Atrip[$input['tripTypeId']];
            foreach($updateTripType AS $updateTripTypeId) {
                $preparedSetting[$travelKey][$this->_Atrip[$updateTripTypeId]]['Enable'] = $activationStatus;
            }
            $preparedSetting['Domestic']['Enable'] = $this->_changeTravelModeActivationStatus($preparedSetting,'Domestic');
            $preparedSetting['International']['Enable'] = $this->_changeTravelModeActivationStatus($preparedSetting,'International');
            $this->_writeJsonFile($preparedSetting,$fileName,$input['bookingType']);
        }
    }
    
    /**
     * Travel mode based activation settings for fare profile settings
     * @params $preparedSetting array,$travelMode array
     * @author SATHEESKUMAR
     */
    public function _changeTravelModeActivationStatus($preparedSetting,$travelMode) {
        //return travel mode activation
        if($preparedSetting[$travelMode]['All']['Enable']=='Y' || $preparedSetting[$travelMode]['One_Way']['Enable']=='Y' || $preparedSetting[$travelMode]['Round_Trip']['Enable']=='Y' || $preparedSetting[$travelMode]['Multi_City']['Enable']=='Y') {
            return 'Y';
        } else {
            return 'N';
        }
    }
    
    /**
     * Get working type based on travel mode to fare profile settings
     * @params $input array
     * @author SATHEESKUMAR
     */
    public function _getWorkingType($input) {
        //get settings array
        $settingArray = $this->_getFareProfileSettingFromFile($input['corporateId']."_".$input['userTypeId']);
        foreach($this->_AtravelMode AS $travelMode) {
            if($travelMode!='All') {
                foreach($this->_Atrip AS $tripType) {
                    if($tripType!='All') {
                        $preparedArray[$travelMode][$tripType] = $this->_getWorkingTypeFromArray($settingArray,$travelMode,$tripType);
                    }
                }
            }
        }
        //return results
        return $preparedArray;
    }
    
    /**
     * Get working type based of fare profile settings based given inputs
     * @params $settingArray array,$travelType ,$tripType
     * @author SATHEESKUMAR
     */
    public function _getWorkingTypeFromArray($settingArray,$travelType,$tripType) {
        //retrun results
        return ($settingArray[$travelType][$tripType]['Enable']=='N') ? 'Disabled' : $settingArray[$travelType][$tripType]['Working_Type'];
    }
    
    /**
     * Read fare profile settings from created file
     * @params $fileName string
     * @author SATHEESKUMAR
     */
    public function _getFareProfileSettingFromFile($fileName,$bookingType) {
        //return results
         $_OauthToken = new authToken();
         $purifiedFilePath = $_OauthToken->_purifyInputData($fileName); 
         return json_decode(file_get_contents($this->_prepareFilePath($purifiedFilePath,$bookingType)), true);
    }
    
    /**
     * Prepare absolute file path for fare profile settings
     * @params $fileName string
     * @author SATHEESKUMAR
     */
    public function _prepareFilePath($fileName,$bookingType) {
        //return results
        //get path based on application type
        $fareProfilePath = ($bookingType == 'Corporate') ? FARE_PROFILE_SETTING_JSON_FILE_PATH : FARE_PROFILE_SETTING_JSON_FILE_PATH_PER;
        return APPLICATION_BASE_PATH.$fareProfilePath.$fileName;
    }
        
    /**
     * This method is used to get the application_settings name info
     * params $applicationSettingsNameId int
     * return|array:$result
     * author Karthika.M
     */
    public function _getApplicationSettingConfigNameInfo($applicationSettingsNameId){
        
        $sql = "SELECT
                    dasn.setting_name,
                    dasn.r_application_setting_group_id,
                    dasgn.group_name,
                    dasn.display_name
                FROM
                    dm_application_setting_name dasn
                    INNER JOIN dm_application_setting_group_name dasgn ON dasn.r_application_setting_group_id = dasgn.application_setting_group_name_id 

                WHERE 
                    dasn.application_setting_name_id = ".$applicationSettingsNameId;
        return $this->_OcommonDBO->_getResult($sql)[0];
    }
    
    
    /**
     * forming json data on click of apply changes in manage fare settings
     * @param type $input
     * @return type
     * @Author:- SATHEESKUMAR
     */
    public function _getDataForJson($input){
        $defaultValueId = $input['booking_type'] != 'Personal' ? 1 : 2;
        //get activation status
        $defaultValue = $this->_getApplicationSettings($defaultValueId,0,0,$input['booking_type']);
        
        //get the corporate values
        $corporateValue = $this->_getApplicationSettings($input['fare_profile_setting_id'],0,0,$input['booking_type']);
        
        //get general values
        $generalValue = $this->_getApplicationSettings($input['fare_profile_setting_id'],$input['agency_id'],$input['corporate_id'],$input['booking_type']);
        $corporateValue = (is_array($generalValue)) ? array_merge($corporateValue, $generalValue) : $corporateValue ; 
        
        //set the corporate fare profile settings
        if(isset($corporateValue) && $corporateValue[0] != 'NIL'){
            $inputTypeArray = array("IB","RBI","CP","TB","CBI","IWF","LS", "ED",'IBM');
            foreach ($corporateValue as $key => $value) {
                foreach ($defaultValue as $keySet => $valueSet) {
                    if($value['application_setting_value_id'] == $valueSet['application_setting_value_id']){
                       $defaultValue[$keySet]['default_value'] = $value['default_value'];
                       if(in_array($value['input_type'], $inputTypeArray)){
                           $defaultValue[$keySet]['text_box_value'] = $value['text_box_value'];
                       }
                    }
                   
                }
                
            }
        }
        
        //set the file name
        $fileName = str_replace(' ', '_',$input['fare_profile_settings_name']);
        //set the fare profile settings array
        $fareProfileSettings = $this->_formArrayForJson($defaultValue,$fileName,$input);
        $bookingType = $input['booking_type'];

        //write json file with main settings
        $this->_writeJsonFile($fareProfileSettings,$fileName.".json",$bookingType);
        //write json file with general settings
        $this->_writeJsonFileForGeneralSettings($input['agency_id'],$input['corporate_id'],$input['fare_profile_setting_id'],$fareProfileSettings,$bookingType);

        $this->_AfinalResponse = "success";
        return $defaultValue;
    }
    
    /**
     * Write json file as contain with settings to agency id and corporate id
     * @params $agencyId int,$corporateId int,$fareProfileSettingId int,$fareProfileSettings array
     * @author SATHEESKUMAR
     */
    public function _writeJsonFileForGeneralSettings($agencyId,$corporateId,$fareProfileSettingId,$fareProfileSettings,$bookingType) { 


        //check the agency and corporate id
        if($agencyId==0 && $corporateId==0) {
            return true;
        }
        $applicationType = ($bookingType == 'Personal') ? 'P' : 'C';
        $getCorporateBasedSettings = $this->_OcommonDBO->_select('dm_fare_profile_setting', 'fare_profile_setting_name', array('r_agency_id','r_corporate_id','application_type'), array($agencyId,$corporateId,$applicationType));
        
        //write json file with general settings
        if(is_array($getCorporateBasedSettings)) {
            foreach($getCorporateBasedSettings AS $key => $value) {
                $fileName = str_replace(' ', '_',$value['fare_profile_setting_name']).".json";
                
                $jsonData = $this->_getFareProfileSettingFromFile($fileName,$bookingType);
                $jsonData['General_configurations'] = $fareProfileSettings['General configurations'];
                $this->_writeJsonFile($jsonData,$fileName,$bookingType);

            }
        }
        
    }
    
    /**
     * form array for json data with respect to (RB<CB<RBI<CBI)
     * @param type $applicationSettings
     * @return type
     * @Author SATHEESKUMAR
     */
    public function _formArrayForJson($applicationSettings,$fileName,$input){
         foreach($applicationSettings AS $key => $value) {
             // check for radio button
            if($value['input_type']=='RB'){
                // check if the default value is yes/no
                if($value['json_setting_value']=='Yes' || $value['json_setting_value']=='No'){
                    if($value['json_setting_value']=='Yes' && $value['default_value'] == 'Y'){
                         $appSettings[$value['json_group_name']][$value['json_setting_name']]['status'] = 'Y';
                    }else if($value['json_setting_value']=='No' && $value['default_value'] == 'Y'){
                        $appSettings[$value['json_group_name']][$value['json_setting_name']]['status'] = 'N';
                    }
                }else{// if not yes no
                    $appSettings[$value['json_group_name']][$value['json_setting_name']][$value['json_setting_value']] = $value['default_value'];
                }
            }
            // check for check box
            if($value['input_type']=='CB'){
                $appSettings[$value['json_group_name']][$value['json_setting_name']][$value['json_setting_value']] = $value['default_value'];
            }
            //check for input box
            if($value['input_type']=='IB' || $value['input_type']=='TB'|| $value['input_type']=='LS'){
                $appSettings[$value['json_group_name']][$value['json_setting_name']]['textBoxValue'] = $value['text_box_value'];
            }
            
            // check for check box with input box
            if($value['input_type']=='CBI'){
            //    $appSettings[$value['json_group_name']][$value['json_setting_name']][$value['json_setting_value']]['status'] = $value['default_value'];
                //$appSettings[$value['json_group_name']][$value['json_setting_name']][$value['json_setting_value']] = $value['text_box_value'];
                $appSettings[$value['json_group_name']][$value['json_setting_name']][$value['json_setting_value']]['status'] = $value['default_value'];
                $appSettings[$value['json_group_name']][$value['json_setting_name']][$value['json_setting_value']]['textBoxValue'] = $value['text_box_value'];
            }
            // check for radio button with input box
            if($value['input_type']=='RBI'){
                if($value['json_setting_value']=='Yes' || $value['json_setting_value']=='No'){
                    if($value['json_setting_value']=='Yes' && $value['default_value'] == 'Y'){
                        $appSettings[$value['json_group_name']][$value['json_setting_name']] = array('status'=> 'Y', 'textBoxValue'=> $value['text_box_value']);
                    }else if($value['json_setting_value']=='No' && $value['default_value'] == 'Y'){
                        $appSettings[$value['json_group_name']][$value['json_setting_name']] = array('status'=> 'N', 'textBoxValue'=> $value['text_box_value']);
                    }
                }else{
                    $appSettings[$value['json_group_name']][$value['json_setting_name']][$value['json_setting_value']] = array('status'=>$value['default_value'],'textBoxValue'=>$value['text_box_value']);

                }
            }
            // check colour picker
            if($value['input_type']=='CP'){
                $appSettings[$value['json_group_name']][$value['json_setting_name']][$value['json_setting_value']] = $value['text_box_value'];
            }
            // check colour picker
            if($value['input_type']=='IBM'){
                $appSettings[$value['json_group_name']][$value['json_setting_name']][$value['json_setting_value']] = $value['text_box_value'];
            }
            // check for input box with file upload
            if($value['input_type']=='IWF'){
                $appSettings[$value['json_group_name']][$value['json_setting_name']]['textBoxValue'] = $value['text_box_value'];
            }
            // check for input box with file upload
            if($value['input_type']=='ED'){
                $appSettings[$value['json_group_name']][$value['json_setting_name']]['textBoxValue'] = $value['text_box_value'];
            }            
        }
        
        return $appSettings;
    }

    /**
     * Write json data on json file
     * @param type $defaultValue
     * @param type $fileName
     * @Author SATHEESKUMAR
     */
    public function _writeJsonFile($defaultValue,$fileName,$bookingType){
        $_OauthToken = new authToken();
        
        //set general configuration footer content
        $defaultValue['General_configurations']['E-ticket Footer Content']['textBoxValue'] ? $eticketDataDisplay = $defaultValue['General_configurations']['E-ticket Footer Content']['textBoxValue'] : FALSE;
        
        //write json file
        if(isset($defaultValue) && is_array($defaultValue)) {
            $defaultValue = json_encode($defaultValue);
            $defaultValue = preg_replace('/[ ()-]+/',"_",$defaultValue);
            //purify the json data
            $defaultValue = $_OauthToken->_purifyInputData($defaultValue);            
            $defaultValue = json_decode($defaultValue, TRUE);

            $defaultValue['General_configurations']['E_ticket_Footer_Content']['textBoxValue'] = $eticketDataDisplay;

            $defaultValue = json_encode($defaultValue);
            $purifiedFilePath=$_OauthToken->_purifyInputData($fileName);
            $fh          = fopen($this->_prepareFilePath($purifiedFilePath,$bookingType), 'w');
            chmod($filePath,0777);
            $returnValue = fwrite($fh, $defaultValue);
        }
        //return results
        return true;
    }    
    
    /*
    * @Description  This method is used to get the application_settings group name info
    * @param|int:$applicationSettingsValueId
    * @date:03.10.2017 
    * @return|array:$result
    * @author:Karthika.M
    */ 
    public function _getSettingsGroupNameInfo($applicationSettingsValueId){
        
        $sql = "SELECT dasgn.group_name,dasgn.application_setting_group_name_id
                FROM  dm_application_setting_group_name dasgn
                INNER JOIN dm_application_setting_name dasn ON dasgn.application_setting_group_name_id = dasn.r_application_setting_group_id
                INNER JOIN application_setting_value_details asvd ON dasn.application_setting_name_id = asvd.r_application_setting_name_id
                WHERE asvd.application_setting_value_id = ".$applicationSettingsValueId;
        return $this->_OcommonDBO->_getResult($sql);
    }
    
    /*
    * @Description  This method is used to check the fare profile setting already exist or not.
    * @param|array:$input
    * @date:2.11.2017  
    * @return|array:$result
    * @author:Karthika.M
    */ 
    public function _checkFareProfileSettingsExist($input,$flagForStatus='Y'){
        
        $sql = "SELECT * 
                FROM dm_fare_profile_setting dfps
                WHERE 1 ";
        $flagForStatus == 'Y' ? $sql .= " AND dfps.status = 'Y' " : '';
        $input['r_agency_id'] ? $sql .= " AND dfps.r_agency_id = ".$input['r_agency_id'] : '';  
        $input['r_corporate_id'] ? $sql .= " AND dfps.r_corporate_id = ".$input['r_corporate_id'] : '';    
        $input['settingName'] ? $sql .= " AND dfps.fare_profile_setting_name = '".$input['settingName']."' " : '';
        $input['settingId'] ? $sql .= " AND dfps.fare_profile_setting_id != '".$input['settingId']."' " : '';  
        return $this->_OcommonDBO->_getResult($sql);       
    }
    
    /*
    * @Description  This method is used to get tht fact fare profile setting in fo with respect to the application setting id.
    * @param|int,int:$fareProfileSettingsId,$applicationSettingValueId 
    * @date:4.11.2017  
    * @return|array:
    * @author:Karthika.M
    */ 
    public function _getFactFareProfileSettingsInfo($fareProfileSettingsId,$applicationSettingValueId = 0){
        
        $sql = "SELECT * 
                FROM fact_fare_profile_setting ffps
                WHERE ffps.r_fare_profile_setting_id = ".$fareProfileSettingsId;
        
        $applicationSettingValueId ? $sql .= " AND ffps.r_application_setting_value_id = ".$applicationSettingValueId:'';
        return $this->_OcommonDBO->_getResult($sql);  
    }    
    
    /*
    * @Description  This method is used to get the combination of the settings with respect the setting id.
    * @param|int:$fareProfileSettingsId
    * @date:4.11.2017  
    * @return|array:
    * @author:Karthika.M
    */ 
    public function _getSettingsCombination($fareProfileSettingsId){
        
        $sql = "SELECT dfps.fare_profile_setting_id,dfps.r_agency_id, dfps.r_corporate_id,fptm.r_travel_mode_id,fptm.trip_type_id,fpum.user_mapping_type,fpum.user_mapping_type_id
                FROM 
                    dm_fare_profile_setting dfps
                    INNER JOIN fare_profile_user_mapping fpum ON dfps.fare_profile_setting_id = fpum.r_fare_profile_setting_id
                    INNER JOIN fare_profile_travel_type_mapping fptm ON dfps.fare_profile_setting_id = fptm.r_fare_profile_setting_id
                    WHERE dfps.fare_profile_setting_id =".$fareProfileSettingsId;
        return $this->_OcommonDBO->_getResult($sql);  
    }   
    
    /*
    * @Description  This method is used update the fact_fare_profile_setting.
    * @param|array:$factFareProfileSettings
    * @date:4.11.2017  
    * @return|array:
    * @author:Karthika.M
    */     
    public function _updateFactFareProfileSetting($factFareProfileSettings){
        
        $sql = "UPDATE fact_fare_profile_setting ffps
                SET 
                    ffps.default_value = '".$factFareProfileSettings['default_value']."',ffps.text_box_value = '".addslashes($factFareProfileSettings['text_box_value'])."' 
                WHERE 
                    r_fare_profile_setting_id = ".$factFareProfileSettings['r_fare_profile_setting_id']." 
                    AND r_application_setting_value_id = ".$factFareProfileSettings['r_application_setting_value_id'];
        return $this->_OcommonDBO->_executeQuery($sql);                  
    }


    /*
    * @Description  This method is used to to get the value for a particular with all aggregate created data 
    * @param|array:$input//$input array contains corporate id aagency id and travelmode and trip type
    * @date:2.11.2017  
    * @return|array:$result
    * @author:Baskar.V.p
    */ 
    public function _getFareProfileSettingsName($input,$statusFlag='Y'){
        $sql = "SELECT 
                    fare_profile_setting_name,user_mapping_type_id,dmfps.created_date,fpttm.r_travel_mode_id as travelMode ,fpttm.trip_type_id as tripType
                FROM
                    dm_fare_profile_setting dmfps 
                    INNER JOIN fare_profile_user_mapping fpus
                    ON fpus.r_fare_profile_setting_id = dmfps.fare_profile_setting_id
                    INNER JOIN fare_profile_travel_type_mapping fpttm ON fpttm.r_fare_profile_setting_id = dmfps.fare_profile_setting_id
                WHERE 1";
        
        //corporate id
        $input['corporateId'] ? $sql .= " AND dmfps.r_corporate_id = ".$input['corporateId']:'';
        
        //agency id
        $input['agencyId'] ? $sql .= " AND dmfps.r_agency_id = ".$input['agencyId']:'';
        
        //travel mode
        $input['travelMode'] ? $sql .= " AND fpttm.r_travel_mode_id = ".$input['travelMode'] : '';        
        
        //trip type
        $input['tripType'] ? $sql .= " AND fpttm.trip_type_id = ". $input['tripType'] : '';        
        //flow type whether aggregate or user type
        $input['flowType'] ? $sql .= " AND fpus.user_mapping_type = '".$input['flowType']."'":'';
        
        //mapping id based on the flow type.
        $input['type'] ? $sql .= " AND fpus.user_mapping_type_id IN (".$input['type'].")":'';
      
        //mapping id based on the flow type.
        $input['settingId'] ? $sql .= " AND fare_profile_setting_id != ".$input['settingId']  : '';

        $statusFlag  != 'N' ? $sql .= "AND dmfps.status ='".$statusFlag."'"  : '' ;

        if(isset($input['bookingType']) && $input['bookingType'] != ''){
            $sql .= ($input['bookingType'] == 'Personal') ? " AND application_type = 'P'" : " AND application_type = 'C'";
        }
        else{
            $sql .= (INDEXNAME == 'personal') ? " AND application_type = 'P'" : " AND application_type = 'C'";
        }
      
        $sql .= " ORDER BY dmfps.created_date desc";       

        fileWrite('settingQ'.print_r($sql,1),'baskarSTART','a+');
        return $this->_OcommonDBO->_getResult($sql);      

    }
    
    /**
    * get particular flow type from json
    * @param array $data
    * @return $searchedResponse
    * @author Baskar.V.P
    */
    public function _getSpecificDataFromJSON($corporateId,$flowName ='',$bookingType){
        $corporate = new corporateCustomization();
        $corporate->_IcorporateId = $corporateId;
        $_AsettingsArray = $corporate->_getCorporateSettingsFromJSON('',$bookingType);
        $searchedResponse =  array_search('YES', $_AsettingsArray['settings'][$flowName]);
        return $searchedResponse;
    }
    /**
    * fare profile array formation for backend
    * @param array $data
    * @return $settArray
    * @author Baskar.V.P
    */
    public function _setArrayFormationBackEnd($data){
        foreach ($data as $key => $value) {
            foreach ($value as $innerkey => $innerValuevalue) {
                $settArray[$innerValuevalue['travelMode']][$innerValuevalue['tripType']]['fare_profile_setting_name'] = $innerValuevalue['fare_profile_setting_name'];
            }
        }
        return   $settArray;      
    }
}   