<?php
/************************************************************************
* @Class Name	: coreApplicationSettings
* @Created on	: 2016-04-21
* @Created By	: Taslim
* @Description	: This class handles application settings value setting and manipulation
*
**************************************************************************/
class coreApplicationSettings
{
	public $_Oconnection;

	//contructor for the coreApplicationSettings class
	public function __construct()
	{
	    
	}
        
        public function _fetchApplicationSettingsValue()
        {
            
            $retunValue = '';
            //TO DO need to updagte with organization id for each corporate to fetch values
            $sql = "SELECT s.setting_name, v.value FROM application_settings_details d 
                    JOIN application_settings_value v ON d.value = v.application_settings_value_id
                    JOIN application_settings s ON d.r_setting_id = s.setting_id
                    WHERE s.status = 'Y'";
            if($result = $this->_Oconnection->query($sql)) 
            {
                if ($result->rowCount() > 0)
                {
                    $_Asettings = array();
                    while ($row = $result->fetch(PDO::FETCH_ASSOC)) 
                    {
                        $_Asettings[$row['setting_name']] = $row['value'];
                    }
                    $retunValue = $_Asettings;
                }
            }
            return $retunValue;
        }
	
}
?>