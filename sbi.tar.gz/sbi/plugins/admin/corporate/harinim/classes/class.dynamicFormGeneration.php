<?php
/* * **************************************************************************
 * @File            create Agency class file
 * @Description     This class file holds all agency related functionalities
 * @Author          Taslim
 * @Created Date    07/06/2016
 * @Tables used     dm_agency, agency_corporate_mapping
 * *************************************************************************** */
fileRequire("./lib/common/commonMethods.php");
pluginFileRequire('admin/corporate/harinim/', 'interface/commonConstants.php');
class dynamicFormGeneration implements displaySettingsCommonConstant
{
    public function __construct()
    {
        $this->_OcommonDBO=new commonDBO();
        
    }
    
/******************************************************************************
 * @Method Name      : _getFormNames
 * @Description      : This method is used to get the list of form available in database
 * @Tables Affected  : dm_form
 * @Author           : Baskar V P
 * @Created Date     : 27/12/2016
 * @Modified Date    : 
 * ****************************************************************************/
   public function _getFormNames($traveModeId){
        $sql = "SELECT form_name,form_id
                FROM   dm_form  ";
                
        if($traveModeId != ''){
            $sql.= "WHERE  r_travel_mode_id = '".$traveModeId."'";
        }
        $result = $this->_OcommonDBO->_getResult($sql);
        return $result;
    }
/******************************************************************************
 * @Method Name      : _getContainerDetails
 * @Description      : This method is used to container details from database
 * @Tables Affected  : form_container_mapping, dm_container
 * @Author           : Baskar V P
 * @Created Date     : 27/12/2016
 * @Modified Date    : 
 * ****************************************************************************/
    public function _getContainerDetails($formId){
        $sql = "SELECT  container_name, container_id
                FROM    form_container_mapping fcm INNER JOIN dm_container dmc
                        ON fcm.r_container_id=dmc.container_id
                WHERE   r_form_id = '".$formId."'";
        $result = $this->_OcommonDBO->_getResult($sql);
        return $result;
    }
/******************************************************************************
 * @Method Name      : _getFormMappedValues
 * @Description      : This method is used to container details from database
 * @Tables Affected  : form_container_mapping, dm_container
 * @Author           : Baskar V P
 * @Created Date     : 27/12/2016
 * @Modified Date    : 
 * ****************************************************************************/
    public function _getFormMappedValues($inputData){
        $sql = "SELECT        json_object,agent_form_container_details_id as pkId
                        FROM          agent_form_container_details  afcd
                WHERE         afcd.r_form_id='".$inputData['r_form_id']."' and afcd.r_agent_corporate_usertype_mapping_id='".$inputData['r_agent_corporate_usertype_mapping_id']."' and afcd.r_user_type_id='".$inputData['r_user_type_id']."'";
        $result = $this->_OcommonDBO->_getResult($sql);
        return $result;
    }
/******************************************************************************
 * @Method Name      : _getContainerValues
 * @Description      : This method is used to container details from database
 * @Tables Affected  : form_container_mapping, dm_container
 * @Author           : Baskar V P
 * @Created Date     : 27/12/2016
 * @Modified Date    : 
 * ****************************************************************************/
    public function _getContainerValues($data){
        $sql = "SELECT      container_tab, container_value_details_id
                FROM        container_value_details cvd INNER JOIN form_container_mapping fcm
                            ON cvd.r_form_container_mapping_id= fcm.form_container_mapping_id
                INNER JOIN  dm_container dmc ON dmc.container_id=fcm.r_container_id
                WHERE       r_form_id = '".$data['form_id']."' and r_container_id = '".$data['container_id']."' ";
        $result = $this->_OcommonDBO->_getResult($sql);
        return $result;
    }
/******************************************************************************
 * @Method Name      : _getPrimaryKeyFormContainer
 * @Description      : This method is used to container details from database
 * @Tables Affected  : form_container_mapping, dm_container
 * @Author           : Baskar V P
 * @Created Date     : 27/12/2016
 * @Modified Date    : 
 * ****************************************************************************/
    public function _getPrimaryKeyFormContainer($formId,$containerId){
        $sql = "SELECT form_container_mapping_id
                FROM   form_container_mapping
                WHERE   r_container_id ='".$containerId."' and r_form_id='".$formId."'";
        $result = $this->_OcommonDBO->_getResult($sql);
        return $result[0]['form_container_mapping_id'];
    }

/******************************************************************************
 * @Method Name      : _insertFormContainerValues
 * @Description      : This method is used to container details from database
 * @Tables Affected  : form_container_mapping, dm_container
 * @Author           : Baskar V P
 * @Created Date     : 27/12/2016
 * @Modified Date    : 
 * ****************************************************************************/
    public function _insertFormContainerValues($insertData){
        $tableName = 'agent_form_container_details';
        $insertData['json_object']=addslashes($insertData['json_object']);
        $updateArray = array('json_object' => $insertData['json_object']);
        $result = $this ->_getFormMappedValues($insertData);
        if((isset($result)) && $result != ''){
            $result = $this->_OcommonDBO->_delete($tableName,'agent_form_container_details_id',$result[0]['pkId']);
            $result    = $this->_OcommonDBO->_insert($tableName, $insertData);
        }
        else{
            $result    = $this->_OcommonDBO->_insert($tableName, $insertData);
        }
        return $result;
    }
 /******************************************************************************
 * @Method Name      :_insertNewElementValues
 * @Description      : This method is used to insert into new element into database
 * @Tables Affected  : dm_custom_fields
 * @Author           : Baskar V P
 * @Created Date     : 05/01/2017
 * @Modified Date    : 
 * ****************************************************************************/
    public function _insertNewElementValues($insertData,$action){
        
        $tableName = 'dm_custom_field';
        $updateArray = array('field_object' => $insertData['field_object'], 'custom_field_name' => $insertData['custom_field_name']);
        if($action == 'insert'){
            $result    = $this->_OcommonDBO->_insert($tableName, $insertData);
        }
        elseif($action == 'update'){
             $result =   $this->_OcommonDBO->_update($tableName,$updateArray,'custom_field_id',$insertData['pkid']);
        }

        return $result;
    }   
/******************************************************************************
 * @Method Name      : _getCustomedFields
 * @Description      : This method is used to get custom fields
 * @Tables Affected  : form_container_mapping, dm_container
 * @Author           : Baskar V P
 * @Created Date     : 27/12/2016
 * @Modified Date    : 
 * ****************************************************************************/
    public function _getCustomedFields($customId = '') {
        $sql = "SELECT custom_field_id,custom_field_name,field_object
                FROM   dm_custom_field";
        $append = " WHERE ";
        if ($customId != 0) {
            $sql .= $append . " custom_field_id = '" . $customId . "'";
        }
        $result = $this->_OcommonDBO->_getResult($sql,'',1);
        return $result;
    }
/******************************************************************************
 * @Method Name      : _getTravelModeFormBased
 * @Description      : This method is used to get custom fields
 * @Tables Affected  : form_container_mapping, dm_container
 * @Author           : Baskar V P
 * @Created Date     : 27/12/2016
 * @Modified Date    : 
 * ****************************************************************************/
    public function _getTravelModeFormBased() {
        $sql = "SELECT *
                FROM   dm_travel_mode dtm INNER JOIN dm_form dmf ON dtm.travel_mode_id = dmf.r_travel_mode_id";
        $append = " WHERE ";
        if ($customId != 0) {
            $sql .= $append . " custom_field_id = '" . $customId . "'";
        }
        $result = $this->_OcommonDBO->_getResult($sql);
        return $result;
    }
/******************************************************************************
 * @Method Name      : _getFormName
 * @Description      : This method is used to get the list of form available in database
 * @Tables Affected  : dm_form
 * @Author           : Baskar V P
 * @Created Date     : 27/12/2016
 * @Modified Date    : 
 * ****************************************************************************/
   public function _getFormName($formId){
        $sql = "SELECT form_name
                FROM   dm_form  
                WHERE  form_id = '".$formId."'";
        $result = $this->_OcommonDBO->_getResult($sql);
        return $result;
    }
/*
 * @function Name   :- _deleteElement
 * @description     :- This function deletes the element from the list in element generation
 * @author          :- Vishwa Raj
 */
    public function _deleteElement($elementId){
        $sql = "DELETE FROM dm_custom_field WHERE custom_field_id =".$elementId;
        $result = $this->_OcommonDBO->_getResult($sql);
        return $result;
    }
/*
 * function name    :- _getDynamicFormList()
 * description      :- This function is called by default on clicking the dynamic form generation menu for 
 *                     the list generation
 */
    public function _getDynamicFormList()
    {
        $sql = "SELECT afcd.agent_form_container_details_id, afcd.r_user_type_id ,df.form_name ,da.agency_name, dc.corporate_name 
                FROM agent_form_container_details afcd
                INNER JOIN dm_form df ON afcd.r_form_id = df.form_id
                INNER JOIN agency_corporate_mapping acm ON afcd.r_agent_corporate_usertype_mapping_id = acm.agency_corporate_mapping_id
                INNER JOIN dm_agency da ON acm.agency_id = da.dm_agency_id
                INNER JOIN dm_corporate dc ON acm.corporate_id = dc.corporate_id";
        $result = $this->_OcommonDBO->_getResult($sql,'',1);
        return $result;
    }

/*
 * function name    :- _deleteDynamicForm()
 * description      :- This function is called to delete the respective dynamic form
 *                     the list generation
 */
    public function _deleteDynamicForm($formId)
    {
        $sql = "delete from agent_form_container_details where agent_form_container_details_id =".$formId;
        $result = $this->_OcommonDBO->_getResult($sql);
        return $result;
    }
    
  /*
 * function name    :- _getCategoryType()
 * description      :- This function is called to get category value
 */
    public function _getCategoryType()
    {
        $sql = "SELECT * FROM dm_field_display_category";
        $result = $this->_OcommonDBO->_getResult($sql);
        return $result;
    }  
    
 /*
 * function name    :- _getFormSettingsValues()
 * description      :- This function is called to get category value
 */
    public function _getFormSettingsValues($input)
    {
        
        $sql = "SELECT * FROM display_settings_fields ";
        if($input['form_id'] !=''){
            $sql.= " WHERE r_form_id=".$input['form_id'];
        }elseif($input['display_settings_field_id']!=''){
            $sql.= " WHERE display_settings_field_id=".$input['display_settings_field_id'];
        }
        $result = $this->_OcommonDBO->_getResult($sql);
        return $result;
    }
    
    
  /*
 * function name    :- _getConstantQueryValue()
 * description      :- This function is called to execute the constant query values
 */
    public function _getConstantQueryValue($input){
        $sql = self::getTravelClassCorporate;
        $result = $this->_OcommonDBO->_getResult($sql);
        return $result;
    }  
    /**
     * 
     * @param type $input
     * @return type
     * @Author:- Vishwa Raj
     */
    public function _saveFieldSettingCreationData($input){
        $insertArray = array(
                        "field_name"                => $input['fieldName'],
                        "caption_name"              => $input['captionName'],
                        "field_type"                => $input['fieldType'],
                        "field_value_constant"      => $input['fieldValueConstant'],
                        "value_constant_type"       => $input['valueConstantType'],
                        "r_form_id"                 => $input['formId'],
                        "status"                    => $input['status'],
                        "created_date"              => date("Y-m-d"),
                        "updated_date"              => date("Y-m-d")
        );
        $result = $this->_OcommonDBO->_insert("display_settings_fields", $insertArray);
        return $result;
    }
    
    
    public function _getFieldCreationListData($agencyId='',$corporateId='',$dispSettingfieldId='',$filterData){
        
        $sql = " SELECT dsf.*,dfm.* FROM display_settings_fields dsf INNER JOIN dm_form dfm ON dsf.r_form_id = dfm.form_id WHERE 1";
        if(isset($agencyId) && $agencyId != ''){
            $sql .= " AND agencyId = ".$agencyId ;
        }
        if(isset($corporateId) && $corporateId != ''){
            $sql .= " AND agencyId = ".$agencyId ;
        }
        if(isset($dispSettingfieldId) && $dispSettingfieldId != ''){
            $sql .= " AND display_settings_field_id = ".$dispSettingfieldId ;
        }
        if(isset($filterData['formName']) && $filterData['formName'] != '' && $filterData['formName'] != '0'){
            $sql .= " AND dsf.r_form_id = ".$filterData['formName'];
        }
        if(isset($filterData['fieldName']) && $filterData['fieldName'] != '' && $filterData['fieldName'] != '0'){
            $sql .= " AND dsf.field_name = '".$filterData['fieldName']."'" ;
        }
        if(isset($filterData['status']) && $filterData['status'] != '' && $filterData['status'] != '0'){
            $sql .= " AND dsf.status = '".$filterData['status']."'" ;
        }
        $result = $this->_OcommonDBO->_getResult($sql);
        return $result;
    }
    
    public function _updateFieldSettingCreationData($input){
        $updateArray = array(
                        "field_name"                => $input['fieldName'],
                        "caption_name"              => $input['captionName'],
                        "field_type"                => $input['fieldType'],
                        "field_value_constant"      => $input['fieldValueConstant'],
                        "value_constant_type"       => $input['valueConstantType'],
                        "r_form_id"                 => $input['formId'],
                        "status"                    => $input['status'],
                        "updated_date"              => date("Y-m-d")
        );
        $result = $this->_OcommonDBO->_update("display_settings_fields", $updateArray, "display_settings_field_id", $input['displaySettingId']);
        return $result;
        
    }
    
    public function _getFormData()
    {
        $sql = ' SELECT form_id,form_name FROM dm_form';
        $result = $this->_OcommonDBO->_getResult($sql);
        return $result;
    }
 /******************************************************************************
 * @Method Name      : _insertDynamicSettingsValue
 * @Description      : This method is used to value in database
 * @Tables Affected  : display_settings_mapping, display_settings_field_mapping
 * @Author           : Baskar V P
 * @Created Date     : 27/12/2016
 * @Modified Date    : 
 * ****************************************************************************/
    public function _insertDynamicSettingsValue($insertData){
        // for insert display_settings_mapping
        $dynamicMappingInsert['r_agency_id'] = $insertData['agencyId'];
        $dynamicMappingInsert['r_corporate_id'] = $insertData['corporateId'];
        $dynamicMappingInsert['r_travel_mode_id'] = $insertData['travelModeId'];
        $dynamicMappingInsert['r_form_id'] = $insertData['formName'];
        $dynamicMappingInsert['user_mapping_type'] = $insertData['flowType'] == '0' ? 'UT' : 'A';
        $dynamicMappingInsertReultId    = $this->_OcommonDBO->_insert('display_settings_mapping', $dynamicMappingInsert);
         //display_settings_user_mapping
        $dynamicSettingsMapping['r_display_settings_mapping_id'] = $dynamicMappingInsertReultId;
        $dynamicSettingsMapping['mapping_reference_id'] = $insertData['userType'];
        $dynamicSettingsMappingInsertReultId    = $this->_OcommonDBO->_insert('display_settings_user_mapping', $dynamicSettingsMapping);
        //display_settings_field_mapping
        foreach ($insertData['fieldValues'] as $key => $value) {
            $dynamicSettingsFieldMapping['r_display_settings_field_id'] = $key;
            $dynamicSettingsFieldMapping['r_display_settings_mapping_id'] = $dynamicSettingsMappingInsertReultId;
            $dynamicSettingsFieldMapping['r_field_display_category_id'] = $value['r_field_display_category_id'];
            $dynamicSettingsFieldMapping['field_json'] = $value['field_json'];
            $fieldInsertedId    = $this->_OcommonDBO->_insert('display_settings_field_mapping', $dynamicSettingsFieldMapping);
         }
       return true;
    }
    
  
    
    
    
}
?>
