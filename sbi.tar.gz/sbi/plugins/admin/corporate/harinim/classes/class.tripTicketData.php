<?php

class tripTicketData {

    //constructor
    function __construct() {

        $this->_ODBC = new commonDBO();
    }

    public function _getTripDetails($inputData){

        $sql = "SELECT trip_request_details_id as ID,trip_request_details_id as SBT_TRIP_NO, employee_code as EMPLOYEE_NUMBER,start_date as TRIP_START_DATE,end_date as TRIP_END_DATE,department as DEPARTMENT,branch as LOCATION, status_value as TRIP_STATUS,trd.created_date as CREATED_DATE , approval_type ,source,destination FROM trip_request_details trd
            INNER JOIN dm_employee dme ON dme.email_id  = trd.requested_by
            INNER JOIN dm_status dms ON dms.status_id = r_status_id
            INNER JOIN employee_details ed ON ed.r_employee_id = dme.employee_id
            WHERE requested_by NOT IN ('rajeshwaran@infinitisoftware.net','iocladmin@iocl.com') AND r_status_id != '38' "; 
            $sql .= $this->_getRequestByDateRange($inputData);
            $sql .=$inputData['sortDataFilter']['trip_id'] != '' ?" AND trip_request_details_id = ".$inputData['sortDataFilter']['trip_id'] : '';
        $tripDetails = $this->_ODBC->_getResult($sql);
        
        return $this->_getTripSapSyncDetails($tripDetails);
    }  

    public function _getTripSapSyncDetails($tripDetails){

        foreach ($tripDetails as $key => $value) {
            
            $sql = "SELECT 
                        *
                    FROM
                        sap_sync_details ssd
                    WHERE
                        ssd.reference_type = '0' AND ssd.reference_id = ".$value['SBT_TRIP_NO'];

            $tripDetails[$key]['subinfo'] = $this->_ODBC->_getResult($sql);
        }
        return $tripDetails; 

    } 
     /**
     * @functionName    :   _getRequestByDateRange()
     * @param           :   array $datePeriod
     * @description     :   get view request list for bookings raised based on filter
     * @return          :   string $sql
     * @author sivaprakash
     */         
    public function _getRequestByDateRange($datePeriod = '',$avoidFilter = ''){

        if($avoidFilter != 'NODATERANGE'){
            $range = $datePeriod['range'] ? $datePeriod['range'] : 1;
            if($datePeriod['sortDataFilter']['data_type'] == 1){
                $sql .= " AND DATE(trd.created_date) ";
            }else if($datePeriod['sortDataFilter']['data_type'] == 2){
                $sql .= " AND DATE(od.created_date) ";
            }
            else{
                $sql .= " AND DATE(created_date) ";
            }
        }
        switch ($range){
           case 1:
                $sql.=" = '" . date('Y-m-d') . "' ";
                break;
           case 2:
                $yesterday = date('Y-m-d', strtotime('-1 days'));
                $sql.=" = '" . $yesterday . "' ";
                break;
           case 3:
                $sql.="  BETWEEN DATE_SUB(CURDATE(), INTERVAL 14 DAY) AND DATE_SUB(CURDATE(), INTERVAL 8 DAY) ";
                break;
            case 4:
                $sql.=" BETWEEN DATE_SUB(CURDATE(), INTERVAL 1 WEEK) AND CURDATE() ";
                break;
            case 5:
                if($datePeriod['sortDataFilter']['data_type'] == 2){
                    $sql.=" !=0 AND MONTH(od.created_date) = MONTH(CURDATE()) AND YEAR(od.created_date) = YEAR(CURDATE()) ";    
                }else if($datePeriod['sortDataFilter']['data_type'] == 1){
                    $sql.=" !=0 AND MONTH(trd.created_date) = MONTH(CURDATE()) AND YEAR(trd.created_date) = YEAR(CURDATE()) ";
                }else{
                    $sql.=" !=0 AND MONTH(created_date) = MONTH(CURDATE()) AND YEAR(created_date) = YEAR(CURDATE()) ";
                }
                break;
            case 6:
                $sql.=" BETWEEN DATE_FORMAT(NOW() - INTERVAL 1 MONTH, '%Y-%m-01 00:00:00') AND DATE_FORMAT(LAST_DAY(NOW() - INTERVAL 1 MONTH), '%Y-%m-%d 23:59:59')";
                break;
            case 7:
                $sql.=" BETWEEN '" . $datePeriod['from'] ."' AND '" . $datePeriod['to'] ."' ";
                break;
            case 8:
                $sql.=" YEAR(bh.request_date) = YEAR(CURDATE()) ";
                break;
            default:
                break;
       }
       
       return $sql;
    }

    public function _getTicketDetails($inputData){
            $sql = "SELECT employee_code,ioc_gst_in as GST_Number ,r_trip_request_details_id as SBT_TRIP_NO,ticket_request_number as  SBT_Ticket_Request_No,pnr as AIRLINE_PNR,order_id ,gds_pnr as GDS_PNR,
                status_value as Ticket_status,pvd.r_booking_status_id,(SELECT status_value FROM dm_status WHERE status_id = pvd.r_booking_status_id) as Cancellatoin_status,vfd.trip_type,(SELECT city_name FROM dm_airport WHERE airport_id = r_origin_airport_id) as Origin
                ,(SELECT city_name FROM dm_airport WHERE airport_id = r_destination_airport_id) as Dest ,departure_date as Journey_Date,total_fare,sum(ssr_preferences_fare) as SSR_Amount,(total_fare + sum(ssr_preferences_fare)) as total_amount,od.created_date FROM
                passenger_via_details pvd INNER JOIN order_details od ON od.order_id = pvd.r_order_id
                INNER JOIN fact_booking_details fbd ON fbd.r_order_id = od.order_id
                INNER JOIN fact_trip_order_details ftod ON ftod.r_order_id = od.order_id
                INNER JOIN dm_status dms ON dms.status_id = r_ticket_status_id
                INNER JOIN via_flight_details vfd ON vfd.via_flight_id = pvd.r_via_flight_id
                INNER JOIN via_fare_details vfad ON vfad.r_via_flight_id = pvd.r_via_flight_id
                INNER JOIN fact_passenger_preferences fpp ON vfd.via_flight_id = fpp.r_via_flight_id
                INNER JOIN dm_employee dme ON dme.employee_id = fbd.r_employee_id
                INNER JOIN sap_employee_dependent_details sed ON sed.r_employee_id = fbd.r_employee_id
                WHERE r_corporate_id = ".$_SESSION['corporateId']." AND od.r_ticket_status_id>=8 and od.r_ticket_status_id NOT IN (35,49,10,9) and pnr !=''
                "; 
        $sql .= $this->_getRequestByDateRange($inputData);
        $sql .=$inputData['sortDataFilter']['trip_id'] != '' ?" AND ftod.r_trip_request_details_id = ".$inputData['sortDataFilter']['trip_id'] : '';
        $sql .= " GROUP BY pnr";
        return $this->_ODBC->_getResult($sql);
        }

        public function _getSAPData($inputData){
            $sql = "SELECT * FROM sap_sync_details WHERE 1"; 
            $sql .= $this->_getRequestByDateRange($inputData);
            $sql .=$inputData['sortDataFilter']['trip_id'] != '' ?" AND reference_id = ".$inputData['sortDataFilter']['trip_id'] : '';
            return $this->_ODBC->_getResult($sql);
        }

        /**
        * @functionName    :   _getSAPDetails()
        * @param           :   array $inputData
        * @description    :   get SAP Request data
        * @return          :   array $sql
        * @author          :   Muruganandham M
        */
        public function _getSAPDetails($inputData){
            $sql = "SELECT * FROM sap_sync_details WHERE reference_id = ".$inputData['tripId'][0]; 
            $sql .=$inputData['dataType'] == '1' ?" AND reference_type = "."'0'" : "'1'";
            $sql .="ORDER BY sap_sync_details_id DESC";
            return $this->_ODBC->_getResult($sql)[0];
        }

        /**
        * @functionName    :   _manualSyncTicketData()
        * @param           :   array $inputData
        * @description     :   get SAP Request data
        * @return          :   array $sql
        * @author          :   Muruganandham M
        */
        public function _manualSyncTicketData($inputData){
            /*Object to bookingDetailsSync*/
            $this->_ObookingDetailsSync = common::_checkClassExistsInNameSpace('bookingDetailsSync');
            $requestMethod = 'reSyncSapTicketRequest';
            $sql = "SELECT dmp.package_id as packageId,dmp.booking_type as bookingType,dmp.booking_mode as bookingMode,od.sync_order_id as orderId FROM order_details od INNER JOIN fact_booking_details fbd ON od.order_id = fbd.r_order_id
                INNER JOIN dm_package dmp ON fbd.r_package_id = dmp.package_id
                WHERE od.order_id = ". $inputData['orderId'];
            $_ArequestData =  $this->_ODBC->_getResult($sql)[0];
            /*Functional to Sync*/
            $response = $this->_ObookingDetailsSync->_callBookingSyncMethod($_ArequestData,$requestMethod,$_ArequestData['packageId'],$_ArequestData['booking_type']);
            return $response;
        }
    }

?>