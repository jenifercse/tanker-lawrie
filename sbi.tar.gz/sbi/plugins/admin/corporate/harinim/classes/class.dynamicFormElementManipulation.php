<?php
/* * **************************************************************************
 * @File            file for dynamic field manipulation
 * @Author          Baskar
 * @Created Date    07/06/2016
 * *************************************************************************** */
fileRequire("./lib/common/commonMethods.php");
class dynamicFormElementManipulation
{
    public function __construct()
    {
        
        $this->_OcommonDBO=new commonDBO();
    }
/******************************************************************************
 * @Method Name      : _insertFormContainerValues
 * @Description      : This method is used to container details from database
 * @Tables Affected  : form_container_mapping, dm_container
 * @Author           : Baskar V P
 * @Created Date     : 27/12/2016
 * @Modified Date    : 
 * ****************************************************************************/
  public function _insertDynamicFields($pkId,$tableId,$insertArray)
    {
        $tableName= 'dynamic_field_value';
        foreach ($insertArray as $key => $value) {
            $insert['last_insert_id']=$pkId;
            $insert['r_table_id']=$tableId;
            $insert['field_value']= $value['value'];
            $insert['r_custom_field_id']=$value['id'];
            $resultInsertId[] = $this->_OcommonDBO->_insert($tableName, $insert);
        }
    return $resultInsertId;
    }
    
    /**
     * Deletes field values from the dynamic field value table
     * @param string $tableName Table name
     * @param int $refernceId Relative id for the operation
     * @return int
     */
    public function _deleteDynamicFields($tableName,$refernceId) {
                        
        $sql = "DELETE FROM dynamic_field_value WHERE 1 ";
        
        if($tableName){
            $sql .= " AND r_table_id = '".$tableName."'";
        }
        if($refernceId){
            $sql .= " AND last_insert_id = ".$refernceId;
        }
        
        $result = $this->_OcommonDBO->_getResult($sql);
        
        return $result;
    }
    
    /**
     * Gets table master data
     * @param string $tableName Table name
     * @return array
     */
    public function _getTableId($tableName) {
        
        $result = $this->_OcommonDBO->_select('dm_table_master', array('dm_table_master_id'),'table_name', $tableName);
        
        return $result[0]['dm_table_master_id'];
        
    }
    /**
     * Gets table master data
     * @param string $tableName Table name
     * @return array
     */
    public function _getdynamicValue($insertedId) {
        
      $dynamicValue=    'SELECT * FROM dynamic_field_value
                            WHERE last_insert_id = '.$insertedId.' ';
        return $result = $this->_OcommonDBO->_getResult($dynamicValue);
        
    }
    
    
    /**
     * Gets table master data
     * @param string $tableName Table name
     * @return array
     */
    public function _deleteDynamicValue($insertedId) {
        
      $dynamicValue=    'DELETE  FROM dynamic_field_value
                            WHERE last_insert_id = '.$insertedId.' ';
        return $result = $this->_OcommonDBO->_getResult($dynamicValue);
        
    }
    
     /*
     * @Description  This method returns dynamic field value
     * @param int|$orderId
     * @return array|$result
     * @date|30.05.2017
     * @author|Karthika.M
     */
    public function _getCostCenterIdBasedOrder($orderId,$fieldName ='') {
        
        $dynamicValue  =   'SELECT * 
                            FROM dynamic_field_value dfv
                            INNER JOIN dm_cost_center_code dcc ON dcc.cost_center_code = dfv.field_value
                            INNER JOIN dm_custom_field dcf ON dcf.custom_field_id = dfv.r_custom_field_id
                            WHERE last_insert_id = "'.$orderId.'"'; 
        
        if($fieldName !=''){
            $dynamicValue .= ' AND dcf.custom_field_name = "' . $fieldName . '"';
        }
        return $result = $this->_OcommonDBO->_getResult($dynamicValue);
    }
    
    /**
     * used to update the passenger based dynamic field values
     * @param type $passengerId | int, $tableId | int, $updateArray | array
     * @return update count | boolean false
     */
    public function _updatePassengerDynamicFieldValue($passengerId, $tableId, $updateArray) {
        
        $sql = "UPDATE 
                      dynamic_field_value 
                SET
                      field_value = '".addslashes($updateArray['value'])."'
                WHERE
                      last_insert_id = $passengerId AND r_custom_field_id = '".$updateArray['id']."' AND r_table_id = $tableId ";
        
        return (!empty($updateArray['id']) && !empty($passengerId)) ? $this->_OcommonDBO->_getResult($sql) : FALSE;
    }
    /**
     * used to insert the passenger wise dynamic field value data
     * @param type $insertedPassengerId | int
     * @param type $tableId | int
     * @param type $insertArray | arrat
     * @return last inserted id or boolean false
     */
    public function _insertPassengerDynamicFieldValue($insertedPassengerId, $tableId, $insertArray) {
        
        $insertValues = array(
                        'last_insert_id'=> $insertedPassengerId,
                        'r_table_id'=> $tableId,
                        'field_value'=> addslashes($insertArray['value']),
                        'r_custom_field_id'=> $insertArray['id'],
                    );   
        return (!empty($insertArray['id']) && !empty($insertedPassengerId)) ? $this->_OcommonDBO->_insert('dynamic_field_value', $insertValues) : FALSE;
    }    
}
?>