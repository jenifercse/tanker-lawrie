<?php
/* * **************************************************************************
 * @File             : class.tpl.dynamicApprovalSettingsDetailsTpl.php
 * @Description      : This file is used get the dynamic approval settings tpl
 * @Tables Affected  : 
 * @Author           : Karthika
 * @Created Date     : 03/01/2017
 * @Modified Date    : 
 * ****************************************************************************/

fileRequire('/lib/common/commonMethods.php');
pluginFileRequire('common/', 'interface/commonConstants.php');
class dynamicApprovalSettingsDetailsTpl   implements commonConstants
{    
    public function __construct() 
    {    
        $this->_OcommonDBO = new commonDBO();
        $this->_OapprovalSettings= new dynamicApproverSettings();
        $this->_Oemployee  = new employee();
        $this->_Ocorporate = new corporate();
        $this->_OcommonQ = new commonQuery();
        $this->_CcreateManageAggregate = new createManageAggregate();
        $this->_OdynamicApproverSettings = common::_checkClassExistsInNameSpace('dynamicApproverSettings');
    }
   
   public function _getDisplayInfo()           
   {  
       //set input data
      $input =  $this->_IinputData;
      
      if(count($input) > 0)
      { 
        // get approval setting details
        $approvalSettingsDetails = $this->_OapprovalSettings->_getDynamicApprovalSettingsInfo($input['approvalSettingsId']); 
        
        // get approval setting logic info
        if($approvalSettingsDetails != '')
        { 
           $allCategory = $this->_CcreateManageAggregate->_getAggregateType(array("r_agency_id"=>$approvalSettingsDetails[0]['r_agency_id'],"r_corporate_id"=>$approvalSettingsDetails[0]['r_corporate_id']));
           foreach($approvalSettingsDetails as $data)
           {             
              if($data['parameter_type'] == 'travelmode')
              {                 
                  // set the travel mode value
                  $approvalSettingInfo['travelModeId'] = $data['parameter_id'];
              }    
           }
          $allCriteriaList = $this->_OcommonQ->_getCriteriaList($approvalSettingsDetails[0]['r_agency_id'],$approvalSettingsDetails[0]['r_corporate_id'],$approvalSettingInfo['travelModeId']);
          $approvalSettingsInfo = $this->_editApprovalSettingLogic($approvalSettingsDetails);
        }
        // get approver list info
        $approverInfo = $this->_OapprovalSettings->_getApproverInfo($input['approvalSettingsId']); 
        if($approverInfo != '')
        {
            $approversInfo = $this->_getApproverEmailInfo($approverInfo,$approvalSettingInfo['travelModeId']);
        }     

        //check subcorporate status
        $subCorporateArray = $this->_checkSubcorporateStatus($approversInfo,$approvalSettingsInfo);

        // set the array values in service response 
        $this->_AserviceResponse['editApprovalSettingsInfo'] = $approvalSettingsInfo;
        $this->_AserviceResponse['approvers'] = $approversInfo;
        $this->_AserviceResponse['subCorporateStatusInfo'] = $subCorporateArray;
        $this->_AserviceResponse['allAggregateInfo'] = $allCategory;
        $this->_AserviceResponse['aggregateArr'] = $approvalSettingsInfo['category'];
        
        $selectedAggregates = array_keys($approvalSettingsInfo['category']);
        foreach($allCategory as $catVal)
        {
            if(in_array($catVal['aggregate_type_id'], $selectedAggregates))
            $result['categoryInfo'][] = array("id"=>$catVal['aggregate_type_id'],"name"=>$catVal['aggregate_type']);
        }
        $this->_AserviceResponse['selectedAggregates'] =  $result['categoryInfo'];
        //set criteria value
        $this->_AserviceResponse['criteriaList'] = $allCriteriaList;
        $this->_OcommonQ->_getLogicalOperatorInfo();
        $this->_AserviceResponse['operators'] = $this->_OcommonQ->_Aoperators;
      }
   }      
      
   // get the dynamic approver settings info
   public function _dynamicApprovalSettingLogic($result) 
   {   
           $categoryId=0;
           $criteriaId=0;
           // set the array value
           foreach($result as $data)
           {
              if($data['approval_settings_id'] != '')
              { 
                  $approvalSettingArray['approval_settings_id'] = $data['approval_settings_id'];
              }
              if($data['approval_settings_name'] != '')
              { 
                  $approvalSettingArray['approval_settings_name'] = $data['approval_settings_name'];
              }
              if($data['r_agency_id'] != '')
              { 
                  $approvalSettingArray['agencyId'] = $data['r_agency_id'];
              }
              if($data['r_corporate_id'] != '')
              {                   
                  // set the corporate name
                  $approvalSettingArray['corporateId'] = $data['r_corporate_id'];
                  $corporateName = $this->_Ocorporate->_getCorporateName($data['r_corporate_id']);
                  $approvalSettingArray['corporateName'] = $corporateName;   
              }
              if($data['priority'] != '')
              { 
                  $approvalSettingArray['priority'] = $data['priority'];
              }   
              if(($data['start_date'] != '' )&&($data['end_date'] != '' ))
              { 
                  $approvalSettingArray['startDate'] = $data['start_date'];
                  $approvalSettingArray['endDate'] = $data['end_date'];
              }   
              if($data['parameter_type'] == 'processtype')
              {
                  // set the process type value
                  $approvalSettingArray['processTypeId'] = $data['parameter_id'];
                  $approvalSettingArray['processTypeValue'] = $data['parameter_value'];
                  $approvalSettingArray['processLogicalOperator'] = $data['r_operator_id'];
              }
              
              if($data['parameter_type'] == 'travelmode')
              {
                  // set the travel mode value
                  $approvalSettingArray['travelModeId'] = $data['parameter_id'];
                  $approvalSettingArray['travelModeValue'] = $data['parameter_value'];
                  $approvalSettingArray['travelModeLogicalOperator'] = $data['r_operator_id'];
              }
              
              if($data['parameter_type'] == 'category')
              {
                  // get ParentAggregate name
                  $parentCategoryArray = array('aggregate_name');
                  $parentCategoryName = $this->_OcommonDBO->_select('dm_aggregate', $parentCategoryArray,'aggregate_id',$data['parameter_id']); 
                  $data['parameter_name'] = $parentCategoryName[0]['aggregate_name'];                  
                  if($categoryId==0)
                  {                   
                    $categoryParameterId = $data['parameter_id'];
                    $approvalSettingArray['category'][$categoryId]['aggregate_id'] = $data['parameter_id'];
                    $approvalSettingArray['category'][$categoryId]['aggregate_name'] = $data['parameter_name'];
                    $approvalSettingArray['category'][$categoryId]['aggregate_Value'] = $data['parameter_value'];
                    $approvalSettingArray['category'][$categoryId]['aggregate_operator'] = $data['r_operator_id'];
                  }
                  else
                  {  // set the multiple category value      
                    if($categoryParameterId == $data['parameter_id']){                        
                        $approvalSettingArray['category'][$categoryId-1]['aggregate_Value'] .=",". $data['parameter_value'];
                    }
                    else{     
                        $categoryParameterId = $data['parameter_id'];
                        $approvalSettingArray['category'][$categoryId]['aggregate_id'] = $data['parameter_id'];
                         $approvalSettingArray['category'][$categoryId]['aggregate_name'] = $data['parameter_name'];
                        $approvalSettingArray['category'][$categoryId]['aggregate_Value'] = $data['parameter_value'];
                        $approvalSettingArray['category'][$categoryId]['aggregate_operator'] = $data['r_operator_id'];
                    }
                  }
                  $categoryId++;
              }
             if($data['parameter_type'] == 'criteria')
              {
                  // get ParentAggregate name
                  $parentCriteriaArray = array('criteria_name','criteria_type');
                  $parentCriteriaName = $this->_OcommonDBO->_select('dm_criteria', $parentCriteriaArray,'criteria_id',$data['parameter_id']); 
                  $data['parameter_name'] = $parentCriteriaName[0]['criteria_name'];
                  $data['parameter_type'] = $parentCriteriaName[0]['criteria_type'];
                  if($criteriaId==0)
                  {                   
                    $criteriaParameterId = $data['parameter_id'];
                    $approvalSettingArray['criteria'][$criteriaId]['criteria_id'] = $data['parameter_id'];
                    $approvalSettingArray['criteria'][$criteriaId]['criteria_name'] = $data['parameter_name'];
                    $approvalSettingArray['criteria'][$criteriaId]['criteria_value'] = $data['parameter_value'];
                    $approvalSettingArray['criteria'][$criteriaId]['criteria_operator'] = $data['r_operator_id'];
                    $approvalSettingArray['criteria'][$criteriaId]['criteria_type'] = $data['parameter_type'];
                  }
                  else
                  { // set the multiple criteria value       
                    if($criteriaParameterId == $data['parameter_id']){
                        $approvalSettingArray['criteria'][$criteriaId-1]['criteria_value'] .=",". $data['parameter_value'];
                        $criteriaId = $criteriaId-1;
                    }
                    else{     
                        $criteriaParameterId = $data['parameter_id'];
                        $approvalSettingArray['criteria'][$criteriaId]['criteria_id'] = $data['parameter_id'];
                        $approvalSettingArray['criteria'][$criteriaId]['criteria_name'] = $data['parameter_name'];
                        $approvalSettingArray['criteria'][$criteriaId]['criteria_value'] = $data['parameter_value'];
                        $approvalSettingArray['criteria'][$criteriaId]['criteria_operator'] = $data['r_operator_id'];
                        $approvalSettingArray['criteria'][$criteriaId]['criteria_type'] = $data['parameter_type'];
                    }
                  }
                  $criteriaId++;
              }                    
             
           }
       return $approvalSettingArray;
   }
   
    // get the approver email info
    public function _getApproverEmailInfo($approverInfo,$travelModeId){
        if($approverInfo != ''){
            foreach ($approverInfo as $value){                
                //set the approver type
                if($value['approval_type'] != ''){
                   $value = $this->_OdynamicApproverSettings->_setApproverType($value,$travelModeId);
                }
                // set the approver email
                if($value['approver_id'] != ''){
                    $emailId = $this->_Oemployee->_getEmpInfo($value['approver_id']);
                    $value['approver_email'] = $emailId['email_id'];
                }              
                $approversInfo[] = $value;    
            }
            return $approversInfo;
        }
    }  

   
   // get the dynamic approver settings info
   public function _editApprovalSettingLogic($result) 
   {   
           $categoryId=0;
           $criteriaId=0;
           // set the array value
           foreach($result as $data)
           {
              if($data['approval_settings_id'] != '')
              { 
                  $approvalSettingArray['approval_settings_id'] = $data['approval_settings_id'];
              }
              if($data['approval_settings_name'] != '')
              { 
                  $approvalSettingArray['approval_settings_name'] = $data['approval_settings_name'];
              }
              if($data['r_agency_id'] != '')
              { 
                  $approvalSettingArray['agencyId'] = $data['r_agency_id'];
              }
              if($data['r_corporate_id'] != '')
              {                   
                  // set the corporate name
                  $approvalSettingArray['corporateId'] = $data['r_corporate_id'];
                  $corporateName = $this->_Ocorporate->_getCorporateName($data['r_corporate_id']);
                  $approvalSettingArray['corporateName'] = $corporateName;   
              }
              if($data['priority'] != '')
              { 
                  $approvalSettingArray['priority'] = $data['priority'];
              }   
              if(($data['start_date'] != '' )&&($data['end_date'] != '' ))
              { 
                  $approvalSettingArray['startDate'] = $data['start_date'];
                  $approvalSettingArray['endDate'] = $data['end_date'];
              }   
              if($data['parameter_type'] == 'processtype')
              {
                  // set the process type value
                  $approvalSettingArray['processTypeId'] = $data['parameter_id'];
                  $approvalSettingArray['processTypeValue'] = $data['parameter_value'];
                  $approvalSettingArray['processLogicalOperator'] = $data['r_operator_id'];
              }
              
              if($data['parameter_type'] == 'travelmode')
              {
                  // set the travel mode value
                  $approvalSettingArray['travelModeId'] = $data['parameter_id'];
                  $approvalSettingArray['travelModeValue'] = $data['parameter_value'];
                  $approvalSettingArray['travelModeLogicalOperator'] = $data['r_operator_id'];
              }
              
              if($data['parameter_type'] == 'category')
              {
                  // get ParentAggregate name
                  $parentCategoryArray = array('aggregate_type_id');
                  $parentCategoryName = $this->_OcommonDBO->_select('dm_aggregate', $parentCategoryArray,'aggregate_id',$data['parameter_id']); 
                  $data['parameter_type'] = $parentCategoryName[0]['aggregate_type_id']; 
                  if(!in_array($data['parameter_type'],$approvalSettingArray['selectedAggregateTypes']))
                        $approvalSettingArray['selectedAggregateTypes'][] = $data['parameter_type'];
                        $categoryParameterId = $data['parameter_id'];
                        $approvalSettingArray['category'][$data['parameter_type']][$categoryId]['aggregate_id'] = $data['parameter_id'];
                        $approvalSettingArray['category'][$data['parameter_type']][$categoryId]['aggregate_type_id'] = $data['parameter_type'];
                        $approvalSettingArray['category'][$data['parameter_type']][$categoryId]['aggregate_name'] = $data['parameter_value'];
                        $approvalSettingArray['category'][$data['parameter_type']][$categoryId]['aggregate_operator'] = $data['r_operator_id'];
                          $categoryId++;
              }
              if($data['parameter_type'] == 'employee')
              {
                        $approvalSettingArray['category'][SELF::EMPLOYEE_AGGREAGTE_TYPE_ID][$categoryId]['aggregate_id'] = $data['parameter_id'];
                        $approvalSettingArray['category'][SELF::EMPLOYEE_AGGREAGTE_TYPE_ID][$categoryId]['aggregate_type_id'] = $data['parameter_type'];
                        $approvalSettingArray['category'][SELF::EMPLOYEE_AGGREAGTE_TYPE_ID][$categoryId]['aggregate_name'] = $data['parameter_value'];
                        $approvalSettingArray['category'][SELF::EMPLOYEE_AGGREAGTE_TYPE_ID][$categoryId]['aggregate_operator'] = $data['r_operator_id'];
                          $categoryId++;
              }
              if($data['parameter_type'] == 'criteria')
              {
                  // get ParentAggregate name
                  $parentCriteriaArray = array('criteria_name','criteria_type');
                  $parentCriteriaName = $this->_OcommonDBO->_select('dm_criteria', $parentCriteriaArray,'criteria_id',$data['parameter_id']); 
                  $data['parameter_name'] = $parentCriteriaName[0]['criteria_name'];
                  $data['parameter_type'] = $parentCriteriaName[0]['criteria_type'];  
                  if(!in_array($data['parameter_type'],$approvalSettingArray['selectedCriteria']))
                        $approvalSettingArray['selectedCriteria'][] = $data['parameter_type'];
                    $criteriaParameterId = $data['parameter_id'];
                    $approvalSettingArray['criteria'][$data['parameter_id']]['criteria_id'] = $data['parameter_id'];
                    $approvalSettingArray['criteria'][$data['parameter_id']]['criteria_name'] = $data['parameter_name'];
                    $approvalSettingArray['criteria'][$data['parameter_id']]['criteria_value'] = $data['parameter_value'];
                    $approvalSettingArray['criteria'][$data['parameter_id']]['criteria_operator'] = $data['r_operator_id'];
                    $approvalSettingArray['criteria'][$data['parameter_id']]['criteria_type'] = $data['parameter_type'];
                  $criteriaId++;
              }        
              if($data['start_date']  != "0000-00-00")
              {
                    $startDate = date_create($data['start_date']);
                    $approvalSettingArray['startDate'] = date_format($startDate,"d-M-Y");
              }
              if($data['end_date']  != "0000-00-00")
              {
                    $endDate = date_create($data['end_date']);
                    $approvalSettingArray['endDate'] = date_format($endDate,"d-M-Y");
              }
             
           }
       return $approvalSettingArray;
   }
   
   // get the the subcorporate status
   public function _checkSubcorporateStatus($approversInfo,$approvalSettingsInfo) 
   {
       if($approversInfo != '')
       {
           $subCorporateStatus = 'N';
           foreach($approversInfo as $data)
           {
               $subCorproateId = $this->_Ocorporate->_getCorporateNameInfo($data['approver_id']);
               $data['corporate_id'] = $subCorproateId[0]['r_corporate_id'];
               $data['corporate_name'] = $subCorproateId[0]['corporate_name']; 
               if($approvalSettingsInfo['corporateId'] != $data['corporate_id'])
               {
                  $subCorproateInfo['sub_corporate_status'] = 'Y';
                  $subCorproateInfo['sub_corporate_id'] = $data['corporate_id'];
                  $subCorproateInfo['sub_corporate_name'] = $data['corporate_name'];
                  $subCorproateInfo[$data['approver_id']]['sub_corporate_id'] = $data['corporate_id'];
                  $subCorproateInfo[$data['approver_id']]['sub_corporate_status'] = 'Y';                  
                  return $subCorproateInfo;
               }               
           }
       }       
   }
   
    
}
?>