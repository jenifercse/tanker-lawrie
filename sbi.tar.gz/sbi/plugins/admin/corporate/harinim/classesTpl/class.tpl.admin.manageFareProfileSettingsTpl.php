<?php

/* * **************************************************************************
 * @File             : class.tpl.admin.manageFareProfileSettingsTpl.php
 * @Description      : This file is used to view and create the fare profile settings
 * @Tables Affected  : application_settings,application_settings_details,setting_value
 * @Author           : Karthika
 * @Created Date     : 17/08/2017
 * @Modified Date    :
 * *************************************************************************** */

class manageFareProfileSettingsTpl {

    public function __construct() {

        $this->_OcommonDBO = new commonDBO();
        $this->_OcommonQuery = new commonQuery();
        $this->_OAgency = new agency();
        $this->_OappSettings = new manageApplicationSettings();
        $this->_Opermission = new getPermission();
        $this->_Ocorporate = new corporate();
        $this->_Oemployee = new employee();
    }

    //function for getting module mapping info and assign it in twig.
    public function _getDisplayInfo(){

        //set Input data
        $input = $this->_IinputData;

        //calling function based on the action.
        switch($input['action']){

            //get Corporate name
            case "getCorporateName":
                $agencyCorporateList = $this->_OAgency->_getAgencyCorporateList($input['agencyId']);
                $this->_AfinalResponse = $agencyCorporateList;
                break;

            //get user type or aggregate based on the process type for the corporate.
            case 'corporateType':
                $this->_AfinalResponse = $this->_OcommonDBO->_select('dm_user_type', '*');
                break;

            //used to get booking type personal or corporate
            case 'getBookingType':
                $this->_getBookingType($input);               
                break;

            //get user type.
            case 'processType';
                $this->_getProcessType();
                break;

            //get user type.
            case 'travelMode';
                $this->_getTravelMode($input);
                break;

            //get trip type
            case 'tripType';
                $this->_getTripType($input);
                break;

            //get trip type
            case 'workingType';
                $this->_getWorkingType($input);
                break;

            //get trip type
            case 'activationStatus';
                $this->_getActivationStatus($input);
                break;

            //get application setting info.
            case 'getApplicationSettings':
                $this->_getApplicationSettings($input);
                break;

            //create the json
            case 'createJson':
                $_OauthToken = new authToken();
                $purifiedValue = $_OauthToken->_purifyInputData(APPLICATION_BASE_PATH.FARE_PROFILE_SETTING_JSON_FILE_PATH.'mobile_fareProfileSetting_*.json');
                array_map('unlink', glob($purifiedValue));

                //calling function for updating the fare profile settings for the corporate.
                $response = $this->_createFareProfileSettings($input);
                
                //write the json.
                $this->_OappSettings->_getDataForJson($this->_IinputData);
                $this->_AfinalResponse = array('status' => 3);
                break;
            
            //settings for aggregate view
            //get category list
            case "getCategorySubCorporateInfo":        
                $category =  $this->_OcommonQuery->_getAggregateByType($input);
                $finalArrayInfo = [];
                $finalArrayInfo['categoryInfo']= $category;
                $this->_AfinalResponse = $finalArrayInfo;
                break;

            case 'getCorporateFlowType':
                // to get corporate Flow Type
                $this->_getFlowTypeValueFromJson($input);
                break;

            case 'EDIT':
                $bookingType = $this->_IinputData['bookingType'];
                $this->_editValues = $this->_OappSettings->_prepareFareProfileList($this->_OappSettings->_getApplicationSettingsList('FARE_SETTING_ID',$input['fareProfileSettingId'],0,0,$bookingType),'FARE_SETTING_ID');
                $approvalSettingsInfo = $this->_getAggregateData($this->_editValues[0]['editValue']['category']);
                $this->_AserviceResponse['modify']  = 'Y';
                $this->_AserviceResponse['editValues']  =$this->_editValues[0];
                $this->_AtwigOutputArray['editAction'] = 'editFareSettings';
                /* aggregate Funtion  */
                // get approval setting logic info
                 $allCategory = $this->_OcommonQuery->_getAggregateByType(array("agencyId"=>$this->_editValues[0]['r_agency_id'],"corporateId"=>$this->_editValues[0]['r_corporate_id'])); 
                // set the array values in service response 
                
                $this->_AserviceResponse['allAggregateInfo'] = $allCategory;
                $this->_AserviceResponse['aggregateArr'] =$approvalSettingsInfo['category'];
                $selectedAggregates = array_keys($approvalSettingsInfo['category']);
                foreach($allCategory as $catVal)
                {
                    if(in_array($catVal['aggregate_type_id'],$selectedAggregates))
                    $result['categoryInfo'][] = array("id"=>$catVal['aggregate_type_id'],"name"=>$catVal['aggregate_type']);
                }
                $this->_AserviceResponse['selectedAggregates'] =  $result['categoryInfo'];
                break;

             
             case 'checkSettingsExist':
                //to check whether settings with travel mode and trip exist or not
                $this->_checkSettingsExist($input);
                break;   

            case 'settingNameExist':
                $this->_checkNameExist($input);
                break;

            case 'getCorporateEnabledBookingType':
                $this->_AfinalResponse= $this->_OcommonQuery->_getCorporateEnabledType($this->_IinputData['corporate_id']);
                break;

            default:

                //calling function for showing the agency and corporate based on permission.
                $this->_OcommonQuery->_getAgencyCorporatePermissionCheck();

                //get corporate enabled booking type
                $bookingTypeInfo = $this->_OcommonQuery->_getCorporateEnabledType($_SESSION['corporateId']);

                $this->_AserviceResponse = $this->_OcommonQuery->_AserviceResponse;
                $this->_AtwigOutputArray = $this->_OcommonQuery->_AtwigOutputArray;
                $this->_AserviceResponse['userTypeId'] = $_SESSION['userTypeId'];
                if($_SESSION['userTypeId'] == 3){
                    $this->_AserviceResponse['corporate'] = $this->_Ocorporate->_getSyncCorporateDetails();
                }
                $this->_AserviceResponse['bookingTypeInfo'] = $bookingTypeInfo;
        }
    }
    
    function _getWorkingType($input) {

        $this->_AfinalResponse = $this->_OappSettings->_getWorkingType($input);
    }

    function _getActivationStatus($input) {
        $this->_OappSettings->_getActivationStatus($input);
        $this->_AfinalResponse = "SUCCESS";
    }

    //Get the settings info based on input while click search.
    function _getApplicationSettings($input) {
        
        //Get product default settings based on personal / corporate setting
        $defaultSettingId = ($input['bookingType'] == 'Personal') ? 2 : 1;

        $defaultSetting = $this->_OappSettings->_getApplicationSettings($defaultSettingId,0,0,$input['bookingType']); //For get default settings

        //Get corporate based settings
        $corporateSetting = ($input['fareProfileSettingId'] > 2) ? $this->_OappSettings->_getApplicationSettings($input['fareProfileSettingId'],0,0,$input['bookingType']) : '' ;
        $this->fareSettingArray = (is_array($corporateSetting)) ? array_merge($defaultSetting, $corporateSetting) : $defaultSetting ; 
        
        //Get geneal settings based on corporate
        $fareProfileSettingId = $this->_OappSettings->_getFareSettingId($input['agencyId'],$input['corporateId'],$input['bookingType']);
        $generalSetting = $this->_OappSettings->_getApplicationSettings($fareProfileSettingId,$input['agencyId'],$input['corporateId'],$input['bookingType']);
        $this->fareSettingArray = (is_array($generalSetting)) ? array_merge($this->fareSettingArray, $generalSetting) : $this->fareSettingArray ; 
        
        //calling function for getting the info
        $this->_AfinalResponse = $this->_segregateArray($this->fareSettingArray);
        $this->_AserviceResponse['viewData'] = $this->_segregateArray($this->fareSettingArray);
    
    }

    //array formation for show the application settings info.
    function _segregateArray($applicationSettings) {
        foreach ($applicationSettings AS $key => $value) {  
            
            $appSettings[$value['group_name']][$value['setting_name']][$value['setting_value']] = array('setting_value' => $value['setting_value'],
                'input_type' => $value['input_type'],
                'default_value' => $value['default_value'],
                'text_box_value' => $value['text_box_value'],
                'fare_profile_setting_id' => $value['fare_profile_setting_id'],
                'application_setting_name_id' => $value['application_setting_name_id'],
                'application_settings_value_id' => $value['application_setting_value_id'],
                'fact_fare_profile_setting_id' => $value['fact_fare_profile_setting_id'],
                'mandatory_status' => $value['mandatory_status']);
        }
        foreach ($appSettings AS $groupNameKey => $groupNameValue) {
            foreach ($groupNameValue AS $settingNameKey => $settingNameValue) {
                $appSettings[$groupNameKey][$settingNameKey] = array_values($settingNameValue);
            }
        }
        return $appSettings;
    }

    function _getTravelMode($input) {

        $this->_AfinalResponse = $this->_OappSettings->_checkTravelModeTripTypeMapping($input);
    }

    function _getTripType($input) {

        $this->_AfinalResponse = $this->_OappSettings->_checkTravelModeTripTypeMapping($input);
    }

    //get the userType and aggregate info based on the work flow selection in session.
    function _getProcessType() {
        //get from the session.

        $this->_AfinalResponse = $this->_OcommonDBO->_select('dm_user_type', '*');
    }

    /*
    * description:: function to get data based on corporate id passing
    */
    public function _getFlowTypeValueFromJson($corporateId){
        $corporateId['bookingType'] = $corporateId['bookingType'] == "Corporate" ? "corporate/" : "personal/";

        $this->_AfinalResponse = $this->_OappSettings->_getSpecificDataFromJSON($corporateId['corporateId'],'FARE_PROFILE_FLOW_TYPE',$corporateId['bookingType']);
    }
    
    //function used to update the fare profile settings info.
    public function _createFareProfileSettings($input){     
       
        //get the modified settings info from the interface.
        $modifiedSettingsInfo = $this->_getModifiedSettingsInfo($input);
        //calling the function based on the action.
        $input['fareProfileSettingsAction'] == 'INSERT' ? $this->_insertFareProfileSettings($modifiedSettingsInfo,$input):$this->_updateFareProfileSettings($modifiedSettingsInfo,$input);

     }

    //forming the array for getting the updated settings info from the interface.
    public function _getModifiedSettingsInfo($input){

        //assign the variable.
        $modifiedSettingsInfo = $updatedSettingsInfo = array();
        
        //looping the previous fare profile settings info.
        foreach ($input['previousSettingsInfo'] as $configKey => $configValue){
            
            foreach ($configValue as $settingNameKey => $settingNameValue){              
                
                foreach ($settingNameValue as $setKey => $setValue){                    
                 
                    //forming the array for based on input type.
                    if ($setValue['input_type'] == 'IB'|| $setValue['input_type'] == 'IBM'  || $setValue['input_type'] == 'TB' || $setValue['input_type'] == 'IWF' || $setValue['input_type'] == 'CP' || $setValue['input_type'] == 'LS' || $setValue['input_type'] == 'ED') {
                        //getting the values of updated info(compare the updated value with previous value of application settings)

                        if ($setValue['text_box_value'] != $input['updatedSettingsInfo'][$configKey][$settingNameKey][$setKey]['text_box_value']) {
                            //getting the changed setting name id.
                            $applicationSettingsNameId[] = $setValue['application_setting_name_id'];
                            //pushing the updated settings info in a array
                            $modifiedSettingsInfo[$setValue['application_setting_name_id']][$setValue['fact_fare_profile_setting_id']] = $input['updatedSettingsInfo'][$configKey][$settingNameKey][$setKey];

                        }
                    } 
                    else if ($setValue['input_type'] == 'CBI'){
                         
                        if ($setValue['text_box_value'] != $input['updatedSettingsInfo'][$configKey][$settingNameKey][$setKey]['text_box_value'] || $setValue['default_value'] != $input['updatedSettingsInfo'][$configKey][$settingNameKey][$setKey]['default_value']) {

                            //getting the changed setting name id.
                            $applicationSettingsNameId[] = $setValue['application_setting_name_id'];
                            //pushing the updated settings info in a array
                            $modifiedSettingsInfo[$setValue['application_setting_name_id']][$setValue['fact_fare_profile_setting_id']] = $input['updatedSettingsInfo'][$configKey][$settingNameKey][$setKey];
                        }
                    } 
                    else{

                        //getting the values of updated info(compare the updated value with previous value of application settings)
                        if ($setValue['default_value'] != $input['updatedSettingsInfo'][$configKey][$settingNameKey][$setKey]['default_value']) {

                            //getting the changed setting name id.
                            $applicationSettingsNameId[] = $setValue['application_setting_name_id'];
                            //pushing the updated settings info in a array
                            $modifiedSettingsInfo[$setValue['application_setting_name_id']][$setValue['fact_fare_profile_setting_id']] = $input['updatedSettingsInfo'][$configKey][$settingNameKey][$setKey];
                        }
                    }
                }
            }
        }
        
        //remove the duplicates from the value.
        $applicationSettingsNameId = array_unique($applicationSettingsNameId);
        $applicationSettingsNameId = array_values($applicationSettingsNameId);
        
        //get the settings info with respect to the application settings name id.
        if (count($applicationSettingsNameId) > 0){
            
            //get previous setting info for updated setting name id.
            $oldExistingSettingArray = $this->_formingExistingSettingsInfo($input, $applicationSettingsNameId);  
            
            //looping for compare the updated array and previous array of particular application setting name id.
            foreach ($oldExistingSettingArray as $settingsNameId => $settingsNameValue){
                
                //get the unchanged setting info of updated setting name id.
                $remainingSettingInfo = array_diff_key($settingsNameValue, $modifiedSettingsInfo[$settingsNameId]);
                
                //merge the not updated setting info and updated setting info with respect to application_setting_name_id
                $newSettingArray = array_merge((array) $remainingSettingInfo, (array) $modifiedSettingsInfo[$settingsNameId]);
                
                //all setting array in a loop.
                $allSettingInfo = array_merge((array) $allSettingInfo, (array) $newSettingArray);
            }
        }

        return $allSettingInfo;
    }

    //forming the array for getting the common(all) settings info for the particular application setting name id.
    public function _formingExistingSettingsInfo($input, $applicationSettingsNameId) {

        foreach ($applicationSettingsNameId as $nameId){
            
            //getting the name info with respect to application_settings_name id
            $applicationSettingNameInfo = $this->_OappSettings->_getApplicationSettingConfigNameInfo($nameId); 
            
            //get the value from the previous value.
            $existingSettingsInfo = $input['previousSettingsInfo'][$applicationSettingNameInfo['group_name']][$applicationSettingNameInfo['display_name']];
            foreach ($existingSettingsInfo as $key => $value) {
                //pushing the array with the index of application_setting_name_id.
                $allExistingSetting[$value['application_setting_name_id']][$value['fact_fare_profile_setting_id']] = $value;
            }
        }      
        return $allExistingSetting;
    }
    
    
    /*
    * @Description  This method is used insert the fare profile setting table while creation
    * @param|array:$input,$modifiedSettingsInfo
    * @date:2.11.2017  
    * @author:Karthika.M
    */ 
    public function _insertFareProfileSettings($modifiedSettingsInfo,$input){  
        //insert into dm_fare_profile_setting table.
        $this->_IinputData['fare_profile_setting_id'] = $input['fare_profile_setting_id'] = $fareProfileSettingsId = $this->_fareProfileSettingsMasterInsert($input);        

        //insert the other table based on the master id.
        if($fareProfileSettingsId != '' && $fareProfileSettingsId != 0){
            
            //insert the general configuration settings with respect to the agency and corporate.
            $generalConfigSettingId = $this->_insertGeneralConfigurationSettingValue($input);

            //insert into fact_fare_profile_setting       
            count($modifiedSettingsInfo) > 0 ? $factFareProfileSettingsId = $this->_factFareProfileSettingsInsertion($modifiedSettingsInfo,$input):'';

            //insert into fare_profile_user_mapping
            $fareProfileUserMappingId = $this->_fareProfileUserMappingInsert($input,$fareProfileSettingsId);    

            //insert into fare_profile_travel_type_mapping
            $fareProfileTravelTypeMappingId = $this->_fareProfileTravelTypeMappingInsert($input,$fareProfileSettingsId); 

            $this->_insertFareProfileSettingTracking($input,"create");
        }
    }    
    
    /*
    * @Description  This method is used insert the existing general configurations for selected agency and corporate.
    * @param|array:$input
    * @date:6.11.2017  
    * @return|array:$factFareProfileSettingsId
    * @author:Karthika.M
    */ 
    public function _insertGeneralConfigurationSettingValue($input){
        //get the fare profile setting id with respect to the agency and corporate. 
        $fareProfileSettingsId = $this->_OappSettings->_getFareSettingId($input['agency_id'],$input['corporate_id'],$input['booking_type']);
        
        //get the general configurations info for the setting id,agency and corporate id.
        $settingsInfo = $this->_OappSettings->_getApplicationSettings($fareProfileSettingsId,$input['agency_id'],$input['corporate_id'],$input['booking_type']);

         
        if(count($settingsInfo) > 0){
            //form the fact profile settings array.
            foreach($settingsInfo as $key => $value){                
                $factFareProfileSettings['r_fare_profile_setting_id'] = $input['fare_profile_setting_id'];
                $factFareProfileSettings['r_application_setting_value_id'] = $value['application_setting_value_id'];
                $factFareProfileSettings['default_value'] = $value['default_value'];
                $factFareProfileSettings['text_box_value'] = $value['text_box_value'];    
                $factFareProfileSettingsId[] = $this->_insertUpdateFactFareProfile($factFareProfileSettings,$settings['fare_profile_setting_id'],$value['application_settings_value_id']);
            }
            
            return $factFareProfileSettingsId;
        }
    }
    
    /*
    * @Description  This method is used insert the dm_fare_profile_setting
    * @param|array:$input
    * @date:2.11.2017  
    * @return|array:$fareProfileSettingsId
    * @author:Karthika.M
    */ 
    public function _fareProfileSettingsMasterInsert($input){
        $applicationTypeFlag = ($input['booking_type'] == 'Personal') ? 'P' : 'C';

        //forming the array from input.
        $fareProfileSettings['fare_profile_setting_name'] = $input['fare_profile_settings_name'];
        $fareProfileSettings['r_corporate_id']            = $input['corporate_id'];
        $fareProfileSettings['r_agency_id']               = $input['agency_id'];
        $fareProfileSettings['application_type']          = $applicationTypeFlag;

        return $this->_OcommonDBO->_insert('dm_fare_profile_setting',$fareProfileSettings);     
    }
    
    /*
    * @Description  This method is used insert the fact_fare_profile_setting
    * @param|array,int:$modifiedSettingsInfo,$fareProfileSettingsId
    * @date:2.11.2017  
    * @return|array:$factFareProfileSettingsId
    * @author:Karthika.M
    */ 
    public function _factFareProfileSettingInsert($fareProfileSettingsId,$modifiedSettingsInfo){
        
        //forming the array for insertion.
        foreach ($modifiedSettingsInfo as $key => $value){            
            
            $factFareProfileSettings['r_fare_profile_setting_id'] = $fareProfileSettingsId;
            $factFareProfileSettings['r_application_setting_value_id'] = $value['application_settings_value_id'];
            $factFareProfileSettings['default_value'] = $value['default_value'];
            $factFareProfileSettings['text_box_value'] = ($value['input_type'] == 'IB' || $value['input_type'] == 'TB' || $value['input_type'] == 'IWF' || $value['input_type'] == 'CBI' || $value['input_type'] == 'CP' || $value['input_type'] == 'LS') ? $value['text_box_value'] : '';
            $factFareProfileSettingsId[] = $this->_OcommonDBO->_insert('fact_fare_profile_setting',$factFareProfileSettings);  
        }
        return $factFareProfileSettingsId;
    }
    
    
    /*
    * @Description  This method is used insert the fare_profile_user_mapping
    * @param|array,int:$input,$fareProfileSettingsId
    * @date:2.11.2017  
    * @return|array:$fareProfileUserMappingId
    * @author:Karthika.M
    */ 
    public function _fareProfileUserMappingInsert($input,$fareProfileSettingsId){
        
       //if flow type is aggregate based.
        if(count($input['aggregate_id']) > 0){            
            foreach($input['aggregate_id'] as $type => $aggregateValue){                
                foreach ($aggregateValue as $aggregateKey => $aggregateId){
                    $userMappingId[] = $aggregateId;
                }
            }    
            $mappingType = 'A';
        }
        else{
            //if flow type is user type based.
            $userMappingId = $input['user_type'];
            $mappingType = 'U';
        }        
        
        //forming the array and insert into the fare_profile_user_mapping table
        foreach ($userMappingId as $key => $userMappingId){
            $fareProfileUserMapping['r_fare_profile_setting_id'] = $fareProfileSettingsId;
            $fareProfileUserMapping['user_mapping_type'] = $mappingType;
            $fareProfileUserMapping['user_mapping_type_id'] = $userMappingId;   
            $fareProfileUserMappingId[] = $this->_OcommonDBO->_insert('fare_profile_user_mapping',$fareProfileUserMapping); 
        }        
        return $fareProfileUserMappingId;
    }
    
   /*
    * @Description  This method is used insert the fare_profile_travel_type_mapping
    * @param|array,int:$input,$fareProfileSettingsId
    * @date:2.11.2017  
    * @return|array:$fareProfileTravelTypeMappingId
    * @author:Karthika.M
    */ 
    public function _fareProfileTravelTypeMappingInsert($input,$fareProfileSettingsId){
        
        //looping the travel mode info for forming the fare profile travel type info
        foreach ($input['travelModeId'] as $travelKey => $travelType){
            $travelModeId = $this->_OcommonDBO->_select('dm_travel_mode','travel_mode_id','travel_mode_code',$travelKey)[0]['travel_mode_id'];
            foreach ($travelType as $tripKey => $tripType){
                $fareProfileTravelTypeMapping['r_fare_profile_setting_id'] = $fareProfileSettingsId;
                $fareProfileTravelTypeMapping['r_travel_mode_id'] = $travelModeId;
                $fareProfileTravelTypeMapping['trip_type_id'] = $tripType;
                $fareProfileTravelTypeMappingId[] = $this->_OcommonDBO->_insert('fare_profile_travel_type_mapping',$fareProfileTravelTypeMapping); 
            }
        }        
        return $fareProfileTravelTypeMappingId;
    }     

    public function _getAggregateData($categoryData){
        $categoryId=0;

        // get ParentAggregate name
        foreach ($categoryData as $key => $value) {
              $parentCategoryArray = array('aggregate_type_id','aggregate_name','aggregate_id');
              $parentCategoryName = $this->_OcommonDBO->_select('dm_aggregate', $parentCategoryArray,'aggregate_id',$value)[0]; 
              $data['parameter_type'] = $parentCategoryName['aggregate_type_id']; 
              if(!in_array($data['parameter_type'],$approvalSettingArray['selectedAggregateTypes']))
                    $approvalSettingArray['selectedAggregateTypes'][] = $data['parameter_type'];
                    $approvalSettingArray['category'][$data['parameter_type']][$categoryId]['aggregate_id'] = $parentCategoryName['aggregate_id'];
                    $approvalSettingArray['category'][$data['parameter_type']][$categoryId]['aggregate_type_id'] = $data['parameter_type'];
                    $approvalSettingArray['category'][$data['parameter_type']][$categoryId]['aggregate_name'] = $parentCategoryName['aggregate_name'];
                      $categoryId++;
        }
        return $approvalSettingArray;
    }
    
    /*
    * @Description  This method is used update the fare profile settings info.
    * @param|array:$input,$modifiedSettingsInfo
    * @date:2.11.2017  
    * @return|array:
    * @author:Karthika.M
    */ 
    public function _updateFareProfileSettings($modifiedSettingsInfo,$input){ 
        
        $settingsCombination = $input['editValue']['editValue'];        
        
        //check the mapping type id with the previous input based on the flow type.
        $this->_updateFareProfileUserMapping($settingsCombination,$input);
        
        //check the travel mapping type id with the previous input.
        $this->_updateFareProfileTravelMapping($settingsCombination,$input);  

        //insert the fare_profile_tracking table.
        // if(count($this->_fareProfileUserMappingInfo) > 0 || count($this->_fareProfileTravelMappingInfo) > 0){
            $this->_insertFareProfileSettingTracking($input,"modify");
        // }
        
        //update the fact_fare_profile_settings.
        if(count($modifiedSettingsInfo) > 0){
            $this->_factFareProfileSettingsInsertion($modifiedSettingsInfo,$input);
        }
    }
    
    /*
    * @Description  This method is used update the fare_profile_user_mapping info.
    * @param|array:$settingsCombination,$input
    * @date:4.11.2017  
    * @return|array:
    * @author:Karthika.M
    */ 
    public function _updateFareProfileUserMapping($settingsCombination,$input){
        
        //if flow type is user type
        if($settingsCombination['flowTypeId'] == 1){  
            //set user type.
            $prevInputs['user_type'] = $settingsCombination['category'];        
            //compare the previous input with the current input while update.
            foreach($input['user_type'] as $key => $value){
                if($value != $prevInputs['user_type'][$key]){
                    $modifiedType[] = $value;
                }
            }          
        }
        //if flow type is aggregate.
        else{            
            //compare the previous aggregate input with the input while update.
            foreach($input['aggregate_id'] as $aggregateTypeId => $aggregateType){
                foreach($aggregateType as $aggregateKey => $aggregateId){
                    //comparison.
                    foreach($settingsCombination['category'] as $key => $value) {
                        if($value != $aggregateId){
                            $modifiedType[] = $aggregateId;
                        }
                    }                  
                }
            }
        }        
               
        //delete the existing user mapping value and insert the new mapping value in fare_profile_user_mapping
        if(count($modifiedType) > 0){
            
            //get the previous mapping type as json.
            $fareProfileUserMappingInfo = $this->_OcommonDBO->_select('fare_profile_user_mapping','*','r_fare_profile_setting_id',$input['fare_profile_setting_id']);
            $this->_fareProfileUserMappingInfo = json_encode($fareProfileUserMappingInfo);
            
            //delete the previous values in fare_profile_user_mapping.
            $this->_OcommonDBO->_delete('fare_profile_user_mapping','r_fare_profile_setting_id',$input['fare_profile_setting_id']);
            
            //delete the inputs.
            $fareProfileUserMappingId =  $this->_fareProfileUserMappingInsert($input,$input['fare_profile_setting_id']);
        }               
    }
    
    /*
    * @Description  This method is used update the fare_profile_travel_type_mapping info.
    * @param|array:$settingsCombination,$input
    * @date:4.11.2017  
    * @return|array:
    * @author:Karthika.M
    */ 
    public function _updateFareProfileTravelMapping($settingsCombination,$input){
        
        //looping the input of travel mode.
        foreach($input['travelModeId'] as $travelKey => $travelCode){
            
            //get the travel mode.
            $fieldArray = array('travel_mode_id','travel_mode');
            $travelModeInfo = $this->_OcommonDBO->_select('dm_travel_mode',$fieldArray,'travel_mode_code',$travelKey);
            $travelModeId = $travelModeInfo[0]['travel_mode_id'];
            $travelModeName = $travelModeInfo[0]['travel_mode'];      
            
            //compare the previous travel mode with input of travel mode id.
            if(count($settingsCombination['appliedTo'][$travelModeId][$travelModeName]) != count($travelCode)){
                $modifiedTravelMode[] = $travelKey;
            }
            
            foreach($travelCode as $value){
                if(!isset($settingsCombination['appliedTo'][$travelModeId][$travelModeName][$value]) && $settingsCombination['appliedTo'][$travelModeId][$travelModeName][$value] == ''){
                    $modifiedTravelMode[] = $value;
                }
            }
        }    
        
        //checking the count of previous travel mode with the current input count.
        if(count($settingsCombination['appliedTo']) != count($input['travelModeId'])){
            $modifiedTravelMode[] = 'Y';
        }
        
        if(count($modifiedTravelMode) > 0){
            
            //get the previous mapping type as json.
            $fareProfileTravelMappingInfo = $this->_OcommonDBO->_select('fare_profile_travel_type_mapping','*','r_fare_profile_setting_id',$input['fare_profile_setting_id']);
            $this->_fareProfileTravelMappingInfo = json_encode($fareProfileTravelMappingInfo);
            
            //delete the fare_profile_travel_type_mapping table 
            $this->_OcommonDBO->_delete('fare_profile_travel_type_mapping','r_fare_profile_setting_id',$input['fare_profile_setting_id']);
            
            //insert the new travel mapping value 
            $fareProfileTravelTypeMappingId = $this->_fareProfileTravelTypeMappingInsert($input,$input['fare_profile_setting_id']);  
        }
    }
    
    /*
    * @Description  This method is used update the fact_fare_profile_setting info based on the configurations.
    * @param|array:$settingsCombination,$input
    * @date:4.11.2017  
    * @return|array:
    * @author:Karthika.M
    */ 
    public function _factFareProfileSettingsInsertion($modifiedSettingsInfo,$input){
        
        //check the fact_fare_profile_setting already is there for that settings id,
        foreach($modifiedSettingsInfo as $key => $value){
            
            $factFareProfileSettings['r_fare_profile_setting_id'] = $input['fare_profile_setting_id'];
            $factFareProfileSettings['r_application_setting_value_id'] = $value['application_settings_value_id'];
            $factFareProfileSettings['default_value'] = $value['default_value'];
            $factFareProfileSettings['text_box_value'] = ($value['input_type'] == 'ED' || $value['input_type'] == 'IBM' || $value['input_type'] == 'IB' || $value['input_type'] == 'TB' || $value['input_type'] == 'IWF' || $value['input_type'] == 'CBI' || $value['input_type'] == 'CP' || $value['input_type'] == 'LS') ? $value['text_box_value'] : '';
            
            //get the settings group name with respect to the application settings value.
            $settingsGroupId = $this->_OappSettings->_getSettingsGroupNameInfo($value['application_settings_value_id'])[0]['application_setting_group_name_id'];
           
            //if general configuration settings modified means, we have to update that value for all the settings in fact fare profile settings.
            if($settingsGroupId == 10){
                
                //set agency and corporate id.
                $data['r_agency_id'] = $input['agency_id'];
                $data['r_corporate_id'] = $input['corporate_id'];
                
                //get the settings info with respect to the agency and corporate id.
                $settingsInfo = $this->_OappSettings->_checkFareProfileSettingsExist($data,'N');    
                
                //looping the settings info.
                foreach($settingsInfo as $settings){
                    //set fare profile settings id;
                    $factFareProfileSettings['r_fare_profile_setting_id'] = $settings['fare_profile_setting_id'];                   
                    $factFareProfileSettingsId[] = $this->_insertUpdateFactFareProfile($factFareProfileSettings,$settings['fare_profile_setting_id'],$value['application_settings_value_id']);
                }
            } 
            //for other configurations,
            else{
                
                //insert and update the fact_fare_profile_setting based on the settings info.
                $factFareProfileSettingsId[] = $this->_insertUpdateFactFareProfile($factFareProfileSettings,$input['fare_profile_setting_id'],$value['application_settings_value_id']);
            }
        }
        return $factFareProfileSettingsId;
    }    
    
    /*
    * @Description  This method is used update the fact_fare_profile_setting.
    * @param|array,int,int:$factFareProfileSettings,$fareProfileSettingsId,$settingsValueId
    * @date:4.11.2017  
    * @return|array:
    * @author:Karthika.M
    */ 
    public function _insertUpdateFactFareProfile($factFareProfileSettings,$fareProfileSettingsId,$settingsValueId){
    
        //check if the settings value already insert for the settings id.
        $factFareProfileSettingsInfo = $this->_OappSettings->_getFactFareProfileSettingsInfo($fareProfileSettingsId,$settingsValueId);                    
        if(!$factFareProfileSettingsInfo){          
            $factFareProfileSettingsId = $this->_OcommonDBO->_insert('fact_fare_profile_setting',$factFareProfileSettings);
        }
        else{
            $factFareProfileSettingsId = $this->_OappSettings->_updateFactFareProfileSetting($factFareProfileSettings);
        }        
        return $factFareProfileSettingsId;
    }


    /*
    * @Description  This method is used update the fact_fare_profile_setting.
    * @param|array,int,int:$factFareProfileSettings,$fareProfileSettingsId,$settingsValueId
    * @date:4.11.2017  
    * @return|array:
    * @author:V.P Baskar
    */
    public function _checkSettingsExist($input){
        $count = 0;
        $manageApplicationSettings = new manageApplicationSettings();
        $checkinput['corporateId'] =$input['corporate_id']; 
        $checkinput['agencyId'] =$input['agency_id'];
        if($input['flowType'] == 1){
            foreach ($input['user_type'] as $aggKey => $aggValue) {
                foreach ($input['travelModeId'] as $travelKey => $travelValue) {
                    foreach ($travelValue as $travelInnerKey => $travelInnerValue) {
                        // to form and call the function based on function
                        $checkinput['tripType'] = $travelInnerValue;
                        $checkinput['travelMode'] = $travelKey == 'D' ? 1 : 9;
                        $checkinput['flowType'] = $input['flowType'] == 1 ? 'U' : 'A';
                        $checkinput['type'] = $aggValue;
                        $checkinput['settingId'] = $input['settingId'];
                        $checkinput['bookingType'] = $input['bookingType'];
                        $key = $aggInValue.'_'.$checkinput['travelMode'].'_'.$checkinput['tripType'];
                         $resultValue = $manageApplicationSettings->_getFareProfileSettingsName($checkinput,'N')[0]['fare_profile_setting_name'];
                         if($resultValue != ''){
                            $resultArray[$resultValue][$count]['travelMode'] = $checkinput['travelMode'] == 1 ? 'Domestic' : 'International';
                            $resultArray[$resultValue][$count]['tripType'] = $checkinput['tripType'];
                            $resultArray[$resultValue][$count]['flowType'] = $input['flowType'];
                            $resultArray[$resultValue][$count]['aggregateName'] =$this->_OcommonDBO->_select("dm_user_type","*",'user_type_id',$checkinput['type'])[0]['user_type_name'];
                             $count++;
                         }
                    }
                }
            }
        }
        else{
            // to call and get settings name for the name created array
            foreach ($input['aggregate_id'] as $aggKey => $aggValue) {
                foreach ($aggValue as $aggInKey => $aggInValue) {
                    foreach ($input['travelModeId'] as $travelKey => $travelValue) {
                        foreach ($travelValue as $travelInnerKey => $travelInnerValue) {
                            // to form and call the function based on function
                            $checkinput['tripType'] = $travelInnerValue;
                            $checkinput['travelMode'] = $travelKey == 'D' ? 1 : 9;
                            $checkinput['flowType'] = $input['flowType'] == 1 ? 'U' : 'A';
                            $checkinput['type'] = $aggInValue;
                            $checkinput['settingId'] = $input['settingId'];
                            $checkinput['bookingType'] = $input['bookingType'];
                            $key = $aggInValue.'_'.$checkinput['travelMode'].'_'.$checkinput['tripType'];
                             $resultValue = $manageApplicationSettings->_getFareProfileSettingsName($checkinput,'N')[0]['fare_profile_setting_name'];
                             if($resultValue != ''){
                                $resultArray[$resultValue][$count]['travelMode'] = $checkinput['travelMode'] == 1 ? 'Domestic' : 'International';
                                $resultArray[$resultValue][$count]['tripType'] = $checkinput['tripType'];
                                $resultArray[$resultValue][$count]['flowType'] = $input['flowType'];
                                $resultArray[$resultValue][$count]['aggregateName'] =$this->_OcommonDBO->_select("dm_aggregate","*",'aggregate_id',$checkinput['type'])[0]['aggregate_name'];
                                $count++;
                             }
                        }
                    }
                }
            }
        }
        $this->_AtwigOutputArray['farArray'] = $resultArray;
        $this->_AtwigOutputArray['flowType'] = $input['flowType'];
        $this->_AfinalResponse = count($resultArray)>0 ? array('status' => 1, 'template' => $this->_Otwig->render('fareProfileValidationAlert.tpl',$this->_AtwigOutputArray)) : array('status'=> 0, 'error_alert'=> 'Proceed');
        return true;
    }
    
    /*
    * @Description  This method is used to check the setting name already exist or not.
    * @param|array:$input
    * @date:6.11.2017  
    * @return|array:$this->_AfinalResponse
    * @author:Baskar.V.P
    */
    public function _checkNameExist($input){
        //calling function for checking the setting name.
         $this->_AfinalResponse  = $this->_OappSettings->_checkFareProfileSettingsExist($input,$flag='ALL');
    }
    
    /*
    * @Description  Insert the fare_profile_tracking table
    * @param|array:$input
    * @date:18.11.2017  
    * @return|array:$result
    * @author:Karthika.M
    */
    public function _insertFareProfileSettingTracking($input,$action){
        $sql = "INSERT INTO fare_profile_setting_tracking (r_fare_profile_setting_id, user_mapping_json, travel_type_mapping_json,action, modified_by)
                VALUES (".$input['fare_profile_setting_id'].",compress('".$this->_fareProfileUserMappingInfo."'),compress('".$this->_fareProfileTravelMappingInfo."'),'".$action."','".$_SESSION['loginEmail']."')";
        $result = $this->_OcommonDBO->_executeQuery($sql);
        return $result;
    }

    /*
    * @Description  get the booking type info with respect to the corporate id.
    * @param|array:$input
    * @return|array:$result
    */
    public function _getBookingType($input){    

        //get sync corporate details
        $corporateInfo = $this->_OcommonDBO->_select('sync_corporate_details',array('booking_mode','r_corporate_id'),'sync_corporate_id',$input['syncCorporateId'])[0];

        $this->_AfinalResponse['bookingMode'] = ($corporateInfo['booking_mode'] == '1') ? 'Corporate' : 'Personal';
        $this->_AfinalResponse['r_corporate_id'] = $corporateInfo['r_corporate_id'];
        $this->_AfinalResponse['bookingModeInfo'] = $this->_OcommonQuery->_getCorporateEnabledType($corporateInfo['r_corporate_id']);
        return $this->_AfinalResponse;
    }
}