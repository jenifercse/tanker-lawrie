<?php
/* * **************************************************************************
 * @File             : class.tpl.insertDynamicApproverSettingsTpl.php
 * @Description      : This file is used to insert the dynamic approval settings details
 * @Tables Affected  : approval_parameter_mapping,dm_approval_settings
 * @Author           : Lakshmi.S
 * @Created Date     : 02/01/2017
 * @Modified Date    : 
 * ****************************************************************************/

fileRequire('/lib/common/commonMethods.php');
pluginFileRequire('common/', 'interface/commonConstants.php');
class insertDynamicApprovalSettingsTpl implements commonConstants
{    

    public function __construct() {    
        $this->_OcommonDBO = new commonDBO();
        $this->_OdynamicApproverSettings = new dynamicApproverSettings();
    }
   
   
   public function _getDisplayInfo()           
   {    
        $this->_OcommonArrayClass = new commonArrayFunctions();
        if(!isset($this->_IinputData['selectedAggregates'][SELF::EMPLOYEE_AGGREAGTE_TYPE_ID])){
            $selectedAggregates = $this->_OcommonArrayClass->_arrayFlatten($this->_IinputData['selectedAggregates'],array());
        }
        else{
            $selectedAggregates=$this->_IinputData['selectedAggregates'][SELF::EMPLOYEE_AGGREAGTE_TYPE_ID];
        }
        foreach ($selectedAggregates as $key => $value) 
        {
            if(isset($this->_IinputData['selectedAggregates'][SELF::EMPLOYEE_AGGREAGTE_TYPE_ID])){
                $aggregateCategory[$key]['aggregateCategoryId']  = $value['employeeId'];
                $aggregateCategory[$key]['operatorId'] = $this->_IinputData['selectedAggregatesOperator'];
                $aggregateCategory[$key]['categoryValue']  = $value['emailId'];
                $aggregateCategory[$key]['aggregateCategoryType']  = "'employee'";
            }
            else{
                $aggregateCategory[$key]['aggregateCategoryId']  = $value;
                // get aggregate value
                $aggregateValue =  $this->_OcommonDBO->_select('dm_aggregate', 'aggregate_name', 'aggregate_id', $value);
                $aggregateValue = $aggregateValue[0]['aggregate_name'];
                $aggregateCategory[$key]['aggregateCategoryId']  = $value;
                $aggregateCategory[$key]['operatorId'] = $this->_IinputData['selectedAggregatesOperator'];
                $aggregateCategory[$key]['categoryValue']  = $aggregateValue;  
                $aggregateCategory[$key]['aggregateCategoryType']  = "'category'";
            }
                      
        }
        $this->_IinputData['aggregateCategory'] =  $aggregateCategory;
        unset($this->_IinputData['selectedAggregates']);
        unset($this->_IinputData['selectedAggregatesOperator']);       
        
         if(isset($this->_IinputData['criteria']) && count($this->_IinputData['criteria']) >0)
         {
            // to insert the selected criteria as a string in the dm_approval_settings table
            $criteriaArray = array_column($this->_IinputData['criteriaList'], "criteria_logical_name","criteria_id");        
            $this->_IinputData['validation_string'] = $this->_OdynamicApproverSettings->_generateEvalString($this->_IinputData['criteria'],$criteriaArray);       
         }   
         else
         {
            $this->_IinputData['validation_string'] = 1;
         }
          
        //Function call to insert approval settings mater data (dm_approval_settings table insert)
        $resultApprovalSettings=$this->_OdynamicApproverSettings->_insertDynamicApprovalSettings($this->_IinputData);
       
        if($resultApprovalSettings>0){
           $this->_IinputData['approval_settings_id']= $resultApprovalSettings;
           //Function call to insert approval info details (approval_mapping table insert)
           $resultApprovalParameterMapping=$this->_OdynamicApproverSettings->_insertApprovalParameterMapping($this->_IinputData);
           
           //Function call to insert approval mapping details (approval_mapping table insert)
           $resultApprovalMapping=$this->_OdynamicApproverSettings->_insertApproverMapping($this->_IinputData);
       }
   }     

}
?>