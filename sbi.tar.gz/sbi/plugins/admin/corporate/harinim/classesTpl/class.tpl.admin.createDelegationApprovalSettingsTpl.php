<?php
/* * **************************************************************************
 * @File             : class.tpl.createDelegationApprovalSettingsTpl.php
 * @Description      : This file is used to create dynamic approver settings.
 * @Tables Affected  : delegation_approval_mapping
 * @Author           : Karthika
 * @Created Date     : 23/12/2016
 * @Modified Date    : 
 * ****************************************************************************/

fileRequire('lib/common/commonMethods.php');

class createDelegationApprovalSettingsTpl
{      
    public function __construct() {       
         $this->_OcommonDBO = new commonDBO(); 
         $this->_Oemployee = new employee(); 
         $this->_Odelegation = new delegationApprovalSettings();
         $this->_CcorporateCustomization = new corporateCustomization();
    }

    public function _getDisplayInfo()
    {   
        $usertypeId = '';
        // get travel type enabled for corporate
        $this->travelMode =  $this->_CcorporateCustomization->_getCorporateEnabledTravleModesList($this->_CcorporateCustomization->_getCorporateEnabledTravleModes('TRAVEL_MODES'));
        
        $usertypeId = $_SESSION['userTypeId'];
        
        // get employee email id with session corporate id and based on user type
        $approverEmailId = ($usertypeId == 4) ? $this->_Oemployee->_getCorporateEmployeeInfo($_SESSION['corporateId'], $usertypeId) : $this->_Oemployee->_getCorporateEmployeeInfo($_SESSION['corporateId']);
        $this->_AserviceResponse['approverEmailId'] = $approverEmailId;

        // corporate user delegation approval settings 
        ($usertypeId == 4) ? $this->_AserviceResponse['corporateUserDetails'] = array('employeeEmailId' => $_SESSION['employeeEmailId'], 'employeeId' => $_SESSION['employeeId']) : FALSE;        
        
        // set the input data
        $input = $this->_IinputData;
        
        // insert the data in delegation approval mapping table
        if($input['action'] == 'insert')
        {
            $delegationApproverInfo = $input;
            $delegationApproverInfo['start_date_range'] = $delegationApproverInfo['start_date'];
            $delegationApproverInfo['end_date_range'] = $delegationApproverInfo['end_date'];
            $delegationApproverInfo['travel_mode_id'] = $delegationApproverInfo['r_travel_mode_id'];  
            unset($delegationApproverInfo['start_date']);
            unset($delegationApproverInfo['end_date']);
            unset($delegationApproverInfo['r_travel_mode_id']);
            $delegationApprovalSetting = $this->_Odelegation->_getDelegationApprovalListInfo($delegationApproverInfo);
            
            // evaluate date range of delegate settings 
            $restrictReAssignDelegationApproval = $this->_Odelegation->_restrictDelegationApprovalReAssign($delegationApproverInfo);            
            
            unset($delegationApproverInfo['delegation_approver']);
            
            // evaluate date range of delegate settings 
            $daterangeEvaluation = $this->_Odelegation->_getEvaluateDelegationApprovalDateRange($delegationApproverInfo);
            
            $delegationApprovalExist = $this->_Odelegation->_getDelegationApprovalListInfo($delegationApproverInfo);
            if(count($delegationApprovalSetting) > 0){
               $this->_AfinalResponse = "exist";
            }
            elseif (count($delegationApprovalExist) > 0) {
                $this->_AfinalResponse = "exist";
            }
            // evaluation for date range validation
            elseif (!$daterangeEvaluation) {
                $this->_AfinalResponse = "exist";
            }
            // evaluation for re assigining delegation approval
            else if(!$restrictReAssignDelegationApproval){
                $this->_AfinalResponse = "exist";
            }
            else
            {         
                $unwantedKeys = array($input['action']);
                $insertArray = array_diff($input, $unwantedKeys);
                if((isset($input['start_date'])) && $input['start_date'] != "")
                {
                    $insertArray['start_date'] = date("Y-m-d",strtotime($insertArray['start_date']));
                }                 
                if((isset($insertArray['end_date'])) && $insertArray['end_date'] != "")
                {
                    $insertArray['end_date']=date("Y-m-d",strtotime($insertArray['end_date']));
                }
                $delegationApproverId = $this->_Odelegation->_insertDelegationApprovalSettings('delegation_approval_mapping',$insertArray);
                if($delegationApproverId != '')
                {
                  $this->_Odelegation->_Otwig = $this->_Otwig;
                  $this->_Odelegation->_intimateDelegationApprovalMail($input);
                  $this->_AfinalResponse = "Success";  
                }
            }
        }
        // get the data from delegation approval mapping table
        if($input['action'] == 'edit')
        {           
            // get approval setting details
            $delegationApprovalSettingsDetails = $this->_Odelegation->_getDelegationApprovalInfo($input['delegation_approval_mapping_id']);
            
            if($delegationApprovalSettingsDetails != '')
            {
                $approverEmailIdInfo = $this->_Odelegation->_getCurrentDelegationApproverEmailId($delegationApprovalSettingsDetails);
                $this->_AserviceResponse['editDelegateApprovalInfo'] = $approverEmailIdInfo[0];
                
            }
        }
        // update the data in delegation approval mapping table
        if($input['action'] == 'update')
        {
            $daterangeEvaluation = TRUE;
            $alreadyExistFlag = 'N';
            $delegationApproverInfo = $input;
            $delegationApproverInfo['start_date_range'] = $delegationApproverInfo['start_date'];
            $delegationApproverInfo['end_date_range'] = $delegationApproverInfo['end_date'];
            $delegationApproverInfo['travel_mode_id'] = $delegationApproverInfo['r_travel_mode_id'];
            unset($delegationApproverInfo['start_date']);
            unset($delegationApproverInfo['end_date']);
            unset($delegationApproverInfo['r_travel_mode_id']);
            $delegationApprovalSetting = $this->_Odelegation->_getDelegationApprovalListInfo($delegationApproverInfo);
            unset($delegationApproverInfo['delegation_approver']);

            // evaluate date range of delegate settings 
            $delegationApproverInfo['active_status'] == 'Y' ? $daterangeEvaluation = $this->_Odelegation->_getEvaluateDelegationApprovalDateRange($delegationApproverInfo) : FALSE;
            
            $delegationApprovalExist = $this->_Odelegation->_getDelegationApprovalListInfo($delegationApproverInfo);
            if(count($delegationApprovalSetting) > 0 && count($delegationApprovalExist) > 0)
            {
                foreach($delegationApprovalExist as $value)
                {
                    if($input['delegation_approval_mapping_id'] != $value['delegation_approval_mapping_id'])
                    {    
                        $alreadyExistFlag = 'Y';                       
                        break;
                    }
                }
            }
            if(!$daterangeEvaluation){
                $alreadyExistFlag = 'Y';
            }
            
            if($alreadyExistFlag == 'Y')
            {       
                $this->_AfinalResponse = "exist";
            }
            else
            {     
                if((isset($input['start_date'])) && $input['start_date'] != "")
                {
                    $input['start_date'] = date("Y-m-d",strtotime($input['start_date']));
                }                
                if((isset($input['end_date'])) && $input['end_date'] != "")
                {
                    $input['end_date']=date("Y-m-d",strtotime($input['end_date']));
                }
                $updateDelegationApprovalInfo = $this->_Odelegation->_updateDelegationApprovalSettings($input);  
                if($updateDelegationApprovalInfo == 1)
                {   
                    $this->_Odelegation->_Otwig = $this->_Otwig; 
                    $this->_Odelegation->_intimateDelegationApprovalMail($input);
                    $this->_AfinalResponse = "Success";
                }
            }
        }
     
        $this->_templateAssign();
    }

    // assing the values in twig template
    public function _templateAssign() 
    {    
        $this->_AtwigOutputArray['travelMode'] = $this->travelMode;
        $this->_AtwigOutputArray['action'] = $this->_IinputData['action'];

    }

}
?>