<?php

/* * **************************************************************************
 * @File             : class.tpl.passThrough.php
 * @Description      : This file is a classTpl file for PassThrough Interfce
 * @Author           : A.KAVIYARASAN
 * @Updated By       : Deepak Pande(27-11-2017)
 
 * *************************************************************************** */
class passThroughCreationTpl {

    public function __construct() 
            {
      $this->_OcommonDbo = new commonDBO();        
      $this->_OcommonQuery = new commonQuery();
      $this->_OpassThrough=new passThrough();
            }
    /*
     * @functionName    :   _getDisplayInfo()
     * @description     :   default module method
     * 
     */
            
   public function _getDisplayInfo() 
    {    
        $key=ENCRIPTION_CODE;
        switch($this->_IinputData['action'])
        {
        case 'insertion':       /*for insertion for passThrough Creation Menu*/
                                $message= $this->_OpassThrough->_getInsert($this->_IinputData['datas'],$this->_IinputData['encriptdata'],$key);//normal flow for insertion
                                $this->_AfinalResponse=array('message'=>$message);//sending the status message back to browser
                                break;

        case 'getform'  :        
                                /*getting the Form for PassThroughMapping Creation*/ 
                                $response=$this->_Otwig->render('passThroughform.tpl',array()); //'addressdefault'=>$this->_OpassThrough->_getAgencyAdress(),
                                $this->_AfinalResponse=array('response'=>$response,"message"=>'success','permission'=>$_SESSION['permissions']['permissionName'],'agencyid'=>$_SESSION['agencyId']); 
                                break;
             
             
        case  'edit'    :      /*getting the particular user and cardetails for edition purpose*/
                            $passengerdetail= $this->_OpassThrough->_getUpdateDetails($this->_IinputData['id'],$key);//getting the card  details  by passing the passthrough_card_id 
                            $passengerdetail['agencyname']=$this->_OcommonDbo->_select('dm_agency','agency_name','dm_agency_id',$passengerdetail[0]['r_agency_id']);//getting the agency details by passing r_agency_id 
                            $response=$this->_Otwig->render('passThroughform.tpl',array());//rendering the template with the above details 
                            $this->_AfinalResponse=array('response'=>$response,'passengerdetail'=>$passengerdetail);//assigning into the final response
                            break;
                    
        case  'update'  :    /*for updating the card details  in dm_passthrough_card_details*/
                            /*updating the cardetails by passing datas and passthrough_mapping id*/
                           $message=$this->_OpassThrough->_updateDetails($this->_IinputData['updatewithencript'],$this->_IinputData['updationData'],$this->_IinputData['id'][0][0],$key);
                           $this->_AfinalResponse=array('message'=>$message,'count'=>$result);
                           break;

        case 'searchFilter': /*search filter for all login*/
                              $this->_OpassThrough->_viewList($key,$this->_IinputData['input']);
                              $response=$this->_Otwig->render('passThroughtable.tpl',$this->_OpassThrough->_assigntemplate);//rendring the template
                              $this->_AfinalResponse = array('response'=>$response,'status' => 1,'status'=>'success','hideDiv'=>'passThroughmappingtable');
                            break;
                        
       case 'checkMappedStatus':
                                 $result=$this->_OcommonDbo->_select('passthrough_mapping_details','passthrough_mapping_id',array('r_passthrough_card_id','status'),array($this->_IinputData['passthrough_card_id'],'Y'));
                                 $response['message']='The card cannot be mapped to any corporate/airline if the status is inactive. Still you want to proceed?';
                                  if(!empty($result))
                                  {
                                 $response['message']='Disabling this card will disable all the airline - corporate sets which has this card details mapped to it. You want to continue?';
                                 $response['mappedDetails']=$result;
                                  }
                                 $this->_AfinalResponse = array('response'=>$response);  
                                  break;
                        
        case 'changeStatus':/*for changing the status */
                            if(!empty($this->_IinputData['passthrough_card_id']))
                              {   
                                $this->_IinputData['status']['status']=='Y'?$this->_IinputData['status']['status']='N':$this->_IinputData['status']['status']='Y';
                                $this->_OcommonDbo->_update('dm_passthrough_card_details',$this->_IinputData['status'],'passthrough_card_id',$this->_IinputData['passthrough_card_id']);    
                                 if($this->_IinputData['mappedDetail']!='')
                                 {
                                     $mapId=array_column($this->_IinputData['mappedDetail'], 'passthrough_mapping_id');
                                     $mapId= implode(",",$mapId);
                                     $sql="Update  passthrough_mapping_details set status='N'  where passthrough_mapping_id IN($mapId)";
                                     $this->_OcommonDbo->_executeQuery($sql);
                                 }
                                $this->_AfinalResponse = array('response'=>$response,'status' =>3,'status_message' => 'success', 'error_alert' => '','result'=>'Status updated Successfully');  
                            }
                            break;

                    
          default   : 
               /*for checking the usert type and permission by calling the function agencyCorporateCheck()*/
               $this->_OcommonQuery->_getAgencyCorporatePermissionCheck();
              /*getting the permission data  from the agencyCorporateCheck */
               $this->_AserviceResponse = $this->_OcommonQuery->_AserviceResponse;
               $this->_AserviceResponse['agency'] = $this->_OcommonQuery->_AtwigOutputArray;
               //unset($this->_AserviceResponse['corporate']);
               //$this->_AserviceResponse['card_type']=array('BTA','CTA','Credit Card');
               $this->_assigntemplate= $this->_OcommonQuery->_AtwigOutputArray;
               $input=$this->_OcommonQuery->_getUserTypePermissionCheck();
               //executing at default case
               $this->_OpassThrough->_viewList($key,$input);
               break;
        }
        $this->_templateassaign();//executing at all cases
    }
    
    
    /*
     * @functionName    :   _templateassaign()
     * @description     :   used to store  the passThrough class AtwigOutputArray into this class AtwigOutputArray
     * return value     : 
     */
    
        public function _templateassaign()
           {
               $this->_AtwigOutputArray=$this->_OpassThrough->_assigntemplate;
            
               
           }
           
     
            
               

    }
