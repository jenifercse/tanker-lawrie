<?php
/* * **************************************************************************
 * @File            Manage employee profile
 * @Description     This class file holds all employee related informations
 * @Author          Vijaykeerthi R
 * @Created Date    07/01/2017
 * ****************************************************************************/
class manageEmployeeProfileTpl {

    public function __construct(){
        $this->_Oemployee                = common::_checkClassExistsInNameSpace('employee');
        $this->_Oairline                 = new airline();
        $this->_Oagency                  = new agency();
        $this->_OcreateAggregate         = new createManageAggregate();
        $this->_OcommonQuery             = new commonQuery();
    }
    
    public function _getDisplayInfo(){

        $agencyId                        = $_SESSION['agencyId'] ? $_SESSION['agencyId'] : $_REQUEST['agencyId'];
        $corporateId                     = $_SESSION['corporateId'] ? $_SESSION['corporateId'] : $_REQUEST['corporateId'];
        $this->_SsessionId               = array('agencyId' =>$agencyId ,'corporateId'=>$corporateId);  
        $this->_SsessionId['permission'] = $_SESSION['permissions'] ? $_SESSION['permissions'] : $_REQUEST['permissions'];
        
        $this->_AallowedUserType = array('TR','CA','CU','NU');
        
        switch($this->_IinputData['action']){
            
            case 'getAllEmployeeDetails' :
                $this->_AfinalResponse['employeeListDetails'] = $this->_empListDetails = $this->_Oemployee->_getEmployeeDetailsBasedOnPermissionAccess($this->_SsessionId['permission'],$this->_AallowedUserType,$this->_IinputData['agencyId'],$this->_IinputData['corporateId'],$this->_IinputData['userTypeId'],$this->_IinputData['emailStr'],$this->_IinputData['employeeCode']);
                $this->_templateAssign();
                break;

            case 'getCreateEmployeeForm':
                    $fareProfileSettings = $this->_OcommonQuery->_getSettingsDisplayData('','Request_Form_Configurations');
                    $this->_AfinalResponse['familyEnable'] = $fareProfileSettings['Family']['status'];
                    $this->_prepareProfileForm($corporateId);
                    $this->_templateAssign();
                    $this->_AtwigOutputArray['action']      = $this->_IinputData['action'];
                    $_SgridDisplay = $this->_Otwig->render('employeeProfileForm.tpl', $this->_AtwigOutputArray);
                    $this->_AfinalResponse = array('status' => 1, 'status_message' => 'success', 'error_alert' => '', 'result' => 'success', 'template' => $_SgridDisplay);
                    break;
                    
            case 'getEmployeeDetails':                
                $this->_AfinalResponse = $this->_getEmployeeDetails();
                break;

            case 'getAggregateValues':
                $empAggregate = $this->_Oemployee->_getAggregateDetails($this->_IinputData['aggregate_id']);
                $this->_AfinalResponse['employeeAggregateVals'] = $this->_Oemployee->_getEmployeeAggregateDetails($empAggregate[0]['parent_id']);
                break;

            case 'insertEmployeeDetails' :
                $this->_AfinalResponse = $this->_Oemployee->_insertEmployeeDetails($this->_IinputData,$corporateId);
                break;

            case 'updateEmployeeDetails' :
                $this->_AfinalResponse = $this->_Oemployee->_updateEmployeeDetails($this->_IinputData,$corporateId);
                break;

            case 'getAgencyCorporates'  :
                $this->_AfinalResponse = $this->_Oagency->_getAgencyCorporateList($this->_IinputData['agencyId']);
                break;

            case 'getCostCenterMapped' :
                $this->_AfinalResponse = $this->_getCostCenterCode($corporateId,$this->_IinputData['businessAreaCode']);
                break;

            case 'addEmployeeCorporateSettings':
                $this->addEmployeeCorporateSettings();
                break;

            case 'checkemployeeProfileUpdate':
                $this->_AfinalResponse = $this->_Oemployee->_getCorporateEmployeeProfileSettingsUpdated($_SESSION['employeeId']);
                break;

            // case to check and employee status in database
            case 'updateEmployeeStatus':
                $this->_OcommonDBO = new commonDBO();
                $query = "UPDATE dm_employee SET status = '".$this->_IinputData['status']."' WHERE employee_id =".$this->_IinputData['employeeId'];
                $masterResult = $this->_OcommonDBO->_executeQuery($query);
                $this->_AfinalResponse = array('status' => 1, 'status_message' => 'success', 'error_alert' => '', 'result' => 'success', 'template' => '');
                break; 

            default:
                $this->_AfinalResponse['user_type'] = $this->_Oemployee->_getAllowedUserTypes($this->_AallowedUserType);
                $this->_AfinalResponse['fieldList'] = $this->_SsessionId['permission']['fieldList'];
                $this->_AfinalResponse['employeeListDetails'] = $this->_empListDetails = $this->_Oemployee->_getEmployeeDetailsBasedOnPermissionAccess($this->_SsessionId['permission'],$this->_AallowedUserType,$this->_IinputData['agencyId'],$this->_IinputData['corporateId'],$this->_IinputData['userTypeId'],$this->_IinputData['emailStr'],$this->_IinputData['employeeCode']);
                $this->_getAgencyCorporatePermissions();
                $this->_templateAssign();
                //Show ajax list content
                $_SgridDisplay = $this->_Otwig->render('manageEmployeeProfileList.tpl', $this->_AtwigOutputArray);
                $this->_AfinalResponse = array('status' => 1, 'status_message' => 'success', 'error_alert' => '', 'result' => 'success', 'template' => $_SgridDisplay);


                break;
        }
        $this->_AserviceResponse['EmpProfileRestriction'] = $this->_Oemployee->_getEmployeeProfileRestriction();
        $this->_AfinalResponse['userTypeId'] = $this->_AserviceResponse['userTypeId'] = $_SESSION['userTypeId'];
    }
    
    /**
     * add function adds employe corporate settings
     * @param 
     * @return 
     */
    public function addEmployeeCorporateSettings(){
        return;
    }
    
    /**
     * Gets employee profiles based on their permission
     */
    public function _getAgencyCorporatePermissions(){

        if($_SESSION['permissions']['permissionName']=='Self'){
            $this->_AfinalResponse['access'] = 'Self';
        } 
        else if($_SESSION['permissions']['permissionName']!='All'){
            $this->_AfinalResponse['agency_id'] = $_SESSION['agencyId'];
            $corporates = $this->_OcommonQuery->_corporateAgencyPermission();
            $this->_AfinalResponse['agencyCorporates'] = $corporates['corporate'];
        } 
        else{
            $this->_AfinalResponse['agencies'] = $this->_Oagency->_getAgencyList(array('dm_agency_id','agency_name'));
        }        
    }
    
    /**
     * Prepare form select box values
     * @param int $corporateId Corporate id
     * @return boolean
     */
    public function _prepareProfileForm($corporateId){

        $this->_AfinalResponse['user_type']               = $this->_Oemployee->_getAllowedUserTypes($this->_AallowedUserType);
        $this->_AfinalResponse['employeeDesignations']    = $this->_Oemployee->_getDesignationDetails($corporateId);
        $this->_AfinalResponse['employeeDepartments']     = $this->_Oemployee->_getDepartmentDetails($corporateId);
        $this->_AfinalResponse['employeeBranches']        = $this->_Oemployee->_getBranchDetails($corporateId);
        $this->_AfinalResponse['employeeBands']           = $this->_Oemployee->_getBandDetails($corporateId);
        $this->_AfinalResponse['employeeBilltoAddresses'] = $this->_Oemployee->_getBilltoAddressDetails($corporateId);
        $this->_AfinalResponse['employeeSeatPreferences'] = $this->_Oemployee->_getSeatPreferences();
        $this->_AfinalResponse['employeeMeals']           = $this->_Oemployee->_getMealDetails();
        $this->_AfinalResponse['businessAreaCodes']       = $this->_getbusinessAreaCode($corporateId);
        $this->_AfinalResponse['costcenterCodes']         = $this->_getCostCenterCode($corporateId);
        $this->_AfinalResponse['travelmodes']             = $this->_Oemployee->_getTravelModes();
        $this->_AfinalResponse['airline_list']            = $this->_Oairline->_getAirlineDetails($airlineId=0,array('airline_id','airline_name')); 
        $this->_AfinalResponse['bookingType']             = INDEXNAME;
       
        return TRUE;
    }
    
    /*
     * Calling seperately to override method in loreal customization
     */
    public function _getCostCenterCode($corporateId, $businessAreaCode=''){
        $costCenterCode = $this->_Oemployee->_getCostcenterCodeDetails($corporateId,'','','','',$businessAreaCode);
        return $costCenterCode;
    }
    
    public function _getbusinessAreaCode($corporateId){
        $businessAreaCode = $this->_Oemployee->_getCostcenterCodeDetails($corporateId,'','','','P');
        return $businessAreaCode;
    }
    
    /**
     * Assing values for template
     */
    public function _templateAssign(){        
        $this->_AtwigOutputArray = $this->_AfinalResponse;
    }

    public function _getEmployeeDetails(){

        //set employee id for the edit my profile
        (!isset($this->_IinputData['employee_id']) && $this->_IinputData['employee_id'] == '') ? $this->_IinputData['employee_id'] = $_SESSION['employeeId'] : '';

        //set session of employee id
        $employeeData['sessEmpId'] = $_SESSION['employeeId'];
        
        //get employee master details
        $employeeData['employeeData'] = $this->_Oemployee->_getEmployeeMasterDetails($this->_IinputData['employee_id']);
        //get employee frequent flyer details
        $employeeData['employeeFrequentFlyer'] = $this->_Oemployee->_getEmployeeFrequentFlyer($this->_IinputData['employee_id']);

        $employeeData['EmpProfileRestriction'] = $this->_Oemployee->_getEmployeeProfileRestriction();

        //add conditon for super-admin to display all possible values
        if($this->_SsessionId['permission']['permissionName'] != 'All'){
            //get employee corporate id and populate possible values in dropdown
            $corporateId = $employeeData['employeeData']['r_corporate_id'];
        }

        //Get form select box values
        $this->_prepareProfileForm($corporateId);

        //get aggretate values
        $this->_AfinalResponse['employeeAggregateVals'] = $this->_OcreateAggregate->_getEmployeeAggregateDetails($this->_IinputData['employee_id']);
                    
        //Get aggregate childs
        foreach($this->_AfinalResponse['employeeAggregateVals'] as $key => $value) {
            $this->_OcreateAggregate->_getAggregateParentId($value['aggregate_id']);
        }

        //Get approver details
        $this->_AfinalResponse['approverDetails'] = $this->_Oemployee->_getEmployeeApprovers($this->_OcreateAggregate->_PparentId,$this->_IinputData['employee_id']);
        
        $this->_AfinalResponse['approverDetails'] = $this->_Oemployee->_setApproverInfo($this->_AfinalResponse['approverDetails'],$this->_IinputData['employee_id']);

        //get business area code details
        $this->_AfinalResponse['businessAreaCodes'] = $this->_getbusinessAreaCode($corporateId);

        $this->_AfinalResponse['bookingType'] = INDEXNAME;

        //get fare profile settings info
        $fareProfileSettings = $this->_OcommonQuery->_getSettingsDisplayData('','Request_Form_Configurations');
        $this->_AfinalResponse['familyEnable'] = $fareProfileSettings['Family']['status'];
                    
        //rendering in the template
        $this->_templateAssign();
        $_SgridDisplay = $this->_Otwig->render('employeeProfileForm.tpl',$this->_AtwigOutputArray);

        //assign family details   
        $familyDetails = $this->_Oemployee->_getFamilyDetails($this->_IinputData['employee_id'],'Y');
        if(is_array($familyDetails) && count($familyDetails) > 0){
            $employeeData['familyDetails'] = $familyDetails;
        }

        //set action.
        $employeeData['action'] = $this->_Oemployee->_getManageEmployeeDetails();        

        //set final response
        return array('status' => 1,'status_message' => 'success','error_alert' => '','result' => $employeeData,'template' => $_SgridDisplay,'familyEnable' => $fareProfileSettings['Family']['status'],'employeeId' => $this->_IinputData['employee_id']);
    }
}
?>