<?php
/* * **************************************************************************
 * @File             : class.tpl.corporateMigrationTpl.php
 * @Description      : This file is used to migrate employee with approval based
 * @Author           : Sivaprakash.M
 * @Created Date     : 08/03/2017
 * @Modified Date    : 
 * ****************************************************************************/

fileRequire('classes/class.migrate.php');

class corporateMigrationTpl
{
    public $_Afiles;

    public function __construct() {
        $this->_Afiles = array();
       $this->_Ccorporate = new corporate();
       $this->_Omigrate = new migrate();
    }
    /*
     * @Description  Common module function
     */
    public function _getDisplayInfo()
    {
    
	$action = $this->_IinputData['action'];
        
        switch ($action) {
            case 'getCorporateMigrationCsv':
                $response = $this->_migrateData();
                $this->_Omigrate->_aggregateBasedApprovalInsertion($response);
                $this->_AfinalResponse = array('status' => 1, 'message' => 'Migration done successfully!');
                break;

            default:
                $this->_Afiles = $this->_Omigrate->_getMigrationCsvFiles();
                $this->_templateAssign();
        }
        
        
    }
    
    /**
     * Migrate data
     */
    public function _migrateData() {
        
        $filename = $this->_IinputData['file'];
        $approvalType = $this->_IinputData['approvalType'];
        
        //GEt csv data depend on the approval type
        if($approvalType=='Normal'){
            $data = $this->_Omigrate->_readBookingCSV($filename);
        } else {
            $data = $this->_Omigrate->_readCostCenterCSV($filename);
        }
        
        $dataOut = $this->_Omigrate->_createAggregate($data,$approvalType);
        
        return $dataOut;
    }
    
    public function _templateAssign() {
        $this->_AtwigOutputArray['files'] = $this->_Afiles;
        
    }
}
?>
