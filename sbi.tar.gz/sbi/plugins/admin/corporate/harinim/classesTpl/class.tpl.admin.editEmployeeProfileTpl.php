<?php

/* * **************************************************************************
 * @File            editEmployeeProfileTpl
 * @Description     This class file holds employee related informations
 * @Author          Sivaprakash.M
 * @Created Date    03/03/2017
 * *************************************************************************** */
pluginFileRequireByTravelMode('classesTpl/class.tpl.admin.manageEmployeeProfileTpl.php', true);
require_once 'classes/class.common.php';

class editEmployeeProfileTpl {

    public function __construct() {
        $this->_MmanageProfile = new manageEmployeeProfileTpl();
        $this->_MmanageProfile->_Otwig = init();
        $this->_Oemployee = common::_checkClassExistsInNameSpace('employee');
        $this->_Oairline = new airline();
        $this->_OcreateAggregate = new createManageAggregate();
        $this->_OcommonDBO = new commonDBO();
    }

    public function _getDisplayInfo() {
        $agencyId = $_SESSION['agencyId'];
        $corporateId = $_SESSION['corporateId'];
        $this->_SsessionId = array('agencyId' => $agencyId, 'corporateId' => $corporateId);
        
        $r_employee_id = !empty($this->_IinputData['employee_id']) ?  $this->_IinputData['employee_id'] : $_SESSION['employeeId'];
        $allowedUserType = array('CA', 'CU', 'NU');
        switch ($this->_IinputData['action']) {

            case 'getEmployeeDetails' :
                $this->_MmanageProfile->_IinputData['employee_id'] = $r_employee_id;
                $this->_MmanageProfile->_IinputData['action'] = $this->_IinputData['action'];
                $this->_MmanageProfile->_getDisplayInfo();
                $this->_AfinalResponse = $this->_MmanageProfile->_AfinalResponse;
                $this->_AfinalResponse['user_type'] = $this->_Oemployee->_getAllowedUserTypes($allowedUserType); //_getUserTypes();
                $this->_AfinalResponse['employeeId'] = $r_employee_id;
                $this->_AfinalResponse['corporateId'] = $corporateId;
                $this->_AfinalResponse['action'] = $this->_Oemployee->_getManageEmployeeDetails();
                $this->_AfinalResponse['EmpProfileRestriction'] = $this->_Oemployee->_getEmployeeProfileRestriction();
                break;

            case 'changePassword' :
                $this->_AfinalResponse = $this->changePassword($this->_IinputData);
                break;

            case 'getCountryList' :

                if($this->_IinputData['type'] == 1 || $this->_IinputData['type'] == 3) {
                    $_OLocation = new location();
                    $this->_AfinalResponse['countryList'] = $_OLocation->_getCountryList($this->_IinputData['countryName']);
                }
                
                if($this->_IinputData['type'] == 2 || $this->_IinputData['type'] == 3) {
                    $this->_AfinalResponse['visaList']    = $this->_getVisaDetails($this->_IinputData['visaId']);
                }
                
                break;

            case 'saveVisaDetails' :
                $this->_AfinalResponse = $this->_saveVisaDetails($this->_IinputData);
                break;
            
            case 'deleteVisa':
                $this->_AfinalResponse = $this->_deleteVisaDetails($this->_IinputData['visaId']);
                break;

            default :
                $this->_AfinalResponse['user_type'] = $this->_Oemployee->_getAllowedUserTypes($allowedUserType); //
                $this->_AfinalResponse['employeeBands'] = $this->_Oemployee->_getBandDetails($corporateId);
                $this->_AfinalResponse['employeeDesignations'] = $this->_Oemployee->_getDesignationDetails($corporateId);
                $this->_AfinalResponse['employeeDepartments'] = $this->_Oemployee->_getDepartmentDetails($corporateId);
                $this->_AfinalResponse['employeeBranches'] = $this->_Oemployee->_getBranchDetails($corporateId);
                $this->_AfinalResponse['businessAreaCodes'] = $this->_getbusinessAreaCode($corporateId);
                $this->_AfinalResponse['costcenterCodes'] = $this->_getCostCenterCode($corporateId);
                $this->_AfinalResponse['companycode'] = $this->_getCompanyCode($r_employee_id);
                $this->_AfinalResponse['employeeBilltoAddresses'] = $this->_Oemployee->_getBilltoAddressDetails($corporateId);
                $this->_AfinalResponse['employeeSeatPreferences'] = $this->_Oemployee->_getSeatPreferences();
                $this->_AfinalResponse['employeeMeals'] = $this->_Oemployee->_getMealDetails();
                $this->_AfinalResponse['airline_list'] = $this->_Oairline->_getAirlineDetails($airlineId = 0, array('airline_id', 'airline_name'));
                $this->_AfinalResponse['employeeAggregateVals'] = $this->_OcreateAggregate->_getEmployeeAggregateDetails($r_employee_id);

                $this->_OcommonQuery = new commonQuery(); 
                $fareProfileSettings = $this->_OcommonQuery->_getSettingsDisplayData('','Request_Form_Configurations');
                $this->_AfinalResponse['familyEnable'] = $fareProfileSettings['Family']['status'];
                $this->_AfinalResponse['bookingType'] = INDEXNAME;
                //Get aggregate parent
                foreach ($this->_AfinalResponse['employeeAggregateVals'] as $key => $value) {
                    $this->_OcreateAggregate->_getAggregateParentId($value['aggregate_id']);
                }

                $approverData = $this->_Oemployee->_getEmployeeApprovers($this->_OcreateAggregate->_PparentId, $r_employee_id);
                $this->_AfinalResponse['approverDetails'] = $this->_Oemployee->_setApproverInfo($approverData,$r_employee_id);

        }
        $this->_templateAssign();
        $this->_AserviceResponse['EmpProfileRestriction'] = $this->_Oemployee->_getEmployeeProfileRestriction();
        $this->_AfinalResponse['userTypeId'] = $this->_AserviceResponse['userTypeId'] = $_SESSION['userTypeId'];
    }

    /**
     * Getting value for cost center code
     */
    public function _getCostCenterCode($corporateId, $businessAreaCode = '') {
        $costCenterCode = $this->_Oemployee->_getCostcenterCodeDetails($corporateId, '', '', '', '', $businessAreaCode);
        return $costCenterCode;
    }
    /**
     * Getting value for cost center code
     */
    public function _getCompanyCode($employeeId) {
        $companyCode = $this->_Oemployee->_getEmployeeSapDetails($employeeId);
        return $companyCode;
    }

    public function _getbusinessAreaCode($corporateId) {
        $businessAreaCode = $this->_Oemployee->_getCostcenterCodeDetails($corporateId, '', '', '', 'P');
        return $businessAreaCode;
    }

    /**
     * @Description Change existing , after login
     * @return $returnArray
     * @author Ganesan S
     */
    public function changePassword($input) {
    
        global $CFG;
        
        $sql = "SELECT 
                    da.login_password,
                    da.transaction_password 
              FROM dm_account da 
              INNER JOIN fact_employee fe ON da.account_id = fe.r_account_id 
              WHERE fe.r_employee_id=" . $input['employeeId'];
        $result = $this->_OcommonDBO->_getResult($sql);
        foreach ($result as $key => $value) {
            $loginPassword = $value['login_password'];
            $transactionPassword = $value['transaction_password'];
        }
        $oldPassword = commonEncryptDecrypt::_encryptData($input['oldPassword']);
        $newPassword = commonEncryptDecrypt::_encryptData($input['newPassword']);
        //If user entered existed  what he have already,this condition restrict that attempt
        if (($oldPassword != $loginPassword) && ($oldPassword != $transactionPassword)) {
            $returnArray = array('status' => 4, 'message' => 'You enter wrong current password. Please enter correct existing password');
            return $returnArray;
        }
        if ($newPassword == $oldPassword) {
            $returnArray = array('status' => 6, 'message' => 'Entered current password and new password is same. Please try some other password');
            return $returnArray;
        }
        $employee = new employee();
        // first we need to get the account_id for that corporate
        $sql = 'select * from fact_employee WHERE r_employee_id = ' . $input['employeeId'];
        // after getting all the account details for that particular corporate
        $accountDetails = $this->_OcommonDBO->_getResult($sql);
        $resultData = $employee->resetPassword($input, $accountDetails);
        if ($resultData != 0) {
            $returnArray = array('status' => 2, 'message' => 'Password Updated Successfully');
        }
        
        //After  changed successfully the page redirect to below link
        $returnArray['redirectTo'] = "/ZGFzaEJvYXJRVU1vZDg=";
        if(in_array($_SESSION['corporateId'],$CFG['HOME_ICON_HIDE'])) {
            $returnArray['redirectTo'] = "/dmlld1JlcXVlaW9ncXN0QWlyOQ==";
        }
        
        return $returnArray;
    }

    public function _saveVisaDetails() {

        $_Ainsert = array();
       
        $_Ainsert['r_country_id']     = $this->_IinputData['countryId'];
        $_Ainsert['visa_type']        = $this->_IinputData['visaType'];
        $_Ainsert['journey_type']     = $this->_IinputData['journeyType'];
        $_Ainsert['valid_start_date'] = date('Y-m-d', strtotime($this->_IinputData['startDate']));
        $_Ainsert['valid_end_date']   = date('Y-m-d', strtotime($this->_IinputData['endDate']));

        ### insert employee_visa_details
        if(!isset($this->_IinputData['editId']) && empty($this->_IinputData['editId'])) {
            $_Ainsert['r_employee_id']    = $_SESSION['employeeId'];
            $employeeVisaDetailsId = $this->_OcommonDBO->_insert('employee_visa_details', $_Ainsert);
        } else {
            $employeeVisaDetailsId = $this->_OcommonDBO->_update('employee_visa_details', $_Ainsert, 'pass_visa_details_id', $this->_IinputData['editId']);
        }
        $returnValue = ($employeeVisaDetailsId > 0) ? true : false;

        return $returnValue;
    }
    
    public function _deleteVisaDetails($visaId) {
        $this->_OcommonDBO->_delete('employee_visa_details', 'pass_visa_details_id', $visaId);
    }
    
    public function _getVisaDetails($visaId='', $employeeId = '') {
        
        $employeeId = $_SESSION['employeeId'];
        $sql = "SELECT e.pass_visa_details_id as visa_id, c.country_name, e.r_country_id, e.visa_type, e.journey_type,  DATE_FORMAT(e.valid_start_date,'%d-%m-%Y') as valid_start_date, DATE_FORMAT(e.valid_end_date,'%d-%m-%Y') as valid_end_date
                FROM employee_visa_details e INNER JOIN dm_country c ON e.r_country_id = c.country_id WHERE e.r_employee_id = ".$employeeId."";
        
        if($visaId !='') {
            $sql .= " AND pass_visa_details_id = ".$visaId.""; 
        }
        
        $result = $this->_OcommonDBO->_getResult($sql);
        
        return $result;
    }

    /**
     * Assing values for template
     */
    public function _templateAssign() {
        $this->_AtwigOutputArray = $this->_AfinalResponse;
    }

}

?>