<?php
/* * **************************************************************************
 * @File             : class.tpl.insertMenuTpl.php
 * @Description      : This file is used to insert menu in the database.
 * @Tables Affected  : core_menu_details
 * @Author           : Karthika
 * @Created Date     : 29/11/2016
 * @Modified Date    : 
 * ****************************************************************************/

fileRequire('lib/common/commonMethods.php');

class insertMenuTpl
{  

    public function __construct()
    {     
        $this->_OcommonDBO = new commonDBO();   
        $this->_OcommonClas=new common();        
        $this->_OcommonMethods = new commonMethods();
    }
   
   
   public function _getDisplayInfo()           
   {  
       $input = $this->_IinputData;
       
       // Insert the menu       
       if($input['action'] == "insert" )
       {
            $menuId = $this->_insertMenu($input);    
            if($menuId != "")
            {
                $this->_AfinalResponse  = "Success";
            }
       }
       
       // get the menu info       
       elseif($input['action'] == "edit" )
       {           
           $this->_AfinalResponse = $this->_getMenuInfo($input);
       }
       
       // Update the menu
       elseif($input['action'] == "update" )
       {           
           $updateMenuInfo = $this->_updateMenuInfo($input);
           if($updateMenuInfo == 1)
           {
               $this->_AfinalResponse = "Success";
           }
       }
       
       // Delete the menu
       elseif($input['action'] == "delete" )
       {           
           $deleteMenuId = $this->_deleteMenu($input);
           if($deleteMenuId != 0)
           {
              $this->_AfinalResponse = "Success";
           }
       }
       
   }
    // This Function is used for insert menu details in to core_menu_details
    public function _insertMenu($input) 
    {      
        $menuInfo = array();
        $tableName = 'core_menu_details';
        $routingNameEncoded = $input['routing_name'] ? $this->_OcommonMethods->_encriptValue($input['routing_name']) : '';
        $menuInfo['menu_name'] = $input['menu_name'];
        $menuInfo['menu_link'] = $input['menu_link'];
        $menuInfo['menu_status'] = $input['menu_status'];
        $menuInfo['controller_name'] = $input['controller_name'];
        $menuInfo['routing_name'] = $routingNameEncoded;
        $menuInfo['created_date'] = date('Y-m-d');  
        $lastInsertedMenuId = $this->_OcommonDBO->_insert($tableName, $menuInfo);
        return $lastInsertedMenuId;
    }
    
    // This Function is used to get menu details from core_menu_details
    public function _getMenuInfo($input)
    {
        $fieldsArray = array('menu_name','menu_link','menu_status','controller_name','routing_name');
        $result = $this->_OcommonDBO->_select('core_menu_details', $fieldsArray, 'menu_id', $input['menuId']);        
        if($result  != "")
        {
            $result[0]['routing_name'] = $result[0]['routing_name'] ? $this->_OcommonClas->decryptData($result[0]['routing_name']) : '';
            return $result[0];
        }         
    }
    
    // This Function is used for update menu details in to core_menu_details
    public function _updateMenuInfo($input) 
    {    
        $menuUpdateId = '';
        $selectedArray = $this->_getMenuInfo($input);
        $unwantedKeys = array($input['menuId'], $input['action'],$input['tplClassFile'],$input['moduleName']);
        $inputReassign = array_diff($input, $unwantedKeys);
        $updateArray = array_diff($inputReassign, $selectedArray);
        if(count($updateArray) > 0)
        {
            $updateArray['updated_date'] = date('Y-m-d');
            if(isset($updateArray['routing_name']) && (!empty($updateArray['routing_name'])))
            {
                $updateArray['routing_name'] = $this->_OcommonMethods->_encriptValue($updateArray['routing_name']);
            }
            $menuUpdateId = $this->_OcommonDBO->_update('core_menu_details', $updateArray, 'menu_id', $input['menuId']);
        }
        return  $menuUpdateId; 
    }
    
    // This Function is used for delete menu details from core_menu_details
    public function _deleteMenu($input)
    {
        $deleteMenu = $this->_OcommonDBO->_delete('core_menu_details', 'menu_id', $input['menuId']);
        return $deleteMenu;
    }
   
}
?>