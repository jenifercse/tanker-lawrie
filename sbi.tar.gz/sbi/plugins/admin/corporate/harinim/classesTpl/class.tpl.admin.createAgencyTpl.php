<?php
/* * **************************************************************************
 * @File            create Agency
 * @Description     This class file holds all employee related informations
 * @Author          Taslim
 * @Created Date    06/06/2016
 * @Tables used     agency_master, agency_corporate_mapping
 * *************************************************************************** */
class createAgencyTpl {

    //Class variables    
    public  $_Oconnection;
    private $_AFields           = array();
    public  $_AglobalGridValues = array();
    private $_AgridHeader;
    
    public function __construct() 
    {
        $this->_OAgency = new agency();
         $this->db = new commonDBO();
         $this->_AapplicationError[] = 'create agency module error';
    }
    
    /*
     * @Description  this function handles the create agency logic and template to be ovewridden and displayed
     * @param 
     * @return 
     */
    public function _getDisplayInfo()
    {
        $this->_OAgency->_SmoduleAction = $this->_SmoduleAction;
        $this->_OAgency->_IinputData    = $this->_IinputData;
        $this->_OAgency->_Otwig         = $this->_Otwig;
        $this->_OAgency->_IinputData['corporateId']  = $_SESSION['corporateId'];
        $this->_action = isset($this->_IinputData['action']) && !empty($this->_IinputData['action']) ? $this->_IinputData['action'] : 'insert';
        switch($this->_action) {
            
            case 'insert':
                $this->_action = 'insert';
                //default header display
                break;
            
            case 'saveAgency':
                $this->_OAgency->action = 'saveAgency';
                $this->_AfinalResponse = $this->_OAgency->_saveAgency();
                break;
            
            case 'EDIT':
                $result = $this->_OAgency->_getAgencyList('*',$this->_IinputData['id']); // list the agency details
                $this->_OAgency->_assignCorporateToView(); // assigning corporate list to array
                $corporateList = $this->_OAgency->_getAgencyCorporateMappingList($this->_IinputData['id']);
                
                $this->_AtwigOutputArray = $this->_OAgency->_AtwigOutputArray;
                
                if(is_array($corporateList)) {
                    $this->_AtwigOutputArray['selectedValues'] = json_encode($corporateList);
                }

                $this->_AtwigOutputArray['agencyDetails']  = $result[0];
                
            default:
                //
        }
        
        $this->_AtwigOutputArray['agencyDetails']['corporateId'] = $_SESSION['corporateId'];
        
        //$this->_SAlertMsg
        if(isset($this->_OAgency->_ATwigAlertOutput))
        {
           $this->_ATwigAlertOutput = $this->_OAgency->_ATwigAlertOutput;
        }
        
        if(isset($this->_OAgency->_AoverridetemplateNameArray))
        {
            $this->_AoverridetemplateNameArray = $this->_OAgency->_AoverridetemplateNameArray;
        }
        
        $this->_templateAssign();
    }
    
     /*
     * @Description  this function assigns the values to be sent to the template view
     * @param 
     * @return 
     */
    public function _templateAssign()
    {
        $fieldsArray = array('corporate_id','corporate_name');
        $wherekey    = 'status';
        $wherevalue  = 'Y';
        $corporateArray = $this->db->_select('dm_corporate', $fieldsArray, $wherekey, $wherevalue);
        $corporateArray = array_column($corporateArray,'corporate_name','corporate_id');
        $this->_AtwigOutputArray['corporateArray'] = $corporateArray;
        $this->_AtwigOutputArray['action']     = $this->_action;
        $this->_AtwigOutputArray['moduleName'] = $this->_SmoduleName;
        $this->_AtwigOutputArray['agencyStatus'] = array('Y', 'N');
    }
    
}
?>
