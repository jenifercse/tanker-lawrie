<?php
/* * **************************************************************************
 * @File             : class.tpl.createApproverSettingsTpl.php
 * @Description      : This file is used to create dynamic approver settings.
 * @Tables Affected  : dm_approval_settings
 * @Author           : Karthika
 * @Created Date     : 23/12/2016
 * @Modified Date    : 
 * ****************************************************************************/

fileRequire('lib/common/commonMethods.php');
pluginFileRequire('common/', 'interface/commonConstants.php');

class createApproverSettingsTpl implements commonConstants
{  
    public function __construct() 
    {        
        $this->_OcommonDBO=new commonDBO(); 
        $this->_OAgency = new agency();
        $this->_OmanageAggregate = new createManageAggregate();
        $this->_OcommonQuery = new commonQuery();
        $this->_Ocorporate = new corporate();
        $this->_Oemployee = new employee();
        $this->_CcorporateCustomization = new corporateCustomization();
        $this->_CcreateManageAggregate = new createManageAggregate();
    }

    public function _getDisplayInfo(){
        
        // get agency list based on permission.  
        $this->_permissionCheck();
        $this->_AempLevelId = array(5,3);
        $this->_AempLevelId = implode(',', $this->_AempLevelId);
        
        // set Input data
        $input = $this->_IinputData;
        if($input != ""){
            switch($input['action']){            
                // get Corporate name
                case "getCorporateName":
                    $agencyCorporateList =  $this->_OAgency->_getAgencyCorporateList($input['agencyId']);
                    $this->_AfinalResponse = $agencyCorporateList;
                    break;
                   
                //get category list
                case "getCategorySubCorporateInfo":        
                    $category = $this->_CcreateManageAggregate->_getAggregateType(array("r_agency_id"=>$input['agencyId'],"r_corporate_id"=>$input['corporateId']));
                    $subcorporate =  $this->_Ocorporate->_getSubCorporateName($input['corporateId']);
                    $employeeId =  $this->_Oemployee->_getEmployeeId($input['corporateId']);
                    $approverId =  $this->_Oemployee->_getEmployeeId($input['corporateId'],5);
                    $finalArrayInfo = [];
                    $finalArrayInfo['categoryInfo']= $category;
                    $finalArrayInfo['subcorporateInfo']= $subcorporate;
                    $finalArrayInfo['employeeInfo']= $employeeId;
                    $finalArrayInfo['approverInfo']= $approverId;
                    $this->_AfinalResponse = $finalArrayInfo;
                    break;
                
		case 'getAggregateDetailsByType':
                    $responseArray = $this->_fetchAggregatesByType($this->_IinputData);
                    $this->_AfinalResponse = $responseArray ;
                    break;
  
                //get Criteria
                case "getCriteriaList":
                    $result['criteria'] =  $this->_OcommonQuery->_getCriteriaList($input['agencyId'],$input['corporateId'],$input['travelModeId']);
                    $AoperatorArray = $this->_OcommonQuery->_getLogicalOperatorInfo();
                    $result['operators'] = $this->_OcommonQuery->_Aoperators;
                    $this->_AfinalResponse = $result;
                    break;
                
                //get Criteria
                case "getOperatorList":                    
                    $AoperatorArray = $this->_OcommonQuery->_getLogicalOperatorInfo();
                    $result['operators'] = $this->_OcommonQuery->_Aoperators;
                    $this->_AfinalResponse = $result;
                    break;
                
                //get subcorporate employee  email id
                case "getSubcorpEmpInfo":          
                    $employeeIdInfo =  $this->_Oemployee->_getEmployeeId($input['subcorporateId'],$this->_AempLevelId);
                    $this->_AfinalResponse = $employeeIdInfo;
                    break;
                
                case 'getEmployeeEmailId':
                    if($input['method'] == 'approverEmail'){
                        $approverId =  $this->_Oemployee->_getEmployeeId($_SESSION['corporateId'],$this->_AempLevelId,$input['employee_email']);
                        $finalArrayInfo['approverInfo']= $approverId;
                    }else{
                        $employeeId =  $this->_Oemployee->_getEmployeeId($_SESSION['corporateId'],$this->_AempLevelId,$input['employee_email']);
                        $finalArrayInfo['approverInfo']= $employeeId;
                    }
                    $this->_AfinalResponse = $finalArrayInfo;
                    break;                    
            }
        }
        
        //get sub corporate value
        $this->_AsubCorporateName = $this->_Ocorporate->_getSubCorporateName();
        
        //get travel modes for the approver setting creation
        $this->travelMode = $this->_OcommonQuery->_getTravelModes();

        // assign the array in twig
        $this->_templateAssign();
        
    }   

    public function _fetchAggregatesByType($input)
    {       
        $aggregateInfoArray = $this->_OcommonQuery->_createCategorySubArray($input);
        $this->_AtwigOutputArray['aggregateInfo'] = $aggregateInfoArray;
        $_SgridDisplay = $this->_Otwig->render('aggregateSelectionDisplay.tpl', $this->_AtwigOutputArray);
        $responseArray = array("aggregateInfo" => $aggregateInfoArray, "template" => $_SgridDisplay);
        return $responseArray;
    }   
    
    
    public function _permissionCheck()
    {        
        $agencyList = 'N';
        $recieveData = $this->_OcommonQuery->_corporateAgencyPermission();
        $this->_Ocorporate->_Sstatus = 'Y';
        $this->_Aagency = array_column($recieveData['agency'], 'agency_name', 'dm_agency_id');
        $this->_AtwigOutputArray['timebasedApprovalEnable'] = (isset($_SESSION['userApplicationSettings']['TIME_BASED_APPROVAL']) && $_SESSION['userApplicationSettings']['TIME_BASED_APPROVAL'] == 'YES') ? 'Y' : 'N';
        if(count($this->_Aagency) > 0)
        {
           $agencyList = 'Y';
           $this->_AtwigOutputArray['agencyListStatus'] = $agencyList;
           $this->_AtwigOutputArray['agency'] = $recieveData['agency']; 
        }else
        {
            $agencyList = 'N';
            $this->_AserviceResponse['agencyListStatus'] = $agencyList;           
            $this->_AserviceResponse['agencyId'] = $_SESSION['agencyId']; 
            $agencyNameArray = array('agency_name');      
            $agencyName = $this->_OcommonDBO->_select('dm_agency', $agencyNameArray,'dm_agency_id',$_SESSION['agencyId'])[0];  
            $this->_AserviceResponse['agencyName'] =  $agencyName['agency_name'];
        }
        if(count($recieveData['corporate']) > 0 )
        {           
            if(count($recieveData['corporate']) == 1)
            {
                $corporateList = 'N';
                $this->_AserviceResponse['corporateListStatus'] = $corporateList;
                $this->_AserviceResponse['corporateId'] = $_SESSION['corporateId'];                
                $corporateNameArray = array('corporate_name');      
                $corporateName = $this->_OcommonDBO->_select('dm_corporate', $corporateNameArray,'corporate_id',$_SESSION['corporateId'])[0];  
                $this->_AserviceResponse['corporateName'] =  $corporateName['corporate_name'];
            }  
            else 
            {
                $corporateList = 'Y';
                $this->_AserviceResponse['corporate'] = $recieveData['corporate']; 
                $this->_AserviceResponse['corporateListStatus'] = $corporateList; 
            }             
        }
        else 
        {
            $corporateList = 'N';
            $this->_AserviceResponse['corporateListStatus'] = $corporateList;
            $this->_AserviceResponse['corporateId'] = $_SESSION['corporateId']; 
            $corporateNameArray = array('corporate_name');      
            $corporateName = $this->_OcommonDBO->_select('dm_corporate', $corporateNameArray,'corporate_id',$_SESSION['corporateId'])[0];  
            $this->_AserviceResponse['corporateName'] =  $corporateName['corporate_name'];
        }
    }
 
    public function _templateAssign() 
    {    
        $this->_AtwigOutputArray['agencyList'] = $this->_AagencyList;
        $this->_AtwigOutputArray['travelMode'] = $this->travelMode;
        $this->_AtwigOutputArray['approvalType'] = $this->approvalType;
        $this->_AtwigOutputArray['sessionUserTypeId'] = $_SESSION['userTypeId'];
        $this->_AtwigOutputArray['operatorInfo'] = $this->_AoperatorArray;
        $this->_AtwigOutputArray['action'] = "createApproverSettings";
        if($this->_IinputData['action'] == "edit")
        { // action for setting corporate name,process type,travel mode and agency id readonly
            $this->_AtwigOutputArray['editAction'] = "editApproverSettings";
        }
        $this->_AtwigOutputArray['employee'] = SELF::EMPLOYEE_AGGREAGTE_TYPE_ID;
    }
}
?>