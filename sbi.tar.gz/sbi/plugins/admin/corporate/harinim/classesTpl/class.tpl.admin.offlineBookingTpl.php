<?php
/* * **********************************************************************
 * @Class Name	:   class.tpl.admin.offlineBookingTpl.php
 * @Description	:   This file use to handle the offline booking flow process
 * @Author      :   Muruganandham M
 * ************************************************************************ */
class offlineBookingTpl {
    public function __construct() {
    	$this->_OcommonDBO = new commonDBO();
        $this->_OtripCreation = common::_checkClassExistsInNameSpace('tripCreation');
        $this->_Oemployee = new employee();
        $this->_Ocorporate = new corporate();
        $this->_OtripListDisplay    = new tripListDisplay();
    } 
    /*
     * @functionName    :   _getDisplayInfo()
     * @description     :   default module method
     */
    public function _getDisplayInfo() {

        $this->_OcommonQuery = new commonQuery();
        $this->_AtwigOutputArray['GuestStatus'] =  $this->_OcommonQuery->_getSettingsDisplayData('','Request_Form_Configurations')['Guest']['status']; 
            $this->_AfinalResponse['corporateDetails'] = $this->_setCorporateId();
        	$this->_AtwigOutputArray['corporate'] = $this->_AfinalResponse['corporateDetails'] ;
            $this->_AserviceResponse['corporateDetails'] = $this->_AfinalResponse['corporateDetails'];
        $this->_AserviceResponse['tourType'] = $this->_OtripCreation->_getTourType();
        switch ($this->_IinputData['action']) {
            case 'employeeDetails':
                $employeeDetails = $this->_getEmployeeDetails($this->_IinputData['corporateId'],$this->_IinputData['empCode']);
                $this->_AfinalResponse['employeeDetails'] =  $employeeDetails!=''?$employeeDetails:false;
                $this->_AserviceResponse['tourType'] = $this->_OtripCreation->_getTourType($employeeDetails['employee_id'],$employeeDetails['email_id']);
                $this->_AfinalResponse['tourTypeName'] = $this->_AserviceResponse['tourType'] ;
                 $this->_AfinalResponse['tourTypeName']['selfBooking'] = $employeeDetails['employee_id'] == $_SESSION['employeeId'] ? true : false;
                $this->_AfinalResponse['TripCreationStatus'] = $this->_OtripCreation->_checkTripCreationStatus($employeeDetails['employee_id'])[0];
                $this->_AfinalResponse['TripCreationStatus']['guestStatus'] =$this->_AtwigOutputArray['GuestStatus'];
            break;
            case 'tripDetails':
               $this->_AfinalResponse['tripDetails'] =  $this->_setTripDetails($this->_IinputData['trip_id'],$this->_IinputData['empEmail']);
               $tripStatusArray = array(CANCELLED);
               $this->_AfinalResponse['tripOrderCancelStatus'] = $this->_OtripListDisplay->_getTripOrderList($this->_IinputData['trip_id'],$tripStatusArray);
               $this->_AfinalResponse['postfactoDisplayFlag'] = ($_SESSION['employeeEmailId'] != $this->_AfinalResponse['tripDetails']['created_by']) ? 'Y' : 'N';
               $this->_AfinalResponse['userType'] = $_SESSION['userType'];
            break;
        }
    }
    /*
     * @functionName    :   _setTripDetails()
     * @description     :   default module method
     */
    public function _setTripDetails($tripId,$empEmail) {
        $tripDetails = $this->_OtripListDisplay->_tripOrderDetails($tripId,$empEmail);
        $setTripDetails = $tripDetails!=''? $tripDetails :false;
        if($tripDetails !=''){
            if($tripDetails['trip_flow_type'] == 'F' || $tripDetails['trip_flow_type'] == 'G'){ 
                if($tripDetails['requested_by'] == $_SESSION['employeeEmailId']){
                    $setTripDetails = $tripDetails;
                }else{
                    $setTripDetails['blockTrip'] = 'Y';
                }
            } 
        } 
        return $setTripDetails;
    }  
       /*
     * @functionName    :   _setEmployeeDetails()
     * @description     :   default module method
     */
    public function _getEmployeeDetails($corporateId,$empCode) {
      $empDetails = $this->_Oemployee->_getEmployeeInfo('','','',$corporateId,$empCode,'Y');
        if($empDetails['employee_id'] !=''){  
            $gradeDetails = $this->_OcommonDBO->_select('sap_employee_dependent_details','check_box','r_employee_id',$empDetails['employee_id'])[0];
            if(isset($gradeDetails) && $gradeDetails['check_box'] == 'X'){
                $empDetails['gradeDetails'] = 'Y';      
            }
            else{
                $empDetails['gradeDetails'] = 'N';      
            }
        }
        return $empDetails;
    }  
    
    
    /*
     * @functionName    :   _setCorporateId()
     * @description     :   default module method
     */
    public function _setCorporateId() {
         if($_SESSION['userType']=='TA'){
        $this->_OcommonQuery = new commonQuery();
        $this->_Ocorporate = new corporate();

        $this->_OcommonQuery->_getAgencyCorporatePermissionCheck();
        $this->_AserviceResponse = $this->_OcommonQuery->_AserviceResponse;
        $this->_AserviceResponse['userTypeId'] = $_SESSION['userTypeId'];
        if($_SESSION['userTypeId'] == 3){
            $this->_AserviceResponse['corporateDetails'] = $this->_Ocorporate->_getSyncCorporateDetails('CORPORATE','Y');
        }else{
            $this->_AserviceResponse['corporateDetails'] = $this->_AserviceResponse['corporate'];
        }
        $corp = [];
        foreach ($this->_AserviceResponse['corporateDetails'] as $key => $value) {
            $corp[$value['r_corporate_id']]=$value['corporate_name'] ;
        }
        $corporateDetails = $corp;
        }
        if ($_SESSION['userType']=='CA') {
            $corporateDetails['corporateId']=$_SESSION['corporateId'];
            $corporateDetails['userType']=$_SESSION['userType'];
        }
        return $corporateDetails;
    }
}