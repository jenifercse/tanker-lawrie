<?php
/* * **************************************************************************
 * @File             : class.tpl.moduleMappingListTpl.php
 * @Description      : This file is used to view and create the module mapping
 * @Tables Affected  : core_module_mapping_details
 * @Author           : Karthika
 * @Created Date     : 08/12/2016
 * @Modified Date    : 
 * ****************************************************************************/

class moduleMappingListTpl
{  
    public function __construct() 
    {        
        $this->_OcommonDBO= new commonDBO();
        $this->_OlistMenu = new listMenu(); 
        $this->_Oapplication = new applicationSettings();
        $this->_Oemp = new employee();
        
    }
    
    // function for getting module mapping info and assign it in twig.
    public function _getDisplayInfo()
    {
        //get Module Mapping Info
        $this->_AmoduleMappingInfo = $this->_OlistMenu->_getModuleMappingList(); 
        
        
        //get class tpl file name         
        $classTplInfo = $this->_Oapplication->_getFileName('./plugins/default/classesTpl','php');  
        if($classTplInfo != "")
        {
            foreach ($classTplInfo as $data)
            {
                $file = str_replace(".php","",basename($data));
                $fileName = str_replace("class.tpl.","",basename($file));
                $this->_classTplInfo[] = $fileName;                
            }            
        }
        
        // get template folder       
        $this->_AtemplateFolderInfo = $this->_Oapplication->_getAllSubFolderArray('./view/twig'); 
        
        // get group id         
        $this->_groupId = $this->_Oemp->_getUserTypes();
        
        //get std std tpl id 
        $this->_stdTplInfo = $this->_OlistMenu->_getStdTplInfo();
        
        // template assign
        $this->_templateAssign();        
    }    
    
    public function _templateAssign() 
    {           
        $this->_AtwigOutputArray['moduleInfo'] = $this->_AmoduleMappingInfo;
        $this->_AtwigOutputArray['classTplInfo'] = $this->_classTplInfo;
        $this->_AtwigOutputArray['templateFolder'] = $this->_AtemplateFolderInfo;
        $this->_AtwigOutputArray['groupIdInfo'] = $this->_groupId; 
        $this->_AtwigOutputArray['stdTplInfo'] = $this->_stdTplInfo;
    }
   
}
?>