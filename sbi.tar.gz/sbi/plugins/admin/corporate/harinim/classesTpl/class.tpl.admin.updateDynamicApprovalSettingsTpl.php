<?php
/* * **************************************************************************
 * @File             : class.tpl.insertDynamicApproverSettingsTpl.php
 * @Description      : This file is used to insert the dynamic approval settings details
 * @Tables Affected  : approval_parameter_mapping,dm_approval_settings,approval_settings_history
 * @Author           : Lakshmi.S
 * @Created Date     : 02/01/2017
 * @Modified Date    : 
 * ****************************************************************************/

fileRequire('/lib/common/commonMethods.php');
pluginFileRequireBasic('admin/corporate/harinim/', 'classesTpl/class.tpl.admin.dynamicApprovalSettingsDetailsTpl.php'); 
pluginFileRequire('common/', 'interface/commonConstants.php');
class updateDynamicApprovalSettingsTpl  implements commonConstants
{    

    public function __construct() {    
        $this->_OcommonDBO = new commonDBO();
        $this->_OdynamicApproverSettings = new dynamicApproverSettings();
        $this->_OdynamicApprovalSettingsDetailsTpl = new dynamicApprovalSettingsDetailsTpl();
    }
   
   
   public function _getDisplayInfo()           
   {       
        $this->_OcommonArrayClass = new commonArrayFunctions();
        if(isset($this->_IinputData['selectedAggregates'][SELF::EMPLOYEE_AGGREAGTE_TYPE_ID]) && count($this->_IinputData['selectedAggregates'][SELF::EMPLOYEE_AGGREAGTE_TYPE_ID])>0){
         
            $selectedAggregates=$this->_IinputData['selectedAggregates'][SELF::EMPLOYEE_AGGREAGTE_TYPE_ID]; 
        }
        else{
            $selectedAggregates = $this->_OcommonArrayClass->_arrayFlatten($this->_IinputData['selectedAggregates'],array()); 
        }
        foreach ($selectedAggregates as $key => $value) 
        {
            if(isset($this->_IinputData['selectedAggregates'][SELF::EMPLOYEE_AGGREAGTE_TYPE_ID]) && count($this->_IinputData['selectedAggregates'][SELF::EMPLOYEE_AGGREAGTE_TYPE_ID])>0){
                $aggregateCategory[$key]['aggregateCategoryId']  = $value['employeeId'];
                $aggregateCategory[$key]['operatorId'] = $this->_IinputData['selectedAggregatesOperator'];
                $aggregateCategory[$key]['categoryValue']  = $value['emailId'];
                $aggregateCategory[$key]['aggregateCategoryType']  = "'employee'";
            }
            else
            {   
                $aggregateCategory[$key]['aggregateCategoryId']  = $value;
                // get aggregate value
                $aggregateValue =  $this->_OcommonDBO->_select('dm_aggregate', 'aggregate_name', 'aggregate_id', $value);
                $aggregateValue = $aggregateValue[0]['aggregate_name'];
                $aggregateCategory[$key]['aggregateCategoryId']  = $value;
                $aggregateCategory[$key]['operatorId'] = $this->_IinputData['selectedAggregatesOperator'];
                $aggregateCategory[$key]['categoryValue']  = $aggregateValue;
                $aggregateCategory[$key]['aggregateCategoryType']  = "'category'";
            }                      
        }
        
        $this->_IinputData['aggregateCategory'] =  $aggregateCategory;
        unset($this->_IinputData['selectedAggregates']);
        unset($this->_IinputData['selectedAggregatesOperator']);
        
        if(isset($this->_IinputData['criteria']) && count($this->_IinputData['criteria']) >0)
        {
            // to insert the selected criteria as a string in the dm_approval_settings table
            $criteriaArray = array_column($this->_IinputData['criteriaList'], "criteria_logical_name","criteria_id");        
            $this->_IinputData['validation_string'] = $this->_OdynamicApproverSettings->_generateEvalString($this->_IinputData['criteria'],$criteriaArray);       
        }
        else
        {
             $this->_IinputData['validation_string'] = 1;
        }
       
        //Function call to update approval settings master data ( dm_approval_settings table update)
        $resultUpdate=$this->_OdynamicApproverSettings->_updateDynamicApprovalSettings($this->_IinputData);

        $approvalSettingArray=array();
        // Get approver list info of the current settings id
        $approverInfo = $this->_OdynamicApproverSettings->_getApproverInfo($this->_IinputData['approval_settings_id']);

        if(is_array($approverInfo) && count($approverInfo)>0)
        {
           $approvalSettingArray['approverInfo'] = $approverInfo;
        }
        // get dynamic approval settings info of the current settings id
        $resultApprovalSettings=$this->_OdynamicApproverSettings->_getDynamicApprovalSettingsInfo($this->_IinputData['approval_settings_id']);

        if(is_array($resultApprovalSettings) && count($resultApprovalSettings)>0){
            $approvalSettingArray['approvalSettingsInfo']=$this->_OdynamicApprovalSettingsDetailsTpl->_dynamicApprovalSettingLogic($resultApprovalSettings);
        }
            
            if(count($approvalSettingArray)>0){
                
                //Encode the approval settings data to take the back up
                $approvalSettingsJsonData=json_encode($approvalSettingArray);
                
                //Array preparation to take back up of the existing approval settings and approval info
                $insertApproverSettingsHistory=array();
                $insertApproverSettingsHistory['r_approval_settings_id']=$this->_IinputData['approval_settings_id'];
                $insertApproverSettingsHistory['action']='EDIT';
                $insertApproverSettingsHistory['json_data']=$approvalSettingsJsonData;
                
                //Function call to insert exiting approval settings history (approval_settings_history table insert)
                $resultHistory=$this->_OdynamicApproverSettings->_insertDynamicApprovalSettingsHistory($insertApproverSettingsHistory); 
                
                //Function call to delete exiting approval settings history after take the bakcup(approval_parameter_mapping table delete)
                $resultApprovalMappingDelete=$this->_OdynamicApproverSettings->_deleteApprovalSettings($this->_IinputData['approval_settings_id']);
                //Function call to delete exiting approval info history (approval_mapping table delete)
                $resultApprovalDelete=$this->_OdynamicApproverSettings->_deleteApproverMapping($this->_IinputData['approval_settings_id']);
                
                //Function call to insert edited approval settings details (approval_parameter_mapping table insert)
                $resultApprovalParameterMapping=$this->_OdynamicApproverSettings->_insertApprovalParameterMapping($this->_IinputData);
                
                //Function call to insert edited approval info details (approval_mapping table insert)
                $resultApprovalMapping=$this->_OdynamicApproverSettings->_insertApproverMapping($this->_IinputData);
            }
       }   
}
?>