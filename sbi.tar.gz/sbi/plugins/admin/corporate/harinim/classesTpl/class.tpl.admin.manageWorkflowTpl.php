<?php

/* * *****************************************************************************
 * @class		manageWorkflow class TPl file
 * @author      	Mercy Chrysolite
 * @created date	29 - 11 - 2016
 * **************************************************************************** */

//fileRequire("lib/common/commonMethods.php");
//fileRequire("lib/common/commonFunctions.php");
pluginFileRequire('common/','interface/commonConstants.php');

class manageWorkflowTpl implements commonConstants{

    public function __construct() {
        $this->_ODBC = new commonDBO();
        $this->_Oworkflow = new workflow();
        $this->_Oagency = new agency();
        $this->_Ocorporate = new corporate();
        $this->_Oapp = new applicationSettings();
        $this->_OcommonQ = new commonQuery();
        $this->_Oemployee = new employee();
        $this->_AprocessType = array('B' => 'Booking');//, 'C' => 'Cancellation');
    }

    /*
     * @Function: _getDisplayInfo()
     * @Description:  method to get handles actions
     * @return: array|$returnValue (reponse array)
     */

    public function _getDisplayInfo() {

        $returnValue = array('status' => 0, 'status_message' => 'success', 'error_alert' => '', 'result' => array());

        
        $this->action = $this->_IinputData['action'];

        switch ($this->action) {

            case 'getCorporateList':
                $result = $this->_corporateList();
                $this->_AfinalResponse = array('status' => 1, 'status_message' => 'success', 'error_alert' => '', 'result' => $result, 'template' => array());
                break;
            case 'createWorkFlow':
                $result = $this->_insertSelectedWorkFlow();
                $this->_AfinalResponse = array('status' => $this->_Istatus, 'status_message' => 'success', 'error_alert' => '', 'result' => $this->_Serror, 'template' => $this->_SgridDisplay);
                break;
            case 'updateWorkFlow':
                $result = $this->_updateWorkFlow();
                $this->_AfinalResponse = array('status' => $this->_Istatus, 'status_message' => 'success', 'error_alert' => '', 'result' => $this->_Serror, 'template' => $this->_SgridDisplay);
                break;
            case 'getSearchList':
                $result = $this->_searchFilterWorkFlow();
                //for getting value to use in interface
                $this->_AfinalResponse = array('status' => $this->_Istatus, 'status_message' => 'success', 'error_alert' => '', 'result' => $this->_SinsertError, 'template' => $this->_SgridDisplay);
                break;
            case "getCategorySubCorporateInfo": 
                
                if($_SESSION['permissions']['permissionName'] == 'All'){
                    
                   $aggregate=  $this->_OcommonQ->_getAggregateByType($this->_IinputData);
                
                }
                else{
                    
                    $this->_IinputData['agencyId'] = $_SESSION['agencyId'];
                    $this->_IinputData['corporateId'] = $_SESSION['corporateId'];
                    $aggregate=  $this->_OcommonQ->_getAggregateByType($this->_IinputData);
                    
                }
                foreach ($aggregate as $key => $value) {
                    if($value['aggregate_type_id'] == SELF::EMPLOYEE_AGGREAGTE_TYPE_ID){
                        unset($aggregate[$key]);
                    }
                }
                $subcorporate =  $this->_Ocorporate->_getSubCorporateName($input['corporateId']);
                $employeeId =  $this->_Oemployee->_getEmployeeId($input['corporateId']);
                $finalArrayInfo = [];
                $finalArrayInfo['categoryInfo']= $aggregate;
                $finalArrayInfo['subcorporateInfo']= $subcorporate;
                $finalArrayInfo['employeeInfo']= $employeeId;
                $this->_AfinalResponse = $finalArrayInfo;
                break;
                
            case 'getAggregateDetailsByType':
                $responseArray = $this->_fetchAggregatesByType($this->_IinputData);
                $this->_AfinalResponse = $responseArray ;
                 break;
            case 'editWorkflowMapping':
                $this->_editWorkflowMapping();
                break;
            case 'createWorkflowMapping':
                $corporateId = $this->_IinputData['selectedCorporate'] != "" ? $this->_IinputData['selectedCorporate'] : $_SESSION['corporateId'];
                $agencyId = $this->_IinputData['selectedAgency'] != "" ? $this->_IinputData['selectedAgency'] : $_SESSION['agencyId'];
                $corporate = new corporateCustomization();
                $corporate->_IcorporateId = $corporateId;
                $WorkflowSelectionSettings = $corporate->_getCorporateSettingsFromJSON('WorkflowSelection');
                if(!isset($WorkflowSelectionSettings['User Type']) || !isset($WorkflowSelectionSettings['User Type']))
                {
                    $WorkflowSelectionSettings['User Type'] = "YES";
                    $WorkflowSelectionSettings['Aggregate Type'] = "NO";
                }
                
                $this->_AfinalResponse = array('status' => 1, 'status_message' => 'success', 'error_alert' => '', 'result' => '', 'template' => '','permissionId'=>$_SESSION['permissions']['permissionId'],'agencyID'=>$agencyId,'corporateID'=>$corporateId,'wsUserType'=>$WorkflowSelectionSettings['User Type'],'wsAggregateType'=>$WorkflowSelectionSettings['Aggregate Type']);
                break;
            
            case 'reload':
                $this->_viewList();
                break;
            case 'changeStatus':
                $this->_updateWorkFlowStatus();
                break;
            default:
                $this->_viewList();
        }

        $this->_templateAssign();

        return $returnValue;
    }

    /*
     * @Function: _viewList()
     * @Description:  method to load default page
     */

    public function _viewList() {

        $this->_ObjWorkflows = $this->_Oworkflow->_getWorkflows();
        
        if(isset($_SESSION['userApplicationSettings']['WorkflowSelection']['User Type']))
        {
            $this->_AtwigOutputArray['workflow_select_user_type'] = $_SESSION['userApplicationSettings']['WorkflowSelection']['User Type'];
            $this->_AtwigOutputArray['workflow_select_aggregate_type'] = $_SESSION['userApplicationSettings']['WorkflowSelection']['Aggregate Type'];
        }
        else
        {
            $this->_AtwigOutputArray['workflow_select_user_type'] = "YES";
            $this->_AtwigOutputArray['workflow_select_aggregate_type'] = "NO";
        }
        $this->_AtwigOutputArray['permissionValue'] = $_SESSION['permissions']['permissionId'];
        foreach ($this->_ObjWorkflows as $value) {
            $this->_Aworkflows[$value['workflow_id']] = $value;
        }

        //for getting value to use in interface
        //$input = array("agencyId" => '0', "corporateId" => '0');
        if($_SESSION['permissions']['permissionName'] == 'All'){
            $this->_AworkflowMappings = $this->_Oworkflow->_getWorkflowMappings($input);
        }
        else{
            $input = array("agencyId" =>$_SESSION['agencyId'] , "corporateId" =>$_SESSION['corporateId']);
            $this->_AworkflowMappings = $this->_Oworkflow->_getWorkflowMappings($input);
        }
        $this->_arrayFormation();
        $this->_permissionCheck();
    }

    /*
     * @Function: _corporateList()
     * @Description: loading corporate name base on agency name
     */

    public function _corporateList() {
        $responseArray = $this->_Oagency->_getAgencyCorporateList($this->_IinputData['agencyId']);
        return $responseArray;
    }

    /*
     * Function: _insertSelectedWorkFlow()
     * @Description: insertion of selected workflow in the database
     */

    public function _insertSelectedWorkFlow() {
        
        // @for assiging the value to the variable 
        $this->_OcommonArrayClass = new commonArrayFunctions();
        $selectedAggregates = $this->_IinputData['aggregates'] = $this->_OcommonArrayClass->_arrayFlatten($this->_IinputData['selectedAggregates'],array());
        
        if($_SESSION['permissions']['permissionName'] != 'All'){
            $this->_IinputData['wfWorkFlow']['selectedAgency'] = $_SESSION['agencyId'];
            $this->_IinputData['wfWorkFlow']['selectCorporate'] = $_SESSION['corporateId'];
        }
        
        if(!$this->_validateWorkflowSelection())
            return false;
        
        $receivedDataId = $this->_Oworkflow->_insertWorkFlow($this->_AinputArray,$selectedAggregates);
        $this->_IinputData['input']['id'] = $receivedDataId;
        $this->_searchFilterWorkFlow();
        $this->_Serror = 'WORKFLOW_INSERTED';
        $this->_Istatus = 3;
        return true;
        //calling _insertWorkFlow method from classes.workFlow.php
    }
    
    private function _validateWorkflowSelection() {
        
        if(!empty($this->_IinputData['aggregates']))
        {
            $this->_IinputData['wfWorkFlow']['selectUserType'] = 0;
        }
        $keys = array("enterFlowName" => "workflow_mapping", "selectedAgency" => "agencyId", "selectCorporate" => "corporateId", "selectUserType" => "userTypeId", "selectTravelType" => "travelTypeId", "selectWorkflowType" => "workFlowTypeId","priority"=>"priority","selectProcessType"=>"processType");
        $validation = array('agencyId', 'corporateId', 'userTypeId', 'travelTypeId', 'processType','priority');
        foreach ($this->_IinputData['wfWorkFlow'] as $key => $value) {
            if ($keys[$key] != '') {
                $this->_AinputArray[$keys[$key]] = $value;
            }
            if (in_array($keys[$key], $validation)) {
                $validateArray[$keys[$key]] = $value;
            }
        }

        //this is for checking is flowname already exits or not
        $validFlowName = $this->_Oworkflow->_getWorkflowMappings(array(
            'agencyId' => $this->_IinputData['wfWorkFlow']['selectedAgency'], 
            'corporateId' => $this->_IinputData['wfWorkFlow']['selectCorporate'], 
            'flowName' => $this->_IinputData['wfWorkFlow']['enterFlowName']));
        if ($validFlowName != '') {
            $this->_Serror = 'FLOWNAME_EXISTS';
            $this->_Istatus = 0;
            return false;
        }
        
        if(empty($this->_IinputData['aggregates']))
        {
            //this is for checking if same USER TYPE based setting already exits or not
            $validSetting = $this->_Oworkflow->_getWorkflowMappings($validateArray);
            if ($validSetting != '') {
                $this->_Serror = 'SETTING_EXISTS';
                $this->_Istatus = 0;
                return false;
            }
        }
        else
        {
            //this is for checking if same AGGREGATE based setting already exits or not
            $checkAggregateExit = $this->_Oworkflow->_getWorkflowAggregateCheck($validateArray);
            $aggregateExists = false;
            foreach($checkAggregateExit as $value)
            {
                $validateArray = explode(",",$value['exitAggregate']);

                foreach($this->_IinputData['selectedAggregates'] as $selectedValue)
                {
                    foreach($selectedValue as $eachSelectedValue)
                    {
                        if(in_array($eachSelectedValue,$validateArray))
                        {
                            $aggregateExists = true;
                        }
                    }
                }
            }
            
            if($aggregateExists)
            {
                $this->_Serror = 'AGGREGATE_EXISTS';
                $this->_Istatus = 0;
                return false;
            }
        }
        
        return true;
    }

    /*
    *@Function: _searchFilterWorkFlow()
    *@Description: this function search on the basic of filter provide by the user
    */

    public function _searchFilterWorkFlow() {

        $this->_ObjWorkflows = $this->_Oworkflow->_getWorkflows();

        foreach ($this->_ObjWorkflows as $value) {
            $this->_Aworkflows[$value['workflow_id']] = $value;
        }

        if($_SESSION['permissions']['permissionName'] == 'All'){
            
            $this->_AworkflowMappings = $this->_Oworkflow->_getWorkflowMappings($this->_IinputData['input']);
            
        }
        else{

            $this->_IinputData['input']['agencyId'] = $_SESSION['agencyId'];
            $this->_IinputData['input']['corporateId'] = $_SESSION['corporateId'];
            $this->_AworkflowMappings = $this->_Oworkflow->_getWorkflowMappings($this->_IinputData['input']);
            

        }
        $this->_arrayFormation();
        $this->_permissionCheck();
        $this->_templateAssign();
        
        $this->_SgridDisplay = $this->_Otwig->render('workflowList.tpl', $this->_AtwigOutputArray);
    }

    /*
    *@Function: _updateWorkFlow()
    *@Description: this function is use to update the exiting workflowS
    */

    public function _updateWorkFlow() {
        $this->_OcommonArrayClass = new commonArrayFunctions();
        $selectedAggregates = $this->_IinputData['aggregates'] = $this->_OcommonArrayClass->_arrayFlatten($this->_IinputData['input']['selectedAggregates'],array());
        
        if(!$this->_validateWorkflowUpdation())
            return false;
        
        $this->_Oworkflow->_updateWorkFlow($this->_IinputData['input'],$selectedAggregates);
        $this->_Istatus = 1;
        
        $this->_searchFilterWorkFlow();
        $this->_permissionCheck();
    }
    
    private function _validateWorkflowUpdation() {
        
        //To get mapping details
        $mappingInfo = $this->_Oworkflow->_getWorkflowMappings(array('factWorkFlowId' => $this->_IinputData['input']['id']))[0];

        //this is for checking is flowname already exits or not
        $validFlowName = $this->_Oworkflow->_getWorkflowMappings(array(
            'agencyId' => $mappingInfo['r_agency_id'], 
            'corporateId' => $mappingInfo['r_corporate_id'], 
            'flowName' => $this->_IinputData['input']['workFlowMappingName']));
        if ($validFlowName != '' && $validFlowName[0]['fact_workflow_id']!=$this->_IinputData['input']['id']) {
            $this->_Serror = 'FLOWNAME_EXISTS';
            $this->_Istatus = 0;
            return false;
        }
        
        if(!empty($this->_IinputData['aggregates']))
        {            
            $validateQueryArray['agencyId'] = $mappingInfo['r_agency_id'];
            $validateQueryArray['corporateId'] = $mappingInfo['r_corporate_id'];
            $validateQueryArray['userTypeId'] = 0;
            $validateQueryArray['travelTypeId'] = $mappingInfo['r_travel_mode_id'];
            $validateQueryArray['processType'] = $mappingInfo['flow_type'];
            
            //this is for checking if same AGGREGATE based setting already exits or not
            $checkAggregateExit = $this->_Oworkflow->_getWorkflowAggregateCheck($validateQueryArray);
            $aggregateExists = false;
            foreach($checkAggregateExit as $value)
            {
                if($value['fact_workflow_id']!=$this->_IinputData['input']['id'])
                {
                    $validateArray = explode(",",$value['exitAggregate']);

                    foreach($this->_IinputData['input']['selectedAggregates'] as $selectedValue)
                    {
                        foreach($selectedValue as $eachSelectedValue)
                        {
                            if(in_array($eachSelectedValue,$validateArray))
                            {
                                $aggregateExists = true;
                            }
                        }
                    }
                }
            }
            
            if($aggregateExists)
            {
                $this->_Serror = 'AGGREGATE_EXISTS';
                $this->_Istatus = 0;
                return false;
            }
        }
        
        return true;
    }

    /*
     * @Function: _templateAssign()
     * @Description:  method to set data to twig
     * @return: array|response array
     */

    public function _templateAssign() {

        $this->_AtwigOutputArray['workflows'] = $this->_Aworkflows;
        $this->_AtwigOutputArray['workflowMappings'] = $this->_AworkflowMappings;
        $this->_AtwigOutputArray['agencies'] = $this->_Aagency;
        $this->_AtwigOutputArray['corporates'] = $this->_Acorporate;
        $this->_AtwigOutputArray['userTypes'] = $this->_AuserTypes;
        $this->_AtwigOutputArray['travelModes'] = $this->_AtravelModes;
        $this->_AtwigOutputArray['processType'] = $this->_AprocessType;
    }
    
    /*
     * @Function: _arrayFormation()
     * @Description:  method to formed array for agency, coporate, user type etc,  
     */

    public function _arrayFormation() {

        $this->_AuserTypes = array_column($this->_Oapp->_getUserTypes(), 'user_type_name', 'user_type_id');
        $this->_AtravelModes = array_column($this->_Oapp->_getTravelMode(array('travel_mode_id', 'travel_mode')), 'travel_mode', 'travel_mode_id');
    }

    public function _permissionCheck(){
        
        $recieveData = $this->_OcommonQ->_corporateAgencyPermission();
        $this->_Ocorporate->_Sstatus = 'Y';
        $this->_Acorporate = array_column($recieveData['corporate'], 'corporate_name', 'corporate_id');
        $this->_Aagency = array_column($recieveData['agency'], 'agency_name', 'dm_agency_id');
        
        
    }
    
    public function _fetchAggregatesByType($input) {
        
        $aggregateInfoArray = $this->_OcommonQ->_createCategorySubArray($input);
        $this->_AtwigOutputArray['aggregateInfo'] = $aggregateInfoArray;
        $_SgridDisplay = $this->_Otwig->render('aggregateSelectionDisplay.tpl', $this->_AtwigOutputArray);
        $responseArray = array("aggregateInfo" => $aggregateInfoArray, "template" => $_SgridDisplay);
        return $responseArray;
    }
    
     public function _editWorkflowMapping(){
         
         $result['workflowAggregates'] = $this->_Oworkflow->_getWorkflowAggregateDetails($this->_IinputData['workFlowId'],'aggregate_type_id');
         $input['r_agency_id'] = $this->_IinputData['agencyId'];
         $corporateIdDetails = array('corporate_id');
         $input['r_corporate_id'] = $this->_ODBC->_select('dm_corporate',$corporateIdDetails,'corporate_name',$this->_IinputData['corporateId'])[0]['corporate_id'];
         $result['category'] = $this->_OcommonQ->_getAggregateByType(array("agencyId"=>$input['r_agency_id'],"corporateId"=>$input['r_corporate_id']));
        
        foreach ($result['category'] as $key => $value) {
            if($value['aggregate_type_id'] == SELF::EMPLOYEE_AGGREAGTE_TYPE_ID){
                unset($result['category'][$key]);
            }
        }
                
        $result['selectedAggregateTypes'] = array_keys($result['workflowAggregates']);
        foreach($result['category'] as $catVal)
        {
            if(in_array($catVal['aggregate_type_id'], $result['selectedAggregateTypes']))
                $result['categoryInfo'][] = array("id"=>$catVal['aggregate_type_id'],"name"=>$catVal['aggregate_type']);
        }
        $this->_AfinalResponse = array('status' => 1, 'status_message' => 'success', 'error_alert' => '', 'result' => $result, 'template' => $_SpolicyMapping);
    }
    
    public function _updateWorkFlowStatus() {
        
        if($this->_IinputData['status']== 'Y'){
            $this->_IinputData['status']= 'N';
        } 
        else {
            $this->_IinputData['status']= 'Y';
        }
        unset($this->_IinputData['action']);
        $updateStatus = $this->_Oworkflow->_updateWorkFlowStatus($this->_IinputData);
        if($updateStatus){
            $this->_Serror = 'Status Updated Successfully';
            $this->_Istatus = 3;
        }
        else{
             $this->_Serror = 'Status Not Updated';
             $this->_Istatus = 0;
        }
        $this->_AfinalResponse = array('status' => $this->_Istatus, 'status_message' => 'success', 'error_alert' => '', 'result' => $this->_Serror);
    }

}

?>
