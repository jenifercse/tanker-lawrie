<?php

/* * *****************************************************************************
 * @class		managePolicy class TPl file
 * @author      	Mercy Chrysolite
 * @created date	29 - 11 - 2016
 * **************************************************************************** */
fileRequire("lib/common/commonMethods.php");
fileRequire("lib/common/commonFunctions.php");

class managePolicyTpl {

    var $_ApolicyList;
    var $_AtravelModes;
    var $_AselectAgency;
    var $_AselectCorporate;

    public function __construct() {
        
    }

    /*
     * @Description:  method to get handles actions
     * @return: array|$returnValue (reponse array)
     */

    public function _getDisplayInfo() {

        $this->_ODBC = new commonDBO();
        $this->_Opolicy = new policy();
        $this->_Oapp = new applicationSettings();
        $this->_ApolicyList = array();
        $this->_OcommonQ = new commonQuery();
        $this->_Oagency = new agency();
        $this->_Ocorporate = new corporate();

        $this->action = $this->_IinputData['action'];

        switch ($this->action) {

            case 'createPolicy':
                $this->_createPolicy();
                break;
            case 'searchFilter':
                $this->_searchFilter();
                break;
            case 'editPolicy':
                $this->_editPolicy();
                break;
            case 'updatePolicy':
                $this->_updatePolicy();
                break;
            case 'searchDate':
                $this->_searchDate();
                break;
            case 'dateRange':
                $this->_dateRange();
                break;
            case 'getCorporateList':
                $result = $this->_corporateList();
                $this->_AfinalResponse = array('status' => 1, 'status_message' => 'success', 'error_alert' => '', 'result' => $result, 'template' => array());
                break;
            case 'fetchCriteria':
                $this->_fetchCriteria();
                break;
            case 'insertPolicy':
                $this->_insertPolicy();
                $this->_AfinalResponse = array('status' => $this->_Istatus, 'status_message' => 'success', 'error_alert' => '', 'result' => $this->_SinsertError, 'template' => '');
                break;
            case 'changeStatus':
                $this->_changeStatus();
                break;

            default:
                $this->_viewList();
                break;
        }

        $this->_templateAssign();
    }

    /*
     * @function Name : _viewList
     * @Description:  method to load default page
     * @param : -
     * @return : array |  policy list
     */

    public function _viewList() {

        //this condition is for checking wheather to display all policy or only that particular corporate policy
        if ($_SESSION['permissions']['permissionName'] == 'All') {
            $this->_ApolicyList = $this->_Opolicy->_getPolicyMasterList($this->_IinputData['input']);
        } else {
            $this->_IinputData['input']['r_agency_id'] = $_SESSION['agencyId'];
            $this->_IinputData['input']['r_corporate_id'] = $_SESSION['corporateId'];
            $this->_ApolicyList = $this->_Opolicy->_getPolicyMasterList($this->_IinputData['input']);
        }

        $this->_AtravelModes = array_column($this->_Oapp->_getTravelMode(array('travel_mode_id', 'travel_mode')), 'travel_mode', 'travel_mode_id');
        //function for calling for getting the permission to display corporate and agency 
        $this->_permissionCheck();
    }

    /*
     * @function : _createPolicy
     * @Description:  method to create new policy
     * @return: array|resposne array
     * @Author : Deepak Pande
     */

    public function _createPolicy() {

        //calling the permission check function
        $this->_permissionCheck();
        //setting the travel mode array
        $this->_AtravelModes = array_column($this->_Oapp->_getTravelMode(array('travel_mode_id', 'travel_mode')), 'travel_mode', 'travel_mode_id');
        //calling for getting the logical operator
        $this->_OcommonQ->_getLogicalOperatorInfo();
        $result['operators'] = $this->_OcommonQ->_Aoperators;
        //calling for assigning the values
        $this->_templateAssign();
        //variable for rendering the template
        $_SpolicyTemplate = $this->_Otwig->render('policyCreateEdit.tpl', $this->_AtwigOutputArray);
        //assigning the response 
        $this->_AfinalResponse = array('status' => 1, 'status_message' => 'success', 'error_alert' => '', 'result' => $result, 'template' => $_SpolicyTemplate, 'permissionId' => $_SESSION['permissions']['permissionId'], 'wsUserType' => $_SESSION['userApplicationSettings']['WorkflowSelection']['User Type'], 'wsAggregateType' => $_SESSION['userApplicationSettings']['WorkflowSelection']['Aggregate Type']);
    }

    /*
     * @Function : _editPolicy
     * @Description:  method to edit exiting policy
     * @return: array|resposne array
     */

    public function _editPolicy() {

        //function for calling for getting the permission to display corporate and agency 
        $this->_permissionCheck();
        //creating the travel mode array
        $this->_AtravelModes = array_column($this->_Oapp->_getTravelMode(array('travel_mode_id', 'travel_mode')), 'travel_mode', 'travel_mode_id');
        $this->_templateAssign();
        //assigning the template for rendering
        $_SpolicyTemplate = $this->_Otwig->render('policyCreateEdit.tpl', $this->_AtwigOutputArray);
        //this array is geting the required data from the database
        $result['policyInput'] = $this->_Opolicy->_getPolicyDetails($this->_IinputData['policyId']);
        $result['criteriaList'] = $this->_OcommonQ->_getCriteriaList($result['policyInput']['r_agency_id'], $result['policyInput']['r_corporate_id'], $result['policyInput']['r_travel_mode_id']);
        $this->_OcommonQ->_getLogicalOperatorInfo();
        $result['operators'] = $this->_OcommonQ->_Aoperators;
        $result['agencyName'] = $this->_Oagency->_getAgencyList('agency_name', $result['policyInput']['r_agency_id'])[0];
        $result['corporateName'] = $this->_Ocorporate->_getCorporateName($result['policyInput']['r_corporate_id']);
        //assiging the resonpse
        $this->_AfinalResponse = array('status' => 1, 'status_message' => 'success', 'error_alert' => '', 'result' => $result, 'template' => $_SpolicyTemplate);
    }

    /*     * *****************************************************************************
     * @class		managePolicy class TPl file
     * @author      	Vishwa Raj
     * Description:- This method is called from above switch case. This will display result according to
     *               the type of filter used.
     * @created date	29 - 11 - 2016
     * **************************************************************************** */

    public function _searchFilter() {   // Method currently in use
        if ($_SESSION['permissions']['permissionName'] == 'All') {
            $this->_ApolicyList = $this->_Opolicy->_getPolicyMasterList($this->_IinputData['input']);
        } else {
            $this->_IinputData['input']['r_agency_id'] = $_SESSION['agencyId'];
            $this->_IinputData['input']['r_corporate_id'] = $_SESSION['corporateId'];
            $this->_ApolicyList = $this->_Opolicy->_getPolicyMasterList($this->_IinputData['input']);
        }
        $this->_ApolicyList = $this->_Opolicy->_getPolicyMasterList($this->_IinputData['input']);
        $this->_templateAssign();
        $_SgridDisplay = $this->_Otwig->render('managePolicyList.tpl', $this->_AtwigOutputArray);
        $this->_AfinalResponse = array('status' => 1, 'status_message' => 'success', 'error_alert' => '', 'result' => $data, 'template' => $_SgridDisplay);
    }

    /*
     * @Description:  method to fetch policy criteria based on input
     * @return: array|response array
     */

    public function _fetchCriteria() {

        $criteria = $this->_OcommonQ->_getCriteriaList($this->_IinputData['r_agency_id'], $this->_IinputData['r_corporate_id'], $this->_IinputData['r_travel_mode_id']);
        $this->_AfinalResponse = array('status' => 1, 'status_message' => 'success', 'error_alert' => '', 'result' => $criteria, 'template' => '');
    }

    /*
     * @Function : _corporateList
     * @Description:  method to load corporate according to agency
     * @return: array|response array
     */

    public function _corporateList() {
        $responseArray = $this->_Oagency->_getAgencyCorporateList($this->_IinputData['agencyId']);
        return $responseArray;
    }

    /*
     * @Function : _insertPolicy
     * @Description:  method to inset  data into dm_policy
     * @return: array|response array
     */

    public function _insertPolicy() {

        //this $selectedCriteria is array use for storing the data in fact_policy_details table`
        if ($_SESSION['permissions']['permissionName'] != 'All') {
            $this->_IinputData['data']['r_agency_id'] = $_SESSION['agencyId'];
            $this->_IinputData['data']['r_corporate_id'] = $_SESSION['corporateId'];
        }
        $selectedCriteria = $this->_IinputData['data']['selectedCriteria'];
        $criteriaAvailTypeArray = array_column($this->_IinputData['data']['criteriaList'], "criteria_avail_type", "criteria_id");
        $criteriaAvailValue = 'R';
        foreach ($selectedCriteria as $key => $value) {
            if ($criteriaAvailTypeArray[$value['r_policy_criteria_id']] == 'B') {
                $criteriaAvailValue = 'B';
            }
        }
        $this->_IinputData['data']['policy_check_type'] = $criteriaAvailValue == 'B' ? 'B' : 'R';
        $criteriaArray = array_column($this->_IinputData['data']['criteriaList'], "criteria_logical_name", "criteria_id");

        //this unset method is use for removing the unwanted data
        unset($this->_IinputData['data']['selectedCriteria']);
        unset($this->_IinputData['data']['criteriaList']);

        //this $input data is for storing the data in the dm_policy table
        $input = $this->_IinputData['data'];
        $validateInput = array('r_agency_id' => $input['r_agency_id'], 'r_corporate_id' => $input['r_corporate_id'], 'r_travel_mode_id' => $input['r_travel_mode_id']);
        // this is use to check whether the same policy exits
        $validSetting = $this->_Opolicy->_getPolicyMasterList($validateInput);
        if ($validSetting != '') {
            $this->_SinsertError = 'SETTING_EXISTS';
            $this->_Istatus = 0;
            return false;
        }
        //this is to check whether the same policy name exits or not
        $validPolicyNameIp = array('r_agency_id' => $input['r_agency_id'], 'r_corporate_id' => $input['r_corporate_id'], 'policy_name' => $input['policy_name']);
        $validPolicyName = $this->_Opolicy->_getPolicyMasterList($validPolicyNameIp);
        if ($validPolicyName != '') {
            $this->_SinsertError = 'POLICYNAME_EXISTS';
            $this->_Istatus = 0;
            return false;
        }

        // to insert the selected criteria as a string in the dm_policy table
        $input['validation_string'] = $this->_generateEvalString($selectedCriteria, $criteriaArray);
        $input['violation_alert'] = addslashes($input['violation_alert']);
        $policyId = $this->_Opolicy->_insertCreatedPolicy($input, $selectedCriteria);

        if ($policyId != 0) {
            $this->_SinsertError = 'Policy Created Successfully!!';
            $this->_Istatus = 3;
        } else {
            $this->_SinsertError = 'ERROR_OCCURED';
            $this->_Istatus = 0;
        }
        //this is the final response array for sending the data
        $this->_AfinalResponse = array('status' => $this->_Istatus, 'status_message' => 'success', 'error_alert' => '', 'result' => $this->_SinsertError, 'template' => '');
    }

    /*
     * @Function : _updatePolicy
     * @Description:  method to update exiting  policy
     * @return: array|resposne array
     */

    public function _updatePolicy() {
        $selectedCriteria = $this->_IinputData['data']['selectedCriteria'];
        $criteriaArray = array_column($this->_IinputData['data']['criteriaList'], "criteria_logical_name", "criteria_id");
        unset($this->_IinputData['data']['selectedCriteria']);
        unset($this->_IinputData['data']['criteriaList']);
        unset($this->_IinputData['data']['criteriaInfo']);
        unset($this->_IinputData['data']['r_agency_id']);
        unset($this->_IinputData['data']['r_corporate_id']);
        unset($this->_IinputData['data']['created_date']);
        $input = $this->_IinputData['data'];
        $input['violation_alert'] = addslashes($input['violation_alert']);
        $input['validation_string'] = $this->_generateEvalString($selectedCriteria, $criteriaArray);
        $returnResponse = $this->_Opolicy->_updateCreatedPolicy($input, $selectedCriteria);
        if ($returnResponse) {
            $this->_SinsertError = 'Policy Updated Successfully!!';
            $this->_Istatus = 3;
        } else {
            $this->_SinsertError = 'Error while update !!';
            $this->_Istatus = 0;
        }

        $this->_AfinalResponse = array('status' => $this->_Istatus, 'status_message' => 'success', 'error_alert' => '', 'result' => $this->_SinsertError, 'template' => '');
    }

    /*
     * @Function : _generateEvalString
     * @Description:  for storing the string value in database
     * @return: array|resposne array
     */

    public function _generateEvalString($selectedCriteria, $criteriaArray) {

        $string = "";
        $and = "";
        $_Ooperators = $this->_OcommonQ->_getLogicalOperatorInfo();
        $_Aoperators = array_column($_Ooperators, "operator_logical_id", "operator_id");

        foreach ($selectedCriteria as $key => $value) {

            $name = "[" . $criteriaArray[$value['r_policy_criteria_id']] . "]";
            if ($value['r_operator_id'] == 9) {

                $value = explode('$$', $value['policy_value']);
                $string .= $and . '"' . $value[0] . '" <= "' . $name . '" && "' . $name . '" <= "' . $value[1] . '"';
            } else if ($value['r_operator_id'] == 16) {

                $value = explode('$$', $value['policy_value']);
                $string .= $and . '"' . $value[0] . '" <= "' . $name . '" && "' . $name . '" <= "' . $value[1] . '"';
            } else {
                if (trim($_Aoperators[$value['r_operator_id']]) == "IN") {

                    $value = trim(str_replace(",", "/,/", $value['policy_value']));
                    $string .= $and . " strpos(\'/" . $value . "/\', \'/" . $name . "/\') !== false ";
                } elseif (trim($_Aoperators[$value['r_operator_id']]) == "NOT IN") {

                    $value = trim(str_replace(",", "/,/", $value['policy_value']));
                    $string .= $and . " strpos(\'/" . $value . "/\', \'/" . $name . "/\') === false ";
                } else {

                    $string .= $and . ' "' . $name . '" ' . $_Aoperators[$value['r_operator_id']] . ' "' . $value['policy_value'] . '"';
                }
            }

            $and = " && ";
        }

        $result = $string == "" ? 1 : $string;
        return $result;
    }

    /*
     * @function : _templateAssign
     * @Description:  method to set data to twig
     * @return: array|response array
     */

    public function _templateAssign() {

        $this->_AtwigOutputArray['policyList'] = $this->_ApolicyList;
        $this->_AtwigOutputArray['travelModes'] = $this->_AtravelModes;
        $this->_AtwigOutputArray['agencies'] = $this->_Aagency;
        $this->_AtwigOutputArray['corporates'] = $this->_Acorporate;
        $this->_AtwigOutputArray['corporateList'] = $this->_Acorporate;
        $this->_AtwigOutputArray['selectCategory'] = $this->_AtravelModes;     //this will populates the field select category dropdown in policy creation
    }

    /*
     * @function : _permissionCheck
     * @Description: this function is used for getting the corporate and agency list base on the permission
     * @return: array|response array
     */

    public function _permissionCheck() {

        $recieveData = $this->_OcommonQ->_corporateAgencyPermission();
        $this->_Ocorporate->_Sstatus = 'Y';
        $this->_Acorporate = array_column($recieveData['corporate'], 'corporate_name', 'corporate_id');
        $this->_Aagency = array_column($recieveData['agency'], 'agency_name', 'dm_agency_id');
    }

    /**
     * @function : _changeStatus
     * @Description: this function is for updation the status of created policy
     * @return: array|response array
     */
    public function _changeStatus() {
        $this->_IinputData['status'] = $this->_IinputData['status'] == 'Y' ? 'N' : 'Y';
        unset($this->_IinputData['action']);
        $updateStatus = $this->_Opolicy->_updatePolicyStatus($this->_IinputData);
        if ($updateStatus) {
            $this->_Serror = 'Status Updated Successfully';
            $this->_Istatus = 3;
        } else {
            $this->_Serror = 'Status Not Updated';
            $this->_Istatus = 0;
        }
        $this->_AfinalResponse = array('status' => $this->_Istatus, 'status_message' => 'success', 'error_alert' => '', 'result' => $this->_Serror);
    }

}

?>
