<?php
/* * **************************************************************************
 * @File             : class.tpl.insertMenuMappingTpl.php
 * @Description      : This file is used to insert menu mapping  in the database.
 * @Tables Affected  : core_menu_mapping_details
 * @Author           : Karthika
 * @Created Date     : 29/11/2016
 * @Modified Date    : 
 * ****************************************************************************/

fileRequire('lib/common/commonMethods.php');

class insertMenuMappingTpl
{  

    public function __construct()
    {     
        $this->_OcommonDBO = new commonDBO();   
        $this->_OcommonMethods = new commonMethods();
    }
   
   
   public function _getDisplayInfo()           
   {  
       $input = $this->_IinputData;
       
       // Insert the menu       
       if($input['action'] == "insert" )
       {
            $menuMappingId = $this->_insertMenuMapping($input);
            if($menuMappingId != "")
            {
                $this->_AfinalResponse  = "Success";
            }
       }
       
       // get the menu info       
       elseif($input['action'] == "edit" )
       {           
           $this->_AfinalResponse = $this->_getMenuMappingInfo($input);
       }
       
       // Update the menu
       elseif($input['action'] == "update" )
       {           
           $updateMenuMappingInfo = $this->_updateMenuMappingInfo($input);
           if($updateMenuMappingInfo == 1)
           {
               $this->_AfinalResponse = "Success";
           }
       }
       
       // Delete the menu
       elseif($input['action'] == "delete" )
       {           
           $deleteMenuMappingId = $this->_deleteMenuMapping($input);
           if($deleteMenuMappingId != 0)
           {
              $this->_AfinalResponse = "Success";
           }
       }
       
   }
    // This Function is used for insert menu details in to core_menu_details
    public function _insertMenuMapping($input) 
    {      
        $menuMappingInfo = array();
        $tableName = 'core_menu_mapping_details';
        $menuMappingInfo['parent_id'] = $input['parent_id'];
        $menuMappingInfo['child_id'] = $input['child_id'] ? $input['child_id'] : 0;
        $menuMappingInfo['display_order'] = $input['display_order'];
        $menuMappingInfo['display_status'] = $input['display_status'];
        $menuMappingInfo['group_id'] = $input['group_id'];
        $menuMappingInfo['corporate_id'] = $input['corporate_id'] ? $input['corporate_id'] : 0;
        $menuMappingInfo['created_date'] = date('Y-m-d');  
        $menuMappingInfo['menu_alternate_name'] = '';  
        $menuMappingInfo['menu_alternate_link'] = '';  
        $menuMappingInfo['project_code'] = $input['project_code']; 
        $InsertedMenuMappingId = $this->_OcommonDBO->_insert($tableName, $menuMappingInfo);
        return $InsertedMenuMappingId;
    }
    
    // This Function is used to get menu mapping details from core_menu_details
    public function _getMenuMappingInfo($input)
    {
        $fieldsArray = array('parent_id','child_id','display_order','display_status','group_id','corporate_id','project_code');
        $result = $this->_OcommonDBO->_select('core_menu_mapping_details', $fieldsArray, 'menu_mapping_id', $input['menuMappingId']);;        
        if($result  != "")
        {
            return $result[0];
        }       
    }
    
    // This Function is used for update menu details in to core_menu_details
    public function _updateMenuMappingInfo($input) 
    {
        $menuUpdateId = '';
        $selectedArray = $this->_getMenuMappingInfo($input);
        $unwantedKeys = array('menuMappingId'=>$input['menuMappingId'], 'action'=>$input['action'], 'tplClassFile'=>$input['tplClassFile'], 'moduleName'=>$input['moduleName']);
        $updateArray = array_diff($input, $unwantedKeys);
        //$inputReassign = array_diff($input, $unwantedKeys);
        //$updateArray = array_diff($inputReassign, $selectedArray);
        if(count($updateArray) > 0)
        {
            $updateArray['updated_date'] = date('Y-m-d');
            $menuUpdateId = $this->_OcommonDBO->_update('core_menu_mapping_details', $updateArray, 'menu_mapping_id', $input['menuMappingId']);
        }
        return  $menuUpdateId;        
    }
    
    // This Function is used for delete menu details from core_menu_details
    public function _deleteMenuMapping($input)
    {
        $deleteMenu = $this->_OcommonDBO->_delete('core_menu_mapping_details', 'menu_mapping_id', $input['menuMappingId']);
        return $deleteMenu;
    }
   
}
?>