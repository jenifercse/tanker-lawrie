<?php
/**
 * @File             : class.tpl.createManageAggregateTpl.php
 * @Description      : This file is used track payment history
 * @Author           : Sivaprakash.M
 * @Created Date     : 26/12/2016
 * @Modified Date    : 18/01/2018
 */
class createManageAggregateTpl
{
    public function __construct() {
        $this->_createManageAggregate = common::_checkClassExistsInNameSpace('createManageAggregate','admin');
        $this->_CcommonArrayFunction = new commonArrayFunctions();
        $this->_CcommonQuery = new commonQuery();
        $this->_Oemployee = new employee();
        $this->_OAgency = new agency();
        $this->_Oreport = new report();
    }
    /**
     * @functionName    :   _getDisplayInfo()
     * @description     :   common module function
     */
    public function _getDisplayInfo() 
        {
            !empty($this->_IinputData['r_corporate_id']) ? $r_corporate_id = $this->_IinputData['r_corporate_id'] : $r_corporate_id = $_SESSION['corporateId'];
            !empty($this->_IinputData['r_agency_id']) ? $r_agency_id = $this->_IinputData['r_agency_id'] : $r_agency_id = $_SESSION['agencyId'] ;
        // assign agency and corporate id in input data    
            $this->_IinputData['r_agency_id'] = $r_agency_id;
            $this->_IinputData['r_corporate_id'] = $r_corporate_id;            
        // for agency and corporate id array    
            $this->inputId = compact('r_agency_id','r_corporate_id');
            switch ($this->_IinputData['action']) 
            {
            // used to insert the data passed towards the function create aggregate
                case 'insertAggregate':
                case 'updateAggregate':
                        $insertAggregate                   = $this->_IinputData;
                        $insertAggregate['aggregate_desc'] = addslashes($insertAggregate['aggregate_desc']);
                        $insertAggregate['aggregate_name'] = addslashes($insertAggregate['aggregate_name']);
                        $aggregateArray = $this->_CcommonArrayFunction->_getArrayDiffValues($insertAggregate, array($this->_IinputData['action']));
                        return $this->_aggregateValidation($aggregateArray);
                break;            
                case 'getChildAggregates':
                    // the array consist of all child sub child aggregate mapped with parent aggregate
                        $inputArray = array('aggregate_id'=>$this->_IinputData['aggregate_id'],'r_agency_id'=>$r_agency_id,'r_corporate_id'=>$r_corporate_id, 'action'=>'getChildAggregateDetails');
                        $childAggregateArray['subAggregateInfo'] = $this->_CcommonQuery->_createCategorySubArray($inputArray);
                        $childAggregateArray['aggregatetype'] = $this->_CcommonArrayFunction->_getMultiDimenKeyValues($this->_createManageAggregate->_getAggregateType($this->inputId), 'aggregate_type_id', 'aggregate_type'); 
                        $_SsettingDisplay = $childAggregateArray['subAggregateInfo'] ? $this->_Otwig->render('displayChildAggregate.tpl', $childAggregateArray) : '';
                        $this->_AfinalResponse = $_SsettingDisplay ? $_SsettingDisplay : array('status' => 0, 'error_alert' => 'No child aggregate mapped');
                break;  
                case 'getCorporate':
                        $corporateData = $this->_OAgency->_getAgencyCorporateList($this->_IinputData['r_agency_id']);
                        $this->_AfinalResponse = $corporateData ? array('status' => 1, 'corporateList' => $corporateData) : array('status' => 0, 'error_alert' => 'No corporate mapped to the agency');
                break;             
                case 'getAggregateDetail':
                    // used to get only respective aggregate details                    
                        $aggregateDetails = $this->_createManageAggregate->_getAggregateDetails($this->_IinputData);
                        $aggregateDetails[0] ? $aggregateDetails[0]['aggregateParentList'] = $this->_createManageAggregate->_getAggregate($this->inputId, 'onlyParentAggregate') : FALSE;
                        $this->_AfinalResponse = $aggregateDetails[0] ? $aggregateDetails[0] : '';
                break;  
                case 'insertAggregateType':
                        $aggregateTypeArray = $this->_CcommonArrayFunction->_getArrayDiffValues($this->_IinputData, array($this->_IinputData['action']));
                        $this->_AfinalResponse = $this->_createManageAggregate->_ValidateAggregateType($aggregateTypeArray);
                break;              
                case 'getDisplaydetails':
                        $aggregateList       = $this->_createManageAggregate->_getAggregateDetails($this->inputId);
                        $aggregareParentList = $this->_createManageAggregate->_getAggregateDataOverRide($this->inputId);
                        $aggregareTypeList   = $this->_createManageAggregate->_getAggregateType($this->inputId);
                        $filterData          = $this->_getCorporateFilterDetailsForEmployee($r_corporate_id);
                        $this->_CcommonQuery->_getAgencyCorporatePermissionCheck();
                        $listDetails = $this->_CcommonQuery->_AserviceResponse;
                        $levelId             = $_SESSION['levelId'];
                        $agencyCorporateId   = $this->inputId;
                        $agencyList          = $listDetails['agencyId'] ? $listDetails['agencyId'] : '';
                        $corporateEmployeeEmail = $this->_Oemployee->_getEmployeeId($this->inputId['r_corporate_id']);
                        if($levelId == 1){
                            $corporateList   = $this->_OAgency->_getAgencyCorporateList($this->inputId['r_agency_id']);
                        }else{
                            $corporateList   = count($listDetails['corporate']) > 1 ? $listDetails['corporate'] : '';
                        }
                        $this->_AfinalResponse = array('status' => 1,'listData' =>compact('aggregateList','aggregareParentList','aggregareTypeList','agencyList', 'corporateList', 'levelId', 'agencyCorporateId'), 'filterData'=>$filterData, 'corporateEmployeeEmail'=>$corporateEmployeeEmail);
                break;
                case 'getAggregateEmployeeDetail':
                        $aggregateArray = array('aggregate_id' => $this->_IinputData['aggregate_id'], 'filters' => $this->_IinputData['filters']);

                        $aggregateEmployeeList['aggregateEmployeeList'] = $this->_createManageAggregate->_getAggregateEmployeeDetail($aggregateArray); 

                        $aggregateEmployeeList['aggregateEmployeeList'] ? $this->_AfinalResponse = array('status' => 1,'aggregateEmployeeList' =>$this->_Otwig->render('aggregateEmployee.tpl', $aggregateEmployeeList), 'aggregateDetails'=> $this->_createManageAggregate->_getAggregateDetails($this->_IinputData)[0], 'aggEmpList' => $aggEmpList) : $this->_AfinalResponse = array('status' => 0,'error_alert' =>'No employee mapped',  'aggregateDetails'=> $this->_createManageAggregate->_getAggregateDetails($this->_IinputData)[0],'aggregateEmployeeList' =>$this->_Otwig->render('aggregateEmployee.tpl', $aggregateEmployeeList));

                break;
                case 'getNotAggregatedEmployee':
                        $aggregateArray = array('aggregate_id' => $this->_IinputData['aggregate_id'], 'filters' => $this->_IinputData['filters']);
                        $nonAggregateList = $employeeNotAggregatedList['employeeNotAggregatedList'] = $this->_createManageAggregate->_getNotAggregateEmployeeDetail($aggregateArray);
                        $employeeNotAggregatedList['employeeNotAggregatedList'] ? $this->_AfinalResponse = array('status' => 1,'employeeNotAggregatedList' =>$this->_Otwig->render('notAggregateEmployee.tpl', $employeeNotAggregatedList), 'nonAggregateList' => $nonAggregateList) : $this->_AfinalResponse = array('status' => 0,'error_alert' =>'No employee found to be mapped with aggregate');
                break;  
                case 'addEmployeeAggregate':
                        unset($this->_IinputData['r_agency_id']);unset($this->_IinputData['r_corporate_id']);
                        $insertEmployeeAggregateArray = $this->_CcommonArrayFunction->_getArrayDiffValues($this->_IinputData, array($this->_IinputData['action']));

                        $result = $this->_createManageAggregate->_insertAggregateEmployeeDetails($insertEmployeeAggregateArray);
                        $this->_AfinalResponse = $result ? array('status' => 1, 'success_message' => 'Aggregate mapped sucessfully') : array('status' => 0, 'error_alert' => 'Aggregate not mapped');
                break;
                case 'removeEmployeeAggregate':
                        $removeEmployeeAggregateArray = $this->_CcommonArrayFunction->_getArrayDiffValues($this->_IinputData, array($this->_IinputData['action']));
                        $result = $this->_createManageAggregate->_removeEmployeeAggregateMapping($removeEmployeeAggregateArray);
                        $result ? $this->_AfinalResponse = array('status' => 1, 'success_message' => 'Mapping removed successfully') : $this->_AfinalResponse = array('status' => 0, 'error_alert' => 'Aggregate mapping not removed');
                break;
                case 'searchEmployee':
                        $aggregateArray = array('aggregate_id' => $this->_IinputData['aggregate_id'], 'filters' => $this->_IinputData['filters']);
                    // get employee who are mapped with aggregate
                        if($this->_IinputData['type'] == 'aggregateEmployeeList'){
                        $employeeArray['aggregateEmployeeList'] = $this->_createManageAggregate->_getAggregateEmployeeDetail($aggregateArray);
                        $employeeArray['aggregateEmployeeList'] ? $this->_AfinalResponse = array('status' => 1, 'employeeArray' => $this->_Otwig->render('aggregateEmployee.tpl', $employeeArray)) : $this->_AfinalResponse = array('status' => 0, 'error_alert' => 'No employee found for filter option');
                        }
                    // get employee who are not mapped with aggregate    
                        if($this->_IinputData['type'] == 'employeeNotAggregatedList'){
                        $employeeArray['employeeNotAggregatedList'] = $this->_getNotAggregatedEmployee($aggregateArray);
                        $employeeArray['employeeNotAggregatedList'] ? $this->_AfinalResponse = array('status' => 1, 'employeeArray' => $this->_Otwig->render('notAggregateEmployee.tpl', $employeeArray)) : $this->_AfinalResponse = array('status' => 0, 'error_alert' => 'No employee found for filter option');
                        }
                break;            
                case 'removeBulkEmployeeAggregateMapping':
                case 'addBulkEmployeeAggregateMapping':
                        unset($this->_IinputData['r_agency_id']);unset($this->_IinputData['r_corporate_id']);
                    // add or remove employee from aggregate mapping
                        $bulkEmployeeAggregateArray = $this->_CcommonArrayFunction->_getArrayDiffValues($this->_IinputData, array($this->_IinputData['action']));
                        $this->_AfinalResponse = $this->_createManageAggregate->_bulkEmployeeAggregateDetails($bulkEmployeeAggregateArray['bulkdata']);
                break;
                case 'searchAggregate':
                        $searchAggregate = $this->_CcommonArrayFunction->_getArrayDiffValues($this->_IinputData, array($this->_IinputData['action']));
                        if(isset($this->_IinputData['employee_id']) && !empty($this->_IinputData['employee_id']))
                        {
                            $aggregateList = $this->_getEmployeeMappedAggregtaeDetails();
                            $error_alert = 'Employee not mapped with aggregate';
                        }else{                       
                            $aggregateList = $this->_createManageAggregate->_getAggregateDetails($searchAggregate);
                            $error_alert = 'No parent aggregate found for your filter option';
                        }
                        $aggregareParentList = $this->_createManageAggregate->_getAggregate($this->inputId);
                        $aggregareTypeList   = $this->_createManageAggregate->_getAggregateType($this->inputId); 
                        $listData            = compact('aggregateList','aggregareParentList','aggregareTypeList');
                        $this->_aggregateDetails = $listData['aggregateListDetails'] = $listData['aggregateList'];
                        $filterData          = $this->_getCorporateFilterDetailsForEmployee($this->inputId['r_corporate_id']);                        
                        $templateData['aggregateListDetails'] = $aggregateList ? $aggregateList : '';
                        $this->_AserviceResponse = $this->_AfinalResponse = $aggregateList ? array('status' => 1, 'listData' => $listData, 'filterData'=>$filterData, 'aggregateTemplate' =>$this->_Otwig->render('aggregateListDetails.tpl', $templateData), 'employeeCorporateId'=> $employeeCorporateId ? $employeeCorporateId : $this->inputId['r_corporate_id'], 'employeeAgencyId'=> $employeeAgencyId ? $employeeAgencyId : $this->inputId['r_agency_id']) : array('status' => 0, 'error_alert' => $error_alert, 'listData' =>$listData, 'filterData'=>$filterData, 'employeeCorporateId'=> $employeeCorporateId ? $employeeCorporateId : '', 'employeeAgencyId'=> $employeeAgencyId ? $employeeAgencyId : '');

                break;   
                case 'getCorporateEmployeeEmail':
                    $corporateEmployeeEmail = $this->_Oemployee->_getEmployeeId($this->inputId['r_corporate_id']);
                    $this->_AfinalResponse = count($corporateEmployeeEmail) > 0 ? array('status' => 1, 'corporateEmployeeEmail'=>$corporateEmployeeEmail) : array('status' => 0, 'error_alert' => 'No record found');
                break;
                case 'getParentAggregateDetails':
                    $aggregateDetails = $this->_createManageAggregate->_getAggregateDetails($this->_IinputData);
                    $aggregateTypeDetails = $this->_createManageAggregate->_getAggregateType($this->_IinputData);
                    $this->_AfinalResponse['aggregateDetails'] = $aggregateDetails;
                    $this->_AfinalResponse['aggregateTypeDetails'] = $aggregateDetails;
                    break;
                // default to display the ui data from the begining for list all parent aggregate details
                default:
                    (isset($this->_IinputData['recordLimit']) || !isset($this->_IinputData['recordLimit'])) ? $this->_IinputData['recordLimit'] = $this->_Oreport->_recordLimit($this->_IinputData['recordLimit']) : '';
                    $this->inputId['recordLimit'] = $this->_IinputData['recordLimit'];
                    $this->_getDisplaydetails();
            }
            $this->_templateAssign();
        }     
    /**
     * @functionName    :   _templateAssign()
     * @description     :   common module function
     */        
        public function _templateAssign() {
            $this->_AtwigOutputArray['aggregateListDetails'] = $this->_aggregateDetails ? $this->_aggregateDetails : '';
        }

/**
         * used to get the display details for the aggregate list and aggregtae details 
         * @return array response array
         * @author sivaprakash
         */
        private function _getDisplaydetails() {
            
                $this->_Oemployee = new employee();
                $this->_OAgency   = new agency();
            // get corporate agency based aggregate and filter datas    
                
                $this->_aggregateDetails = $aggregateListDetails = commonArrayFunctions::_formatSameArrayValueInArrayKey($this->_createManageAggregate->_getAggregateDetails($this->inputId));
                $aggregareParentList  = $this->_createManageAggregate->_getAggregateDataOverRide($this->inputId);
                $aggregareTypeList    = $this->_createManageAggregate->_getAggregateType($this->inputId);
                $filterData           = $this->_getCorporateFilterDetailsForEmployee($this->inputId['r_corporate_id']);
            // check permission level access    
                $this->_CcommonQuery->_getAgencyCorporatePermissionCheck();
                $listDetails = $this->_CcommonQuery->_AserviceResponse;
            // assign the permission data    
                $levelId             = $_SESSION['levelId'] ? $_SESSION['levelId'] : $_REQUEST['levelId'];
                $agencyCorporateId   = $this->inputId;
                $agencyList          = $listDetails['agencyId'] ? $listDetails['agencyId'] : '';
                
                if($levelId == 1){
                    $corporateList   = $this->_OAgency->_getAgencyCorporateList($this->inputId['r_agency_id']);
                }else{
                    $corporateList   = count($listDetails['corporate']) > 1 ? $listDetails['corporate'] : $listDetails['corporate'];
                }
                $this->_AfinalResponse = array('listData' => compact('aggregateListDetails','aggregareParentList','aggregareTypeList','agencyList', 'corporateList', 'levelId', 'agencyCorporateId'), 
                                                'filterData'=>$filterData, 'recordLimit' => $this->inputId['recordLimit']);


                $response =  $this->_AserviceResponse = array('listData' => compact('aggregateListDetails','aggregareParentList','aggregareTypeList','agencyList', 'corporateList', 'levelId', 'agencyCorporateId'), 
                                                'filterData'=>$filterData, 'recordLimit' => $this->inputId['recordLimit']);
                return $this->_AserviceResponse;
        }


    /**
    * used to get the employee mapped aggregate details
    * @return array aggragate employee details
    * @author sivaprakash
    */
        public function _getEmployeeMappedAggregtaeDetails() {
            
                $employeeCorporateId = $this->_createManageAggregate->_OcommonDBO->_select('fact_employee', 'r_corporate_id', 'r_employee_id', $this->_IinputData['employee_id'])[0]['r_corporate_id'];
                $this->inputId['r_corporate_id'] = $employeeCorporateId ? $employeeCorporateId : '';
                
                $employeeAgencyId =  $this->_createManageAggregate->_OcommonDBO->_select('agency_corporate_mapping', 'agency_id', 'corporate_id', $employeeCorporateId)[0]['agency_id'];
                $this->inputId['r_agency_id'] = $employeeAgencyId ? $employeeAgencyId : '';
                
                return $this->_IinputData['employee_id'] ? $this->_createManageAggregate->_getEmployeeAggregateDetails($this->_IinputData['employee_id']) : '';            
        }
        
    /**
     * @functionName    :   _insertAggregateDetails()
     * @description     :   To insert aggregate newly created
     * @params          :   $insertArray contains the aggregate creation data
     * @returnType      :   integer last inserted aggregate id 
     * @author sivaprakash
     */    
        public function _insertAggregate($insertAggregate) {
            $insertAggregate['created_date']    = $this->_CcommonArrayFunction->_getCurrentDateAndTime();
            $lastIsertedAggregateId = $this->_createManageAggregate->_insertAggregateDetails($insertAggregate);
            return $lastIsertedAggregateId;
        }
    /**
     * @functionName    :   _aggregateLevelCheck()
     * @description     :   To  check aggregate level
     * @params          :   $parentAggregateId contains the aggregate id
     * @returnType      :   $result empty or value to proces 
     * @author sivaprakash
     */    
        public function _aggregateLevelCheck($parentAggregateId) {
            if($parentAggregateId != '')
            {//function called for checking aggregate level of mapping
                $this->_createManageAggregate->_checkAggregateLevel($parentAggregateId);
                $value = $this->_createManageAggregate->_CcheckAggregateLevel;
                if($value >= AGGREGATE_MAX_LEVEL)
                {
                    return false;
                }
                else if($value < AGGREGATE_MAX_LEVEL) 
                {
                    return true;
                }
            }
            else
            {
                return false;
            }
        }               
    /**
     * @functionName    :   _aggregateValidation()
     * @description     :   To validate the aggregate before inserting and updating process
     * @params          :   $inputArray contains the aggregate data action contains of to insert or update action
     * @returnType      :   return either true success messange or false error message
     * @author sivaprakash
     */       
        public function _aggregateValidation($inputArray) {
            $levelResult = true; $checkInsert = true; $checkName = true;
        // check aggregate parent and child mapping level    
            if($inputArray['aggregate_parent_id'] != 0) {
                $levelResult = $this->_aggregateLevelCheck($inputArray['aggregate_parent_id']);
                !$levelResult ? $error_message = "Aggregate reached maximum mapping level " : '';
            }
        // check aggregate name already exist on inserting new aggregate
            if((!isset($inputArray['aggregate_id']))){
                $checkInsert = $this->_createManageAggregate->_checkAggregateNameExist($inputArray);
                !$checkInsert ? $error_message .= "Aggregate name already exist" : '';
            }
        // check aggregate name already exist on updating aggregate
            if((isset($inputArray['aggregate_id']))){
                $checkUpdateName = $this->_createManageAggregate->_getAggregateByActionBased("dm_aggregate", 'aggregate_name, aggregate_id' , 'aggregate_id = '.$inputArray['aggregate_id'],$inputArray);
                $aggregateArray = $this->_CcommonArrayFunction->_getArrayDiffValues(array('aggregate_id'=>$inputArray['aggregate_id'],'aggregate_name'=>$inputArray['aggregate_name']), $checkUpdateName[0]);
                !empty($aggregateArray) ? $checkName = $this->_createManageAggregate->_checkAggregateNameExist($inputArray) : '';
                if(!$checkName){return $this->_AfinalResponse = array('status' => 0, 'error_alert' => 'Aggregate name already exist');}
            }
        // proceed the insert or update functionality for aggregate on previous validation get succeded    
            if(($checkInsert && $levelResult))
            {
                if((isset($inputArray['aggregate_id']) && !empty($inputArray['aggregate_id'])))
                {// for update validation
                    return ($inputArray['status'] == 'N') ? $this->_aggregateUpdateValidation($inputArray) : $this->_aggregateUpdate($inputArray);
                }else{
                // for aggregate creation    
                    return $this->_aggregateCreation($inputArray);
                }
            }else{
                return $this->_AfinalResponse = array('status' => 0, 'error_alert' => $error_message);    
            }
        }
    /**
    * used to create and insert new aggregate and aggregate type
    * @param type $inputArray
    * @return array response
    * @author sivaprakash
    */
        private function _aggregateCreation($inputArray) {
            // for child aggregate insertion parent mapping
                if($inputArray['aggregate_parent_id'] != 0){
                    $this->_createManageAggregate->_getAggregateParentId($inputArray['aggregate_parent_id']);
                    $inputArray['parent_id'] = count($this->_createManageAggregate->_PparentId) > 0 ? json_encode($this->_createManageAggregate->_PparentId) : '';
                }
            // for aggregate type insertion    
                if(!empty($inputArray['aggregate_type'])){
                    $inputArray['aggregate_type_id'] = $this->_createManageAggregate->_validateAggregateType($inputArray);
                    unset($inputArray['aggregate_type']);
                }
                $insertResult = $this->_insertAggregate($inputArray);
                $templateData['aggregateListDetails'] = $this->_createManageAggregate->_getAggregateDetails($this->inputId);
                return !empty($insertResult) ? $this->_AfinalResponse = array('status' => 1, 'message' => 'Aggregate created successfully', 'aggregateTemplate' =>$this->_Otwig->render('aggregateListDetails.tpl', $templateData), 'aggregateParentList'=>$this->_createManageAggregate->_getAggregate($this->inputId), 'aggregareTypeList'=> $this->_createManageAggregate->_getAggregateType($this->inputId)) : $this->_AfinalResponse = array('status' => 0, 'error_alert' => 'Aggregate not created');
        }
    /**
    * used to update the aggregate details
    * @param type $inputArray
    * @return array response
    * @author sivaprakash
    */
        private function _aggregateUpdate($inputArray) {
            // mapping child aggregate with parent aggregate
                if($inputArray['aggregate_parent_id'] != 0 ){
                    $this->_createManageAggregate->_getAggregateParentId($inputArray['aggregate_parent_id']);
                    $inputArray['parent_id'] = count($this->_createManageAggregate->_PparentId) > 0 ? json_encode($this->_createManageAggregate->_PparentId) : '';
                }
            // update aggregate details    
                $resultUpdate = $this->_createManageAggregate->_updateAggregateDetails($inputArray);
                $templateData['aggregateListDetails'] = $this->_createManageAggregate->_getAggregateDetails($this->inputId);
                
            return $resultUpdate ? $this->_AfinalResponse = array('status' => 1, 'status_message' => 'Aggregate updated successfully', 'aggregateTemplate' =>$this->_Otwig->render('aggregateListDetails.tpl', $templateData), 'aggregateParentList'=>$this->_createManageAggregate->_getAggregate($this->inputId)) : $this->_AfinalResponse = array('status' => 0, 'error_alert' => 'Aggregate not updated');
        }
    /**
     * @functionName    :   _aggregateUpdateValidation()
     * @description     :   To validate the aggregate before updating process
     * @params          :   $inputArray contains the aggregate data 
     * @returnType      :   return either true success messange or false error message
     * @author sivaprakash
     */        
        public function _aggregateUpdateValidation($updateArray)  {
            
            $checkSubchildMapped = $this->_createManageAggregate->_getAggregateByActionBased('dm_aggregate', '*' , 'getChildAggregateDetails', $updateArray);
            $checkSubchildMapped ? $error_message = " Aggregate mapped with sub child, " : '';
            //to check aggregate has approval settings mapped in approval settings table
            $checkAggregateMapping = array('aggregateId' => $updateArray['aggregate_id'], 'r_agency_id'=>$updateArray['r_agency_id'], 'r_corporate_id'=>$updateArray['r_corporate_id'],'parameterType'=>'category');
            $checkAggregateApprovalMapping = $this->_createManageAggregate->_checkAggregateApprovalMapping($checkAggregateMapping);
            !$checkAggregateApprovalMapping ? $error_message .= " approval settings, " : '';
            //check aggregate mapped with policy 
            $checkAggregatePolicy = $this->_createManageAggregate->_checkAggregatePolicyMapping(array('aggregateId' => $updateArray['aggregate_id']));
            !$checkAggregatePolicy ? $error_message .= " policy mapping, " : '';
            // if aggregate has no subchild and approval mapped allow the aggregate status to be in active
                if((empty($checkSubchildMapped) && ($checkAggregateApprovalMapping) && ($checkAggregatePolicy))){
                    return $this->_aggregateUpdate($updateArray);
                }else{
                    $error_message .= " status cant be Inactive";
                    return $this->_AfinalResponse = array('status' => 0, 'error_alert' => $error_message);
                }            
        }       
    /**
     * @functionName    :   _getNotAggregatedEmployeeDetails()
     * @description     :   To get the employee not mapped with aggregate
     * @params          :   $aggregateArray aggregate details
     * @returnType      :   return $employeeNotAggregatedList employee details
     * @author sivaprakash
     */         
        public function _getNotAggregatedEmployee($aggregateArray) {
            $aggregatedEmployee = $this->_createManageAggregate->_getAggregateEmployeeDetail($aggregateArray);
            $aggregateNotEmployee = $this->_createManageAggregate->_getNotAggregateEmployeeDetail($aggregateArray);
            return $employeeNotAggregatedList = $aggregatedEmployee ? $this->_CcommonArrayFunction->_getArrayDiffValuesOfAssociativeArray($aggregatedEmployee, $aggregateNotEmployee) : $aggregateNotEmployee;            
            
        }
    /**
     * @functionName    :   _getCorporateFilterDetailsForEmployee()
     * @description     :   To get the get Corporate Filter Details For Employee
     * @params          :   $r_corporate_id corporate id
     * @returnType      :   return $filterData array
     * @author sivaprakash
     */          
        public function _getCorporateFilterDetailsForEmployee($r_corporate_id) {
            global $CFG;
            $this->_Eemployee    = new employee();
            $userTypes = $department = $designation = $location = '';
            
        // get user types for filter details    
            $userTypes           = $this->_Eemployee->_getAllowedUserTypes($CFG['AGGREGATE_ALLOWED_USER_TYPES']);
        // get corporate based department    
            $department          = $this->_Eemployee->_getDepartmentDetails($r_corporate_id);
        // get corporate based designation
            $designation         = $this->_Eemployee->_getDesignationDetails($r_corporate_id);
        // get corporate based location
            $location            = $this->_Eemployee->_getBranchDetails($r_corporate_id);

            return $r_corporate_id ? compact('userTypes','department','designation','location') : '';
        }
}
?>
