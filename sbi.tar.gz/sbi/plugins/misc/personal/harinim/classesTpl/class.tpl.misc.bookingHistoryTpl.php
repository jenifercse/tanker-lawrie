<?php

/* * **************************************************************************
 * @File            list Booking History List
 * @Description     class Tpl file to list log file data in UI
 * @Author          Baskar V P
 * @Created Date    04/11/2016
 * @Tables used     Booking History  
 * **************************************************************************** */
fileRequire('lib/common/commonMethods.php');
fileRequire("lib/common/fusioncharts.php");

class bookingHistoryTpl {

    public function __construct() {
        $this->_OcommonDBO = new commonDBO();
    }

    /*
     * @Description  the function to be called based on action parameters
     * @param 
     * @return 
     */

    public function _getDisplayInfo() {
        $this->_OAgency = new agency();
        $this->_OAppSetting = new applicationSettings();
        $this->_OAppSetting->_ODBC = $this->_ODBC;
        $returnValue = array('status' => 0, 'status_message' => 'success', 'error_alert' => '', 'result' => array());
        
        if (isset($this->_IinputData['action'])) {
            $this->action = $this->_IinputData['action'];
        } else {
            $this->action = 'view';
        }
        
        //customization added of LNT single sigon personal booking
        if($_SESSION['corporateId'] == LNT_SSO_CORPORATE_ID) {
            $this->_IinputData['agencyId']    = LNT_SSO_AGENCY_ID;
            $this->_IinputData['corporateId'] =  LNT_SSO_CORPORATE_ID;
        }
        
        switch ($this->action) {
            case 'displaySettings':
                
                
                $returnValue = $this->_displayBookingList($this->_IinputData['agencyId'], $this->_IinputData['corporateId']);
                break;
            case 'agencyCorporate':
                $this->_AagencyCorporateList = $this->_OAgency->_getAgencyCorporateList($this->_IinputData['agencyId']);
                !empty($this->_AagencyCorporateList) ? $this->_AfinalResponse = array('status' => 0, 'result' => $this->_AagencyCorporateList) : $this->_AfinalResponse = array('status' => 1, 'error_alert' => 'No corporate has been listed for the agent id' . $this->_IinputData['agencyId']);
                break;
            case 'view':
                $this->_viewCorporate();
                break;
            case 'chart':
                $this->chart();
                break;
            default:
                break;
        }
        return $this->_AfinalResponse;
    }

    /*
     * This function is used to display agency name list
     */

    public function _viewCorporate() {
        $fieldsArray = array('dm_agency_id', 'agency_name');
        $this->_AagencyList = $this->_OAgency->_getAgencyList($fieldsArray);
        $this->_templateAssign();
    }

    /*
     * @Description  function is use to display booking list based on user given agency id and corporate id
     * @param 
     * @return 
     */

    public function _displayBookingList($agencyId = 0, $corporateId = 0) {
        $period = $this->_IinputData['period'];
        //query for total amount 
        $queryAmount = " SELECT MONTHNAME(CONCAT(booking_date)) as label,
                        YEAR(booking_date) as year,
                        sum(total_amount) as total,
                        sum(package_amount) as package,
                        sum(extra_charges) as  payment_gateway_charges
                        FROM booking_history 
                        where total_amount!=0 and sync_order_id!=0 and booking_type= '0' and payment_status='Y' and r_booked_by!=0
                        and ";
        $query = "select  
            order_id as 'Order_ID',
            case trip_type
            when '0' then 'One Way'
            when '1' then 'Round Trip'
            when '' then 'Hotel'
            end as 'Trip_Type',
            case travel_mode
            when 'D' then 'Air'
            when 'H' then 'Hotel'
            end as 'Travel_Mode',
            r_booked_by ,
            DATE_FORMAT(booking_date,'%b-%d-%Y %h:%i %p') as 'Booked_Date',
            sector_from as 'From',
            sector_to as 'To',
            no_of_passenger as 'Total_Passenger',
            adult as Adult,
            child as Child,
            infant as Infant,
            dc.corporate_name AS Corporate_Name,
            hotel_name as Hotel_Name,
            checkin_date as CheckIn_Date,
            checkout_date as CheckOut_Date,
            sync_order_id as sync,
            rooms_count as Room_Count,
             ";
        if ($this->_IinputData['package_type'] == 1) {
            $query.="sum(total_amount) as 'Total_Amount',
                    sum(package_amount) as 'Actual_ticket_fare',
                    sum(extra_charges) as 'Payment_gateway_charges',";
        }
        if ($this->_IinputData['package_type'] == 3) {
            $query.="  sum(adult) as 'Adult',"
                    . "sum(child) as 'Child',"
                    . "sum(infant) as 'Infant',"
                    . "(SUM(adult)+SUM(child)+SUM(infant)) AS 'Total_No_of_Passengers',"
                    . "sum(package_amount) AS 'Ticket_Fare',"
                    . "sum(extra_charges) AS 'Payment_Gateway_Charges',"
                    . "(sum(package_amount) + sum(extra_charges)) AS 'Total_Amount',"
                    . "count(payment_status) AS 'No_Of_Transcations' , ";
        } else {
            $query.=" total_amount as 'Total_Amount',
            package_amount as 'Actual_ticket_fare',
            extra_charges as 'Payment_gateway_charges', ";
        }
        $query.="payment_status as 'Payment_Status',
             DATE_FORMAT(onward_depature_date,'%b-%d-%Y %h:%i %p') as 'Onward_Departure_Date',
            DATE_FORMAT(onward_arrival_date,'%b-%d-%Y %h:%i %p') as 'Onward_Arrival_Date' ,
            DATE_FORMAT(return_depature_date,'%b-%d-%Y %h:%i %p') as 'Return_Departure_Date',
            DATE_FORMAT(return_arrival_date,'%b-%d-%Y %h:%i %p') as 'Return_Arrival_Date'
            FROM booking_history bh  
            INNER JOIN dm_corporate dc ON bh.r_corporate_id = dc.corporate_id
             where total_amount!=0 and sync_order_id!=0 and booking_type = '0' and r_booked_by!=0 and payment_status='Y' and  ";
        //check corporateId and agencyId values

        if ($this->_IinputData['agencyId'] != '') {
            $queryAmount.="r_agency_id =  '" . $this->_IinputData['agencyId'] . "' and ";
            $query.="r_agency_id =  '" . $this->_IinputData['agencyId'] . "' and ";
        }
        if ($this->_IinputData['corporateId'] != '') {
            $query.="r_corporate_id =  '" . $this->_IinputData['corporateId'] . "' and ";
            $queryAmount.="r_corporate_id =  '" . $this->_IinputData['corporateId'] . "' and ";
        }
        if ($this->_IinputData['travel_mode'] != '') {
            $query.="travel_mode =  '" . $this->_IinputData['travel_mode'] . "' and ";
            $queryAmount.="travel_mode =  '" . $this->_IinputData['travel_mode'] . "' and ";
        }
        $query.="booking_date ";
        $queryAmount.="booking_date";
        $today = date('Y-m-d');
        switch ($period) {
            case 1:
                $query.=" like '" . $today . "%'";
                $queryAmount.=" like '" . $today . "%' ";
                break;
            case 2:
                $yesterday = date('Y-m-d', strtotime('-1 days'));
                $query.=" like '" . $yesterday . "%'";
                $queryAmount.=" like '" . $yesterday . "%'";
                break;
            case 3:
                $Lastweek = date('Y-m-d', strtotime('-7 days'));
                $query.=" BETWEEN '" . $Lastweek . "' AND '" . $today . "'";
                $queryAmount.=" BETWEEN '" . $Lastweek . "' AND '" . $today . "'";
                break;

            case 4:
                //$Lastweek = date('Y-m-d', strtotime('-7 days'));
                $query.=" BETWEEN DATE_ADD(CURDATE(), INTERVAL 1-DAYOFWEEK(CURDATE()) DAY)
                     AND DATE_ADD(CURDATE(), INTERVAL 7-DAYOFWEEK(CURDATE()) DAY)";
                $queryAmount.=" BETWEEN DATE_ADD(CURDATE(), INTERVAL 1-DAYOFWEEK(CURDATE()) DAY)
                    AND DATE_ADD(CURDATE(), INTERVAL 7-DAYOFWEEK(CURDATE()) DAY)";
                break;

            case 5:
                $query.=" !=0 and MONTH(booking_date) = MONTH(CURDATE())";
                $queryAmount.="!=0 and MONTH(booking_date) = MONTH(CURDATE())";
                break;

            case 6:
                $Lastmonth = date('Y-m-d', strtotime('-30 days'));
                $query.=" BETWEEN DATE_FORMAT(NOW() - INTERVAL 1 MONTH, '%Y-%m-01 00:00:00') AND DATE_FORMAT(LAST_DAY(NOW() - INTERVAL 1 MONTH), '%Y-%m-%d 23:59:59')";

                $queryAmount.=" BETWEEN DATE_FORMAT(NOW() - INTERVAL 1 MONTH, '%Y-%m-01 00:00:00') AND DATE_FORMAT(LAST_DAY(NOW() - INTERVAL 1 MONTH), '%Y-%m-%d 23:59:59')";
                break;
            case 7:
                $query.=" BETWEEN '" . $this->_IinputData['from'] . " 00:00:00' AND '" . $this->_IinputData['to'] . " 23:55:55 '";
                $queryAmount.=" BETWEEN '" . $this->_IinputData['from'] . " 00:00:00' AND '" . $this->_IinputData['to'] . " 23:55:55 '";

                break;
            case 8:
                $query.="YEAR(booking_date) = YEAR(CURDATE())";
                $queryAmount.="YEAR(booking_date) = YEAR(CURDATE())";
                break;
            default:
                break;
        }
        if ($this->_IinputData['package_type'] == 1) {
            $query.="GROUP by package_id";
        }
        if ($this->_IinputData['package_type'] == 3) {
            $query.="  GROUP by r_corporate_id";
        }
        $query.=" order by sync_order_id asc";
        $emailResult = array();
        $result = $this->_OcommonDBO->_getResult($query);
        foreach ($result as $key => $value) {
            $email = "SELECT email_id from dm_employee 
                    where employee_id ='" . $value['r_booked_by'] . "'";
            $resultEmail = $this->_OcommonDBO->_getResult($email);
            foreach ($resultEmail as $keys => $values) {
                if ($values['email_id'] == '') {
                    $result[$key]['Booked_by'] = 'TESTW';
                } else {
                    $result[$key]['Booked_by'] = $values['email_id'];
                }
            }
        }
        $resultForAmount = $this->_OcommonDBO->_getResult($queryAmount);
        $_AtwigOutputArray['data'] = $result;
        $_AtwigOutputArray['amount'] = $resultForAmount;
        if ($this->_IinputData['package_type'] == 3) {
            $_SsettingDisplay = $this->_Otwig->render('bookingDataByCorporate.tpl', $_AtwigOutputArray);
        } else {
            $_SsettingDisplay = $this->_Otwig->render('bookingData.tpl', $_AtwigOutputArray);
        }
        $this->_AfinalResponse = array('status' => 0, 'status_message' => 'success', 'error_alert' => '', 'result' => array(), 'template' => $_SsettingDisplay);
        return $this->_AfinalResponse;
    }

    /*
     * @Description  function to assign values to twig template
     * @param 
     * @return 
     */

    public function chart() {
        $period = $this->_IinputData['period'];
        $today = date('Y-m-d');
        $queryForChart = "SELECT  
                MONTHNAME(CONCAT(booking_date)) as label,
                YEAR(booking_date) as year,
                MONTH(booking_date) as labeldata,
                sum(total_amount) as value
            FROM 
            booking_history
            WHERE total_amount!=0 and booking_type = '0' and sync_order_id !=0 and r_booked_by !=0 and payment_status='Y' and ";
        $queryForCount = "SELECT  
                count(total_amount) as value,
                MONTHNAME(CONCAT(booking_date)) as label,
                MONTH(booking_date) as labeldata
            FROM 
            booking_history
            WHERE total_amount!=0 and booking_type = '0' and sync_order_id !=0 and r_booked_by !=0 and payment_status='Y' and ";
        
        if($_SESSION['corporateId'] == 52) {
            $this->_IinputData['corporateId'] = $_SESSION['corporateId'];
        }
        
        if ($this->_IinputData['corporateId'] != '') {
            $queryForChart.="r_corporate_id =  '" . $this->_IinputData['corporateId'] . "' and ";
            $queryForCount.="r_corporate_id =  '" . $this->_IinputData['corporateId'] . "' and ";
        }
        if ($this->_IinputData['agencyId'] != '') {
            $queryForChart.="r_agency_id= '" . $this->_IinputData['agencyId'] . "' and ";
            $queryForCount.="r_agency_id= '" . $this->_IinputData['agencyId'] . "' and ";
        }
        if ($this->_IinputData['travel_mode'] != '') {
            $queryForChart.="travel_mode = '" . $this->_IinputData['travel_mode'] . "' and ";
            $queryForCount.="travel_mode = '" . $this->_IinputData['travel_mode'] . "' and ";
        }
        switch ($period) {
            //today
            case 1:
                $queryForChart.="DATE(booking_date) = CURDATE()
            and YEAR( booking_date ) !=0  GROUP BY YEAR( booking_date), label";
                $queryForCount.="DATE(booking_date) = CURDATE()
            and YEAR( booking_date ) !=0 GROUP BY YEAR( booking_date), label";
                break;
            //yesterday
            case 2:
                $queryForChart.="DATE(booking_date) = CURDATE()- 1
            and YEAR( booking_date ) !=0  GROUP BY YEAR( booking_date), label";
                $queryForCount.="DATE(booking_date) = CURDATE()- 1
            and YEAR( booking_date ) !=0 GROUP BY YEAR( booking_date), label ";
                break;
            //lastWeek
            case 3:
                $queryForChart.=" booking_date >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY
                        AND booking_date < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY
                        and YEAR( booking_date ) !=0  GROUP BY YEAR( booking_date), label";
                $queryForCount.="booking_date >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY
                        AND booking_date < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY
                        and YEAR( booking_date ) !=0 GROUP BY  label";
                break;
            //this week
            case 4:
                $queryForChart.=" booking_date BETWEEN DATE_ADD(CURDATE(), INTERVAL 1-DAYOFWEEK(CURDATE()) DAY)
                    AND DATE_ADD(CURDATE(), INTERVAL 7-DAYOFWEEK(CURDATE()) DAY)
                        and YEAR( booking_date ) !=0  GROUP BY YEAR( booking_date), label";
                $queryForCount.="booking_date BETWEEN DATE_ADD(CURDATE(), INTERVAL 1-DAYOFWEEK(     CURDATE()) DAY)
                     AND DATE_ADD(CURDATE(), INTERVAL 7-DAYOFWEEK(CURDATE()) DAY)
                        and YEAR( booking_date ) !=0 GROUP BY  label";
                break;
            //this month
            case 5:
                $queryForChart.="MONTH(booking_date) = MONTH(CURDATE())
                        and YEAR( booking_date ) !=0  GROUP BY YEAR( booking_date), label";
                $queryForCount.="MONTH(booking_date) = MONTH(CURDATE())
                        and YEAR( booking_date ) !=0 GROUP BY  label";
                break;


            //lastmonth
            case 6:
                $Lastmonth = date('Y-m-d', strtotime('-30 days'));
                $queryForChart.=" booking_date BETWEEN DATE_FORMAT(NOW() - INTERVAL 1 MONTH, '%Y-%m-01 00:00:00') AND DATE_FORMAT(LAST_DAY(NOW() - INTERVAL 1 MONTH), '%Y-%m-%d 23:59:59')
            and YEAR( booking_date ) !=0  GROUP BY YEAR( booking_date), label";
                $queryForCount.="booking_date BETWEEN DATE_FORMAT(NOW() - INTERVAL 1 MONTH, '%Y-%m-01 00:00:00') AND DATE_FORMAT(LAST_DAY(NOW() - INTERVAL 1 MONTH), '%Y-%m-%d 23:59:59')
            and YEAR( booking_date ) !=0 GROUP BY YEAR( booking_date), label";
                break;
            //daterange    
            case 7:
                $queryForChart.="booking_date 
            BETWEEN '" . $this->_IinputData['from'] . " 00:00:00' AND '" . $this->_IinputData['to'] . " 23:55:55 '
            and YEAR( booking_date ) !=0  GROUP BY YEAR( booking_date), label";
                $queryForCount.="booking_date BETWEEN '" . $this->_IinputData['from'] . " 00:00:00' AND '" . $this->_IinputData['to'] . " 23:55:55 '
             GROUP BY  label";
                break;
            default:
                break;
        }
        $result['total_amount'] = $this->_OcommonDBO->_getResult($queryForChart);
        $result['quantity'] = $this->_OcommonDBO->_getResult($queryForCount);
        $this->_AfinalResponse = json_encode($result);
        return $this->_AfinalResponse;
    }

    /*
     * @Description  function to assign values to twig template
     * @param 
     * @return 
     */

    public function _templateAssign() {
        $this->_AtwigOutputArray['agencyList'] = $this->_AagencyList;
        $this->_AtwigOutputArray['agencyCorporateList'] = $this->_AagencyCorporateList;
    }

}
