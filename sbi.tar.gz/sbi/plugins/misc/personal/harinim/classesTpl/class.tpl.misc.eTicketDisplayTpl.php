<?php
/* * **************************************************************************
 * @File            E ticket display
 * @Description     This class used to e ticket display process
 * @Author          Selvakumar.S
 * @Created Date    12/09/2016
 * @update Date     16/11/2018
 * @update By       Karthika.M
 * ****************************************************************************/
pluginFileRequire('common/', 'interface/commonConstants.php');

//fileRequire('/plugins/misc/corporate/sbi/classes/class.eTicketMail.php');
class eTicketDisplayTpl implements commonConstants{

    public function __construct(){        
        $this->_OpackageDetails = new package();
        $this->_Oeticket = new \eTicketMail();
    }
    
    /* @Function name: _getDisplayInfo
    * @Description: this function is to get E-Ticket details and to assign details to template
    * @param: No param
    * @return: 
    */
    public function _getDisplayInfo(){
        
        fileWrite(print_r($this->_IinputData,1),"eticketInpp","a+");
        
        $input = $this->_IinputData;        
        
        //set inputs
        if(isset($input['contentIdData'])){
            $inputData = explode(":",$input['contentIdData']);
            $input['package_id'] = $inputData[0];
            $input['package_type'] = $inputData[2];
            $input['eticketType'] = $input['eticketType'] ? $input['eticketType'] : $_SESSION['eticketType'];
        }
        
        if(count($input) > 0){
            
            switch ($input['action']){
                case 'htmlGeneration':
                    $this->_AfinalResponse =  $this->_Oeticket->eTicketHtmlGeneration($input);
                    break;
                
                case 'sendEticketMail':
                    $status =  $this->_Oeticket->_sendEticket($input);
                    return $this->_AfinalResponse = $status ? 'success' : FALSE;
                    break;
                //function used to send the mail to pax with respect to the order id.
                case 'mailEticketButton':
                    $this->_AfinalResponse = $this->_Oeticket->_mailEticketToPax($input);
                    break;

                default:
                    //calling function for displaying the eticket.
                    $this->displayEticket($input);
                    
                    break;
            }
        }
    }
    
    //calling the function for getting the eticket info based on package type.
    public function displayEticket($input){
        
        //get order id 
        $input['package_id'] ? $orderId = $this->_OpackageDetails->_getPaidPackageDetails($input['package_id'], '', 'ticketed') : '';
        $input['order_id'] ? $orderId = $this->_OpackageDetails->_getPaidPackageDetails('', '', 'ticketed', $input['order_id']) : '';
        //calling eticket function based on travel mode and package type.
        count($orderId) > 0 ? $this->_Oeticket->_callingEticketFunctionByMode($input,$orderId) :'';
        //template assign function.
        $this->_templateAssign($input);
    }   

    
    /* Function name: _templateAssign
    * @Description  this function assigns the values to be sent to the template view
    * @param |array
    * @return 
    */
    //function used to assign the varible in template.
    public function _templateAssign($input){        

        global $CFG;
        $this->_AtwigOutputArray['eTicketAction'] = $input['package_type'];
        $this->_AtwigOutputArray['eticketInfo'] = $this->_Oeticket->_AEticketDetails;       
        $this->_AtwigOutputArray['orderId'] = $this->_Oeticket->_OorderId;
        $this->_AtwigOutputArray['eticketType'] = 'SBT';
        $this->_AtwigOutputArray['eticketContent'] = $this->_Oeticket->_eticketContent;
        $this->_AtwigOutputArray['buttonStatus'] = 'Y';
        $this->_AtwigOutputArray["BookingReferencePrefixString"]= $this->_Oeticket->_SbookingPrefixSting;  
        $this->_AtwigOutputArray['ltcFare']= $this->_Oeticket->_AltcFareType;
    } 
}
?>