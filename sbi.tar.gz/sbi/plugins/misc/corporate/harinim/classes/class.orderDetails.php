<?php
/************************************************************************
* @Class Name	: OrderDetails
* @Created on	: Aug 29, 2016 (Monday) 20:17:02
* @Created By	: Maliah Rajan M
* @Description	: Common Transaction For Order Details
*
**************************************************************************/
class orderDetails
{
	//common variable
	public $_Oconnection;
	public $_IcountLoop;

	//input data
	public $_IorderId;
	public $_IrTravelModeId;
	public $_StravelPurpose;
	public $_ItotalAmount;
	public $_IrCurrencyTypeId;
	public $_SexpenseBorne;
	public $_SclientName;
	public $_SrPaymentStatusId;
	public $_SrTicketStatusId;
	public $_SapprovalStatus;
	public $_SapprovalLevel;
	public $_ScreatedDate;
	public $_SupdatedDate;
	public $_IsyncOrderId;
	public $_OcommonDbo;

	//output data
	public $_AorderDetails;


	//contructor for the OrderDetails class
	function __construct()
	{
		$this->_Oconnection;
		$this->_IcountLoop=0;
		$this->_IorderId = 0;
		$this->_IrTravelModeId = 0;
		$this->_StravelPurpose = '';
		$this->_ItotalAmount = 0;
		$this->_IrCurrencyTypeId = 0;
		$this->_SexpenseBorne = '';
		$this->_SclientName = '';
		$this->_SrPaymentStatusId = '';
		$this->_SrTicketStatusId = '';
		$this->_SapprovalStatus = '';
		$this->_SapprovalLevel = '';
		$this->_ScreatedDate = '';
		$this->_SupdatedDate = '';
		$this->_IsyncOrderId = 0;
		$this->_AorderDetails=array();
		$this->_OcommonDbo = new commonDBO();
	}
	
	//insert the details into OrderDetails table
	public function _insertOrderDetails()
	{
		
		$sql = "INSERT INTO order_details
				(
					order_id,
					r_travel_mode_id,
					travel_purpose,
					total_amount,
					r_currency_type_id,
					expense_borne,
					client_name,
					r_payment_status_id,
					r_ticket_status_id,
					approval_status,
					approval_level,
					created_date,
					updated_date,
					sync_order_id
				)
				VALUES
				(
					'".$this->_IorderId."',
					'".$this->_IrTravelModeId."',
					'".$this->_StravelPurpose."',
					'".$this->_ItotalAmount."',
					'".$this->_IrCurrencyTypeId."',
					'".$this->_SexpenseBorne."',
					'".$this->_SclientName."',
					'".$this->_SrPaymentStatusId."',
					'".$this->_SrTicketStatusId."',
					'".$this->_SapprovalStatus."',
					'".$this->_SapprovalLevel."',
					'".$this->_ScreatedDate."',
					'".$this->_SupdatedDate."',
					'".$this->_IsyncOrderId."'
				) ";
				
		$_Aresult = $this->_OcommonDbo->_getResult($sql);
		return $_Aresult;
	}

	//get the details from OrderDetails table
	public function _selectOrderDetails()
	{
		
		$sql = "SELECT
					order_id,
					r_travel_mode_id,
					travel_purpose,
					total_amount,
					r_currency_type_id,
					expense_borne,
					client_name,
					r_payment_status_id,
					r_ticket_status_id,
					approval_status,
					approval_level,
					created_date,
					updated_date,
					sync_order_id
				FROM
					order_details
				WHERE 1 ";
		$condition = " AND ";
		if($this->_IorderId != 0)
		{
			$sql = $sql.$condition." order_id = '".$this->_IorderId."' ";
		}
		if($this->_IrTravelModeId != 0)
		{
			$sql = $sql.$condition." r_travel_mode_id = '".$this->_IrTravelModeId."' ";
		}
		if($this->_StravelPurpose != '')
		{
			$sql = $sql.$condition." travel_purpose = '".$this->_StravelPurpose."' ";
		}
		if($this->_ItotalAmount != 0)
		{
			$sql = $sql.$condition." total_amount = '".$this->_ItotalAmount."' ";
		}
		if($this->_IrCurrencyTypeId != 0)
		{
			$sql = $sql.$condition." r_currency_type_id = '".$this->_IrCurrencyTypeId."' ";
		}
		if($this->_SexpenseBorne != '')
		{
			$sql = $sql.$condition." expense_borne = '".$this->_SexpenseBorne."' ";
		}
		if($this->_SclientName != '')
		{
			$sql = $sql.$condition." client_name = '".$this->_SclientName."' ";
		}
		if($this->_SrPaymentStatusId != '')
		{
			$sql = $sql.$condition." r_payment_status_id = '".$this->_SrPaymentStatusId."' ";
		}
		if($this->_SrTicketStatusId != '')
		{
			$sql = $sql.$condition." r_ticket_status_id = '".$this->_SrTicketStatusId."' ";
		}
		if($this->_SapprovalStatus != '')
		{
			$sql = $sql.$condition." approval_status = '".$this->_SapprovalStatus."' ";
		}
		if($this->_SapprovalLevel != '')
		{
			$sql = $sql.$condition." approval_level = '".$this->_SapprovalLevel."' ";
		}
		if($this->_ScreatedDate != '')
		{
			$sql = $sql.$condition." created_date = '".$this->_ScreatedDate."' ";
		}
		if($this->_SupdatedDate != '')
		{
			$sql = $sql.$condition." updated_date = '".$this->_SupdatedDate."' ";
		}
		if($this->_IsyncOrderId != 0)
		{
			$sql = $sql.$condition." sync_order_id = '".$this->_IsyncOrderId."' ";
		}

		$_Aresult = $this->_OcommonDbo->_getResult($sql);
		return $_Aresult;
	}

	//change the details in OrderDetails table
	public function _updateOrderDetails()
	{
		
		$sql = " UPDATE order_details
		        SET ";
		$comma = "  ";

		if($this->_IrTravelModeId != 0)
		{
			$sql = $sql.$comma." r_travel_mode_id = '".$this->_IrTravelModeId."' ";
			$comma = " , ";
		}
		if($this->_StravelPurpose != '')
		{
			$sql = $sql.$comma." travel_purpose = '".$this->_StravelPurpose."' ";
			$comma = " , ";
		}
		if($this->_ItotalAmount != 0)
		{
			$sql = $sql.$comma." total_amount = '".$this->_ItotalAmount."' ";
			$comma = " , ";
		}
		if($this->_IrCurrencyTypeId != 0)
		{
			$sql = $sql.$comma." r_currency_type_id = '".$this->_IrCurrencyTypeId."' ";
			$comma = " , ";
		}
		if($this->_SexpenseBorne != '')
		{
			$sql = $sql.$comma." expense_borne = '".$this->_SexpenseBorne."' ";
			$comma = " , ";
		}
		if($this->_SclientName != '')
		{
			$sql = $sql.$comma." client_name = '".$this->_SclientName."' ";
			$comma = " , ";
		}
		if($this->_SrPaymentStatusId != '')
		{
			$sql = $sql.$comma." r_payment_status_id = '".$this->_SrPaymentStatusId."' ";
			$comma = " , ";
		}
		if($this->_SrTicketStatusId != '')
		{
			$sql = $sql.$comma." r_ticket_status_id = '".$this->_SrTicketStatusId."' ";
			$comma = " , ";
		}
		if($this->_SapprovalStatus != '')
		{
			$sql = $sql.$comma." approval_status = '".$this->_SapprovalStatus."' ";
			$comma = " , ";
		}
		if($this->_SapprovalLevel != '')
		{
			$sql = $sql.$comma." approval_level = '".$this->_SapprovalLevel."' ";
			$comma = " , ";
		}
		if($this->_ScreatedDate != '')
		{
			$sql = $sql.$comma." created_date = '".$this->_ScreatedDate."' ";
			$comma = " , ";
		}
		if($this->_SupdatedDate != '')
		{
			$sql = $sql.$comma." updated_date = '".$this->_SupdatedDate."' ";
			$comma = " , ";
		}
		if($this->_IsyncOrderId != 0)
		{
			$sql = $sql.$comma." sync_order_id = '".$this->_IsyncOrderId."' ";
			$comma = " , ";
		}
		$sql = $sql." WHERE  ";
		
		$condition = " ";
		if($this->_IorderId != 0)
		{
			$sql = $sql.$condition." order_id = '".$this->_IorderId."' ";
			$condition = " AND ";
		}
		
		if($this->_IsyncOrderId != 0)
		{
			$sql = $sql.$condition." sync_order_id = '".$this->_IsyncOrderId."' ";
			$condition = " AND ";
		}

		$_Aresult = $this->_OcommonDbo->_getResult($sql);

		return $_Aresult;
	}
	
	//delete the details in OrderDetails table
	public function _deleteOrderDetails()
	{
		
		$sql = " DELETE FROM
					order_details
				WHERE ";
		$condition = "  ";
		if($this->_IorderId != 0)
		{
			$sql = $sql.$condition." order_id = '".$this->_IorderId."' ";
			$condition = " AND ";
		}
		if($this->_IrTravelModeId != 0)
		{
			$sql = $sql.$condition." r_travel_mode_id = '".$this->_IrTravelModeId."' ";
			$condition = " AND ";
		}
		if($this->_StravelPurpose != '')
		{
			$sql = $sql.$condition." travel_purpose = '".$this->_StravelPurpose."' ";
			$condition = " AND ";
		}
		if($this->_ItotalAmount != 0)
		{
			$sql = $sql.$condition." total_amount = '".$this->_ItotalAmount."' ";
			$condition = " AND ";
		}
		if($this->_IrCurrencyTypeId != 0)
		{
			$sql = $sql.$condition." r_currency_type_id = '".$this->_IrCurrencyTypeId."' ";
			$condition = " AND ";
		}
		if($this->_SexpenseBorne != '')
		{
			$sql = $sql.$condition." expense_borne = '".$this->_SexpenseBorne."' ";
			$condition = " AND ";
		}
		if($this->_SclientName != '')
		{
			$sql = $sql.$condition." client_name = '".$this->_SclientName."' ";
			$condition = " AND ";
		}
		if($this->_SrPaymentStatusId != '')
		{
			$sql = $sql.$condition." r_payment_status_id = '".$this->_SrPaymentStatusId."' ";
			$condition = " AND ";
		}
		if($this->_SrTicketStatusId != '')
		{
			$sql = $sql.$condition." r_ticket_status_id = '".$this->_SrTicketStatusId."' ";
			$condition = " AND ";
		}
		if($this->_SapprovalStatus != '')
		{
			$sql = $sql.$condition." approval_status = '".$this->_SapprovalStatus."' ";
			$condition = " AND ";
		}
		if($this->_SapprovalLevel != '')
		{
			$sql = $sql.$condition." approval_level = '".$this->_SapprovalLevel."' ";
			$condition = " AND ";
		}
		if($this->_ScreatedDate != '')
		{
			$sql = $sql.$condition." created_date = '".$this->_ScreatedDate."' ";
			$condition = " AND ";
		}
		if($this->_SupdatedDate != '')
		{
			$sql = $sql.$condition." updated_date = '".$this->_SupdatedDate."' ";
			$condition = " AND ";
		}
		if($this->_IsyncOrderId != 0)
		{
			$sql = $sql.$condition." sync_order_id = '".$this->_IsyncOrderId."' ";
			$condition = " AND ";
		}

		$_Aresult = $this->_OcommonDbo->_getResult($sql);
		return $_Aresult;
	}
	
}
?>
