
<?php

/* * **************************************************************************
 * @File             : class.manageModuleClass.php
 * @Description      : This file is used to handle queries which is used to manage momdules
 * @Author           : Sri muthu rajesh
 * @Created Date     : 01/08/2017
 * @Modified Date     : 
 * *************************************************************************** */
fileRequire('classes/class.commonDBO.php');

class manageModuleClass {
    private $_OcommonDBO;

    public function __construct() {
         $this->_OcommonDBO = new commonDBO();
         }

    /**
     * @Description :This function is used to insert the package details 
     * @param :array   | $packageDetails - holds array of package details
     * @return integer |$resultPackageId - inserted package id
     */

    public function _checkModule($moduleName) {

        $tableName = 'core_module_details';
        $fields = 'module_id';
        $where = 'module_name';
        $value = $moduleName;
        $result = $this->_OcommonDBO->_select($tableName, $fields, $where, $value);
        return $result;
    }
    
    /**
     * @Description :This function is used to insert the package details 
     * @param :array   | $packageDetails - holds array of package details
     * @return integer |$resultPackageId - inserted package id
     */
    public function _getTravelTypeFolder(){
        return array_diff(scandir('../plugins'), array('.', '..'));
    }
    public function _getPluginFolder($data){
        $folder = '../plugins';
        foreach($data as $folderData ){
            $folder .= '/'.$folderData;
        }
        filewrite(print_r($data,1),'folder');
        return array_diff(scandir($folder), array('.', '..'));
    }
    public function _getViewTypeFolder(){
        return array_diff(scandir('../view'), array('.', '..'));
    }
    public function _getViewFolder($data){
        $folder = '../view';
        foreach($data as $folderData ){
            $folder .= '/'.$folderData;
        }
        return array_diff(scandir($folder), array('.', '..'));
    }
    public function _getModuleList(){
        $tabeName = '_module_details';
        $fieldscore = '*';
        $result = $this->_OcommonDBO->_select($tableName, $fieldscore);
        filewrite($result,'query','a+');
        return $result;
    }
    
    /**
     * @Description :This function is used to insert the package details 
     * @param :array   | $packageDetails - holds array of package details
     * @return integer |$resultPackageId - inserted package id
     */
    public function _getBookingTypeFolder($travelType){
        return array_diff(scandir('../plugins/'.$travelType), array('.', '..'));
    }
    public function _getCorporateFolder($travelType,$bookingType){
        return array_diff(scandir('../plugins/'.$travelType.'/'.$bookingType), array('.', '..'));
    }
    public function _getClassTplFiles($travelType,$bookingType,$corporate){
         return array_diff(scandir('../plugins/'.$travelType.'/'.$bookingType.'/'.$corporate.'/classesTpl'), array('.', '..'));
    }
    function _moduleinsert($moduleName){
	//$objDataBase = new dataBase;
	//$objDataBase->dataBaseConnection();
        //$objDataBase   = dataBase::_createDBO();
        //$_Oconnection  = $objDataBase->_Oconnection;
	
        $tableName = 'core_module_details';
        $fields = 'module_id';
        $where = 'module_name';
        $value = $moduleName;
        $result = $this->_OcommonDBO->_select($tableName, $fields, $where, $value);
            if(!$result){
                $insertResult = $this->_OcommonDBO->_insert("core_module_details",array('module_name'=>$moduleName));
                if(!$insertResult)
                {
			fileWrite($moduleInsert,"SqlError","a+");
		} 
                return $insertResult;
            }
	}
    		
    
    public function _templateInsert($templateName,$className,$templateType){
        //$objDataBase = new dataBase;
	//$objDataBase->dataBaseConnection();
	$tableName = 'core_template_details';
        $fields = 'template_id';
        $where = array('template_name','class_tpl_name','template_type');
        $value = array($templateName,$className,$templateType);
        $result = $this->_OcommonDBO->_select($tableName, $fields, $where, $value);
        
        if(!$result)
	{       $insertValues=array('template_name' =>$templateName,'class_tpl_name' => $className,'template_type' => $templateType);
		$templateInsertResult = $this->_OcommonDBO->_insert("core_template_details",$insertValues);
                if(!$templateInsertResult)
                {
			fileWrite($templateInsert,"SqlErrors","a+");
		} 	
		return $templateInsertResult;
	}
    }
  
    function _mappSetting($groupId,$moduleId,$templateId,$displayOrder,$displayStatus,$stdTplId){
        //$objDataBase = new dataBase;
        //$objDataBase->dataBaseConnection();

        $tableName = 'core_module_group_mapping';
        $fields = 'module_group_id';
        $where = array('group_id','module_id','template_id','dispay_status');
        $value = array($groupId,$moduleId,$templateId,$displayStatus);
        $result = $this->_OcommonDBO->_select($tableName, $fields, $where, $value);
        if(!$result)
        {   
            $insertValues=array('group_id' =>$groupId,'module_id' => $moduleId,'template_id' => $templateId,'display_order' => $displayOrder, 'display_name' => $displayStatus);
            $moduleGroupMappingInsertResult = $this->_OcommonDBO->_insert('core_module_group_mapping',$insertValues);
                if(!$moduleGroupMappingInsertResult){
                    fileWrite($templateInsert,"SqlErrors","a+");
                } else{ 	
                $moduleGroupId = $moduleGroupMappingInsertResult;
                $coreModuleGroupMappingupdateResult = $this->_OcommonDBO->_update('core_module_group_mapping', array('display_order' => $displayOrder), 'module_group_id', $moduleGroupId);
                    if(!$coreModuleGroupMappingupdateResult)
                    {
                        fileWrite($sqlUpdate,"SqlErrors","a+");
                    } 						
                }
        $tableName = 'core_module_group_stdtpl_mapping';
        $fields = 'group_id';
        $where = array('group_id','module_id','std_tpl_id','class_name');
        $value = array($groupId,$moduleId,$stdTplId,'content12px');
        $result = $this->_OcommonDBO->_select($tableName, $fields, $where, $value);
        if(!$result)
        {   $insertValues=array('module_id' =>$moduleId,'std_tpl_id' => $stdTplId,'group_id' => $groupId,'class_name' => 'content12px');
            $corestdtplmappingInsertResult = $this->_OcommonDBO->_insert("core_module_group_stdtpl_mapping",$insertValues);
                if(!$corestdtplmappingInsertResult)
                {
                    fileWrite($stdTplInsert,"SqlErrors","a+");
                }
            } 
        }
        return $corestdtplmappingInsertResult;
    }		
}
?>