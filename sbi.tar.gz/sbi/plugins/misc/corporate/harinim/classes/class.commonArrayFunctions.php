<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class commonArrayFunctions{
    /**
     * @description: Method to return the key value pair in mulitidimension array based on the key names
     * @example : 
     *          array_column($array,$keyIndexName,$valueIndexName)
     * @return array
     */
    public function _getMultiDimenKeyValues($array,$key,$value){
       return array_column($array,$value,$key);
    }
    
    /*
     * @Description : Method to return the key value pair in mulitidimension array based on the key names
     * @Param     : array_column($array,$keyIndexName)
     * @Return      : array with index and value
     */
    public function _getArrayKeyValue($array,$key)
    {
       return array_column($array,$key);
    }

    /*
     * @functionName        :   _getArrayDiffValues
     * @description         :   To remove the unwanted key value in array
     * @param               :   $inputArray|input - array which has to be filtered with combining the second param array
     * @param               :   $unwantedKeyArray|arrayFields - array of indexes to be differed from the inpurtArray
     * @return              :   Array which contains filtered unwanted key and values
     */
    public function _getArrayDiffValues($inputArray , $unwantedKeyArray){
        return array_diff($inputArray, $unwantedKeyArray);
    }
    /*
     * @functionName        :   _getCurrentDateAndTime
     * @description         :   To get current date and time
     * @param               :   based on user defined date format like 'Y-m-d H:i:s'
     * @return              :   current date and time
     */
    public function _getCurrentDateAndTime($dateFormat = COMMON_SQL_DATE_FORMAT){
        return date($dateFormat);
    }    
    
    /*
     * @functionName        :   _formatInputArray
     * @description         :   To get only required fields from and existing array
     * @param               :   array|input - array which has to be filtered
     * @param               :   array|arrayFields - array of indexes required from input array; 
     *                          key is the key to be matched in input array, value is the key for new array
     */
    public function _formatInputArray($input, $arrayFields) {
        
        $result = array();
        
        //preparing array with values
        foreach( $arrayFields as $fieldKey => $fieldValue) {
            $result[$fieldValue] = $input[$fieldKey];
        }
        
        return $result;
    }
    /**
     * @Description : Method to return the key value pair in mulitidimension array based on the key names
     * @Param     :
     * 
     * example array
     * 
     *    $input_array1 = array( 
       "0"=>array('aggregate_id'=>2,'employee_id'=>3,'employee_name'=>'Mr. Uday Kotak'),
       "1"=>array('aggregate_id'=>2,'employee_id'=>8,'employee_name'=>'Mr. Aakash Aggarwal'),
       "2"=>array('aggregate_id'=>2,'employee_id'=>16,'employee_name'=>'Mr. A Rajish'));
     * 
     * 
     *    $input_array2 = array( 
       '0' => Array ('aggregate_id'=>2,'employee_id' => 2,'employee_name' => 'Mr. Corporate Admin'),
    '1' => Array('aggregate_id'=>2,'employee_id' => 3,'employee_name' => 'Mr. Uday Kotak'),
    '2' => Array('aggregate_id'=>2,'employee_id' => 4,'employee_name' =>' Mr. Infiniti Developer'),
    '3' => Array('aggregate_id'=>2,'employee_id' => 5,'employee_name' => 'Mr. test ayprc'),
    '4' => Array('aggregate_id'=>2,'employee_id' => 6,'employee_name' => 'Mr. Anant Sahasrabuddhe'),
    '5' => Array('aggregate_id'=>2,'employee_id' => 8,'employee_name' => 'Mr. Aakash Aggarwal'),
    '6' => Array('aggregate_id'=>2,'employee_id' => 9,'employee_name' => 'Ms. Aakanksha Kundra'),
    '7' => Array('aggregate_id'=>2,'employee_id' => 10,'employee_name' => 'Mr. Aaftab khan'),
    '8' => Array('aggregate_id'=>2,'employee_id' => 16,'employee_name' => 'Mr. A Rajish'));
     * 
     * @author : sivaprakash
     * 
     */
    public function _getArrayDiffValuesOfAssociativeArray($input_array1,$input_array2)
    {
       return   array_map("unserialize",array_diff(array_map("serialize", $input_array2),array_map("serialize", $input_array1)));
    }    
    /*
     * @functionName        :   _strReplace
     * @description         :   To replace string with comparing string
     * @param               :   $compareString, $replaceString, $string
     * @return              :   string with replaced
     */
    public function _strReplace($compareString, $replaceString, $string){
        return str_replace($compareString, $replaceString, $string);
    }
    public function _arrayFlatten($array,$return) {
        
        foreach($array as $x => $value) {
		if(is_array($array[$x])) {
			$return = $this->_arrayFlatten($array[$x], $return);
		}
		else {
			if(isset($array[$x])) {
				$return[] = $array[$x];
			}
		}
	}
	return $return;
    }
    
    /*
     * @Description  This method returns unique array
     * @param array|$array as input
     * @return array|$uniqueArray
     * @date|10.05.2017 
     * @author|Sathees,Karthika.M
     * sample Array: 
     * Array
        (
            [0] => Array
                (
                    [r_employee_id] => 1958
                    [first_name] => Fleming
                )

            [1] => Array
                (
                    [r_employee_id] => 261
                    [first_name] => Infiniti
                )

            [2] => Array
                (
                    [r_employee_id] => 1958
                    [first_name] => Fleming
                )

        ) 
     * 
     */    
    
    public function _arrayUniqueInBasedOnValue($array,$arrayKey){        
        $arrcol = array_column($array,$arrayKey);
        $arruni = array_unique($arrcol);
        foreach($array as $key=>$value)
        {
            if(isset($arruni[$key]))
            {
             $arrorg[] = $array[$key];
            }
        } 
        return $arrorg;
    }
    /**
     * used to check word present in string and replace it by other given string
     * @param type $value strint
     * @param type $checkWord string
     * @param type $replaceWord string
     * @return type string
     * @author sivaprakash
     */
    public function _checkWordPresentInString(&$value, $checkWord, $replaceWord) {
        // if given word matches the in string replace word or return the same value
        return preg_match('/'.$checkWord.'/', $value) ? $value = $replaceWord : $value;
    }    
    /**
     * used to get the array unique values
     * @param type $arrayData
     * @return type array of unique values
     * @author sivaprakash
     * input array
     * 
        [0] => Array
            (
                [email_id] => senthil@atyourprice.in
            )
        [1] => Array
            (
                [email_id] => senthil@atyourprice.in
            )
        [2] => Array
            (
                [email_id] => senthilnathan@ghumo.com
            )
        [3] => Array
            (
                [email_id] => senthilnathan@ghumo.com
            )
        [4] => Array
            (
                [email_id] => karthik.vn@infinitisoftware.net
            )
        [5] => Array
            (
                [email_id] => ganesamoorthi@infinitisoftware.net
            )
     * 
     * output 
     *  [0] => Array
            (
                [email_id] => senthil@atyourprice.in
            )
        [2] => Array
            (
                [email_id] => senthilnathan@ghumo.com
            )
        [4] => Array
            (
                [email_id] => karthik.vn@infinitisoftware.net
            )
        [5] => Array
            (
                [email_id] => ganesamoorthi@infinitisoftware.net
            )
     */
    public function _getArrayUniqueData($arrayData) {
        // if the given array count is not empty return the array unique data or boolean false
        return (count($arrayData) > 0) ? array_map("unserialize", array_unique(array_map("serialize", $arrayData))) : FALSE;
    }
    /**
     * used to search and get the last word  of the string
     * @param string $string
     * @param string $searchWord
     * @return (string or boolean)
     * @author sivaprakash
     * input string example
     * 
     *      dmp.package_id=272793  AND od.r_travel_mode_id = 1 AND 
     * 
     * the last word to be fing is AND it returns the last word as searched from the string
     * 
     *  output as AND
     * 
     * if the string is passed in between the word as AND last word is not and
     * 
     * dmp.package_id=272793  AND od.r_travel_mode_id = 1
     * 
     *   output as  AND od.r_travel_mode_id = 1
     * 
     * as the search AND word starts from the position to the end
     */
    public function _getTheLastWordFromString($string, $searchWord) {
        //check hte param is not empty if empty return false if not empty return search result
        return (!empty($string) && !empty($searchWord)) ? strrchr($string, $searchWord) : FALSE;
    }

     /**
     * used to format the array in same key with respective array value
     * @param array $inputArray
     * @return array
     * @author sivaprakash
     */
    public static function _formatSameArrayValueInArrayKey($inputArray) {
        $formatArray = array();
        foreach ($inputArray as $key => $value){
            $formatArray[] = $value;
        }
        return $formatArray;
    }
}
?>
