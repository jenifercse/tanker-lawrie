<?php

/** 
 * @description - Class file holds different fee type based calcultions
 * Created By : JK Thirumal
 * Created Date : 31/10/2016
 */
class feeCalculation{
    
    public $_AallowedFeeTypes=array();
    public $_IsysUsageFee =0;
    public $_IdiscountFee=0;
    public $_ItransactionFee=0;
                
    
    
    public function __construct() {
        
        $this->_AallowedFeeTypes = explode(",", ALLOWED_AGENT_FEES_CALCULATION);
    }
    
    public function _doAirFeeCalc($agentFeeDetailsArray,$segmentCount,$transDetails){
        
        if(is_array($agentFeeDetailsArray)){
            
            foreach ($agentFeeDetailsArray as $agentFeeValue){
                
                switch($agentFeeValue['agent_fee_name']){
                    
                    case 'transactionFee':
                        $this->_ItransactionFee= $this->_calTransactionFee($agentFeeValue,$segmentCount,$transDetails);
                        break;
                    
                    case 'discountAmount':
                        $this->_IdiscountFee= $this->_calDiscountFee($agentFeeValue,$segmentCount,$transDetails);
                        break;
                    
                    case 'systemUsageFee';
                        $this->_IsysUsageFee= $this->_calSystemUsageFee($agentFeeValue);
                        break;
                    
                    default:
                        break;
                }
            }
        }        
    }
    /**
     * @description : Method to calculate the transaction fee
     */
    public function _calTransactionFee($agentFeeDetailsArray,$segmentCount,$transDetails){
        /* agent_fee_type = 'P' => percentage calculation / 'V' => 'Absolute values calcuation'
          calc_based_on = TB => on total base fare / TT => on tax amount / AB - base fare + tax amount
          types of agent fees (transactionFee / discountAmount / systemUsageFee / CancellationFee)
          segment calculation will be based on each airline - via_flight_details.r_airline_id or each flight number */
                    
        $agentFeeType = $agentFeeDetailsArray['fee_type'];
        $calcBasedOn = $agentFeeDetailsArray['calc_based_on'];
        $transFee = $agentFeeDetailsArray['fee_value'];
        $passCount = $transDetails['passCount'];
        $calcTransFee = 0;
        $personalTax=PERSONAL_TRANSACTION_BOOKING_FEE;
                    
        if (in_array($agentFeeDetailsArray['agent_fee_name'], $this->_AallowedFeeTypes)) { // check for transaction fee calculation allowed or not

            if ($agentFeeType == 'P') { //Percentage based calcuation

                if ($calcBasedOn == 'TB' || $calcBasedOn == 'BY') { //on total base fare 

                    $calcTransFee = $this->_calcFeeByType(1,$transFee,$transDetails);

                } elseif ($calcBasedOn == 'TT') { // on tax amount

                    $calcTransFee = $this->_calcFeeByType(2,$transFee,$transDetails);

                } elseif ($calcBasedOn == 'AB') { //on basefare+tax amount

                   $calcTransFee = $this->_calcFeeByType(3,$transFee,$transDetails);
                }
                
            } else { //absolute calcuation
                
                if ($calcBasedOn == 'TB'){

                    $calcTransFee = floatval($transFee)*floatval($passCount);
            
                }elseif($calcBasedOn == 'AB'){

                    $calcTransFee = floatval($transFee)*floatval($segmentCount);

                }elseif($calcBasedOn == 'SP'){

                    $calcTransFee = floatval($transFee)*floatval($segmentCount)*floatval($passCount);
                }
            }
        } 
        
        return round(floatval($calcTransFee)+floatval($personalTax));
            
    }
    /**
     * @description : Method to calculate the discount fee
     */
    public function _calDiscountFee($agentFeeDetailsArray,$segmentCount,$transDetails){
        
        $discountFare = 0;
                    
        if (in_array($agentFeeDetailsArray['agent_fee_name'], $this->_AallowedFeeTypes)) {  // check for transaction fee calculation allowed or not

           $dicountFeeType = $agentFeeDetailsArray['fee_type'];//P
           $discountBasedOn = $agentFeeDetailsArray['calc_based_on'];//TT
           $discountFee = $agentFeeDetailsArray['fee_value'];
           $passCount = $transDetails['passCount']; 

            if($dicountFeeType=='P'){ //Percentage based calcuation

                if($discountBasedOn=='TB' || $discountBasedOn='BY'){ //on total base fare || by fuel charge

                   $discountFare = $this->_calcFeeByType(1,$discountFee,$transDetails);

                }elseif($discountBasedOn=='TT'){ //on tax amount

                   $discountFare = $this->_calcFeeByType(2,$discountFee,$transDetails);

                }elseif($discountBasedOn=='AB'){ //on basefare+tax amount

                    $discountFare = $this->_calcFeeByType(3,$discountFee,$transDetails);
                }
               
           }else{ 

                if($transDetails['travelType']!='IN'){
                    
                    if($discountBasedOn=='TB'){
                       
                       $discountFare = floatval($discountFee)*floatval($passCount);
                       
                    }elseif($discountBasedOn=='AB'){
                       
                       $discountFare = floatval($discountFee)*floatval($segmentCount);
                       
                    }elseif($discountBasedOn=='SP'){
                       
                       $discountFare = floatval($discountFee)*floatval($segmentCount)*floatval($passCount);
                    }
                    
                }else{
                   
                    if($discountBasedOn=='TB'){
                       
                       $discountFare = floatval($discountFee);
                       
                    }elseif($discountBasedOn=='TT'){
                       
                       $discountFare = floatval($discountFee)/floatval($passCount);
                       
                    }elseif($discountBasedOn=='AB'){
                       
                       $discountFare = floatval($discountFee);
                    }
               }
            }
                    
        }
        return round(floatval($discountFare));
    }
    /**
     * @description : Method to calculate the system usage fee
     */
    public function _calSystemUsageFee($systemUsageArray){
                    
        if($systemUsageArray['fee_value']!=''){
            return round(floatval($systemUsageArray['fee_value']));
        }else{
            return 0;
        }
    }
    
    public function _calcFeeByType($calcType,$fee,$transDetails=array()){
        
        $calcFare=0;
        
        switch($calcType){
            
            case '1'://Fee calculation from basefare
                
                    $calcFare = (floatval($transDetails['onwBaseFare'])*floatval($fee))/100;
            
                    if($transDetails['tripType']==1){

                        $calcFare += floatval((floatval($transDetails['retBaseFare'])*floatval($fee))/100);
                    }
            
                break;
                
            case '2'://Fee calculation from tax
            
                    $calcFare = (floatval($transDetails['onwTaxFare'])*floatval($fee))/100;
                
                    if($transDetails['tripType']==1){
                        
                       $calcFare += floatval((floatval($transDetails['retTaxFare'])*floatval($fee))/100);
                       
                    }
                    
                break;
                
            case '3'://Fee calculation from basefare + tax
                    $calcFare = floatval(((floatval($transDetails['onwBaseFare'])+floatval($transDetails['onwTaxFare']))*floatval($fee))/100);
                
                    if($transDetails['tripType']==1){
                        
                        $calcFare += floatval(((floatval($transDetails['retBaseFare'])+floatval($transDetails['retTaxFare']))*floatval($fee))/100);
                    }
            
                break;
            
            default:
                break;
            
        }
            
        return round($calcFare);
    }
    /**
     * @description : Method to flush the fare details
     */
    public function _flushFareData(){
        $this->_ItransactionFee=0;  
        $this->_IdiscountFee=0;
        $this->_IsysUsageFee=0;
    }
}
?>