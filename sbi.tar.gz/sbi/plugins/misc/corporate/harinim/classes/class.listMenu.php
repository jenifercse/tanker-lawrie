<?php
/* * **********************************************************************
 * @Class Name      :   class.listMenu.php
 * @Description     :   This file is used create menu json from db and create json file
 * @Author          :   Taslim
 * @Created Date    :   08-08-2016
 * @Modified Date   :   25-01-2018
 * @Modified By     :   Taslim
 * ************************************************************************ */
fileRequire('lib/common/commonMethods.php');
fileRequire('classes/class.customtwig.php');
pluginFileRequire('admin/corporate/harinim/', "classes/class.applicationSettings.php");
require_once("lib/system/authToken.php");

class listMenu {

    public function __construct() {
        $this->db = new commonDBO();
        $this->_OapplicationSettings = new applicationSettings();
    }

    /*
     * @functionName    :   _getMenuDetails()
     * @description     :   get menu for the user group
     * @params          :   int|$groupId
     * @returnType      :   array|$result
     */

    public function _getMenuDetails($groupId) {

        $result = false;
        
        $cond .= $this->_constructTravelModeQuery();

        if (isset($groupId) && $groupId != '') {

            $sql = "SELECT md.menu_id, CONCAT('/', md.routing_name) as name, CONCAT('/', md.routing_name) as url, 
                    'controller/route.php' as template, md.routing_name as modulename,  md.controller_name
                    FROM core_menu_details md 
                    INNER JOIN core_menu_mapping_details mmd ON (md.menu_id = mmd.parent_id OR md.menu_id = mmd.child_id)
                    WHERE mmd.group_id = " . $groupId . " AND  md.menu_status = 'Y' AND md.routing_name !='' AND mmd.project_code = " . MENU_PROJECT_CODE . " 
                    " . $cond . "
                    GROUP BY md.menu_id
                    ORDER BY mmd.display_order asc";
            
            $result = $this->db->_getResult($sql);
        }

        return $result;
    }

    /*
     * @description     :   create state menu filke
     * @params          :   array|$menuListArray
     * @params          :   int|$groupId
     * @returnType      :   array|$returnValue
     */

    public function _createStateFile($menuListArray, $groupId) {
        $_OauthToken = new authToken();
        $menuList = "var stateData_" . $groupId . "=";
        $menuList .= (is_array($menuListArray) ? json_encode($menuListArray) : $menuListArray);

        $filename = $_OauthToken->_purifyInputData(APPLICATION_BASE_PATH . 'lib/script/angular/config/'.INDEXNAME.'/staterouter_' . $groupId . '.js');
        
        if (!file_exists($filename)){
            $returnValue = file_put_contents($filename,$menuList);
        } else {
            $returnValue = true;
        }
        $returnValue = file_put_contents($filename,$menuList);
        return $returnValue;
    }

    /*
     * @description : get the menu details info
     * @return array|$result
     */

    public function _getMenuDetailsInfo() {

        $sql = "SELECT * from core_menu_details";

        $result = $this->db->_getResult($sql);
        if ($result != "") {
            return $result;
        }
    }

    /*
     * @description : get the menu Name by passing menu id
     * @param : int|menuId
     * @return array|$result
     */

    public function _getMenuName($menuId) {

        $sql = "SELECT menu_name FROM core_menu_details WHERE menu_id =" . $menuId;

        $result = $this->db->_getResult($sql);
        if ($result != "") {
            return $result;
        }
    }

    /*
     * @description : get the menu Mapping details.
     * @param : 
     * @return array|$menuInfo
     */

    public function _getMenuMappingDetails() {
        $sql = "SELECT 
                    cmp.menu_mapping_id, 
                    cmd.menu_name, 
                    cmp.parent_id, 
                    cmp.child_id, 
                    cmp.display_order, 
                    cmp.display_status, 
                    cmp.group_id, 
                    cmp.corporate_id
                FROM 
                    core_menu_mapping_details cmp
                    INNER JOIN core_menu_details cmd ON cmp.parent_id = cmd.menu_id";


        $result = $this->db->_getResult($sql);
        if ($result != "") {
            foreach ($result as $data) {
                if ($data['parent_id'] != "") {
                    $parentMenuName = $this->_getMenuName($data['parent_id']);
                    $data['parent_idName'] = $parentMenuName[0]['menu_name'];
                }

                if ($data['child_id'] != "") {
                    $childMenuName = $this->_getMenuName($data['child_id']);
                    $data['child_idName'] = $childMenuName[0]['menu_name'];
                }

                $menuInfo[] = $data;
            }
            return $menuInfo;
        }
    }

    /*
     * @description : get the module mapping list
     * @param : 
     * @return array|$moduleInfo
     */

    public function _getModuleMappingList($moduleGroupId = 0) {
        $sql = " SELECT DISTINCT
                    cmgm.module_group_id,
                    cmgm.group_id,
                    cmgm.module_id,
                    cmgm.template_id,
                    cmgm.display_order,
                    cmgm.display_status,
                    cmd.module_name,
                    ctd.template_name,
                    ctd.class_tpl_name,
                    ctd.template_type,
                    mgsm.std_tpl_id,
                    cstd.std_tpl_name
                    
                FROM
                    core_module_group_mapping cmgm
                    LEFT JOIN core_module_details cmd ON cmd.module_id = cmgm.module_id
                    LEFT JOIN core_template_details ctd ON ctd.template_id = cmgm.template_id
                    LEFT JOIN core_module_group_stdtpl_mapping mgsm ON mgsm.module_id = cmgm.module_id
                    LEFT JOIN core_std_tpl_details cstd ON cstd.std_tpl_id = mgsm.std_tpl_id";
        if ($moduleGroupId != 0) {
            $sql = $sql . " WHERE cmgm.module_group_id = " . $moduleGroupId;
        }

        $result = $this->db->_getResult($sql);
        if ($result != "") {
            foreach ($result as $value) {
                // get user type name
                if ($value['group_id'] != "") {
                    $userTypeArray = array('user_type_name');
                    $userTypeName = $this->db->_select('dm_user_type', $userTypeArray, 'group_id', $value['group_id']);
                    $value['user_type_name'] = $userTypeName[0]['user_type_name'];
                }
                $row[] = $value;
            }
            return $row;
        }
    }

    /*
     * @description : get the std tpl list
     * @param : 
     * @return array|$stdTplInfo
     */

    public function _getStdTplInfo() {
        $fieldsArray = array('std_tpl_id', 'std_tpl_name');
        $result = $this->db->_select('core_std_tpl_details', $fieldsArray);
        if ($result != "") {
            return $result;
        }
    }

    /*
     * @description : get Template Id
     * @param : $templateName,$classTplName,$templateType
     * @return int|$templateId
     */

    public function _getTemplateId($templateName, $classTplName, $templateType) {
        $sql = "SELECT
                    template_id
               FROM
                    core_template_details
               WHERE
                    template_name = '" . $templateName . "' AND
                    class_tpl_name = '" . $classTplName . "' AND
                    template_type = '" . $templateType . "'";
        $result = $this->db->_getResult($sql);
        if ($result != "") {
            return $result[0]['template_id'];
        }
    }

    /*
     * @description : get module mapping id
     * @param : array|$input
     * @return int|$moduleMappingId
     */

    public function _getModuleMappingId($moduleId, $templateId, $displayStatus, $displayOrder, $groupId) {
        $sql = "SELECT
                module_group_id
            FROM
                core_module_group_mapping
            WHERE
                group_id = $groupId
                AND module_id = $moduleId
                AND template_id = $templateId
                AND display_order = $displayOrder
                AND display_status = '$displayStatus'";

        $result = $this->db->_getResult($sql);
        if ($result != "") {
            return $result[0]['module_group_id'];
        }
    }

    /*
     * @description : get module mapping id
     * @param : array|$input
     * @return int|$moduleMappingId
     */

    public function _getStdTplMappingInfo($moduleId, $groupId, $stdTplId) {
        $sql = "SELECT
                    group_id
              FROM
                    core_module_group_stdtpl_mapping
              WHERE
                   group_id = '" . $groupId . "'
                   AND module_id = '" . $moduleId . "'
                   AND std_tpl_id = '" . $stdTplId . "'
                   AND class_name = 'content12px' ";

        $result = $this->db->_getResult($sql);
        if ($result != "") {
            return $result[0]['group_id'];
        }
    }

    /*
     * @description     :   construct application menu
     * @params          :   ---
     * @returnType      :   array|
     */

    public function _constructMenu() {
       
        $common = new commonMethods();

        ### array initialized for use in quicklink functionality to replace name of array in case of duplicate names in menu
        $_AMenuNames = array();

        ### assign group id and corporate id to class members
        $this->_IgroupDetail = $_SESSION['groupId'];
        $this->_IcorporateId = $_SESSION['corporateId'];

        ###Get parent menu mapping array
        $this->_AParentMenu  = $this->_getParentMenu();
        
        ### get menu mapping array for manipulatin array
        $_AMenuMapping       = $this->_getMappingMenu();
        
        ### declar array
        $this->_AMenuMapping = $this->_AParentChidMapping = array();
        
        ### loog through array to get the mapping hiearcharcy
        foreach($_AMenuMapping as $res) {
            $_IMenuMappingKey = $res['child_id'] != 0 ? $res['child_id'] : $res['parent_id'];
            
            $this->_AMenuMapping[$_IMenuMappingKey] = $res;
           if($res['child_id'] != 0) {
               $this->_AParentChidMapping[$res['child_id']] = $res['parent_id']; 
           } else {
               $this->_AParentChidMapping[$res['parent_id']] = 0; 
           }
        }
        
        ### itineary through array to construct the array
        $this->_AmenuData = $this->_AKeyPointer = array();
        
        foreach ($_AMenuMapping as $mapKey => $mapVal) {
            $this->_constructMenuArray($mapKey, $mapVal);
        }
        
        #### return array to user
        return array($this->_AmenuData, $_AMenuNames);

    }
    
     /*
     * @description : construct menu according to parent child relationship
     * @param : array|$A_Key
     * @param : array|$_Amenu
     * @return array|$response
     */
    private function _constructMenuArray($A_Key, $_Amenu) {

        if(is_array($_Amenu)) {
            ### initialize array

            
            ### if child id is zero then this is parent menu assign to main array
            if($_Amenu['child_id'] == 0) {
                
                ### assing parent id to traverse through main parent menu array and get values
                $pKey          = $_Amenu['parent_id'];
                
                ### check if the key is already present to avoid duplicate overwriting in array and if existing assign key with parent id in decimals
                $mainParentKey = $this->_AKeyPointer[$pKey] = !isset($this->_AmenuData[$_Amenu['display_order']]) ? $_Amenu['display_order'] : $_Amenu['display_order'].'.'.$_Amenu['parent_id']; // assing display order as key for sorting
                
                ### maintin the key and child id for later refernece in child menu
                
                $this->_AmenuData[$mainParentKey]['menu_id']        = $pKey;
                $this->_AmenuData[$mainParentKey]['menu_name']      = isset($this->_AParentMenu[$pKey]['alias_name']) && !empty($this->_AParentMenu[$pKey]['alias_name']) ? $this->_AParentMenu[$pKey]['alias_name'] : $this->_AParentMenu[$pKey]['menu_name'];
                $this->_AmenuData[$mainParentKey]['routing_name']   = $this->_AParentMenu[$pKey]['routing_name'];
                $this->_AmenuData[$mainParentKey]['menu_link']      = $this->_AParentMenu[$pKey]['menu_link'];
                $this->_AmenuData[$mainParentKey]['display_order']  = $_Amenu['display_order'];
                $this->_AmenuData[$mainParentKey]['display_status'] = $_Amenu['display_status'];
                
                ### sort the first level array using key sort
                ksort($this->_AmenuData);
                
            } else {

                ### if child id is NOT zero then child id is the menu array
                $pKey = $_Amenu['parent_id'];
                $cKey = $_Amenu['child_id'];
                
                ### check is parent menu status is enabled then only menu should be displayed
                if($this->_AParentMenu[$cKey]['menu_status'] == 'Y') {
                    
                    if($this->_AParentChidMapping[$_Amenu['parent_id']] == 0) {
                        
                        $pKey               = $this->_AKeyPointer[$pKey];
                        
                        ### check if the key is already present to avoid duplicate overwriting in array and if existing assign key with parent id in decimals
                        $newSubMenuArrayKey = $this->_AKeyPointer[$cKey] = !isset($this->_AmenuData[$pKey]['submenuArray'][$pKey.$_Amenu['display_order']]) ? $pKey.$_Amenu['display_order'] : $pKey.$_Amenu['display_order'].'.'.$_Amenu['child_id'];

                        ### conditon to check if parent id is present
                        if(isset($this->_AmenuData[$pKey])) {
                            ### form second level child menu
                            $this->_AmenuData[$pKey]['submenuArray'][$newSubMenuArrayKey]['submenu_id']     = $cKey;
                            $this->_AmenuData[$pKey]['submenuArray'][$newSubMenuArrayKey]['submenu_name']   = isset($this->_AParentMenu[$cKey]['alias_name']) && !empty($this->_AParentMenu[$cKey]['alias_name']) ? $this->_AParentMenu[$cKey]['alias_name'] : $this->_AParentMenu[$cKey]['menu_name'];
                            $this->_AmenuData[$pKey]['submenuArray'][$newSubMenuArrayKey]['routing_name']   = $this->_AParentMenu[$cKey]['routing_name'];
                            $this->_AmenuData[$pKey]['submenuArray'][$newSubMenuArrayKey]['submenu_link']   = $this->_AMenuMapping[$cKey]['menu_alternate_link'] !="NULL" ? $this->_AMenuMapping[$cKey]['menu_alternate_link'] : $this->_AParentMenu[$cKey]['menu_link'];
                            $this->_AmenuData[$pKey]['submenuArray'][$newSubMenuArrayKey]['display_order']  = $_Amenu['display_order'];
                            $this->_AmenuData[$pKey]['submenuArray'][$newSubMenuArrayKey]['display_status'] = $_Amenu['display_status'];
                            $this->_AmenuData[$pKey]['submenuArray'][$newSubMenuArrayKey]['menu_id']        = $_Amenu['parent_id'];
                            
                            ### sort the first level array using key sort
                            ksort($this->_AmenuData[$pKey]['submenuArray']);
                        }
                    } else {

                        ### get second & thrid parent ids
                        
                        $secondLevelParentId    = $this->_AKeyPointer[$_Amenu['parent_id']];
                        $firstLevelParentId     = $this->_AKeyPointer[$this->_AParentChidMapping[$_Amenu['parent_id']]];
                        $pKey                   = $secondLevelParentId;
                        
                        ### check if the key is already present to avoid duplicate overwriting in array and if existing assign key with parent id in decimals
                        $newSubMenuArrayKey = $this->_AKeyPointer[$cKey] = !isset($this->_AmenuData[$firstLevelParentId]['submenuArray'][$secondLevelParentId]['submenuArray'][$pKey.$_Amenu['display_order']]) ? $pKey.$_Amenu['display_order'] : $pKey.($_Amenu['display_order'].'.'.$_Amenu['display_order']);
                       
                        ### conditon to check if parent id is present
                        if(isset($this->_AmenuData[$firstLevelParentId]['submenuArray'][$secondLevelParentId])) {
                            ### from thrid level child menu
                            $this->_AmenuData[$firstLevelParentId]['submenuArray'][$secondLevelParentId]['submenuArray'][$newSubMenuArrayKey]['submenu_id']     = $cKey;
                            $this->_AmenuData[$firstLevelParentId]['submenuArray'][$secondLevelParentId]['submenuArray'][$newSubMenuArrayKey]['submenu_name']   = isset($this->_AParentMenu[$cKey]['alias_name']) && !empty($this->_AParentMenu[$cKey]['alias_name']) ? $this->_AParentMenu[$cKey]['alias_name'] : $this->_AParentMenu[$cKey]['menu_name'];
                            $this->_AmenuData[$firstLevelParentId]['submenuArray'][$secondLevelParentId]['submenuArray'][$newSubMenuArrayKey]['routing_name']   = $this->_AParentMenu[$cKey]['routing_name'];
                            $this->_AmenuData[$firstLevelParentId]['submenuArray'][$secondLevelParentId]['submenuArray'][$newSubMenuArrayKey]['submenu_link']   = $this->_AMenuMapping[$cKey]['menu_alternate_link'] !="NULL" ? $this->_AMenuMapping[$cKey]['menu_alternate_link'] : $this->_AParentMenu[$cKey]['menu_link'];
                            $this->_AmenuData[$firstLevelParentId]['submenuArray'][$secondLevelParentId]['submenuArray'][$newSubMenuArrayKey]['display_order']  = $_Amenu['display_order'];
                            $this->_AmenuData[$firstLevelParentId]['submenuArray'][$secondLevelParentId]['submenuArray'][$newSubMenuArrayKey]['display_status'] = $_Amenu['display_status'];
                            $this->_AmenuData[$firstLevelParentId]['submenuArray'][$secondLevelParentId]['submenuArray'][$newSubMenuArrayKey]['menu_id']        = $_Amenu['parent_id'];
                           
                            ### sort the first level array using key sort
                            ksort($this->_AmenuData[$firstLevelParentId]['submenuArray'][$secondLevelParentId]['submenuArray']);

                        }
                    }
                }
            }
        }
    }
    
    /*
     * @description : get parent menu details from table
     * @param :
     * @return array|$response
     */
    public function _getParentMenu() {
        
        $personalBookingStatus = 'N';

        if($this->_IcorporateId != ''){

            $leftCond = " AND (ma.corporate_id = " . $this->_IcorporateId . " OR ma.corporate_id =0) AND (ma.group_id = 0 OR ma.group_id = " . $this->_IgroupDetail . ") ";

            //get personal booking status
            $personalBookingStatus =  $this->_OapplicationSettings->_getPersonalBookingsStatus($this->_IcorporateId);
        } 
        else{
            $leftCond = " AND ma.corporate_id = 0  AND ma.group_id = 0";
        }
        
        $sql = "SELECT md.*, ma.alias_name 
                FROM 
                    core_menu_details md 
                    LEFT JOIN core_menu_alias ma ON (md.menu_id = ma.menu_id AND ma.`status` = 'Y'  " . $leftCond . ")
                WHERE 
                    (menu_type = '0' OR menu_type = '1') AND md.menu_status = 'Y'";
        
        $sql .= $personalBookingStatus  == 'Y' ? " AND (md.menu_type = '0' OR menu_type = '1')" : " AND md.menu_type = '0' ";
        
        $sql .= $this->_constructTravelModeQuery();        
        $result = $this->db->_getResult($sql);        
        foreach($result as $key=>$val){
            $returnValue[$val['menu_id']] = $val;
        }        
        return $returnValue;
    }    
        
    /*
     * @description : get menu mapping details from table
     * @param :
     * @return array|$response
     */
    public function _getMappingMenu(){
        
        $sql  = "SELECT 
                        * 
                 FROM 
                        core_menu_mapping_details
                 WHERE 
                        display_status = 'Y' 
                        AND project_code = '".MENU_PROJECT_CODE."' 
                        AND (group_id = 0 OR group_id = ".$this->_IgroupDetail.") 
                        AND (corporate_id = 0 OR corporate_id = ".$this->_IcorporateId.") 
                 ORDER BY 
                        parent_id, child_id,display_order";
        
        $result = $this->db->_getResult($sql);
        
        return $result;
    }

    /*
     * @description : update quick link menu for user in file
     * @param : int|$userId
     * @param : int|$menuId
     * @param : bool|$status
     * @return array|$response
     */

    public function _updateToggleQuickLink($inputData) {

        $userId      = $inputData['userId'];
        $menuId      = $inputData['menuId'];
        $status      = $inputData['status'];
        $menuName    = $inputData['menuName'];
        $routingName = $inputData['routingName'];

        if (!isset($_SESSION['quickLinkArray'])) {
            $_SESSION['quickLinkArray'] = array();
        }

        if ($status == 'Y') {
            //add checked checkbox into array
            //array_push($_SESSION['quickLinkArray'], $menuId);
            $_SESSION['quickLinkArray'][] = $menuId;
            $_SESSION['quickLinkArray'] = array_unique($_SESSION['quickLinkArray']);
        } else {
            //removed unchecked checkbox out of array
            if (($key = array_search($menuId, $_SESSION['quickLinkArray'])) !== false) {
                unset($_SESSION['quickLinkArray'][$key]);
            }
        }

        return $response;
    }

    /*
     * @description : load saved quick link from json file
     * @param :
     * @return array|$contents
     */

    public function _loadSavedQuickLink(){
        
        $_OauthToken = new authToken();
        $userId = $_SESSION['userId'];
        $path = APP_BASE_PATH . 'appSettings/quicklink/user_' . $userId . '.json';
        if(file_exists($path)){
            $contents = file_get_contents($path);    
            $contents = $_OauthToken->_purifyInputData($contents);        
            $contents = (array) json_decode($contents, 1);
        } 
        else{
            $contents = false;   
        }
        return $contents;
    }

    /*
     * @description     :   save quick link from session to file
     * @params          :   int|$userId
     * @returnType      :   
     */

    public function _saveQuickLinkFromSession($userId) {

        $path = APP_BASE_PATH . 'appSettings/quicklink/user_' . $userId . '.json';
        $fp = fopen($path, 'w');
        $contents = json_encode($_SESSION['quickLinkArray']);
        fwrite($fp, $contents);
        fclose($fp);
    }

    /*
     * @description     :  construct quick link menu from session
     * @params          :  
     * @returnType      :  string|$response
     */

    public function _reconstructQuickLinkMenu() {

        $selectedQuickLink = count($_SESSION['quickLinkArray']) > 0 ? $_SESSION['quickLinkArray'] : array(0 => 73);
        $menuArray = $this->_getQuickLinkMenuDetails($selectedQuickLink);

        $_OcustomTwig = new customtwig();
        $response = $_OcustomTwig->_dynamicQuickLink($menuArray);

        return $response;
    }

    /*
     * @description : get quick link menu details from table
     * @param : array\$menuIdsArray
     * @return array|$result
     */

    public function _getQuickLinkMenuDetails() {

        $menuIdsArray = $_SESSION['quickLinkArray'];

        if (!is_array($menuIdsArray) || count($menuIdsArray) < 1) {
            $menuIdsArray = array(0 => 73);
        }

        if (is_array($menuIdsArray)) {

            $menuIdCSV = implode(",", $menuIdsArray);

            if ($_SESSION['groupId'] != '') {
                $cond = " mmd.group_id = " . $_SESSION['groupId'] . "";
            } else {
                $cond = "1";
            }

            $sql = "SELECT md.menu_id, md.menu_name, md.routing_name FROM core_menu_details md 
                    INNER JOIN core_menu_mapping_details mmd ON (md.menu_id = mmd.parent_id || md.menu_id = mmd.child_id) 
                    WHERE " . $cond . " AND md.menu_id IN (" . $menuIdCSV . ") AND mmd.display_status = 'Y'";
            $result = $this->db->_getResult($sql);


            //check for array values which are duplicate and prepend parent menu name for them
            array_walk($result, function(&$value, &$key) {
                if (array_key_exists($value['menu_id'], $_SESSION['ADuplicateQuickLinkMenu'])) {
                    $value['menu_name'] = $_SESSION['ADuplicateQuickLinkMenu'][$value['menu_id']];
                }
            });

            $result = $this->checkAndRemoveExtraMenu($result);
        } else {
            $result = false;
        }

        return $result;
    }

    /*
     * @description     :  check and remove extra menu from quick link menu
     * @params          :  array|$menuArray
     * @returnType      :  array|$menuArray
     */

    private function checkAndRemoveExtraMenu($menuArray) {

        $menuIdArray = array_column($menuArray, 'menu_id');
        $menuNameArray = array_column($menuArray, 'menu_name');
        $menuStr = implode("", $menuNameArray);
        $strLength = strlen($menuStr);

        if ($strLength > 120) {
            array_pop($menuNameArray);
            $this->removedIdArray[] = array_pop($menuIdArray);
            array_pop($menuArray);

            $menuArray = $this->checkAndRemoveExtraMenu($menuArray);
            return $menuArray;
        } else {
            $_SESSION['quickLinkArray'] = $menuIdArray;
            return $menuArray;
        }
    }

    /*
     * @description     :  process duplicate quick links and append parent menu to the menu name
     * @params          :  array|$_AmenuDisplay
     * @returnType      :  array|$A_DuplicateFinalArray
     */

    public function _processDuplicateQuickLInks($_AmenuDisplay) {

        $_ANameArray = array_column($_AmenuDisplay, 'name', 'id');
        $_AOccuranteCount = array_count_values($_ANameArray);

        $_ADuplicates = array_filter($_AOccuranteCount, function($value) {
            return $value > 1;
        });

        $_ADuplicateArray = array_keys($_ADuplicates);

        $A_DuplicateNameArray = array_intersect($_ANameArray, $_ADuplicateArray);
        $A_DuplicateFinalArray = array_intersect_key($_AmenuDisplay, $A_DuplicateNameArray);

        array_walk($A_DuplicateFinalArray, function(&$value, &$key) {
            $value = $value['parent'] . ' > ' . $value['name'];
        });

        //set values in session
        $_SESSION['ADuplicateQuickLinkMenu'] = $A_DuplicateFinalArray;

        return $A_DuplicateFinalArray;
    }

    public function _constructTravelModeQuery() {
        
        $cond = '';
        
        $this->_OAppSettings = new applicationSettings();
        $this->_CcommonArrayFunctions = new commonArrayFunctions();
         
        /*$travelModeSettings = $_SESSION['userApplicationSettings']['TRAVEL_MODES'];

        if (isset($travelModeSettings) && !empty($travelModeSettings)) {
            // the enabled travel modes are verified and arrange for getting menus
                array_walk($travelModeSettings, function(&$value, &$key){
            // if air string matches the enabled travel modes it replaces the string as air (Domestic Air, International Air)
                    $this->_CcommonArrayFunctions->_checkWordPresentInString($value, 'Air', 'Air');
                });

            $applicationSettingsValues = $this->_OAppSettings->_getAllApplicationSettingValues($_SESSION['corporateId'], 'TRAVEL_MODES');

            if (count($applicationSettingsValues) > 0) {
                // getting the corporate enabled from settings and changes the value according to manipulate query for getting the menu as to listed for travel modes
                array_walk($applicationSettingsValues, function(&$value, &$key){
                // if air string matches the enabled travel modes it replaces the string as air (Domestic Air, International Air)
                    $this->_CcommonArrayFunctions->_checkWordPresentInString($value['value'], 'Air', 'Air');
                    
                });

                $appSettings = array_column($applicationSettingsValues, 'value');
                $_AexcludeTravelModes     = array_diff($appSettings, $travelModeSettings);
                $_StravelModeSettingsCSV  = "'" . implode("','", $_AexcludeTravelModes) . "'";

                $cond = " AND md.menu_name NOT IN(" . $_StravelModeSettingsCSV . ")";
            }
        } */ 
        $cond = " AND md.menu_name NOT IN('Bus','Car','Hotel','Train','Trip')";      
        return $cond;
    }

     /*
    * @description : set the details for menu redirection to frontend to backend
    * @return: array|$data
    */
    public function _formMenuInfoForBackend($_AmenuDisplay){        
        
        //obejct declaration.
        $_Oemployee = new employee();
                
        //get employee info
        $employeeInfo = $_Oemployee->_getEmployeeDetailsInfo($_SESSION['employeeId']);
        
        //set menu array for the user.
        $data['menuArray'] = $_AmenuDisplay;
        
        //login type
        $data['loginFrom'] = $_SESSION['loginFrom'];
        
        //set login user details.
        $data['loginDetails']['employeeId']       =  $_SESSION['employeeId'];
        $data['loginDetails']['accountId']        =  $_SESSION['accountId'];
        $data['loginDetails']['employeeCode']     =  $employeeInfo['employee_code'];
        $data['loginDetails']['emailId']          =  $_SESSION['employeeEmailId'];
        $data['loginDetails']['title']            =  $_SESSION['title'];
        $data['loginDetails']['firstName']        =  $_SESSION['firstName'];
        $data['loginDetails']['lastName']         =  $_SESSION['lastName'];
        $data['loginDetails']['accessCorporates'] =  $_SESSION['permissions']['access']['corporateId'];
        $data['loginDetails']['mobileNo']         =  $_SESSION['mobileNo'];
        $data['loginDetails']['corporateId']      =  $_SESSION['corporateId'];
        $data['loginDetails']['userType']         =  $_SESSION['userType'];        
        $data['loginDetails']['department']       =  $employeeInfo['department'];
        $data['loginDetails']['designation']      =  $employeeInfo['designation'];
        $data['loginDetails']['location']         =  $employeeInfo['location'];
        $data['loginDetails']['syncCorporateId']  =  $employeeInfo['syncCorporateId'];    
        $data['loginDetails']['syncPersonalId']  =  $employeeInfo['syncPersonalId'];       
        $data['loginDetails']['empName']          =  $_SESSION['userName'];
        return $data;
    }
}