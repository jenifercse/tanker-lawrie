<?php
/************************************************************************
 * @Class Name  : bookingDetailsSync
 * @Created on  : 2017-02-06
 * @Created By  : 
 * @Description : This class is used to calling the function for sync.
 **************************************************************************/
pluginFileRequire('common/', 'interface/commonConstants.php');

class bookingDetailsSync implements commonConstants{
    
    var $_ItravelClassId =0;    
    public function __construct(){
        
        $this->_AServiceRequest = array();
        $this->_Opackage           = new package();
        $this->_OflightItinerary   = new flightItinerary();
        $this->_Oairline           = new airline();
        $this->_Opassenger         = new passenger();
        $this->_OpassengerPreferences = new passengerPreferences();
        $this->_Oagency            = new agency();
        $this->_Opayment           = new payment();       
        $this->_OcommonMethods     = new commonMethods();
        $this->_OcorporateSettings = new corporateSettings();
        $this->_Oinvoice           = new invoice();
        $this->_OAppSettings       = new applicationSettings();
        $this->_OAirRequest        = new airRequest();       
        $this->db                  = new commonDBO();
        $this->_OsendSms           = new sendSms();
        $this->_Oeticket = new eTicketMail(); 
        $this->_OcommonDBO = new commonDBO();
        $this->_OreminderMail=new reminderMail();
        $this->_Ocommon = new common();
        $this->_Oeticket = common::_checkClassExistsInNameSpace('eTicketMail');
        $this->_OcommonQuery = new commonQuery();
        $this->_BmanualSync = FALSE;
        $this->_manualSyncAutomationFlag = TRUE;
        $this->_errorHandlingObj = new errorHandling();
        $this->_Oemployee = new employee();
        $this->_OcancellationInsert = common::_checkClassExistsInNameSpace('cancellationInsert');
        $this->_OtripCreation = common::_checkClassExistsInNameSpace('tripCreation');
        $this->_OapprovalProcess = common::_checkClassExistsInNameSpace('approvalProcess');
    }

   /* @Description get the agency details with respect to the corporate id. 
    * @param int|$corporateId
    * @return array|$result
    */
    public function _getAgencyDetails($corporateId = 0,$packageId = 0){

        if($corporateId == 0){
            $corporateId = $_SESSION['corporateId'];
        }
        
        if($packageId != 0 && $packageId != ''){
            ($corporateId == 0) ? $corporateId = $this->db->_select('fact_booking_details','r_corporate_id','r_package_id',$packageId)[0]['r_corporate_id'] : '';
        }
        
        $sql = "SELECT agency_id, agency_backend_url, agency_username, agency_password, sync_token, token_validity FROM dm_agency a
                INNER JOIN agency_corporate_mapping m ON a.dm_agency_id = m.agency_id
                WHERE m.corporate_id = " . $corporateId . " AND status='Y'";
        
        $result = $this->db->_getResult($sql);
        return $result;
    }

   /* @Description get the booking details with respect to the order id and package id. 
    * @param int|$packageId,$orderId
    * @return array|$returnValue
    */
    public function _syncBookingDetails($packageId, $orderId = 0,$fareCheckResponse = '',$paymentId=''){

        $this->_SerrorMessage = '';

        ##initialize values
        $_AairRequestData = $_AhotelRequestData = array();
        $agencyUrl = $requestMethod = '';
        
        ## checke for package or order id
        if($packageId != 0 || $orderId != 0){

            if($orderId != 0){
                $this->_IPaymentBasedOn = 2; ## order based payment
            } 
            else if ($packageId != 0){
                $this->_BPaymentBasedOn = 1; ## package based payment
            }

            ## get the complete payment details
            $packageDetails = $this->_Opackage->_getPaymentCompletedPackageDetails($packageId, 0, $orderId, $this->_paymentTypeId);
            foreach($packageDetails as $res){
                $packageId = $res['package_id'];
                ##Get the order id belongs to the package
                if($res['r_travel_mode_id'] == SELF::DOMESTIC_AIR_MODE_ID || $res['r_travel_mode_id'] == SELF::INTERNATIONAL_AIR_MODE_ID) {
                    ## Domestic / International Air Sync
                    $requestMethod      = SELF::AIR_SYNC_METHOD;
                    $_AairRequestData   = array();
                    $_AairRequestData[] = $this->_getBookingFullFillmentRequest($res, $packageId, $orderId, $res['r_travel_mode_id'], $res['booking_type'],$fareCheckResponse,'',$paymentId);
                    fileWrite(print_r($_AairRequestData,1),'requestdataError','a+');
                    fileWrite($this->_SerrorMessage,'requestdataError','a+');
                    (!empty($this->_SerrorMessage)) ? $this->_errorHandlingObj->_setErrorMsg($_AairRequestData,'Booking Fulfillment Request Sync Error', $this->_SerrorMessage) : '';
                    $this->_callBookingSyncMethod($_AairRequestData, $requestMethod, $packageId, $res['booking_type']);
                } 
                else{
                    fileWrite('Invalid package Type Specified', 'SyncDetailsResponse', 'a+');
                }
            }
        } 
        else{
            fileWrite('Response Status: Package or order id not received', 'SyncDetailsResponse', 'a+');
        }
        return true;
    }

    /**
     * Sync additional Payment
     * @param  int $paymentId Payment id
     * @return array
     */
    public function _syncAdditionalPayment($paymentId,$paymentAmount,$packageId){
        
        $_Osync = new sync();

        $sql = "SELECT pd.*, ap.* 
                FROM 
                    additional_payment ap 
                INNER JOIN payment_details pd ON ap.r_payment_id = pd.payment_id 
                WHERE ap.r_payment_id = ".$paymentId;

        $result = $this->_OcommonDBO->_getResult($sql);
        //get agency id
        $agencyId = $this->_OcommonDBO->_select("fact_booking_details",'r_agency_id','r_order_id',$result[0]['r_order_id'])[0]['r_agency_id'];
        //get travel Mode id
        $travelModeId = $this->_OcommonDBO->_select("fact_booking_details",'r_agency_id','r_order_id',$result[0]['r_order_id'])[0]['travel_mode'];

        //get transaction details
        $transactionDetails = $this->_getRequestTransactionDetails($packageId,$result[0]['r_order_id'],$agencyId,$paymentAmount,$travelModeId,$paymentId);

        //set array
        $requestData['additionalPayment'] = array(
            'orderId'       => $result[0]['r_order_id'],
            'amount'        => $result[0]['total_amount'],
            'payment_date'  => $result[0]['payment_date'],
            'payment_type'  => $result[0]['payment_type'],
            'paymentStatus' => $result[0]['payment_status'],
            'transactionDetails' => $transactionDetails
        );     
        ($result[0]['payment_title'] == 'Fare Difference') ? $requestData['additionalPayment']['paymentTitle'] = 'Fare Difference' : $requestData['additionalPayment']['paymentTitle'] = 'SSR';
        foreach ($result as $key => $value) {
            $requestData['additionalPayment']['syncAdditionalId'][] = $result[$key]['sync_additional_id'];
        }   
        $responseArray = $_Osync->_getdata($requestData,'additionalPayment',$agencyId);
        return $responseArray;
    }

    /* @Description call the booking sync with respect to the method 
    * @param array,string,int|$_ArequestData, $requestMethod, $packageId
    * @return array|$returnValue
    */
    public function _callBookingSyncMethod($_ArequestData,$requestMethod,$packageId){

        $returnValue = '';

        $request[$requestMethod] = $_ArequestData;
        $request = json_encode($request);
        $agencySyncData = $this->_getAgencyDetails(0,$packageId);

        $agencyId = $agencySyncData[0]['agency_id'];
        $agencyUrl = $agencySyncData[0]['agency_backend_url'];
        $agencyUname = $agencySyncData[0]['agency_username'];
        $agencyPwd = $agencySyncData[0]['agency_password'];
        $agencyToken = $agencySyncData[0]['sync_token'];
        $tokenValidity = $agencySyncData[0]['token_validity'];

        $response = $this->_OcommonMethods->_callTokenSyncMethod($agencyUrl, $agencyUname, $agencyPwd, $agencyToken, $tokenValidity, $agencyId);

        $response = $this->_OcommonMethods->_callSyncMethod($agencyUrl, $requestMethod, $request, $packageId, $response['serviceToken']);

        $responseArray = (array) json_decode($response, 1);
        ($_SESSION['loginName'] == 'ssomenuLogin' || $_SESSION['loginName'] == 'ssologin') ? $this->_setSsoLoginCheckCookie() : FALSE;
        if ($responseArray['status'] == 'SUCCESS'){            
            //update values to corresponding tables
            if($requestMethod == SELF::AIR_SYNC_METHOD){
                $this->_updateSyncDetails($responseArray['responseData']);
                $returnValue = $responseArray['responseData'];
            }
            else if($requestMethod == 'additionalPayment'){
                $this->_updateSyncDetails($responseArray['responseData']);
                $returnValue = $responseArray['responseData'];
            }
            else if($requestMethod == 'reSyncSapTicketRequest'){
                $returnValue = $responseArray['responseData'];
            }
            else if($requestMethod == 'reSyncAirFullfillment'){
                $this->_updateSyncDetails($responseArray['responseData']);
                $returnValue = $responseArray['status'];
            }
        } 
        else{
            fileWrite('Response Status:' . $responseArray, 'SyncDetailsResponse', 'a+');
        }
        return $returnValue;
    }
    
   /* @Description set cookine while sso login.
    * @param 
    * @return
    */
    public function _setSsoLoginCheckCookie(){
        
        if(isset($_COOKIE['paymentConpleteFlag'])){
            //set paymentConpleteFlag cookie
            setcookie('paymentConpleteFlag','', time()-60*60*24,PRODUCT_ROOT_NAME,DOCUMENT_ROOT,TRUE,TRUE);
            //reassign value of paymentConpleteFlag coookie
            setcookie('paymentConpleteFlag','Y',time()+60*60*24,PRODUCT_ROOT_NAME,DOCUMENT_ROOT,TRUE,TRUE);            
        }        
    }

    /* @Description get booking fulfillment details
    * @param array,int,int: $packageDetails, $packageId, $orderId, $travelModeId, $bookingType=1
    * @return array : $_ArequestData
    */
    public function _getBookingFullFillmentRequest($packageDetails,$packageId,$orderId,$travelModeId,$bookingType = 1,$fareCheckResponse = '',$paymentFaliureFlag ='',$paymentId=''){

        $_OauthToken = new authToken();
        $this->_OcommonInsertFlightItinerary = new commonInsertFlightItinerary();

        $packageCount = count($packageDetails);
        
        //set travel mode id
        $travelModeId = $packageDetails['r_travel_mode_id'];

        // check travel mode is not empty    
        $travelModeId != 0 ? '' : $this->_SerrorMessage .= 'Travel mode id for booking fulfilement is missing';
        $orderId      = $packageDetails['r_order_id'];

        // check order id is not empty    
        $orderId != 0 ? '' : $this->_SerrorMessage .= 'Order id for booking fulfilement is missing';
        $bookingMode = $packageDetails['booking_mode'];

        ## get booking person array
        $bookingPersonInfo = $this->_Opackage->_getCorporateAdminDetails($orderId);

        // check $bookingPersonInfo is not empty    
        !empty($bookingPersonInfo) ? '' : $this->_SerrorMessage .= 'Booking person email id for booking fulfilement is missing';

        ##get order details array
        $orderDetailsArray = $this->_getOrderDetails($orderId);

        ## get requestInfo node
        $_ArequestData['requestInfo'] = $this->_getBookingRequestInfo($packageDetails, $packageId, $orderId);
        
        $cutomFieldValue = $_ArequestData['requestInfo']['customize_fields'];

       unset($_ArequestData['requestInfo']['customize_fields']);

        //Check for multicity package type and assign multicity orders for backend sync
        if($packageDetails['package_type']==1){
            //Get the orders in multicity package
            $packageOrderDetails = $this->_Opackage->_getPaymentCompletedPackageDetails($packageId);
            $orderArray= array_column($packageOrderDetails, 'r_order_id');
            //Assign the orders to sync data
            $_ArequestData['requestInfo']['requestOrderDetails']=implode(",",$orderArray);
        }
        
        /* SAP details addintion starts */
        $sapRequestInfo = $this->_getSapRequestDetails($packageId);
        if(empty($sapRequestInfo)){
            $approverId = $this->_OcommonDBO->_select('order_details','approver_account_id','order_id',$orderId)[0]['approver_account_id'];
            if($approverId > 0){
               $sapRequestInfo = $this->_getRequestApproverInfo($approverId,$orderId);
            }

        }
        //Assign meeting details to booking sync request
        $newMeetingDet = array();
        //purify the json data.
        $sapRequestInfo['meeting_details'] = $_OauthToken->_purifyInputData($sapRequestInfo['meeting_details']);
        if(isset($sapRequestInfo['meeting_details']) && $sapRequestInfo['meeting_details']!='' && !is_null($sapRequestInfo['meeting_details'])){
            $newMeetingDet = json_decode($sapRequestInfo['meeting_details'],TRUE);
        } 
        else{
            $newMeetingDet = array(
                'country' => $sapRequestInfo['country'],
                'city' => $sapRequestInfo['city'],
                'costCenter' => $sapRequestInfo['cost_center_code']
            );
        }

        // settings details for OFFLINE RETRY STATUS mandatory
        $resultSyncOrderId = $this->_OcommonDBO->_select('order_details', '*', 'order_id', $orderId)[0]['sync_order_id'];
        $_ArequestData['requestInfo']['reselectFlight'] = $resultSyncOrderId == 0 ? '' : 'YES';
        $_ArequestData['requestInfo']['meetingDetails'] = $newMeetingDet;

        //Approver details
        $_ArequestData['requestInfo']['approverDetails'] = $this->_setApproverDetails($sapRequestInfo,$orderId);
       
        /* SAP details addintion ends */        
        $_ArequestData['requestInfo']['bookingPersonEmail'] = $bookingType == 0 ? $bookingPersonInfo[0]['sync_email_id'] : $bookingPersonInfo[0]['sync_corporate_email_id'];
       
        //check $_ArequestData['requestInfo']['bookingPersonEmail'] is not empty    
        $_ArequestData['requestInfo']['bookingPersonEmail'] != '' ? '' : $this->_SerrorMessage .= 'bookingPersonEmail for booking fulfilement is missing';        
        
        ## set application type
        $_ArequestData['requestInfo']['bookingType'] = $bookingType == 0 ? 'personal' : 'corporate';
       
        ## set corporate wise customization - balmer
        ## TODO: NEED to fetch agencyemail id from air_booking_details table
        $_ArequestData['requestInfo']['agentEmail'] = $bookingMode == 1 ? $_SESSION['employeeEmailId'] : '';
        
        ##get requestCharges node
        $_ArequestData['requestCharges'] = $this->_getBookingRequestCharges($packageDetails,$packageId);

        ##get card details based on booking airline
        $_ArequestData['requestInfo']['creditCardInfo'] = $this->_getPassthroughCardDetails($packageId, $orderId,SELECTED_ITINERARY);

        ## send booking mode along with the sync
        $_ArequestData['requestInfo']['bookingMode'] = BOOKING_MODE;
        $_ArequestData['requestInfo']['clientIp']    =  $_SERVER['REMOTE_ADDR'];
        $_ArequestData['requestInfo']['postFacto']   =  $this->_getOrderApproverFacto($orderId);
        $_ArequestData['requestInfo']['selfDeclarationData']   =  $this->_getOrderDeclarationData($orderId);

        ## to get transactionDetails for personal booking
        if($bookingType == 0){

            $_ArequestData['transactionDetails'] = $this->_getRequestTransactionDetails($packageId,$orderId,$bookingPersonInfo[0]['agency_id'],$_ArequestData['requestInfo']['totalAmount'],$travelModeId,$paymentId);

            //set pg charges.
            $_ArequestData['requestCharges']['pgCharges'] =  $_ArequestData['transactionDetails']['pgamount'];
        }

        $tripInfo = $this->_getTripInformation($orderId,$sapRequestInfo);
        $_ArequestData['tripInformation'] = $tripInfo['tripInformation'];
        $_ArequestData['requestInfo']['sapRequestDetails'] = $tripInfo['requestInfo']['sapRequestDetails'];
        
        ##get selected ItineraryInfo node
        $itinearayAndFareInfoArray = $this->_getItineraeryAndFareInfo($packageDetails, $packageId, $travelModeId, $_ArequestData['requestInfo']['orderId'],SELECTED_ITINERARY);

        ## set client id
        $_ArequestData['requestInfo']['clientId'] = $itinearayAndFareInfoArray['clientId'];
        if($this->_BmanualSync){//Remove client id for manual sync to do fare check in backend => 17-Jan-2018
            $_ArequestData['requestInfo']['clientId'] = '';
        }
        
        ##set itineary info
        $_ArequestData['itineraryInfo']    = $itinearayAndFareInfoArray['itineraryInfo'];
        
        //check itineraryInfo is not empty    
        (count($_ArequestData['itineraryInfo']) > 0 && !empty($_ArequestData['itineraryInfo'])) ? '' : $this->_SerrorMessage .= 'Itinerary Info for booking fulfilement is missing';
        
        ## set fare info
        $_ArequestData['fareInfo']         = $itinearayAndFareInfoArray['fareInfo'];
        
        //check itineraryInfo is not empty    
        (count($_ArequestData['fareInfo']) > 0 && !empty($_ArequestData['fareInfo'])) ? '' : $this->_SerrorMessage .= 'Fare Info for booking fulfilement is missing';        
        
        ##get selected ItineraryInfo node
        $lowFareItinearayAndFareInfoArray = $this->_getItineraeryAndFareInfo($packageDetails, $packageId, $travelModeId, $_ArequestData['requestInfo']['orderId'],LOW_FARE_ITINERARY);

        ##set itineary info
        $_ArequestData['lowfareitineraryInfo']    = $lowFareItinearayAndFareInfoArray['itineraryInfo'];

        ## set fare info
        $_ArequestData['lowfareitineraryfareInfo'] = $lowFareItinearayAndFareInfoArray['fareInfo'];

        //to set corporate id from fact_booking_details
        $selectCorporate = "SELECT fbd.r_corporate_id,acm.sync_corporate_id,acm.sync_personal_id FROM fact_booking_details fbd INNER JOIN agency_corporate_mapping acm ON fbd.r_corporate_id = acm.corporate_id WHERE fbd.r_order_id = $orderId";
        $corporateInfo = $this->db->_getResult($selectCorporate)[0];

        $_Ologin = new login();
        $folderPath = $bookingType == 0 ? 'personal/' : 'corporate/';

        //set the application settings value in session
        $userApplicationSettings = $_SESSION['userApplicationSettings']['AUTOMATION_PROCESS'] !='' ?$_SESSION['userApplicationSettings']['AUTOMATION_PROCESS'] : $_Ologin->_getCorporateAppSettings($corporateInfo['r_corporate_id'],$folderPath)['AUTOMATION_PROCESS'];

        ## check is automation is enabled
        if( $userApplicationSettings == 'YES' || $this->_automationProcess == 'YES'){
            $_ArequestData['requestInfo']['automationStatus'] = 'Y';
        } 
        else{
            $_ArequestData['requestInfo']['automationStatus'] = 'N';
        } 
        // check the booking package is gds booking
        if($this->_OcommonDBO->_select('dm_package', 'is_gds_booking', 'package_id', $packageId)[0]['is_gds_booking'] == 1){

            !array_key_exists(0, $this->_IinputData['gdsPaymanetDetails']['gdsRequestData']['PNRDetails']) ? $this->_IinputData['gdsPaymanetDetails']['gdsRequestData']['PNRDetails'] = array($this->_IinputData['gdsPaymanetDetails']['gdsRequestData']['PNRDetails']) : '';

            !array_key_exists(0, $this->_IinputData['gdsPaymanetDetails']['gdsPnrDetails']) ? $this->_IinputData['gdsPaymanetDetails']['gdsPnrDetails'] = array($this->_IinputData['gdsPaymanetDetails']['gdsPnrDetails']) : '';

            $_ArequestData['requestInfo']['gdsBookingDetails'] = $this->_IinputData['gdsPaymanetDetails'];
            $_ArequestData['requestInfo']['gdsBookingDetails']['emdTotalAmount'] = array();
            
            array_walk($this->_OcommonDBO->_select('fact_passenger_preferences','trip_type,ssr_preferences_fare', 'r_package_id', $packageId), function($v, $k) use(&$_ArequestData){
                $_ArequestData['requestInfo']['gdsBookingDetails']['emdTotalAmount'][$v['trip_type']] += $v['ssr_preferences_fare'];
            });

            $_ArequestData['requestInfo']['automationStatus'] = 'N';
        }

        ## set passenger information
        $_ArequestData['passengerInfo']    = $this->_getPassengerInfo($orderId, $orderDetailsArray[0]['expense_bourne'],$travelModeId,$bookingType);
        
        //check itineraryInfo is not empty    
        (count($_ArequestData['passengerInfo']) > 0 && !empty($_ArequestData['passengerInfo'])) ? '' : $this->_SerrorMessage .= 'Passenger Info for booking fulfilement is missing';
        
        $_ArequestData['passengerSsrInfo'] = $this->_getPassengerSSRInfo($orderId, $orderDetailsArray[0]['expense_bourne']);

        $_ArequestData['gstInfo'] = $this->_getGSTValue($_ArequestData['passengerInfo'][0]['r_employee_id'],$bookingPersonInfo,$orderId,$bookingType);

        $_ArequestData['employeeGSTInfo'] = $this->_getGstdata($_ArequestData['passengerInfo'][0]['r_employee_id']);
         
        //set sync corporate id based on the booking type.
        $_ArequestData['syncCorporateId']  = ($bookingType == 0) ? (int)$corporateInfo['sync_personal_id'] : (int)$corporateInfo['sync_corporate_id'];
        
        //check itineraryInfo is not empty    
        $_ArequestData['syncCorporateId'] ? '' : $this->_SerrorMessage .= 'Sync CorporateId for booking fulfilement is missing';                                
        
        #### if payment gateway is sabre then send card details through sync
        if($this->_paymentTypeId == 8) {
            $_ArequestData['PGTYPE']      = 'sabrePG';
            $_ArequestData['cardDetails'] = $this->_cardDetailsArray;
        }
        $_ArequestData['orderNo'] = $fareCheckResponse['orderNo'];
        $_ArequestData['classCode'] = $fareCheckResponse['classCode'];
        
        global $CFG;
        $_ArequestData['requestInfo']['gdsBookingEnable'] = 'N';

        //if payment is failure set the automation as 'N'
        if($paymentFaliureFlag == 'Y'){
            $_ArequestData['requestInfo']['automationStatus'] = 'N';
            $_ArequestData['paymentFailure'] = 'Y';
            //update payment failure status in order_details
            $updateStatus['r_ticket_status_id'] = PAYMENT_FAILURE;
            $this->_OcommonDBO->_update('order_details',$updateStatus,'order_id',$orderId);
        }
         $cutomFieldValue  = json_decode($cutomFieldValue,1);
         $_ArequestData['customizedFare']= '';
        // LTC and go air defence fare details
            if(!empty($cutomFieldValue) && isset($cutomFieldValue)){
                if($cutomFieldValue['LTCEnable'] == 'Y'){
                 $_ArequestData['customizedFare']= 'LTC';
                }
                else if($cutomFieldValue['defenseFare']== 'Y'){
                $_ArequestData['customizedFare']= 'DEFENCE';
                }
            }
        // disable automation for manual sync when automation flag is not set
        if(!$this->_manualSyncAutomationFlag){
            $_ArequestData['requestInfo']['automationStatus'] = 'N';
        }
        if(in_array($packageDetails['requested_by'],$CFG['offlineEmailId'])){
            $_ArequestData['requestInfo']['automationStatus'] = 'N';
            $_ArequestData['requestInfo']['gdsBookingEnable'] = 'Y';
        }
        return $_ArequestData;
    }
  

    
    //function to get the transaction details
    public function _getRequestTransactionDetails($packageId,$orderId,$agencyId,$totalAmount,$travelModeId,$paymentId = ''){
        
        //get payment details with respect to the package id
        if($paymentId != ''){
            $result = $this->_OcommonDBO->_select('payment_details',array('payment_response','r_payment_type_id'),'payment_id',$paymentId)[0];
        }
        else{
            $result = $this->_OcommonDBO->_select('payment_details',array('payment_response','r_payment_type_id'),'r_package_id',$packageId)[0];   
        }

        $_Opayemnt = new payment();
        $pgDetails = $_Opayemnt->_calculatePGAmount($totalAmount,$result['r_payment_type_id'],$agencyId,$travelModeId);
        
        global $CFG;

        //decode the payment response array
        $paymentResponse  = json_decode($result['payment_response'],1);

        if($paymentResponse['msg'] == ''){
            $serverResponse = $this->_OcommonDBO->_select('pg_payment_details','server_response_data','r_request_id',$paymentId)[0]['server_response_data'];
            $resultArray = explode("|", $serverResponse);

        }
        else{
            //get data
            $resultArray = explode("|", $paymentResponse['msg']);
        }       

        $finalArray['merchantId']           = $CFG['merchantId'][$result['r_payment_type_id']];
        $finalArray['transactionId']        = $resultArray[2];
        $finalArray['pgRef']                = $resultArray[1];
        $finalArray['pgcharges']            = $pgDetails['percentage'] ? $pgDetails['percentage'] : 0;
        $finalArray['pgamount']             = $pgDetails['pgAmount'];
        $finalArray['pgErrorCode']          = $resultArray[14];
        $finalArray['pgErrorText']          = $resultArray[24];//(!empty($result['hidRequestId'])) ? $result['hidRequestId']."-".$CFG['billDeskErrorDesc'][$resultArray[14]] : $CFG['billDeskErrorDesc'][$resultArray[14]];
        $finalArray['bankId']               = $resultArray[5];
        $finalArray['bankRefNo']            = $resultArray[3];
        $finalArray['bankMerchantId']       = $resultArray[6];
        $finalArray['itemCode']             = $resultArray[9];
        $finalArray['payMode']              = $CFG['paymentType'][$result['r_payment_type_id']][$resultArray[7]];
        $finalArray['creationDate']         = $resultArray[13];
        $finalArray['paySource']            = 'OnLine';
        $finalArray['paymentStatus']        = $resultArray[14] == '300' ? 'Captured' : 'Not Captured';
        $finalArray['transactionStatus']    = 'Response Received';
        $finalArray['isCheckSumVerified']   = 1;
        return $this->_Opassenger->_getPaxAddressInfo($orderId,$finalArray);
    }


    /* @Description get hotel itinerary info
    * @param array,int,int: $packageDetails, $orderId, $requestId
    * @return array : $returnArray
    */
    private function _getBookingRequestInfo($packageDetails,$packageId,$orderId){

        $returnArray = array();
        
        //get booking person details.
        $bookingPersonDetails = $this->_Opackage->_getBookingPersonInfo($packageDetails['r_order_id']);
        
        //get currency details.
        $currencyDetails      = $this->_OAppSettings->_getCurrencyDetails($packageDetails['r_currency_type_id']);
        
        //get air request details.
        $airRequestDetails    = $this->_OAirRequest->_getAirRequest($bookingPersonDetails[0]['r_request_id'], array('num_passenger', 'trip_type', 'r_travel_class_id', 'travel_type', 'customize_fields'));
        $this->_ItravelClassId=$airRequestDetails[0]['r_travel_class_id'];
        
        //payment details
        $paymentDetails = $this->_Opayment->_getPaymentDetails($packageDetails['r_order_id'], $packageId, $this->_paymentTypeId);
        
        //payment code details
        $paymentCode = $this->_Opayment->_getPaymentTypeDetails($paymentDetails[0]['r_payment_type_id']);
        
        //get class info
        $travelClassArray = $this->_Oairline->_getTravelClassName($airRequestDetails[0]['r_travel_class_id']);

        $returnArray['packageId'] = (int) $packageDetails['package_id'];
        
        //check $returnArray['packageId'] is not empty    
        $returnArray['packageId'] != 0 ? '' : $this->_SerrorMessage .= 'Package id for booking fulfilement is missing';        
        
        $returnArray['orderId'] = (int)$packageDetails['r_order_id'];
        //check $returnArray['orderId'] is not empty    
        $returnArray['orderId'] != 0 ? '' : $this->_SerrorMessage .= 'order id for booking fulfilement is missing';                
        
        $returnArray['requestPersonEmail'] = $packageDetails['requested_by'] . "," . $bookingPersonDetails[0]['email_id'];

        
        $returnArray['requestEmployeeId'] = $this->_setEmployeeId($packageDetails['r_employee_id']);


        //check $returnArray['requestPersonEmail'] is not empty    
        $returnArray['requestPersonEmail'] != '' ? '' : $this->_SerrorMessage .= 'requestPersonEmail for booking fulfilement is missing';        
        
        $returnArray['packageDateTime']    = $packageDetails['created_date'];
        //check $returnArray['packageDateTime'] is not empty    
        $returnArray['packageDateTime'] != '' ? '' : $this->_SerrorMessage .= 'packageDateTime for booking fulfilement is missing';                
        $returnArray['travelPurpose']      = $packageDetails['travel_purpose'];
        
        $returnArray['currencyCode']       = strtoupper($currencyDetails[0]['currency_symbol']);
        // check $returnArray['currencyCode'] is not empty    
        $returnArray['currencyCode'] != '' ? '' : $this->_SerrorMessage .= 'currencyCode for booking fulfilement is missing';                        
        
        $returnArray['totalAmount']        = (int)$packageDetails['total_amount'];
        // check $returnArray['totalAmount'] is not empty    
        $returnArray['totalAmount'] != 0 ? '' : $this->_SerrorMessage .= 'totalAmount for booking fulfilement is missing';                                
        
        $returnArray['tripType']           = $packageDetails['package_type']==1 ? 'MULTICITY' : ($airRequestDetails[0]['trip_type'] == 0 ? 'ONEWAY' : 'ROUNDTRIP');
        $returnArray['numberOfPax']        = (int) $airRequestDetails[0]['num_passenger'];
        // check $returnArray['numberOfPax'] is not empty    
        $returnArray['numberOfPax'] != 0 ? '' : $this->_SerrorMessage .= 'numberOfPax for booking fulfilement is missing';                                        
        
        $returnArray['className']          = $travelClassArray[0]['class_name'];
        // check $returnArray['className'] is not empty    
        $returnArray['className'] != '' ? '' : $this->_SerrorMessage .= 'className for booking fulfilement is missing';                                        
        
        $returnArray['paymentType']        = $paymentCode[0]['payment_type_code'];
        // check $returnArray['numberOfPax'] is not empty    
        $returnArray['paymentType'] != '' ? '' : $this->_SerrorMessage .= 'paymentType for booking fulfilement is missing';                                        
        
        $returnArray['tralveModeCode']     = $airRequestDetails[0]['travel_type'];
        // check $returnArray['tralveModeCode'] is not empty    
        $returnArray['tralveModeCode'] != '' ? '' : $this->_SerrorMessage .= 'tralveModeCode for booking fulfilement is missing';                                        
        
        $billtoResult=$this->_getBilltoAddress($packageDetails['r_order_id']);
        
        $returnArray['billTo'] = $returnArray['billToAddress'] = $billtoResult[0]['billto_name'] ? $billtoResult[0]['billto_name'] : '';
        $returnArray['billToStateId'] = $billtoResult[0]['billto_state_id'] ? $billtoResult[0]['billto_state_id'] : '';
            
         //get LCT flight request flag   
         $returnArray['customize_fields'] = $airRequestDetails[0]['customize_fields'];
        // check the order is ticket approval flow and assign key tag for approval flow
        (CMP_TICKET_APPROVAL == $this->db->_select('order_details', 'workflow_caption', 'order_id', $packageDetails['r_order_id'])[0]['workflow_caption']) ? $returnArray['approvalFlow'] = CMP_TICKET_APPROVAL : FALSE;
        return $returnArray;
    }

    
    /* @Description get sap request details
    * @param int: $packageId
    * @return array : $result
    */
    private function _getSapRequestDetails($packageId){
        
        //Query to get the costcenter code based on sap cost center
        $sqlCostcenter="SELECT  sap_request_id,
                                city,country,
                                approver_employee_code,
                                approver_name,
                                approver_mobile_no,
                                approver_remarks,
                                cost_center_code,
                                meeting_details 
                        FROM    sap_request_details srd
                        INNER JOIN dm_cost_center_code ccd ON srd.r_cost_center_code_id = ccd.cost_center_code_id 
                        WHERE srd.r_package_id=".$packageId;
        //Get the result for costcenter code 
        $result = $this->db->_getResult($sqlCostcenter);
        
        if(is_array($result)){
            $resultSapSegmentId = $this->db->_select('sap_sequence_details', array('onward_sequence_no', 'return_sequence_no'), 'r_package_id', $packageId);
            if(is_array($resultSapSegmentId)){
                $result[0]['onwardSequenceNo']=$resultSapSegmentId[0]['onward_sequence_no'];
                $result[0]['returnSequenceNo']=$resultSapSegmentId[0]['return_sequence_no'];
            }
            else{
                $result[0]['onwardSequenceNo']='';
                $result[0]['returnSequenceNo']='';
            }
        }
        return $result[0];
    }
    
    /* @Description get pass through card details.
    * @param int: $packageId,$orderId,$itineraryStatus
    * @return array : $passthroughCardArray
    */
    private function _getPassthroughCardDetails($packageId,$orderId=0,$itineraryStatus){
        
        $passthroughCardArray = array();

        $passthroughCardDetailsArray = $this->_OflightItinerary->_getPassthroughCardDetails($packageId,$orderId,$itineraryStatus);
        
        fileWrite(print_r($passthroughCardDetailsArray,true),"PASSTHROUGH","a+");

        ### loop through order_id passthrough flight card details
        foreach ($passthroughCardDetailsArray as $key => $cardDetails){ 
            $passthroughCardArray[$cardDetails['airlineCode']]['cardNumber']=base64_encode($this->_Ocommon->aesEncryption(AJAXENCYPTSALT, $cardDetails['cardNumber']));
            $passthroughCardArray[$cardDetails['airlineCode']]['expiryMonth']=$cardDetails['expiryMonth'];
            $passthroughCardArray[$cardDetails['airlineCode']]['expiryYear']=$cardDetails['expiryYear'];
        }
        return $passthroughCardArray;
    }

   /* @Description get booking request charges
    * @param array,int: $packageDetails,$packageId
    * @return array : $returnArray
    */
    private function _getBookingRequestCharges($packageDetails,$packageId){

        //array declaration
        $returnArray = $orderFeeInfo = array();

        foreach($packageDetails['agentFeeDetails'] as $key => $value) {
           if($value['agent_fee_name'] != 'feeGST'){
                $orderFeeInfo[] = $value;
           }
        }
        $returnArray = array_column($orderFeeInfo, 'fee_value', 'agent_fee_name');
        return $returnArray;
    }

   /* @Description get itinerary info and fare info.
    * @param array,int: $packageDetails,$packageId,$travelModeId,$orderId = '',$itineraryStatus
    * @return array : $returnArray
    */
    private function _getItineraeryAndFareInfo($packageDetails,$packageId,$travelModeId,$orderId = '',$itineraryStatus){

        $fareInfoArray = $returnArray = array();

        $flightDetailsArray = $this->_OflightItinerary->_getPackageFlightDetails($packageId, $orderId,$itineraryStatus);
        ### loop through order_id flight details
        foreach ($flightDetailsArray as $orderId => $orderDetails) {

            //getlow fare reason from table for this order_id
            $reasonResult = $this->_OflightItinerary->_getLowFareReason($orderId);
            //$clientId = array();
            //loop through onward / return of each order id
            foreach ($orderDetails as $type => $res) {

                foreach ($res['viaInfo'] as $via) {
                    //Set client id for automation farecheck
                    if (!isset($clientId['onward']) && $via['trip_type'] == 0) {
                        $clientId['onward'] = $orderId . $via['via_flight_id'];
                    } else if (!isset($clientId['return']) && $via['trip_type'] == 1) {
                        $clientId['return'] = $orderId . $via['via_flight_id'];
                    }

                    $vaiArray = array();
                    $vaiArray = $via;
                    $vaiArray['itineraryId'] = (int)$via['via_flight_id'];
                    $vaiArray['departureDate'] = $via['departure_date'];
                    $vaiArray['arrivalDate'] = $via['arrival_date'];
                    $vaiArray['cancellationPenalty'] = $via['cancellation_penalty'];
                    $vaiArray['departureTime'] = $via['time_departure'];
                    $vaiArray['arrivalTime'] = $via['time_arrival'];
                    $vaiArray['flightNumber'] = (int)$via['flight_no'];
                    $vaiArray['fareType'] = $via['fare_type'];
                    $vaiArray['flightType'] = $via['flight_type'];
                    $vaiArray['LayoverTime'] = $via['layover_time'];
                    $vaiArray['tripType'] = $via['trip_type'];
                    $vaiArray['totalTime'] = $via['total_time'];
                    $vaiArray['trip'] = $type == 0 ? 'ONWARD' : 'RETURN';
                    $vaiArray['lowFareReason'] = $type == 0 ? $reasonResult[0]['onward_fare_reason'] : $reasonResult[0]['return_fare_reason'];
                    $fareType=$via['fare_type'];
                    $airlineCode=$via['airlineCode'];
                    if ($airlineCode != '') {
                        if($airlineCode=='6E' || $airlineCode=='SG'){
                            if($fareType=='C' || $fareType=='CF' || $fareType=='CF-W')
                                $fareTypeCode='CF';
                            else
                                $fareTypeCode='RF';
                        }
                        else
                           $fareTypeCode =$fareType;     
                    }
                    $requestedData['bookingClass']=$via['booking_class'];
                    $requestedData['cabinClass']=$this->_ItravelClassId;
                    $requestedData['travelMode']=$via['travel_mode_id'];
                    $requestedData['fareType']=$fareTypeCode;
                    fileWrite("PromoBookingClass".$fareTypeCode,"AYPR_FARECHECK".$orderId,"a+");
                    if($airlineInfo[0]['airline_code']=='6E' || $airlineInfo[0]['airline_code']=='SG'){
                        $promoCodes = $this->_OcommonQuery->_discountFareFlightsPromoCode($via['departure_date'],$airlineCode,$_SESSION['corporateId'],$requestedData,'',$orderId);
                        //$promoCodes = $this->_getPromoCode($airlineInfo[0]['airline_code'],$fareTypeCode);
                        if(is_array($promoCodes) && count($promoCodes)>0 && isset($promoCodes['promoCode'])){
                                $vaiArray['promoCode'] = $promoCodes['promoCode'];
                        }                    
                        else{
                            $vaiArray['promoCode'] = '';
                        }
                    }
                    else{
                        $promoCodes = $this->_OcommonQuery->_discountFareFlightsPromoCode($via['departure_date'],$airlineCode,$_SESSION['corporateId'],$requestedData,'',$orderId);
                        //$promoCodes = $this->_getPromoCode($airlineInfo[0]['airline_code'],'');
                        if(is_array($promoCodes) && count($promoCodes)>0 && isset($promoCodes['promoCode'])){
                            $vaiArray['promoCode'] = $promoCodes['promoCode'];
                        }                    
                        else{
                            $vaiArray['promoCode'] = '';                    
                        }
                    }    
                    
                    $vaiArray['serviceProviderId'] = $via['service_provider_id'];
                    $vaiArray['airlineCommission'] = $via['commission'] ? (int) $via['commission'] : (int) 0;
                    
                    //get Fare Info Array by passing via flight id
                    $fareSplitUpArray = $this->_getViaFareSplitUpDateilsByViaFlightId($via['via_flight_id'], $travelModeId);
                    
                    //condition added for not returning empty via fare details as only first via flight will have fare information
                    if (count($fareSplitUpArray) > 0) {
                        if(isset($fareInfoArray) && count($fareInfoArray)>0)
                            $fareInfoArray = array_merge ($fareInfoArray,$fareSplitUpArray);
                        else
                             $fareInfoArray = $fareSplitUpArray;   
                    }
                    unset($vaiArray['fact_air_itinerary_id']);
                    unset($vaiArray['departure_date']);
                    unset($vaiArray['time_departure']);
                    unset($vaiArray['time_arrival']);
                    unset($vaiArray['fare_type']);
                    unset($vaiArray['flight_type']);
                    unset($vaiArray['flight_type']);
                    unset($vaiArray['layover_time']);
                    unset($vaiArray['via_flight_id']);
                    unset($vaiArray['tripType']);
                    unset($vaiArray['total_time']);
                    unset($vaiArray['travel_mode_id']);
                    $returnArray[] = $vaiArray;
                }
            }
        }
        return array('itineraryInfo' => $returnArray, 'fareInfo' => $fareInfoArray, 'clientId' => $clientId);
    }
    
    /*
    * Method Name        : getPromoCodes
    * Desc  	      : To check the corporate is having discount promo codes
    * @access public
    * @param corporateId : Unique id of a corporate
    * @airlineCode		  : Unique code for a Airline eg:('SG','6E','9W'....)
    * @travelDate		  : Travel date of the requested sector
    * @return type		  : array
    */
    private function _getPromoCode($corporateId,$airlineId,$fareTypeId=''){
        $promoFares='EMPTY';
        //discountFareFlights method's input array generation
        if($airlineId!=''){ 
            $todayDate=date('Y-m-d');
            $sqlPromocode="SELECT
                            pcd.marketing_airline_code as airlineCode,
                            pcd.booking_class as bookingClass,  
                            pcm.r_corporate_id as corporateid,
                            pcd.fare_basis_code as fareBasisCode,
                            pcd.promo_code_value as promoCode
                        FROM
                            dm_promo_code pcd 
                            INNER JOIN promo_code_mapping pcm ON pcd.promo_code_id = pcm.r_promo_code_id
                        WHERE
                            pcm.r_promo_code_id=pcd.promo_code_id
                            AND pcm.r_corporate_id=".$corporateId."
                            AND pcd.marketing_airline_code ='".$airlineId."'
                            AND pcm.status='Y'
                            AND  '".$todayDate."' between pcd.start_date and pcd.end_date";
            if($fareTypeId!=''){
                $sqlPromocode.=" AND pcd.fare_type='".$fareTypeId."'";
            }
            $sqlPromocode.="  ORDER BY pcd.promo_code_id ASC";
            $result =  $this->_OcommonDBO->_getResult($sqlPromocode);

            if(!$result){                     
                fileWrite('Error in query:'.$sqlPromocode, 'SqlError', 'a+');
            } 
            else 
            {
                $promoFares=$result; 
            } 
        }
        return $promoFares;
    }

   /* @Description get via fare splitup details
    * @param array,int: $viaFlightId,$travelModeId
    * @return array : $response
    */
    private function _getViaFareSplitUpDateilsByViaFlightId($viaFlightId,$travelModeId){
        
        $response = array();        
        //get viaflight id from via fare id
        $result = $this->_OflightItinerary->_getViaFareIdByViaFlightId($viaFlightId);
        foreach($result as $res){
            $splitupResponse = $this->_getViaFareSplitUpDateils($res['via_fare_id'], $travelModeId);   
            if(!$splitupResponse && $res['passenger_type'] == '2'){
                $splitupResponse['itinerayId'] = $res['r_via_flight_id'];
                $splitupResponse['passengerType'] = 'INF';
                $splitupResponse['serviceTax'] = 0;
                $splitupResponse['tax'] = 0;
                $splitupResponse['baseFare'] = $res['base_fare'];
                $splitupResponse['fare_basis_code'] = $res['fare_basis_code'];
            } 
            if(is_array($splitupResponse) && count($splitupResponse)>0){
                $response[]=$splitupResponse;
            }
        }
        return $response;
    }
    
   /* @Description get via fare splitup details
    * @param int,int: $viaFareId, $travelModeId
    * @return array : $result
    */
    private function _getViaFareSplitUpDateils($viaFareId, $travelModeId){

        $result = $this->_OflightItinerary->_getSplitupForViaFareId($viaFareId, $travelModeId);
        return $result;
    }

    /**
     * Get passengers details
     * @param int $orderId Order id
     * @param string $expenseBourne Expense bourne(official/personal)
     * @param int $travelModeId Travel mode id
     * @return array
     */
    private function _getPassengerInfo($orderId, $expenseBourne,$travelModeId,$bookingType = '') {
         
        $passengerDetailsArray = $this->_Opassenger->_getAllPassengerDetailsByOrderId($orderId);

        // call only if travel mode is international
        if($travelModeId == SELF::INTERNATIONAL_AIR_MODE_ID){
            //$passportDetails = $this->_Opassenger->_getPassengerPassportDetails(array('orderId'=>$orderId));
            $passportDetails = $this->_getPassengerPassportDetails($orderId);
        }
        $returnArray = array();
        $i = 0;
        foreach ($passengerDetailsArray as $res) {
            $returnArray[$i]['passengerId'] = (int) $res['passenger_id'];
            $returnArray[$i]['salutation'] = $res['title'];
            $returnArray[$i]['firstName'] = $res['first_name'];
            $returnArray[$i]['lastName'] = $res['last_name'];
            $returnArray[$i]['passengerType'] = $res['passenger_type'];
            $returnArray[$i]['projectCode'] = $res['project_code'];
            $returnArray[$i]['r_employee_id'] = $res['r_employee_id'];

            $returnArray[$i]['companyCode'] = $this->_getDivison($res['employee_code'])[
            'company_code'];

            $returnArray[$i]['employeeCode'] = $res['employee_code'] !='FAMILY'?$res['employee_code']:$this->db->_select('dm_employee','employee_code','employee_id',$_SESSION['employeeId'])[0]['employee_code'] ;
            $returnArray[$i]['expenseBorne'] = $expenseBourne;
            
            $returnArray[$i]['division'] = $this->_getDivison($res['employee_code'])['division'];
            $returnArray[$i]['designation'] = $res['designation'];
            $returnArray[$i]['adharCardNumber'] = $res['aadhar'];
            
            $returnArray[$i]['age'] = $this->_getEmployeeAgeDetails($res['employee_code'],$res['passenger_id']); //$res['age'];

            $returnArray[$i]['DOB'] = $res['DOB'];
            //booking mode for personal
            $returnArray[$i]['emailId'] = ($res['passenger_type'] != 'ADT') ? $passengerDetailsArray[0]['email_id'] : $res['email_id'];
            if( $bookingType == 0 && $returnArray[$i]['emailId']==''){
                $returnArray[$i]['emailId'] = ($res['passenger_type'] == 'ADT') ? $passengerDetailsArray[0]['email_id'] : $res['email_id'];
            }

            $returnArray[$i]['mobileNumber'] = ($res['passenger_type'] != 'ADT') ? $passengerDetailsArray[0]['mobile_no'] :  $res['mobile_no'];
            if( $bookingType == 0 && $returnArray[$i]['mobileNumber']==''){
                $returnArray[$i]['mobileNumber'] = ($res['passenger_type'] == 'ADT') ? $passengerDetailsArray[0]['mobile_no'] : $res['mobile_no'];
            }

            $returnArray[$i]['department'] = $res['department'];
            $returnArray[$i]['location'] = $res['location'];            
            $returnArray[$i]['country'] = $res['country'];
            $returnArray[$i]['city'] = $res['city'];
            $returnArray[$i]['address'] = $res['location'];
            $returnArray[$i]['pin_code'] = $res['pin_code'];
            $returnArray[$i]['contact_no'] = $res['contact_no'];
            $returnArray[$i]['parent_infant_id'] = $res['infantParentId'];
            $returnArray[$i]['familyAssocType'] = $res['familyAssocType'];
            $returnArray[$i]['childAssocNumber'] = $res['childAssocNumber'] == 0 ? '' : '0'.$res['childAssocNumber'];
            if($travelModeId == SELF::INTERNATIONAL_AIR_MODE_ID){
                $returnArray[$i]['passportInfo']['passportNo'] = $passportDetails[$res['passenger_id']]['number'];
                $returnArray[$i]['passportInfo']['passportPlace'] = $passportDetails[$res['passenger_id']]['place'];
                $returnArray[$i]['passportInfo']['passportCountry'] = $passportDetails[$res['passenger_id']]['country'];
                $returnArray[$i]['passportInfo']['passportIssuedate'] = $passportDetails[$res['passenger_id']]['issuedate'];
                $returnArray[$i]['passportInfo']['passportExpirydate'] = $passportDetails[$res['passenger_id']]['expirydate'];
                $returnArray[$i]['passportInfo']['passportDOB'] = $passportDetails[$res['passenger_id']]['dob'];
                $returnArray[$i]['passportInfo']['passportAddress1'] = $passportDetails[$res['passenger_id']]['address'];
                $returnArray[$i]['passportInfo']['passportAddress2'] = $passportDetails[$res['passenger_id']]['address_two'];
                $returnArray[$i]['passportInfo']['pincode'] = $passportDetails[$res['passenger_id']]['pincode'];
            }else{
                $returnArray[$i]['passportInfo']="";
            }
            $i++;
        }
        return $returnArray;
    }

   /* @Description get passenger ssr info
    * @param int: $orderId
    * @return array : $returnArray
    */
    private function _getPassengerSSRInfo($orderId){

        $mealCodeValueArray = $this->_getMealCodeValues();
        $seatCodeValueArray = $this->_getSeatCodeValues();
        $baggageCodeValueArray = $this->_getBaggageCodeValues();

        $passengerSSRDetails = $this->_OpassengerPreferences->_getSSRpreferencesFareDetails($orderId);

        $returnArray = array();

        foreach ($passengerSSRDetails as $res){
            $returnArray[$res['r_via_flight_id'] . $res['r_passenger_id']]['passengerId'] = $res['r_passenger_id'];
            $returnArray[$res['r_via_flight_id'] . $res['r_passenger_id']]['itineraryId'] = $res['r_via_flight_id'];
            $frequentFlyerDetails = $this->_OpassengerPreferences->_getFlightPassengerFrequentFlyerDetails($res['r_passenger_id'],$res['r_via_flight_id']);
            $returnArray[$res['r_via_flight_id'] . $res['r_passenger_id']]['frequentFlyerNo']=$frequentFlyerDetails[0]['number'];
                
            switch ($res['preferences_type']) {

                case 'seat':
                    $returnArray[$res['r_via_flight_id'] . $res['r_passenger_id']]['additionalssrInfo']['SEAT']['type'] = $seatCodeValueArray[$res['preferences_value_id']];
                    $returnArray[$res['r_via_flight_id'] . $res['r_passenger_id']]['additionalssrInfo']['SEAT']['fare'] = $res['ssr_preferences_fare'];
                    $returnArray[$res['r_via_flight_id'] . $res['r_passenger_id']]['additionalssrInfo']['SEAT']['jsonValue'] = $res['ssr_preferences_value'];
                    break;

                case 'meal':
                    $returnArray[$res['r_via_flight_id'] . $res['r_passenger_id']]['additionalssrInfo']['MEAL']['type'] = $mealCodeValueArray[$res['preferences_value_id']];
                    $returnArray[$res['r_via_flight_id'] . $res['r_passenger_id']]['additionalssrInfo']['MEAL']['fare'] = $res['ssr_preferences_fare'];
                    $returnArray[$res['r_via_flight_id'] . $res['r_passenger_id']]['additionalssrInfo']['MEAL']['jsonValue'] = $res['ssr_preferences_value'];
                    break;

                case 'baggage':
                    $returnArray[$res['r_via_flight_id'] . $res['r_passenger_id']]['additionalssrInfo']['BAGGAGE']['type'] = $baggageCodeValueArray[$res['preferences_value_id']];
                    $returnArray[$res['r_via_flight_id'] . $res['r_passenger_id']]['additionalssrInfo']['BAGGAGE']['fare'] = $res['ssr_preferences_fare'];
                    $returnArray[$res['r_via_flight_id'] . $res['r_passenger_id']]['additionalssrInfo']['BAGGAGE']['jsonValue'] = $res['ssr_preferences_value'];
                    break;
            }
        }
        $returnArray = array_values($returnArray);
        return $returnArray;
    }
    
   /* @Description get meal code values
    * @param int: $orderId
    * @return array : $returnValue
    */
    private function _getMealCodeValues(){
        $sql = "select * from dm_meal_code_details";
        $result = $this->db->_getResult($sql);
        $returnValue = array_column($result, 'meal_description', 'meal_code_id');
        return $returnValue;
    }

   /* @Description get seat code values
    * @param int: $orderId
    * @return array : $returnValue
    */
    private function _getSeatCodeValues(){
        $sql = "select * from dm_seat_code_details";
        $result = $this->db->_getResult($sql);
        $returnValue = array_column($result, 'seat_code', 'seat_code_id');
        return $returnValue;
    }

    /* @Description get seat code values
    * @param int: $orderId
    * @return array : $returnValue
    */
    private function _getBaggageCodeValues(){
        $sql = "select * from dm_baggage_code_details";
        $result = $this->db->_getResult($sql);
        $returnValue = array_column($result, 'baggage_description', 'baggage_code_id');
        return $returnValue;
    }

   /* @Description get order details info
    * @param int: $orderId
    * @return array : $returnValue
    */
    private function _getOrderDetails($orderId){
        $sql = "SElECT * FROM order_details where order_id = " . $orderId . "";
        $result = $this->db->_getResult($sql);
        return $result;
    }

    /**
     * insert order gst splitup mapping
     * @param type $gstData
     * @param type $orderId
     */
    public function _insertGstSplitUpForOrder($gstData,$orderId,$gstType=0){
        
        global $CFG;
        
        //get gst order mapping info
        $gst_order_mapping_id = $this->db->_select('gst_order_mapping','gst_order_mapping_id','order_id',$orderId);
        fileWrite(print_r($gst_order_mapping_id,1),"gstSplitupOrderInfo","a+");      
        
        //insert into the gst_splitup_order_mapping
        //for onward
        if(isset($gstData['onward']) && count($gstData['onward']) > 0){  
            //get the gst splitup order mapping
            $gstSplitupOrderMapping = $this->_getGSTSplitupOrderMapping($gst_order_mapping_id[0]['gst_order_mapping_id'],$gstType);
            $insertId = $this->_insertUpdateGSTSplitupMapping($gstData['onward'],$gst_order_mapping_id[0]['gst_order_mapping_id'],$gstType,$gstSplitupOrderMapping);
        }
        //for return
        if(isset($gstData['return']) && count($gstData['return']) > 0){
            //get the gst splitup order mapping
            $gstSplitupOrderMapping = $this->_getGSTSplitupOrderMapping($gst_order_mapping_id[1]['gst_order_mapping_id'],$gstType);
            $insertId = $this->_insertUpdateGSTSplitupMapping($gstData['return'],$gst_order_mapping_id[1]['gst_order_mapping_id'],$gstType,$gstSplitupOrderMapping);
        }
        return $insertId;
    }    
    
    /**
    * insert order gst splitup mapping
    * @param type $gstData
    * @param type $orderId
    */
    public function _insertUpdateGSTSplitupMapping($gstData,$gstOrderMapId,$gstType,$gstSplitupOrderMapping){
        
        global $CFG;
        $insertArray = array();
        
        foreach($gstData as $key => $value){
            //set an array
            $insertArray['gst_order_mapping_id']   = $gstOrderMapId;
            $insertArray['gst_tax_splitup_id']     = $this->db->_select('gst_tax_splitup_master','gst_tax_splitup_id','gst_tax_splitup_name',$value['taxName'])[0]['gst_tax_splitup_id'];
            $insertArray['passenger_type']         = $CFG['paxType'][$value['passengerType']];
            $insertArray['gst_tax_splitup_amount'] = $value['taxAmount'];
            $insertArray['gst_type']               = $gstType;
            if(!$gstSplitupOrderMapping){
                $result[] = $this->db->_insert('gst_splitup_order_mapping', $insertArray);
            }
            else{
                $result[] = $this->db->_update('gst_splitup_order_mapping', $insertArray,'gst_splitup_order_mapping_id',$gstSplitupOrderMapping[$key]['gst_splitup_order_mapping_id']);
            }
        }
        return $result;
    }
    
    /* @Description get gst splitup order mapping info
    * @param int: $gstOrderMappingId,$gstType
    * @return array : $returnValue
    */
    public function _getGSTSplitupOrderMapping($gstOrderMappingId,$gstType = ''){        
        
        $sql = "SELECT * FROM gst_splitup_order_mapping WHERE gst_order_mapping_id IN (".$gstOrderMappingId.")";
        
        //add gst type.
        ($gstType != '') ? $sql .= " AND gst_type = ".$gstType : '';
        fileWrite($sql,"gstSplitupOrderInfo","a+");
        return $this->db->_getResult($sql);
    }
    
   /**
    * Update the request details after fullfilment
    * @param type array 
    */    
    public function _updateFullfilmentData($fullfilmentDetails){
        //object creation.
        $this->_errorHandlingObj = new errorHandling();      
        
        // check sync id updation in case of server error
        $this->_checkSyncOrderIdExits($fullfilmentDetails["orderId"]);

        //checking the via flight details array is present or not.
        if(isset($fullfilmentDetails['viaFlights']) && count($fullfilmentDetails['viaFlights']) > 0){
            
            //calling function for to check whether the pnr is comes in the request.
            $pnrStatus = $this->_checkPNRStatus($fullfilmentDetails['viaFlights']);  
            if($pnrStatus == 'Y'){  
                //get order info.
                $orderArray = array('order_id', 'total_amount');
                $syncOrderId = isset($fullfilmentDetails["syncOrderId"]) ? $fullfilmentDetails["syncOrderId"] : $fullfilmentDetails["orderId"];
                
                //get order id with respect to the sync order id.
                $orderSyncDetails = $this->_Opackage->_getOrderDetailsForGivenInput($orderArray, 'sync_order_id', $syncOrderId);
                //order id.
                if(isset($orderSyncDetails[0]['order_id']) && $orderSyncDetails[0]['order_id'] != ''){

                    //update ticket status in order_details table
                    $orderId = $orderSyncDetails[0]['order_id'];
                    $orderDetails['r_ticket_status_id'] = TICKETTED;
                    $this->_Opackage->_updateOrderDetails($orderDetails, $orderId);
                     
                    //update passenger_via_details.
                    $this->_updateAirData($fullfilmentDetails['viaFlights'], $orderId);

                    // update orgin destination flight details with travel date
                    if(isset($fullfilmentDetails['sectorDetails'])){
                        $this->_updateFullFiledFlightData($fullfilmentDetails['viaFlights'],$orderId,$fullfilmentDetails['sectorDetails']);
                    }


                    //update via_flight_details.
                    $this->_updateViaFlightTerminalDetails($fullfilmentDetails['viaFlights'][0]);

                    //store via_flight_pnr_details.
                    //$this->_updateViaFlightPNRDetails($fullfilmentDetails['viaFlights'][0]);

                    //insert the GST details.
                    $this->_insertGstSplitUpForOrder($fullfilmentDetails['GST'], $orderId);
                    if(isset($fullfilmentDetails['agentGST'])){
                        $this->_insertGstSplitUpForOrder($fullfilmentDetails['agentGST'], $orderId,$agencyGst=1);
                    }
                    
                    //set invoice id.
                    $invoiceDetails['sync_invoice_id'] = $fullfilmentDetails['invoiceId'];

                    //Get the package id for the input booking id
                    $bookingPersonDetails = $this->_Opackage->_getBookingPersonInfo($orderId);
                    $bookingCorporateId = $bookingPersonDetails[0]['r_corporate_id'];
                    $packageId = $bookingPersonDetails[0]['r_package_id'];

                    //Get the travel mode id for the package
                    $packageDetails = $this->_Opackage->_getPaymentCompletedPackageDetails($packageId);
                    $invoiceDetails['invoice_type_id'] = $packageDetails[0]['r_travel_mode_id'];

                    //Get billto id for the booking corporate
                    $billToDetails = $this->_OcorporateSettings->_getBillToMapping($bookingCorporateId, 0, '', 'Y');
                    $invoiceDetails['r_billto_id'] = $billToDetails[0]['billto_id'];
                    $invoiceDetails['created_date'] = date("Y-m-d H:i:s");

                    //Insertion of Invoice Details
                    $factInvoiceId = $this->db->_select('fact_booking_details','r_invoice_id','r_order_id',$orderId)[0]['r_invoice_id'];
                    fileWrite("InvoiceId".$factInvoiceId,"gstSplitupOrderInfo","a+");
                    if($factInvoiceId == 0 || $factInvoiceId == ''){   
                        fileWrite("INSERT".print_r($invoiceDetails,1),"gstSplitupOrderInfo","a+");
                        $invoiceId = $this->_Oinvoice->_insertInvoice($invoiceDetails);
                        $factBookingDetails['r_invoice_id'] = $invoiceId;

                        //Updation of invoice id in fact_booking_details table
                        $factUpdate = $this->_Opackage->_updateFactBookingWithOrderId($factBookingDetails, $orderId);
                    }
                    else{
                        unset($invoiceDetails['created_date']);
                        fileWrite("UPDATE".print_r($invoiceDetails,1),"gstSplitupOrderInfo","a+");
                        $invoiceIdInfo = $this->_Oinvoice->_updateInvoice($invoiceDetails,$factInvoiceId);
                        $invoiceId = $factInvoiceId;
                    }

                    //Update SAP Request id
                    if(isset($fullfilmentDetails['sapRequestId']) && $fullfilmentDetails['sapRequestId']!=''){
                        $this->_updateSAPDetails(array('orderId' => $orderId, 'sapRequestId' => $fullfilmentDetails['sapRequestId']));
                    }
                    
                    //update fare details at the time of fare increase.
                    if(isset($fullfilmentDetails['fareDetails']) && count($fullfilmentDetails['fareDetails']) > 0){
                        $this->_OfareDetails = new fareDetails();
                        $this->_OfareDetails->_updateChangedViaFareDetails($fullfilmentDetails['fareDetails'],$orderId);
                    }
                    // functionality to check booking block email and sms
                    $blockEMAILSMS = true;
                    $explodeEmail = explode(',', BLOCK_EMAIL_BALMER);
                    fileWrite('Booking Re sms'.print_r($explodeEmail,1),'BLOCKEMAIL','a+');
                    fileWrite('Booking Re sms $packageDetails '.print_r($packageDetails[0]['requested_by'],1),'BLOCKEMAIL','a+');
                    if(in_array($packageDetails[0]['requested_by'], $explodeEmail)){
                        $blockEMAILSMS = false ;
                        fileWrite('Booking if sms'.print_r($blockEMAILSMS,1),'BLOCKEMAIL','a+');
                    }
                    fileWrite('Booking if sms after if'.print_r($blockEMAILSMS,1),'BLOCKEMAIL','a+');
                    //checking remainder mail setting  and  storing  the reminder mail in mail_log
                    $settingsSMSArray = $this->_OcommonQuery->_getSettingsDisplayData($packageId,'SMS/Email');
                    filewrite('inside if condition=>'.print_r($settingsSMSArray,1),'RemainderMail');
                    if($settingsSMSArray['Email']['status']=='Y' && array_search('Y',$settingsSMSArray['Remainder_Mail']) && $blockEMAILSMS){
                        $this->_OreminderMail->_reminderEmail($syncOrderId,$settingsSMSArray);
                    }
                    
                    // setting the flag to send sms based on email id scenarion
                    //to call and get sms setting from fare profile settings array
                    if($blockEMAILSMS){
                        
                        $this->_OsendSms->_smsDetailsFormation($orderId,'BOOKING',$cancellationAmount,$settingsSMSArray);
                        //to sending  the Eticket to the passenger
                        $this->_sendEticketToPassenger($orderId);
                        //send mail to controlling officer
                        //$this->_sendMailControllingOfficer($orderId);
                    }

                    //get eticket Bl reference number.
                    $eTicketReferenceInfo = $this->_Oeticket->_getRefNoBasedOrderId($orderId);

                    // Mobile Notification Process
                    fileRequire('plugins/service/corporate/classes/class.notification.php');
                    $notification = new notification();
                    $notification->_sendNotification('ETICKET', $orderId, $packageId);                            

                    fileWrite('BEFORE'.$packageId, 'SMS_SEND','a+');
                    $detailsArray = array('order_id' => $orderId, 'orderIdColumn' => $orderId, 'package_id' => $packageId, 'packageType' => $packageDetails[0]['package_type'], 'invoice_id' => $invoiceId);

                    //set eticket additional details.
                    (($eTicketReferenceInfo) && count($eTicketReferenceInfo) > 0)  ? $detailsArray['eTicketReference'] = $eTicketReferenceInfo :'';
                    $response = $this->_OapprovalProcess->_sapUpdateApproveReject($orderId);
                    return array('response' => 'SUCCESS', 'data' => '', 'details' => $detailsArray);    
                }
                else{
                    return $this->_errorHandlingObj->_setErrorMsg($fullfilmentDetails,'air booking fullfilment sync error','requested sync order id not exist.');
                }                
            }
            else{
                return $this->_errorHandlingObj->_setErrorMsg($fullfilmentDetails,'air booking fullfilment sync error','pnr not found');
            }
        }
        else{
            return $this->_errorHandlingObj->_setErrorMsg($fullfilmentDetails,'air booking fullfilment sync error','via flight details not found');
        }
        
    }

    public function _checkSyncOrderIdExits($orderId){

        $syncOrderId = $this->_OcommonDBO->_select('order_details','sync_order_id','order_id',$orderId)[0]['sync_order_id'];

        if($syncOrderId == 0){

            $packageId = $this->_OcommonDBO->_select('booking_history','package_id','order_id',$orderId)[0]['package_id'];
            $requestData['orderId'] = $orderId;
            $methosName = 'reSyncAirFullfillment';
            $response = $this->_callBookingSyncMethod($requestData,$methosName,$packageId);
        }

        return true;
    }
    
    /* @FunctionName    :   _checkPNRStatus()
    *  @Description     :   This function is used to check whether the pnr is comes in the request.
    *  @param           :   $fullfilmentViaDetails| array
    *  @author          :   Karthika.M
    *  @date            :   24-01-2018 
    */
    public function _checkPNRStatus($fullfilmentViaDetails){
        //array declaration.
        $pnrStatus = array();
        //check whether the pnr is come or not.
        foreach($fullfilmentViaDetails as $paxViakey => $paxViaValue){
            $pnrInfo =  array_column($paxViaValue,'pnr');
            if(count($pnrInfo) > 0){
                $pnrStatus[] = in_array('',$pnrInfo) ? 'N' : 'Y';      
            }
            else{
                $pnrStatus[] = 'N';
            }
        }            
        return in_array('N',$pnrStatus) ? 'N' : 'Y';        
    }
    
    /**
     * Updates SAP Request id for an order
     * @param array $sapDetails SAP Request details
     * @return array
     */
    public function _updateSAPDetails($sapDetails) {
        //Check for the availability of order id
        if(!isset($sapDetails['packageId']) || $sapDetails['packageId']==''){
            return array('response' => 'FAILED', 'data' => 'packageId not available', 'details' => 'SAP Request id not updated');
        }
        //Check for the availability of sap id
        if(!isset($sapDetails['SAPRequestId']) || $sapDetails['SAPRequestId']==''){
            return array('response' => 'FAILED', 'data' => 'SAPRequestId not available', 'details' => 'SAP Request id not updated');
        }
        //Check for the order id
        $selectValues = $this->db->_select('sap_request_details', 'r_package_id', 'r_package_id', $sapDetails['packageId']);
        if(!$selectValues){
            return array('response' => 'FAILED', 'data' => 'Invalid orderId', 'details' => 'SAP Request id not updated');
        }
        
        $result = $this->db->_update('sap_request_details', array('sap_request_id'=>$sapDetails['SAPRequestId']), 'r_package_id', $sapDetails['packageId']);
        $sequenceArray = array('r_package_id' => $sapDetails['packageId'], 'r_order_id' => $sapDetails['orderId'], 'onward_sequence_no' => $sapDetails['sequenceNo'], 'return_sequence_no' => isset($sapDetails['returnSequenceNo'])?$sapDetails['returnSequenceNo']:'');
        $insertId = $this->db->_insert('sap_sequence_details', $sequenceArray);

        return array('response' => 'SUCCESS', 'data' => '', 'details' => 'SAP Request id updated successfully');
    }


   /* @Description get bill to address
    * @param int: $orderId
    * @return array : $returnValue
    */
    private function _getBilltoAddress($orderId){

        $sql = "SELECT billto_name,billto_state_id FROM dm_billto_mapping dbm INNER JOIN order_details od ON dbm.billto_id = od.r_billto_id
                WHERE order_id = " . $orderId . "";
        $result = $this->db->_getResult($sql);
        return $result;
    }

   /* @Description update the sync details
    * @param array: $syncResponseData
    * @return array : $returnValue
    */
    private function _updateSyncDetails($syncResponseData){

        foreach ($syncResponseData as $orderId => $orderDetails){
            //1. update sync order id in order_details table
            //$syncOrderData = array('sync_order_id' => $orderDetails['syncOrderInfo']['syncOrderId']);
            $syncOrderData = array('sync_order_id' => $orderDetails['syncOrderId']);
            $this->_Opackage->_updateOrderDetails($syncOrderData, $orderId);
            $this->db->_update('booking_history', $syncOrderData, 'order_id', $orderId);

            //2. update sync_via_flight_id
            //$this->_OflightItinerary->_updateViaFlightSync($orderDetails['syncItineraryInfo']);
            $this->_OflightItinerary->_updateViaFlightSync($orderDetails['itineraryInfo']);
            //3. update sync passenger_id
            //$this->_Opassenger->_updatePassengerSync($orderDetails['syncPassengerInfo']);
            $this->_Opassenger->_updatePassengerSync($orderDetails['passengerInfo']);
        }
    }

   /* @Description update the air details
    * @param array,int: $fullfilmentDetails,$orderId
    */
    private function _updateAirData($fullfilmentDetails, $orderId){
        foreach ($fullfilmentDetails as $paxKey => $paxVia) {
            foreach ($paxVia as $viaKey => $passengerVia) {
                $this->_OflightItinerary->_passengerViaDetailsUpdate($passengerVia, $passengerVia['passenger_id'], $passengerVia['via_flight_id'], $orderId);
            }
        }
    }

     /* @Description update the air details
    * @param array,int: $fullfilmentDetails,$orderId
    */
    private function _updateFullFiledFlightData($fullfilmentDetails, $orderId,$sectorDetails){

        foreach ($fullfilmentDetails as $paxKey => $paxVia) {
            foreach ($paxVia as $viaKey => $passengerVia) {
                $vaiArray = array();
                $vaiArray['r_origin_airport_id'] = $this->_OcommonDBO->_select('dm_airport','*','airport_code', $passengerVia['origin'])[0]['airport_id'];
                $vaiArray['r_destination_airport_id'] = $this->_OcommonDBO->_select('dm_airport','*','airport_code', $passengerVia['destination'])[0]['airport_id']; 
                $vaiArray['arrival_date'] = $passengerVia['arrival_date'];
                $vaiArray['time_arrival'] = $passengerVia['arrival_time'];
                $vaiArray['departure_date'] = $passengerVia['departure_date'];
                $vaiArray['time_departure'] = $passengerVia['departure_time'];
                $vaiArray['r_airline_id'] = $this->_OcommonDBO->_select('dm_airline','*','airline_code', $passengerVia['airline_code'])[0]['airline_id'];
                $vaiArray['flight_no'] = $passengerVia['flight_no'];
                 //calling update method
                $result = $this->_OcommonDBO->_update('via_flight_details', $vaiArray, 'via_flight_id', $passengerVia['sync_itinerary_id']);

                $passengerArray = array();
                $passengerArray['passenger_title'] = $passengerVia['passenger_title'];
                $passengerArray['first_name'] = $passengerVia['passenger_first_name'];
                $passengerArray['last_name'] = $passengerVia['passenger_last_name'];
                $passengerArray['passenger_type'] = $passengerVia['passenger_type'];
                $passengerArray['email_id'] = $passengerVia['emailid'];

                //calling update method
                $result = $this->_OcommonDBO->_update('passenger_details',$passengerArray,'passenger_id', $passengerVia['sync_passenger_id']);
            }
        }
        // update sector in air request Details
        $airReques = array();
        $airReques['r_origin_airport_id'] = $this->_OcommonDBO->_select('dm_airport','*','airport_code', $sectorDetails[0]['origin_id'])[0]['airport_id'];
        $airReques['r_destination_airport_id'] = $this->_OcommonDBO->_select('dm_airport','*','airport_code', $sectorDetails[0]['destination_id'])[0]['airport_id'];
        $airReques['onward_date'] = $sectorDetails[0]['departureDate'];
        $airReques['return_date'] = $sectorDetails[1]['departureDate'] ? $sectorDetails[1]['departureDate'] : '0000-00-00'; 
        $airRequestId = $this->_OcommonDBO->_select('fact_booking_details','*','r_order_id', $orderId)[0]['r_request_id'];
        $result = $this->_OcommonDBO->_update('air_request_details',$airReques,'air_request_id', $airRequestId);
        // booking history update
        $bookingHis = array();
        $bookingHis['sector_from'] =  $sectorDetails[0]['origin_id'];
        $bookingHis['sector_to'] =  $sectorDetails[0]['destination_id'];
        $bookingHis['onward_depature_date'] = $sectorDetails[0]['departureDate'].' '.$sectorDetails[0]['departureTime'].':00';
        $bookingHis['onward_arrival_date'] = $sectorDetails[0]['arrivalDate'].' '.$sectorDetails[0]['arrivalTime'].':00';
        $bookingHis['return_depature_date'] ='0000-00-00 00:00:00';
        $bookingHis['return_arrival_date'] = '0000-00-00 00:00:00';
        if($sectorDetails[1]){
           $bookingHis['return_depature_date'] = $sectorDetails[1]['departureDate'].' '.$sectorDetails[1]['departureTime'].':00';
           $bookingHis['return_arrival_date'] = $sectorDetails[1]['arrivalDate'].' '.$sectorDetails[1]['arrivalTime'].':00';
        }
        $result = $this->_OcommonDBO->_update('booking_history',$bookingHis,'order_id', $orderId);
        return true;
    }

   /* @Description update the via flight terminal details
    * @param array: $viaFlightData
    */
    private function _updateViaFlightTerminalDetails($viaFlightData){
        foreach ($viaFlightData as $viakey => $viavalue) {
            $this->_OflightItinerary->_viaTerminalDetailsUpdate($viavalue, $viavalue['via_flight_id']);
        }
    }

   /* @Description update the via flight terminal details
    * @param array: $_Arequest
    */
    public function _updateItinerary($_Arequest){

        if(isset($_Arequest['viaFlight'])){

            //changing key name itineraryId to syncItineraryId
            $_Arequest['viaFlight'] = json_decode(str_replace("itineraryId", "syncItineraryId", json_encode($_Arequest['viaFlight'], true)), true);

            //calling method to update via flight details
            $this->_OflightItinerary->_updateViaFlightSync($_Arequest['viaFlight']);
            return true;
        }
        return false;
    }

    /*
     * get the passport details for backend sync
     * @param type $orderId
     * @return type
     * @Author :- Vishwa Raj
     */
    public function _getPassengerPassportDetails($orderId){
        $passportFinalDataSet = array();
        // get passengerswith respect to order id
        $passengers = $this->db->_select("passenger_details","*","r_order_id",$orderId);
        // get the details of the passengers with respect to guest and employee with passengerId as the key from (NOTE:-)"passenger_details"
        foreach ($passengers as $key => $value) {
                $passengerId = $value['passenger_id'];
                if($value['employee_code'] != 'GUEST'){
                    $employee_id = $value['r_employee_id'];
                    $passData = $this->_Opassenger->_getPassengerPassportDetailsData($employee_id,'employee');
                    $passportFinalDataSet[$passengerId] = $passData[0];
                }else{
                    $passengerId = $value['passenger_id'];
                    $passData = $this->_Opassenger->_getPassengerPassportDetailsData($passengerId,'GUEST');
                    $passportFinalDataSet[$passengerId] = $passData[0];
                }
            }
        return $passportFinalDataSet;
    }
  
   /* @FunctionName    :   _sendEticketToPassenger()
    * @Description     :   function used to send eticket to all passenger.
    * @param           :   $orderId| int
    */
    //function used to send eticket to all passenger for balmer lawrie.
    public function _sendEticketToPassenger($orderId, $additionalEmailId=''){      

        fileWrite('inside harinim eticket-'.'orderid:'.$orderId,'debug', 'a+');
        //sets inputs
        $input['order_id'] = $orderId;
        $packageDetails        = $this->_Opackage->_getPaidPackageDetails('','','',$orderId);
        
        $input['package_type'] = $packageDetails[0]['package_type']; 
        $input['package_id'] = $packageDetails[0]['package_id']; 
        $input['r_travel_mode_id'] = $packageDetails[0]['r_travel_mode_id'];
        
        //function used to mail eticket to all passengers.
        return $this->_Oeticket->_sendEticketToPassenger($input, $additionalEmailId);        
    }
  
   /* @FunctionName    :   _corpSendRefundAmountToPax()
    * @Description     :   function used to send recend mail to passenger for corporate
    * @param           :   $orderId| int
    */  
   public function _corpSendRefundAmountToPax($cancelInfo,$_IorderId,$reciepientEmail){
        
        fileWrite("---------- " .print_r($cancelInfo,1),"cancelRefundAmountMail","a+");  
        
        //looping the cancelInfo.
        foreach($cancelInfo as $paxId => $paxCancelInfo){
            
            $totalRefundAmount = 0;
            $totalCancellationCharges = 0;
            $pnrInfo = array();
            foreach($paxCancelInfo as $itineraryId => $refundAmountInfo){
                $totalRefundAmount += $refundAmountInfo['refundAmount'];
                $totalCancellationCharges += $refundAmountInfo['cancellationCharges'];
                $pnrInfo[] = $refundAmountInfo['pnr'];
            }            
            fileWrite($totalCancellationCharges.'-'.$paxId."TOTAL".$totalRefundAmount,"cancelRefundAmountMail","a+");
            
            //get the pax info.
            $paxInfo = $this->_OcommonDBO->_select("passenger_details","*","passenger_id",$paxId)[0];
            if($paxInfo['passenger_type'] == 'ADT'){         
            
                //removes duplicates,
                $pnrInfo = array_unique($pnrInfo);
                $pnrInfo = array_values($pnrInfo);

                //form string
                $pnrString = implode(",", $pnrInfo); 

                //forming the mail template and send to pax.
                $mailResponse[] =  $this->_sendRefundMail($paxInfo,$totalRefundAmount,$totalCancellationCharges,$pnrString,$_IorderId,$pnrInfo,'',$reciepientEmail);
            }
        }   
        return $mailResponse;
    }

    
   /* @FunctionName    :   _personalSendRefundAmountToPax()
    * @Description     :   function used to send recend mail to passenger for personal booking
    * @param           :   $orderId| int
    */ 
    public function _personalSendRefundAmountToPax($cancelInfo,$_IorderId,$reciepientEmail){
        $totalRefundAmount = 0;
        $totalCancellationCharges = 0;
      //looping the cancelInfo.
        foreach($cancelInfo as $paxId => $paxCancelInfo){
            $pnrInfo = array();
            foreach($paxCancelInfo as $itineraryId => $refundAmountInfo){
                $totalRefundAmount += $refundAmountInfo['refundAmount'];
                $totalCancellationCharges += $refundAmountInfo['cancellationCharges'];
                $pnrInfo[] = $refundAmountInfo['pnr'];
                $paxIds[] =  $paxId;
            }            
        }
            
            //removes duplicates,
            $pnrInfo = array_values(array_unique($pnrInfo));
            //form string
            $pnrString = implode(",", $pnrInfo); 

             //get passenger Details 
            $sql = "SELECT * FROM passenger_details WHERE passenger_id IN(".implode(',', $paxIds).")";
            $paxViaInfo = $this->_OcommonDBO->_getResult($sql);

            //pax details
            $paxInfo = $paxViaInfo[0];
            //get pax names
            foreach($paxViaInfo as $key => $value){ 
             $paxNames[] = $value['title'].'. '.$value['first_name'].' '.$value['last_name'];
            }

       $mailResponse[] =  $this->_sendRefundMail($paxInfo,$totalRefundAmount,$totalCancellationCharges,$pnrString,$_IorderId,$pnrInfo,$paxNames,$reciepientEmail);
       return $mailResponse;
    }



    //function used to send refund amount details to all passenger while auto cancellation for balmer lawrie.
    public function _sendRefundAmountToPax($cancelInfo,$_IorderId,$reciepientEmail){
         $bookingType = $this->_OcommonDBO->_select("booking_history","booking_type","order_id",$_IorderId)[0]['booking_type'];
        
          //0 - pesonal 1-corporate 
         if($bookingType == 0){
             $this->_personalSendRefundAmountToPax($cancelInfo,$_IorderId,$reciepientEmail);
         }
         else{
            $this->_corpSendRefundAmountToPax($cancelInfo,$_IorderId,$reciepientEmail);
         }
      
    }    
    
    //function used to form the mail template for send refund amount details to all passenger while auto cancellation for balmer lawrie.
    public function _sendRefundMail($paxInfo,$totalRefundAmount,$totalCancellationCharges,$pnrString,$_IorderId,$pnrInfo,$paxNames = array(),$reciepientEmail){

        //get trip type.
        foreach($pnrInfo as $key => $pnr){
            $tripTypeInfo[] = $this->_OflightItinerary->_getTripTypeByPNR($pnr,$_IorderId)[0]['trip_type'];
        }
        
        //set cancellation mail inputs
        $tripTypeInfo = array_values(array_unique($tripTypeInfo));
        $cancelInput['triptype']    = implode(",",$tripTypeInfo);
        $cancelInput['orderid']    = $_IorderId;
        $cancelInput['pnr']        = $pnrString;
        
        //get mail inputs.
        $mailInfo = $this->_OcancellationInsert->_getCancellationMailInputs($cancelInput);        

        //set subject of the mail.
        $_Ssubject = 'Cancellation Successful for '.$pnrString.' for '.$mailInfo['sector'];
        
        //get the mail content.        
        $twigOutputArray = $mailInfo; 
        $twigOutputArray['refundAmount'] = $totalRefundAmount; 
        $twigOutputArray['cancellationCharges'] = $totalCancellationCharges; 
        $twigOutputArray['paxName'] = $paxInfo['title'].'. '.$paxInfo['first_name'].' '.$paxInfo['last_name'];
        $twigOutputArray['host'] = HOST_URL;
        $twigOutputArray['mailSignature'] = EMAIL_SIGNATURE; 
        if(is_array($paxNames) && count($paxNames) > 0){
             $twigOutputArray['paxName'] = "Passenger"; 
             $twigOutputArray['show_paxs'] = "Y"; 
             $twigOutputArray['cancelled_paxs'] = implode(",", $paxNames);
        }
        $this->_Otwig = init();

        if(is_array($reciepientEmail)){
           $twigOutputArray['paxName'] = "Sir/Madam";
        }  
        
        //render the tpl for mail content.
        $_SmailContent = $this->_Otwig->render('cancellationFulfillmentMail.tpl',$twigOutputArray);
        if(is_array($reciepientEmail)){
           $paxInfo['email_id'] = implode(',',$reciepientEmail); 
        }
        //sending the mail.
        if($paxInfo['email_id'] != ''){
            $sendMailResponse = $this->_OcommonMethods->_sendMail($paxInfo['email_id'],'support@atyourprice.in',$_Ssubject,$_SmailContent,'','',BALMER_MAIL_REQUEST_BCC_PASSENGER);
        }
        fileWrite($_Ssubject,'cancelRefundAmountMail',"a+");
        fileWrite($_SmailContent,'cancelRefundAmountMail',"a+");
        fileWrite($sendMailResponse,'cancelRefundAmountMail','a+');       
        return $sendMailResponse;
    }  
    /* @FunctionName    :   _updateHotelFullfilmentData()
    * @Description     :   function used to update the fulfillment details for hotel.
    * @param           :   $fullfilmentDetails| array
    */
    public function _updateHotelFullfilmentData($fullfilmentDetails){
        
        $orderArray = array('order_id', 'total_amount');
        $syncOrderId = isset($fullfilmentDetails["syncOrderId"]) ? $fullfilmentDetails["syncOrderId"] : $fullfilmentDetails["orderId"];
        $orderSyncDetails = $this->_Opackage->_getOrderDetailsForGivenInput($orderArray, 'sync_order_id', $syncOrderId);

        //updat ticket status in order_details table
        $orderId = $orderSyncDetails[0]['order_id'];
        $orderDetails['r_ticket_status_id'] = TICKETTED;
        $this->_Opackage->_updateOrderDetails($orderDetails, $orderId);

        if(isset($fullfilmentDetails['voucherInfo'])){

            $insertValues = array(
                "r_order_id" => $orderId,
                "fullfilment_date" => date('Y-m-d H:i:s'),
                "voucher_number" => $fullfilmentDetails['voucherInfo'][0]['voucherCode'],
                "hotel_payment_amount" => $orderSyncDetails[0]['total_amount'],
                "booked_through" => "",
                "agent_email_id" => $fullfilmentDetails['fullfilmentInfo']['agentId']
            );
            $this->db->_insert('hotel_fullfilment_details', $insertValues);

            $fieldsArray = array('r_request_id');
            $factBookingData = $this->db->_select('fact_booking_details',$fieldsArray,'r_order_id', $orderId);
            $this->_updateHotelRoomId($fullfilmentDetails['voucherInfo'], $factBookingData[0]['r_request_id']);
        }
        
        $invoiceDetails['sync_invoice_id'] = $fullfilmentDetails['invoiceId'];
        
        //Get the package id for the input booking id
        $bookingPersonDetails = $this->_Opackage->_getBookingPersonInfo($orderId);
        $bookingCorporateId = $bookingPersonDetails[0]['r_corporate_id'];
        $packageId = $bookingPersonDetails[0]['r_package_id'];
        
        //Get the travel mode id for the package
        $packageDetails = $this->_Opackage->_getPaymentCompletedPackageDetails($packageId);
        $invoiceDetails['invoice_type_id'] = $packageDetails[0]['r_travel_mode_id'];
        
        //Get billto id for the booking corporate
        $billToDetails = $this->_OcorporateSettings->_getBillToMapping($bookingCorporateId, 0, '', 'Y');
        $invoiceDetails['r_billto_id'] = $billToDetails[0]['billto_id'];
        $invoiceDetails['created_date'] = date("Y-m-d H:i:s");
        
        //Insertion of Invoice Details
        $invoiceId = $this->_Oinvoice->_insertInvoice($invoiceDetails);
        $factBookingDetails['r_invoice_id'] = $invoiceId;
        
        //Updation of invoice id in fact_booking_details table
        $factUpdate = $this->_Opackage->_updateFactBookingWithOrderId($factBookingDetails, $orderId);
    
        $detailsArray = array('order_id' => $orderId, 'orderIdColumn' => $orderId, 'package_id' => $packageId, 'packageType' => $packageDetails[0]['package_type'], 'invoice_id' => $invoiceId);
        return array('response' => 'SUCCESS', 'data' => '', 'details' => $detailsArray);        
    }

    /* @FunctionName    :   _getRequestApproverInfo
    * @Description     :   function is used to get the approver details
    * @param           :   $approverId| int
    */

    public function _getRequestApproverInfo($approverId,$orderId){


        $sql = "SELECT 
                    de.employee_code AS approver_employee_code, 
                    CONCAT(de.title,'',de.first_name,'',de.last_name) AS approver_name, 
                    de.mobile_no AS approver_mobile_no,
                    de.email_id AS approver_email_id,
                    at.approved_date  
                FROM 
                    dm_employee de 
                INNER JOIN approval_tracking at ON at.approver_id = de.employee_id
                WHERE de.employee_id = " . $approverId . "AND at.r_order_id = ".$orderId ;

        return $this->_OcommonDBO->_getResult($sql)[0];

    }

    public function _getTripInformation($orderId,$sapRequestInfo){

        $_ArequestData['requestInfo']['sapRequestDetails'] = array(
            'sapRequestId'      => $sapRequestInfo['sap_request_id'],
            'onwardSequenceNo'  => $sapRequestInfo['onwardSequenceNo'],
            'returnSequenceNo'  => $sapRequestInfo['returnSequenceNo']
        );
        return $_ArequestData;
    }
 
    /* @Description sync booking details when payment faliure occure
    * @param array,string,int|$_ArequestData, $requestMethod, $packageId
    * @return array|$returnValue
    */
    public function _callFailureBookingSync($res,$packageId,$paymentTypeId,$checkPaymentFailure){  
        
        //set payment type id
        $this->_paymentTypeId = $paymentTypeId;
        
        //set method name
        $requestMethod      = SELF::AIR_SYNC_METHOD; 
        
        //form the booking sync array
        $_AairRequestData = array();
        $_AairRequestData[] = $this->_getBookingFullFillmentRequest($res,$packageId,0,$res['r_travel_mode_id'],$res['booking_type'],0,$checkPaymentFailure);
        (!empty($this->_SerrorMessage)) ? $this->_errorHandlingObj->_setErrorMsg($_AairRequestData,'Booking Fulfillment Request Sync Error', $this->_SerrorMessage) : '';
        
        //calling the backend sync
        $this->_callBookingSyncMethod($_AairRequestData,$requestMethod,$packageId,$res['booking_type']);        
        return true;
    }
     /* 
    * @Function Name             : _setApproverDetails
    * @Description               :This function used to set order Approver Details 
    * @Tables                    : 
    * @Author                    : Muruganandham M
    * @Created Date              : 08/04/2019
    */ 
    public function _setApproverDetails($sapRequestInfo,$orderId){
        return array(
            'approverEmpCode'   => $sapRequestInfo['approver_employee_code'],
            'approverName'      => $sapRequestInfo['approver_name'],
            'approverMobileNumber' => $sapRequestInfo['approver_mobile_no'],
            'approverEmailId' => $sapRequestInfo['approver_email_id'],
            'approvedDate' => $sapRequestInfo['approved_date'],
            'approverRemarks'   => $sapRequestInfo['approver_remarks']
        );

    }
    /* 
    * @Function Name             : _getGSTValue
    * @Description               :This function used to get GSt Value 
    * @Tables                    : 
    * @Author                    : Muruganandham M
    * @Created Date              : 01/05/2019
    */
    public function _getGSTValue($empId,$bookingPersonInfo,$orderId,$bookingType){
        
        $gstInfo = $this->_OcommonInsertFlightItinerary->_getGSTCorporateMappingId(0,$bookingPersonInfo[0]['r_corporate_id'],0,'Y',$bookingType)[0];

        if(is_array($gstInfo) && count($gstInfo) > 0){
            $gstValue = $gstInfo;
        }
        else{
            $gstValue = $this->_OcommonInsertFlightItinerary->_getGSTCorporatePreviousMappingIdBasedOrderID($bookingPersonInfo[0]['r_corporate_id'],$orderId,$bookingType)[0];
        }
        return $gstValue;
    }

    public function _sendMailControllingOfficer($orderId){    
        return true;       
    }

    public function _getOrderApproverFacto(){
        return true;
    }
    public function _getOrderDeclarationData(){
        return true;
    }    


    public function _getDivison(){
        return true;
    }

    public function _setEmployeeId($employeeId){
        return $employeeId;
    }
    public function _getEmployeeAgeDetails($employeecode,$passengerId){
        $age = 0;
        return $age;
    }
    public function _getGstdata(){
        return true;
    }

    public function _updateViaFlightPNRDetails($viaFlightDetails){

        $pnrDetails = array();
        foreach($viaFlightDetails as $key => $viaFlight){
            
            if(!empty($viaFlight['travelport_pnr']))
                $pnrDetails[$key]['pnr_details']['TRAVELPORT']  = $viaFlight['travelport_pnr'];

            if(!empty($viaFlight['gds_pnr']))
                $pnrDetails[$key]['pnr_details']['GDS']  = $viaFlight['gds_pnr'];

            if(!empty($viaFlight['pnr']))
                $pnrDetails[$key]['pnr_details']['AIRLINE']  = $viaFlight['pnr'];

            $pnrDetails[$key]['via_flight_id']    =  $viaFlight['sync_itinerary_id'];
        }
        $this->_OflightItinerary->_saveViaFlightPNRDetails($pnrDetails);
    }

}