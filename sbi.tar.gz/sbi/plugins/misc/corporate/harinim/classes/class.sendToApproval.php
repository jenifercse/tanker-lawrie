<?php
/* ***************************************************************************
 * @File             : class.sendToApproval.php
 * @Description      : This file is used to send approval for all the approval flow
 * @Tables Affected  : order_details,approval_tracking
 * @Author           : Karthika
 * @Created Date     : 08/12/2016
 * @Modified Date    : 03/05/2018
 * *************************************************************************** */
pluginFileRequireBasic('common/','interface/commonConstants.php');

class sendToApproval implements commonConstants{
    
    public function __construct(){
        
        $this->_OcommonDBO = new commonDBO();
        $this->_OapprovalProcess = common::_checkClassExistsInNameSpace('approvalProcess');
        $this->_OapprovalTracking = common::_checkClassExistsInNameSpace('approvalTracking');
        $this->_OtripCreation = common::_checkClassExistsInNameSpace('tripCreation');
        $this->_Opackage = new package();
        $this->_OcommonQuery = new commonQuery();
        $this->_Opassenger = new passenger();
        $this->_OsendSms = new sendSms();
        $this->_OssbttoSap = new ssbtToSAP();


    }
    
   /**
    * @Description :calling the function for sending approval based on the work flow.
    * @author Karthika.M
    */
    public function _sendToApprovalProcess(){        
         
        //get fact booking details info with respect to the package id.
        if(!isset($this->_IinputData['factBookingDetails'])){
            $this->_IinputData['factBookingDetails'] = $this->_OcommonDBO->_select('fact_booking_details', array('r_package_id', 'r_order_id', 'r_employee_id', 'r_corporate_id', 'r_request_id', 'travel_mode'), 'r_package_id', $this->_IinputData['packageId'])[0];
        }
        
        //set inputs
        $input = $this->_IinputData;        
        fileWrite(print_r($input, 1),"sendtoapproval");        
       // get package info
        if($input['multicityRequestBooking'] == 'requestBookFlight' || $input['paymentProcess'] == 'orderPayment'){    
           $this->_ApackageInfo  =  $this->_Opackage->_getPaidPackageDetails('','','',$input['orderInfo']); 
        }else{
            $this->_ApackageInfo  = $this->_Opackage->_getPaidPackageDetails($input['factBookingDetails']['r_package_id']);
        }
        //get work flow caption.
        $this->_SworkFlowCaption = $this->_OcommonQuery->_getWorkFlowForOrder($input['factBookingDetails']['r_order_id']);
        fileWrite("workflowCaption".$this->_SworkFlowCaption, "sendtoapproval", "a+");
        
        //calling the send to approval flow based on the work flow.
        $this->_callingApprovalBasedWorkFlow($input);
        fileWrite(print_r($this->_AserviceResponse, 1),"sendtoapproval","a+");
    }
    
    //function used to calling the approval flow based on the work flow.
    public function _callingApprovalBasedWorkFlow($input){
        switch($this->_SworkFlowCaption){
            
            case CMP_TICKET_APPROVAL:
                //ticket approval flow.
                $this->_ticketApprovalFlow($input);
                break;
            
            case CMP_ITINERARY_APPROVAL:
                //itinerary approval flow.
                $this->_itineraryPreApprovalFlow($input);
                break;
            
            case CMP_REQUEST_APPROVAL:
                //request approval flow.
                $this->_requestApprovalFlow($input);
                break;
            
            case CMP_ITINERARY_SSR_APPROVAL:
                $this->_itinerarySSRFlow($input);               
                break;
        }
    }

    /**
    * @Description :function used for send to approval for ticket approval flow
    * @author Karthika.M
    */
    public function _ticketApprovalFlow($input){

         //insert the approver info into in approval_tracking
        (!isset($input['ticketApprovalType'])) ? $insertApprovaltrackingId = $this->_insertApprovalTrackingInfo($input['approvalTrackingInfo']) : '';
        
        //set payment process type.
        $paymentProcessType = ($input['packageType'] == 1) ? 'packagePayment':'orderPayment';      
        
        //set service Response.
        $this->_AserviceResponse['status'] = array('status_code' => 0,'status_message' => 'success','error_alert' => 'APPROVE',
                'auto_payment' => 'Y','paymentProcessType' => $paymentProcessType,
                'sendToApprovalMessage' => 'Your booking request is sent to (' . $this->_SapproverEmailInfo . ') for approval as per travel policy. Soon the ticket will be mailed to your official email-id.',
                'package_id' => $input['factBookingDetails']['r_package_id'],
                'order_id' => $input['factBookingDetails']['r_order_id'],
                'workFlow' => "TicketApprovalFlow");       
    }

    /**
    * @Description :function used for send to approval for itinerary approval flow
    * @author Karthika.M
    */
    public function _itineraryPreApprovalFlow($input){
       
        //send mail to approver.
        $approvalStatus = $this->sendToApprovalBasedTrip($input);
        
        //assing the service response.
        $this->_AserviceResponse['status'] = array('status_code' => 0,
            'status_message' => 'success',
            'error_alert' => 'APPROVE',
            'sendToApprovalMessage' => 'Your booking request is sent to (' . $this->_SapproverEmailInfo . ') for approval.');
    }

    /**
    * @Description :function used for send to approval for request approval flow
    * @author Karthika.M
    */
    public function _requestApprovalFlow($input){
        
        // send mail to approver.
        $approvalStatus = $this->sendToApprovalBasedTrip($input);
        
        //assing the service response.
        $this->_AserviceResponse['status'] = array('status_code' => 0,
            'status_message' => 'success',
            'error_alert' => 'APPROVE',
            'package_id' => $input['factBookingDetails']['r_package_id'],
            'sendToApprovalMessage' => 'Your booking request is sent to (' . $this->_SapproverEmailInfo . ') for approval.');
    }

    // function used for calling send to approval based on trip(oneway,roundtrip or multicity).
    /**
    * @Description : function used for calling send to approval based on trip(oneway,roundtrip or multicity).
    * @author Karthika.M
    */
    public function sendToApprovalBasedTrip($input,$avoidInsertingApprovalTracking = 'Yes'){
        //get order id info for package
        $orderInfo = array_column($this->_ApackageInfo, 'r_order_id');    
        //if the booking is cart or combo
        if($input['packageType'] == SELF::COMBO_PACKAGE_TYPE){   //cart or combo
            
            //insert into approval tracking
            $avoidInsertingApprovalTracking == 'Yes' ? $this->_insertApprovalTrackingInfo($input['approvalTrackingInfo'],$input['packageId']) : FALSE;
            
            //update the status in order details for all the order in package.
            $this->_orderStatusUpdation();
            
            //send mail to approver.
            $approvalStatus = $this->sendToApproval(0,$input,$input['packageId']);            
        } 
        else if($input['packageType'] == SELF::AIR_MULTICITY_PACKAGE_TYPE){//multicity
            
            //insert into approval tracking
            $avoidInsertingApprovalTracking == 'Yes' ? $this->_insertApprovalTrackingInfo($input['approvalTrackingInfo']) : FALSE;
            
            //function used to sending approval for the multicity booking,
            $this->_multicitySendApproval($input,$orderInfo);            
        }
        else{   
            //insert into approval tracking
            $avoidInsertingApprovalTracking == 'Yes' ? $this->_insertApprovalTrackingInfo($input['approvalTrackingInfo']) : FALSE;
            
            //set order id.
            $orderId = ($input['multicityRequestBooking'] == 'requestBookFlight') ? $input['orderInfo']:$input['factBookingDetails']['r_order_id'];
           
            //update approval level in order details 
            $updateOrderArray['r_ticket_status_id'] = SEND_FOR_APPROVAL;
            $orderStatusArray = $this->_Opackage->_updateOrderDetails($updateOrderArray, $orderId);
            
            //send mail to approver.
            $approvalStatus = $this->sendToApproval($orderId, $input);   

        }
        return $approvalStatus;
    }

    /**
    * @Description : function used to send to approval for approval process.
    * @author Karthika.M
    */
    public function sendToApproval($orderId,$input,$packageId = 0){
       
        global $CFG;    
      
        
         $input['orderId'] = $orderId;
       
        //get approver info based on the package type
        $approverInfo = $input['packageType'] == SELF::COMBO_PACKAGE_TYPE ? $this->_OapprovalTracking->_getApprovalTrackingInfoByProcessType(0,$packageId): $this->_OapprovalTracking->_getApprovalTrackingInfoByProcessType($orderId);
        $checkSameApprovalExits = $this->_checkSameApprovalExits($orderId);

        //get approval_level value.
        if(count($approverInfo) > 0){            
            foreach ($approverInfo as $info){                 
                if($info['approval_type'] != 'IA'){
                    //get the approver info without intimation approver
                    $approvalLevel[] = $info['approval_level'];
                    $approverLevelArray[$info['approval_level']][] = $info['approver_id'];
                } 
                else if($info['approval_type'] == 'IA' && $checkSameApprovalExits == 'N'){
                    //get the intimation approver info
                    $intimationApproverId[] = $info['approver_id'];
                }
            }    
            
            //set intimation approver id.
            $this->_AintimationApproverId = $intimationApproverId;
            
            //get first approver based on approval level.
            $minApprovalLevel = min($approvalLevel);
            $employeeApproverId = $approverLevelArray[$minApprovalLevel];
            
            //if it is combo or cart.
            if ($input['packageType'] == SELF::COMBO_PACKAGE_TYPE){
                //sending approval
                $this->_cartSendToApprovalProcess($input,$packageId,$intimationApproverId,$employeeApproverId,$minApprovalLevel);
            } 
            else{
                
                //get mail info with respect to the order id.
                $input['orderMailInfo'] = $this->_OcommonQuery->_orderMailInfo($orderId);
                
                //send initmation mail if intimation approver exist
                if(count($intimationApproverId) > 0 && $checkSameApprovalExits == 'N'){
                    //send intimation approval and sms
                    $this->_formIntimationMailInput($input,$orderId,$intimationApproverId);
                }
                
                // update approval level in order details 
                if($input['flagForCheckApproval'] != ''){
                    $updateOrderArray['approval_level'] = $input['flagForCheckApproval'];
                    $employeeApproverId = $approverLevelArray[$input['flagForCheckApproval']]; 
                }
                else{
                    $updateOrderArray['approval_level'] = $minApprovalLevel;
                }
                
                //update the status while sending approval
                $this->_updateStatusWhileSendingApproval(array($orderId),$orderId,$updateOrderArray['approval_level']);
                
                //send approval mail.
                return $this->_formMailInput($input,$employeeApproverId,'','N','Y');
            }
        }
    }
    // overwite function for iocl
    public function _checkSameApprovalExits($orderId){

        $checkSameApprovalExits = 'N' ;
        return $checkSameApprovalExits;

    }

   /**
    * @Description : function used sending approval for cart or combo
    * @author      : Karthika.M
    * @created_date: 03-05-2018
    */
    public function _cartSendToApprovalProcess($input,$packageId,$intimationApproverId,$employeeApproverId,$minApprovalLevel){
       
        //get package info
        $this->_ApackageInfo = $this->_Opackage->_getPaidPackageDetails($packageId);                

        //set order array.
        $orderInfo = array_column($this->_ApackageInfo,'r_order_id'); 
        
        //set order id in inputs array
        $input['orderId'] = $orderInfo[0];
        
        //update the status while sending approval
        $this->_updateStatusWhileSendingApproval($orderInfo,0,$minApprovalLevel,$packageId);

        //sent intimation mail if intimation approver exist.
        if(count($intimationApproverId) > 0){                    
            //get email content for intimation approval - itinerary template
            $this->_formMailInput($input,$intimationApproverId,'I','Y','N',2);           
        }

        //get email content for approval - itinerary template
        $input['subject'] =  "Request for travel approval - Trip ID " . $packageId; 
        $input['message'] =  "Dear Approver, The following travel request was raised by ".$_SESSION['userName']." and has been sent to you for your approval."  ;
        $this->_formMailInput($input,$employeeApproverId,'','Y','Y');
    }
        
    /**
    * @Description : function used update the status and details while sending approval process
    * @author      : Karthika.M
    * @created_date: 03-05-2018
    */
    public function _updateStatusWhileSendingApproval($orderInfo,$orderId = 0,$minApprovalLevel,$packageId = 0){
    
        //update approval level in order details 
        foreach($orderInfo as $value){      
            //get approval level.
            $updateOrderArray['approval_level'] = $minApprovalLevel;
            $orderApprovalLevelStatusArray[] = $this->_Opackage->_updateOrderDetails($updateOrderArray,$value);
        }

        //update approve sent date in approval tracking 
        $updateApprovalSentDate[] = $this->_OapprovalTracking->_updateApproveSentDate($orderId,$minApprovalLevel,$packageId);
    }
    
    /**
    * @Description :  used to insert the approval_tracking and send mail to intimation approver in request level approval flow, if only intimation approver is present.
    * @author Karthika.M
    */
    public function _sendMailtoIntimationApprover($input,$processType = BOOKING){
        
        //get package info.

        if(!isset($this->_ApackageInfo)){            
            $this->_ApackageInfo  = $this->_Opackage->_getPaidPackageDetails($input['factBookingDetails']['r_package_id']);
        }
        //insert the intimation approver Info in approval_tracking
        $this->_insertApprovalTrackingInfo($input['approvalTrackingInfo']);
        
        //get order info
        $orderInfo = array_column($this->_ApackageInfo, 'r_order_id'); 
        
        //get intimation approver info .
        foreach($orderInfo as $orderId){
            $mailResponse[] = $this->_sendIntimationApprovalByOrder($input,$orderId,$processType);
        } 
        return $mailResponse;
    }
    
    /**
    * @Description : insert the multiple approval tracking info
    * @author Karthika.M
    */
    public function _insertApprovalTrackingInfo($approvalTrackingInfo,$packageId = 0){ 

        if(count($approvalTrackingInfo) > 0) {
            foreach ($approvalTrackingInfo as $key => $value){
                foreach($value as $data){

                    $data['r_package_id'] = $packageId;

                    ($packageId != 0) ?  $data['r_order_id'] = 0 : '';

                    $insertApprovaltracking = $this->_OapprovalTracking->_insertApprovalTracking($data);
                    $insertApprovaltrackingId[] = $insertApprovaltracking;
                }
            }
            return $insertApprovaltrackingId;
        }
    }
    
    /**
    * @Description : calling function for forming the intimation approver email.
    * @author Karthika.M
    */
    public function _formIntimationMailInput($input,$orderId,$intimationApproverId,$multicityFlag = 'N'){   
        //get mail info with respect to the order id.
        (!isset($input['orderMailInfo'])) ? $input['orderMailInfo'] = $this->_OcommonQuery->_orderMailInfo($orderId) : '';                
        
        if(isset($input['processType'])  &&  $input['processType'] == 'callBack') {
          $input['subject'] =  "Intimation Call back Request - Booking ID ".$input['orderMailInfo']['booking_id']." for ".$input['orderMailInfo']['sector'];    
          $input['message'] =  $input['orderMailInfo']['bookingPerson']." has requested for Call back ticket .";
        }   
        else {
           $input['subject'] =  strtolower($input['processType']) == 'cancellation' ? "Booking Cancellation Intimation" : "Intimation Approval Request - Booking ID ".$input['orderMailInfo']['booking_id']." for ".$input['orderMailInfo']['sector'];    
           $input['message'] = strtolower($input['processType']) == 'cancellation' ? "The following cancellation request was raised by ".$_SESSION['userName']." ." : $input['orderMailInfo']['bookingPerson']." has requested for the flight travel.";
        }        
       
        //remove duplicate approver id
        $intimationApproverId = array_values(array_unique($intimationApproverId));     
        
        //get approver email id.
        $intimationApproverEmailInfo = $this->_OapprovalProcess->_getApproverEmailId($intimationApproverId);

       //send intimation mail
        return $this->_sendApprovalMail($input,$orderId,$intimationApproverEmailInfo,$intimationApproverId,'N','I',$multicityFlag);
    }
    
    /**
    * @Description : forming the mail input for both approver and intimation approver.
    * @author Karthika.M
    */
    public function _formMailInput($input,$approverId,$mailType,$multicityStatus,$buttonStatus,$type=1){
        if(isset($input['processType'])  &&  $input['processType'] == 'callBack'){
            //get email content for approval - itinerary template
           $input['subject'] =  "Call back Request - Booking ID ".$input['orderMailInfo']['booking_id']." for ".$input['orderMailInfo']['sector'];    
           $input['message'] =  "The following Call back ticket request was raised by " .$_SESSION['userName']."";
        }  
        else {
             //get email content for approval - itinerary template
             $input['subject'] =  "Approval Request - Booking ID ".$input['orderMailInfo']['booking_id']." for ".$input['orderMailInfo']['sector'];    
             $input['message'] =  "The following travel request was raised by ".$_SESSION['userName']." and has been sent to you for your approval.";
        }
       
        //remove duplicate approver id.
        $approverId = array_values(array_unique($approverId));
        //get approver email id
        if(count($approverId) > 0){            
            $employeeApproverEmailInfo = $this->_OapprovalProcess->_getApproverEmailId($approverId);
            if(count($employeeApproverEmailInfo['nameInfo']) > 0){
                $this->_SapproverEmailInfo = implode(",", $employeeApproverEmailInfo['nameInfo']);
            }
        }
        //send mail
        return $this->_sendApprovalMail($input,$input['orderId'],$employeeApproverEmailInfo,$approverId,$buttonStatus,$mailType,$multicityStatus);        
    }
     
    /**
    * @Description : send the mail with respect to the inputs
    * @author Karthika.M
    */
    public function _sendApprovalMail($input,$orderId,$emailInfo,$approverId,$buttonStatus,$mailType,$multicityStatus){

        $mailInput['package_id'] = $input['factBookingDetails']['r_package_id'];
        $mailInput['order_id'] = $orderId;
        $mailInput['packageType'] = $input['packageType'];
        $mailInput['email_id'] = $emailInfo['mailId']; 
        $mailInput['employee_id'] = $approverId;        
        $mailInput['subject'] = $input['subject'];
        $mailInput['message'] = $input['message'];  
        $mailInput['mailType'] = $mailType;
        $mailInput['status'] = $buttonStatus;
        $mailInput['workflow'] = $this->_SworkFlowCaption;  
        $mailInput['checkTripApproveStatus'] = (isset($input['CHECK_TICKET_TRIP_STATUS']) && $input['CHECK_TICKET_TRIP_STATUS'] == 'Y') ? 'Y' : 'N';
        
        //send mail to approver
        $this->_OapprovalProcess->_Otwig = $this->_Otwig;   
        $mailResponse = $this->_OapprovalProcess->_sendMailContent($mailInput,$multicityStatus);    

        //set approver type
        $approverType = ($mailType == 'I') ? 'IA' : 'NA';  
        
        //send sms to approver.
        $this->_OsendSms->_sendMessagetoApprover($input,$approverId,$approverType);
        return $mailResponse;
    }

    /**
     * @Description :This function is used to insert the violated policy details
     * @param :
     * @return :
     * @author : Deepak Pande
     */
    public function _policyViolationInsert($policyInput){
        //this will check the status if status = 0 means policy violated 
        if (!$policyInput['policyInsertData']['status']) {
            //this will check the trip type whether one way, round , multicity
            if ($policyInput['tripType'] == 2) {
                //$this->_ApackageInfo array contains the all the order_id details for multicity
                foreach ($this->_ApackageInfo as $key => $value) {
                    $orderIdValue = $value['r_order_id'];
                    $policyInsertDetails = $policyInput['policyInsertData']['result'];
                    foreach ($policyInsertDetails as $key => $value) {
                        $insertInput['r_order_id'] = $orderIdValue;
                        $insertInput['r_policy_id'] = $value[0]['r_policy_id'];
                        $insertInput['policy_violated_level'] = "B";
                        $policyViolationLogId = $this->_OcommonDBO->_insert('policy_Violation_log', $insertInput);
                    }
                }
            } else {
                $policyInsertDetails = $policyInput['policyInsertData']['result'];
                foreach ($policyInsertDetails as $key => $value) {
                    $insertInput['r_order_id'] = $policyInput['factBookingDetails']['r_order_id'];
                    $insertInput['r_policy_id'] = $value[0]['r_policy_id'];
                    $insertInput['policy_violated_level'] = "B";
                    $policyViolationLogId = $this->_OcommonDBO->_insert('policy_Violation_log', $insertInput);
                }
            
            }
        }
    }       
    
    
    /**
    * @Description : prepare array for send intimation mail.
    * @author Karthika.M
    */
    public function _sendCancellationIntimationMail($approvalTrackingInfo,$approvalInput,$approvalSettingsResponse){    
        
        //get package info.
        $packageInfo = $this->_Opackage->_getPaidPackageDetails($approvalInput['factBookingDetails']['r_package_id'])[0]; 
        
        //send to approval input.
        $sendToApprovalInput['packageType'] = $packageInfo['package_type'] == 1 ? 0:$packageInfo['package_type'];
        $sendToApprovalInput['approvalTrackingInfo'] = $approvalTrackingInfo;
        $sendToApprovalInput['factBookingDetails'] = $approvalInput['factBookingDetails']; 
        $sendToApprovalInput['processType'] = CANCELLATION; 
        $this->_ApackageInfo = $packageInfo;   
        
        //send the intimation approver only for intimation approver exist.
        $approvalSettingsResponse['intimationApproverExist'] == 'Y' ? $this->_sendMailtoIntimationApprover($sendToApprovalInput,CANCELLATION):'';        
    }
    
    /**
    * used to send approval for both itinerary and ticket approval
    * @param array $inputData
    * @return array
    * @author sivaprakash
    */
    public function _sendBookingApproval($inputData){


        $this->_tripApprovalFlow($inputData['packageId']);

        //get package info
        $this->_ApackageInfo  = $this->_Opackage->_getPaidPackageDetails($inputData['packageId']);        
        
        //initialize the twig.
        $this->_Otwig = init();
        
        //array initialization
        $approvalData = $contentId = array();
        
        //set content id info.
        $contentId = explode(':', $inputData['contentIdData']);
       
        //assign input data array
        $inputData['packageType'] = $this->_OcommonDBO->_select('dm_package',array('package_type'),'package_id',$inputData['packageId'])[0]['package_type'];
        
        //assign input data array
        $inputData['packageType'] = ( $inputData['packageType'] == 1 && $inputData['paymentProcessType'] == 'orderPayment') ? 0 :  $inputData['packageType'];       

        $inputData['factBookingDetails'] = $this->_OcommonDBO->_select('fact_booking_details', '*', 'r_order_id', $inputData['orderId'])[0];
        
        //call to get approval tracking for orderId        
        if( $inputData['packageType'] == 3){
            $approvalData = call_user_func(array($this->_OapprovalTracking,'_getApprovalTrackingInfoByProcessType'),0,$inputData['packageId']);
            $inputData['approvalTrackingInfo'] = $approvalData;
        }
        else if($inputData['packageType'] == 1 && $inputData['paymentProcessType'] == 'packagePayment'){

            //get package and travel mode based orderid                
            $travelModeId = $this->_OcommonDBO->_select('dm_travel_mode', 'travel_mode_id', 'travel_mode_code', $contentId[3])[0]['travel_mode_id'];
            $orderArray = $this->_Opackage->_getPaidPackageDetails($contentId[0],0,'',0,$travelModeId);

            //get order based approval data                
            foreach ($orderArray as $key => $value){
                $approvalData = call_user_func(array($this->_OapprovalTracking,'_getApprovalTrackingInfoByProcessType'), $value['r_order_id']);
                //set order based approval data          
                $inputData['approvalTrackingInfo'][$value['r_order_id']] = $approvalData;                    
            }                 
        }
        else{

            $approvalData = call_user_func(array($this->_OapprovalTracking,'_getApprovalTrackingInfoByProcessType'), $inputData['orderId']);
            $inputData['approvalTrackingInfo'] = $approvalData;

        }        
        return call_user_func(array($this,'sendToApprovalBasedTrip'),$inputData,'No');
    }
    
    /**
    * @Description : function used to sending the approval after payment for the ticket approval flow.
    * @Date : 16-02-2018
    * @author Karthika.M
    */    
    public function _ticketApprovalProcessAfterPayment($input){   
        
        if ($input['multiCityRequestBooking'] == 'requestBookFlight') {
            $packageType = $this->_Opackage->_getPaidPackageDetails('','','',$input['orderInfo']);

        } else {
            $packageType = $this->_Opackage->_getPaidPackageDetails($input['packageId']);

        }
        //set content id info.
        $input['contentIdData'] = $input['packageId'].':'.$input['orderId'].':'.$packageType[0]['package_type'];
        
        //calling the send to approval process.
        array_map(array($this,'_sendBookingApproval'), array($input));    
        
        //update ticket status in order_details 
        $updateOrderArray['approval_status'] = 1;
        $updateOrderArray['r_ticket_status_id'] = PAID;
               
        //update  approval_status in the order_details.
        $updatedOrderStatus = $this->_updateOrderDetailsInfo($packageType,$updateOrderArray);
        
        //assign the  response.
        $response = array('status_code' => 0,
            'status_message' => 'success',
            'error_alert' => 'APPROVE',
            'auto_payment' => 'Y',
            'paymentProcessType' => $input['paymentProcessType'],
            'sendToApprovalMessage' => 'Thank you for booking trip in AtYourPrice portal,Your booking request is sent to (' . $this->_SapproverEmailInfo . ') for approval,Soon the ticket will be mailed to your id after booking gets approved.',
            'package_id' => $input['packageId'],
            'order_id' => $orderInfo[0],
            'workFlow' => "TicketApprovalFlow");
        return $response;       
    }    
    
    /**
    * @Description : function used to sending the approval after payment for the ticket approval flow.
    * @Date : 16-02-2018
    * @author sivaprakash
    */    
    public function _itineraryApprovalAfterSelectSSR($input){  
        //calling approval function  select SSR.
        array_map(array($this,'_sendBookingApproval'), array($input));                
        return array('status_code' => 0,
        'status_message' => 'success','error_alert' => 'APPROVE',
        'sendToApprovalMessage' => 'Your booking request is sent to (' .$this->_SapproverEmailInfo. ') for approval.');
    }
    
    /**
    * @Description : Function used to send the cancellation approval.
    */
    public function _itineraryCancellationApproval($cancelId){
        
        //assign the input data
        $input = $this->_IinputData;
        
        //insert in to approval_tracking 
        foreach ($input['approvalTrackingInfo'] as $key => $value) {
            $input['approvalTrackingInfo'][$key]['r_cancellation_id'] = $cancelId; 
        }
        
        $approvalTrackingInfo[$input['orderId']] = $input['approvalTrackingInfo'];
        $avoidInsertingApprovalTracking = $this->_insertApprovalTrackingInfo($approvalTrackingInfo);
        
        //package type is air.
        if(isset($input['orderId']) && count($input['approvalTrackingInfo']) > 0){
            $approvalStatus[] = $this->sendCancellationToApproval($input,'', $cancelId); 
        } 
        return $approvalStatus;
    }

    /**
    * @Description : Function used to send the cancellation approval.
    */
    public function sendCancellationToApproval($input, $packageId = 0,$cancellationId){
        
        global $CFG;

        $orderId = $input['orderId']; 
        
        $packageDetails = $this->_getPackageDetails($orderId);
        $input['r_package_id'] = $packageDetails['package_id'];
        $input['packageType'] = $packageDetails['package_type'];
        //get approver id
        $approverInfo = $this->_OapprovalTracking->_getApprovalTrackingInfoByProcessType($orderId,'','Cancellation',$cancellationId);
        //get approval_level value.
        if(count($approverInfo) > 0){
            foreach ($approverInfo as $info){   
                if($info['approval_type'] != 'IA'){
                    $approvalLevel[] = $info['approval_level'];
                    $approverLevelArray[$info['approval_level']][] = $info['approver_id'];
                } 
                else if ($info['approval_type'] == 'IA'){
                    $intimationApproverId[] = $info['approver_id'];
                }
            }
            
            //set intimation approver id.
            $this->_AintimationApproverId = $intimationApproverId;
           
            // get first approver based on approval level.
            $minApprovalLevel = min($approvalLevel);

            $employeeApproverId = $approverLevelArray[$minApprovalLevel];
            //update approval level in order details 
            //update approval details in the trans cancellation details
            $updateOrderArray['approval_status'] = SEND_FOR_APPROVAL; 
            $updateOrderArray['approval_level'] = $minApprovalLevel; 
            $orderStatusArray = $this->_Opackage->_updateTransCancellation($updateOrderArray, $orderId,$cancellationId);

            // update approve sent date in approval tracking 
            $updateApprovalSentDate[] = $this->_OapprovalTracking->_updateApproveSentDate($orderId,$updateOrderArray['approval_level'],'','Cancellation',$cancellationId);     

            $passengerName = $this->_getCancelPassengerInfo($cancellationId);             

            //get email content for approval - itinerary template
            $input['subject'] =  "Request for Cancellation-(" .' '.$passengerName.' '. ") - Order Id " . $orderId;                
            $input['cancellationFlag'] ='Y';
            $input['cancellationId'] =$cancellationId;
            $input['message'] = "Dear Approver, The following cancellation request was raised by ".$_SESSION['userName']." and has been sent to you for your approval.";
            $this->_formMailInput($input,$employeeApproverId,'Y','','Y');  

            // send mail for intimation approver.
            if(count($this->_AintimationApproverId) > 0){     
                
                $input['orderId'] = $orderId;
                $intimationApproverId = $this->_AintimationApproverId; 
                
                // get email content for approval - itinerary template
                $this->_formMailInput($input,$intimationApproverId,'I','Y','N',2);   
            }
        }
    }

    /**
    * @Description : Function used to get package info with respect to the order id.
    */
    public function _getPackageDetails($orderId){

        $sql = "SELECT dp.package_id, dp.package_type FROM fact_booking_details fbd
                INNER JOIN dm_package dp ON fbd.r_package_id = dp.package_id 
                WHERE fbd.r_order_id = ".$orderId;
        return $this->_OcommonDBO->_getResult($sql)[0];
    }

    /**
    * @Description :Function used to get passenger info with respect to the order id.
    */
    public function _getPassengerTravelInfo($orderId){

         $sql = "SELECT concat(pd.first_name ,' ', pd.last_name) as passengerName FROM order_details od
                INNER JOIN passenger_details pd ON pd.r_order_id = od.order_id 
                WHERE od.order_id = ".$orderId;
        return $this->_OcommonDBO->_getResult($sql)[0]['passengerName'];
    }
    
    /**
    * @Description :Function used to get passenger info with respect to the cancellation id.
    */
    public function _getCancelPassengerInfo($cancellationId){
        $sql = "SELECT concat(pd.first_name ,' ', pd.last_name) as passengerName FROM trans_cancellation tc 
                INNER JOIN cancellation_details cd ON tc.cancellation_id = cd.r_cancellation_id 
                INNER JOIN passenger_details pd ON cd.r_passenger_id = pd.passenger_id 
                WHERE tc.cancellation_id = ".$cancellationId;
        return $this->_OcommonDBO->_getResult($sql)[0]['passengerName'];

    }
        
    /**
    * @Description : function used to sending the approval for the multicity booking
    * @Date : 03-04-2018
    * @author Karthika.M
    */  
    public function _multicitySendApproval($input,$orderInfo){
           
        $input['approvalTrackingInfo'] = isset($input['approvalTrackingInfo']) ? $input['approvalTrackingInfo'] : $this->_getApprovalInfo($orderInfo);
        //send mail to approver.            
        foreach($input['approvalTrackingInfo'] as $key => $value){
            in_array('NA',array_column($input['approvalTrackingInfo'][$key],'approval_type')) == '' ? $this->_OcommonDBO->_update('fact_trip_order_details',array('ticket_approval_flow_changes'=>'Y'),'r_order_id',$key) : ''; 
                
            if(count($value) > 0){
                
                //calling function for sending approval for each order.
                $approvalStatus[] = $this->sendToApproval($key,$input);

                //set array
                $updateOrderArray['r_ticket_status_id'] = SEND_FOR_APPROVAL;
                $updateOrderArray['r_ticket_status_id'] = $this->_checkTicketFlowChange($updateOrderArray['r_ticket_status_id'],$key);
                //update approval level in order details 
                $orderStatusArray = $this->_Opackage->_updateOrderDetails($updateOrderArray,$key);

                //get approver Id except intimation approver.
                foreach($value as $approverId){
                    if($approverId['approval_type'] != 'IA'){                        
                        //set approval level
                        $approvalLevel[] = $approverId['approval_level'];                        
                        //set approver id with respect to the approval level
                        $approverIdInfo[$approverId['approval_level']][] = $approverId['approver_id'];
                    }
                }
            }
        }
        
        //get first approver based on approval level.
        $minApprovalLevel = min($approvalLevel);
        $approverIdInfo = $approverIdInfo[$minApprovalLevel];
        
        //get approver id.
        $approverIdInfo = array_unique($approverIdInfo);
        $approverIdInfo = array_values($approverIdInfo); 
        $approverEmailInfo = $this->_OapprovalProcess->_getApproverEmailId($approverIdInfo);
        if(count($approverEmailInfo['nameInfo']) > 0){
            $this->_SapproverEmailInfo = implode(",", $approverEmailInfo['nameInfo']);
        }   
        return TRUE;
    }
    /**
    * @Description : function used to get approval tracking info in post facto flow
    * @Date : 23-04-2018
    * @author Rajesh.U
    */ 
    public function _getApprovalInfo($orderInfo){

        foreach ($orderInfo as $key => $value) {

            $result[$value] = $this->_OcommonDBO->_select('approval_tracking','*','r_order_id',$value);
            
        }

        return $result;
    }
        
    /**
    * @Description : function used to update the order details
    * @Date : 09-08-2018
    * @author Karthika.M
    */  
    public function _updateOrderDetailsInfo($packageType,$updateOrderArray){
        
        $orderInfo = array_column($packageType,'r_order_id');            
        foreach($orderInfo as $value){
            //update approval_status in the order_details with respect to the order id.
            $updatedOrderStatus[] = $this->_Opackage->_updateOrderDetails($updateOrderArray, $value);
        }    
        return $updatedOrderStatus;
    }
        
    /**
    * @Description : function used to sending the approval.
    * @Date : 09-08-2018
    * @author Karthika.M
    */  
    public function _itinerarySSRFlow($input){
        //check for CMP_ITINERARY_SSR_APPROVAL flow and insert approval details
        $this->_insertApprovalTrackingInfo($input['approvalTrackingInfo'],$input['r_package_id']);
        //update ticket status id for all the order in package,
        $this->_updateOrderDetailsInfo($this->_ApackageInfo,array('r_ticket_status_id' => ITINERARY_SSR_SELECTED));
    }
    
    /**
    * @Description : update the ticket status id with respect to the order based on the travel mode.
    * @Date : 09-08-2018
    * @author Karthika.M
    */  
    public function _orderStatusUpdation(){;
        
        //set status.
        $updateOrderArray['r_ticket_status_id'] = SEND_FOR_APPROVAL;  
        
        foreach($this->_ApackageInfo as $value){
            
            //set table name based on the travel mode.
            if($value['travelMode'] == SELF::DOMESTIC_AIR_MODE_ID || $value['travelMode'] == SELF::INTERNATIONAL_AIR_MODE_ID){
               $tableName = 'air_booking_details';
            }
            //get the itinerary info
            $status = $this->_OcommonDBO->_select($tableName,'*','r_order_id', $value['order_id']);          
            //update the order_details.
            ($status && count($status) > 0) ?  $updatedOrderStatus[] = $this->_Opackage->_updateOrderDetails($updateOrderArray,$value['order_id']) : '';
        }    
    }
    
    /**
    * @Description : sending the intimation approval for itinerary SSR approval and ticket SSR approval
    * @Date : 24-01-2019
    * @author Karthika.M
    */  
    public function _itinerarySSRIntimationApproval($packageId,$orderId,$paymentProcessType){
        
        //get package info
        $packageInfo  = $this->_Opackage->_getPaidPackageDetails($packageId);
        
        //set inputs
        $input['factBookingDetails']['r_order_id'] = $orderId;
        $input['factBookingDetails']['r_package_id'] = $packageId;
        $input['packageType'] = $packageInfo[0]['package_type'];
        $input['processType'] = 'Booking'; 
        
        //get work flow caption.
        $this->_SworkFlowCaption = $this->_OcommonQuery->_getWorkFlowForOrder($orderId);
        
        //if it is itinerary SSR approval flow.
        if($this->_SworkFlowCaption == CMP_ITINERARY_SSR_APPROVAL || $this->_SworkFlowCaption == CMP_TICKET_APPROVAL){
            //if it is package payment and multicity
            if($paymentProcessType == 'packagePayment' && $input['packageType'] == 1){
                foreach($packageInfo as $key => $value){
                    $mailResponse[] = $this->_sendIntimationApprovalByOrder($input,$value['r_order_id'],$input['processType']);
                }                
            }
            else{
                //send intimation approval for the particular order id
                $mailResponse = $this->_sendIntimationApprovalByOrder($input,$input['factBookingDetails']['r_order_id'],$input['processType']);
            }
        }
        return $mailResponse;
    }   
    
    /**
    * @Description : sending the intimation approval with respect to the order
    * @Date : 25-01-2019
    * @author Karthika.M
    */  
    public function _sendIntimationApprovalByOrder($input,$orderId,$processType){        
        
        //get intimation approver info
        $intimationApproverInfo = $this->_OapprovalTracking->_getApprovalTrackingInfoByProcessType($orderId,'',$processType);
        if(count($intimationApproverInfo) > 0) {
            foreach($intimationApproverInfo as $key => $value){
                if($value['approval_type'] == 'IA'){
                    $intimationApproverId[] = $value['approver_id'];
                }
            }
        }
        //send intimation approver mail.
        if(count($intimationApproverId) > 0){      
            
            //get approval level.
            $updateOrderArray['approval_level'] = 1;
            $this->_Opackage->_updateOrderDetails($updateOrderArray,$orderId);
                
            //update approve sent date in approval tracking 
            $this->_OapprovalTracking->_updateApproveSentDate($orderId,$updateOrderArray['approval_level']);
            
            //assign the twig value to approval process class.
            $this->_OapprovalProcess->_Otwig = $this->_Otwig;       
            
            //send intimation approval and sms
            $response = $this->_formIntimationMailInput($input,$orderId,$intimationApproverId);
        }        
        return $response;
    }

    public function _tripApprovalFlow($packageId){

        return TRUE;

    }

    public function _validateTripApprovalStatus($input){

        return TRUE;

    }

     public function _ticketApprovalAfterSelectSSR($input){
        
        //get fact booking details info with respect to the package id.
        if(!isset($input['factBookingDetails'])){
            $input['factBookingDetails'] = $this->_OcommonDBO->_select('fact_booking_details', array('r_package_id', 'r_order_id', 'r_employee_id', 'r_corporate_id', 'r_request_id', 'travel_mode'), 'r_package_id', $input['packageId'])[0];
        }
                 
        $input['ticketApprovalType'] = 'ticketSSRApprovalFlow';
        $input['packageType'] = explode(":",$input['contentIdData'])[2];
        
        //function call for trip approval flow
        $this->_ticketTripApprovalFlow($input['packageId']);
        
        $this->_ticketApprovalFlow($input);
        return $this->_AserviceResponse;
    }

    public function _ticketTripApprovalFlow($packageId){

        return TRUE;

    }

     public function _updateTripStatusWhileApprove($packageId){
      return true;
    }

    // overWrite function for iocl
    public function _checkTicketFlowChange($status,$input){

        return $status;
    }

    // overWrite function for iocl
    public function _checkTripMailSendStatus($orderId){
        $message = '';
        return $message;
    }

     /*
    * @Description  function used to get the details of passenger and approver with respect to the order id.
    * @param|int:$orderId
    * @date: 30-8-2018
    * @return|array:$smsInfo
    * @author:Karthika.M
    */ 
    public function _formApproverPaxSMSInfo($orderId){
        
        $smsInfo = array();
        
        //object declaration
        $this->_Opassenger = new passenger();
        $this->_Oemployee = new employee();
        $this->_OapprovalTracking = new approvalTracking();
        $this->_OcommoQuery = new commonQuery();
        
        //get order info
        $orderMailInfo = $this->_OcommoQuery->_orderMailInfo($orderId);
        
        //get passenger details
        $passengerInfo = $this->_Opassenger->_getPassengerDetails($orderId);
        //forming the passenger info
        if($passengerInfo && count($passengerInfo) > 0){            
            //forming the passenger sms info.
            foreach($passengerInfo as $key => $value){
                if($value['mobile_no'] != ''){
                    $paxInfo['name'] = $value['paxName'];
                    $paxInfo['mobile_no'] = $value['mobile_no'];
                    $paxInfo['order_id'] = $orderId;                    
                    $paxInfo['booking_id'] = $orderMailInfo['booking_id'];                    
                    $paxInfo['sector'] = $orderMailInfo['sector'];                    
                    $paxInfo['sender'] = $orderMailInfo['sender'];                    
                    $paxInfo['email_id'] = $value['email_id'];     
                    $paxInfo['retryLink'] = 'Y';  
                    $paxInfo['employeeId'] = $value['r_employee_id'];  
                    $smsInfo[] = $paxInfo;
                }                
            }
            
            //get the approver info
            $approvalTrackingInfo = $this->_OapprovalTracking->_getCurrentApprovalActionInfo($orderId);
            if($approvalTrackingInfo &&  count($approvalTrackingInfo) > 0){
                //forming the approver info if approver is exist for the order.
                foreach($approvalTrackingInfo as $keyInfo => $approverInfo){
                    //get the approver details.
                    $empInfo = $this->_Oemployee->_getEmpInfo($approverInfo['approver_id']);
                    $approverSMSInfo[$keyInfo]['name'] = $empInfo['empName'];
                    $approverSMSInfo[$keyInfo]['mobile_no'] = $empInfo['mobile_no'];
                    $approverSMSInfo[$keyInfo]['order_id'] = $orderId;
                    $approverSMSInfo[$keyInfo]['booking_id'] = $orderMailInfo['booking_id'];                    
                    $approverSMSInfo[$keyInfo]['sector'] = $orderMailInfo['sector'];                    
                    $approverSMSInfo[$keyInfo]['sender'] = $orderMailInfo['sender'];  
                    $approverSMSInfo[$keyInfo]['email_id'] = $empInfo['email_id'];
                    $approverSMSInfo[$keyInfo]['employeeId'] = $approverInfo['approver_id'];
                    $approverSMSInfo[$keyInfo]['retryLink'] = 'N'; 
                }   
                //merge the both passernger sms info and approver info
                $smsInfo = array_merge((array)$smsInfo,(array)$approverSMSInfo); 
                
            }
        }
        return $smsInfo;
    }

    /**
    * @Description :function used to sending approval to next level approver
    * @param array $input
    * @author Karthika.M
    */
    public function _sendApprovalToNextLevel($input,$sendPassengerMail = 'Y'){

        fileWrite(print_r($input,1),'nextLevel','a+');
        
        //getting the next level approver info for combo
        if($input['package_type'] == 3){
            $nextLevelApprovalInfo = $this->_OapprovalProcess->_getNextLevelApproval($input['order_id'],'od.approval_level+1',$input['package_id']);
        }
        else{
            //getting the next level approver info for order id
            $nextLevelApprovalInfo = $this->_OapprovalProcess->_getNextLevelApproval($input['order_id'],'od.approval_level+1');
        }
        
        //update approve sent date in approval_tracking table, and get next level approver employee id
        foreach($nextLevelApprovalInfo as $key => $data){

            //update the approve sent date to next level in approval tracking table
            if($data['approval_level'] == $data['orderApprovalLevel']+1){
                //combo 
                if($input['package_type'] == 3){
                    $updateStatus[] = $this->_OapprovalTracking->_updateApproveSentDate($data['r_order_id'],$data['approval_level'],$data['r_package_id']);
                }
                else{
                    //update the approve sent date
                    $updateStatus[] = $this->_OapprovalTracking->_updateApproveSentDate($data['r_order_id'],$data['approval_level']);
                }
                //get next level approver employee id
                $employeeApproverId[] = $data['approver_id'];
            }
        }
        
        //combo
        if($input['package_type'] == 3){
            //update approval level in order details
            $orderApprovalLevelStatus = $this->_OapprovalProcess->_updateOrderApprovalLevel($input['orderIdColumn']);
        }
        else{
            //update approval level in order details
            $orderApprovalLevelStatus = $this->_OapprovalProcess->_updateOrderApprovalLevel($input['order_id']);
        }

        //get approver email id
        if(count($employeeApproverId) > 0){
            //get approver email id with respect to the approver employee id,
            $employeeApproverEmailInfo = $this->_OapprovalProcess->_getApproverEmailId($employeeApproverId);
            //form string, if multiple approver is present,
            if(count($employeeApproverEmailInfo['nameInfo']) > 0){
                //form string
                $approverEmailInfo = implode(",",$employeeApproverEmailInfo['nameInfo']);
            }
        }
        
        //send approval mail to next level of approver.
        $mailContent = $this->_nextLevelApprovalMail($input,$employeeApproverEmailInfo,$employeeApproverId,$sendPassengerMail);  

        //set final response.
        if($orderApprovalLevelStatus != 0){
            $this->_AfinalResponse['status'] = array('status_code'    => 0,
                                               'status_message' => 'success',
                                               'approveStatus'=> 3,
                                               'error_alert'    => 'Booking request is sent to ('.$approverEmailInfo.') for approval.',
                                               'package_id' => $input['package_id'],
                                               'order_id' => $input['order_id']);
        }
        return $mailContent;        
    }    
    
    /**
    * @Description :function used to send approval mail for next level of approver.
    * @param array $input
    * @author Karthika.M
    */
    public function _nextLevelApprovalMail($input,$employeeApproverEmailInfo,$employeeApproverId,$sendPassengerMail){

        $this->_Oemployee = common::_checkClassExistsInNameSpace('employee');
        $this->_OflightItinerary = new flightItinerary();
        $this->_Otwig = init();

        //get approver mail info.
        if(!isset($input['approverEmailIdInfo'])){
            $approverEmailInfo = $this->_Oemployee->_getEmpInfo($input['employeeId']);
            $input['approverEmailIdInfo'] = $approverEmailInfo['title'].'.'.$approverEmailInfo['first_name'].$approverEmailInfo['last_name'].' ('.$approverEmailInfo['email_id'].')';
            $input['approverEmailId'] = $approverEmailInfo['email_id'];
        }
        
        //send Email to corresponding approver
        $this->_OapprovalProcess->_Otwig = $this->_Otwig;        
         
        //set booking id for subject.
        if($input['package_type'] == 3){
            
            $orderId = $input['orderIdColumn'];            
            $mailInfo['subject'] = "Request for travel approval- Order Id ".$input['package_id'];
            
            //Booking sent to next approver email to passenger
            $nextLevelApproverSub = "Request sent For next level Approver - Order Id ".$input['package_id'];
        }
        else{
            
            $orderId = $input['order_id'];

            //get mail info with respect to the order id.
            $input['orderMailInfo'] = $this->_OcommonQuery->_orderMailInfo($orderId);
                    
            $mailInfo['subject'] =  "Approval Request - Booking ID ".$input['orderMailInfo']['booking_id']." for ".$input['orderMailInfo']['sector'];    
            
            //Booking sent to next approver email to passenger
            $nextLevelApproverSub = "Request sent for next level Approver - Booking ID ".$input['orderMailInfo']['booking_id']." for ".$input['orderMailInfo']['sector'];    
        }
        
        //set overrided message
        $itinearayOverrideStatus = $this->_OflightItinerary->_isItineraryOverride($input['order_id']);
        $overrideMsg = $itinearayOverrideStatus ? ' and overrided ' : '';
        
        //set inputs
        $mailInfo['package_id'] = $input['package_id'];
        $mailInfo['order_id'] = $input['order_id'];
        $mailInfo['packageType']=$input['package_type'];
        $mailInfo['email_id'] = $employeeApproverEmailInfo['mailId'];
        $mailInfo['employee_id'] = $employeeApproverId;
        $mailInfo['status'] = 'Y';      
        $requestPersonName = $this->_Opassenger->_getRequestPersonInfo($input['package_id'])[0]['paxName'];

        //set message.
        if($sendPassengerMail == 'Y'){
            $mailInfo['message'] = "Request was approved ".$overrideMsg." by ".$input['approverEmailIdInfo']." and sent for next level approval to you.";
        }
        else{
            $mailInfo['message'] = "The travel request has been sent by ".$requestPersonName." for second level approval. ";
        }
        
        //calling the function for sending the approval.
        $mailContent = $input['package_type'] == 3 ? $this->_OapprovalProcess->_sendMailContent($mailInfo,'Y') : $this->_OapprovalProcess->_sendMailContent($mailInfo);
      
        //send sms to Next level of approver.
        $this->_OsendSms->_sendMessagetoApprover($input,$employeeApproverId);
        
        if($sendPassengerMail == 'Y'){
            /**************send Mail to Passenger.********/
            
            //Booking sent to next approver email to passenger
            $mailInfo['subject'] = $nextLevelApproverSub;
            
            //set message.
            $mailInfo['message'] = "Your travel request was approved by ".$input['approverEmailIdInfo']." and has been sent to the next level approver ".' '.implode(",", $employeeApproverEmailInfo['nameInfo']);
            $mailInfo['status'] = 'N';     
            
            //get passenger email info with respect to the order id.
            $passengerInfo = $this->_Opassenger->_getPassengerDetails($input['order_id'],'ADT');         
            $paxMailId = array_column($passengerInfo,'email_id');
            $paxMailId = array_unique($paxMailId);
            $mailInfo['email_id'] = $paxMailId;        
            $input['package_type'] == 3 ? $this->_OapprovalProcess->_sendMailContent($mailInfo,'Y') : $this->_OapprovalProcess->_sendMailContent($mailInfo);
            
            //send sms to passenger.
            $this->_OsendSms->_approvalSMStoPax('NEXTLEVELAPPROVALTOPAX',$input,$passengerInfo,$input['approverEmailIdInfo'],implode(",", $employeeApproverEmailInfo['nameInfo']));
        }        
        return $mailContent;
    }

    /*
    * @Description  This method used to get the not approve booking in the corporate.
    * @param int,string|$corporateId,$hours,$travelMode
    * @date|22.02.2018 
    * @author|Karthika.M
    */ 

    public function _getNotApprovedOrderDetails($corporateId,$hours,$travelMode){

        $sql = "SELECT 
                    at.r_order_id as orderId,bh.package_id as packageId,at.approver_id,bh.booking_date,bh.travel_mode,
                    TIMESTAMPDIFF(HOUR,bh.booking_date,now()) as hours
                FROM 
                    approval_tracking at
                    INNER JOIN booking_history bh ON at.r_order_id = bh.order_id
                    INNER JOIN order_details od ON od.r_order_id = at.r_order_id
                WHERE 
                    approval_view_status = 'N' AND od.approval_status NOT IN (3,2) AND bh.r_corporate_id  = ".$corporateId;
        
        //add condition for all travel mode.
        if($travelMode == 'ALL'){
            $sql .= " AND IF(bh.travel_mode = 'H',bh.checkin_date >= now(),bh.onward_depature_date >= now())";
        }
        else if($travelMode == 'H'){
            //add condition for hotel.
           $sql .= " AND bh.checkin_date >= now()";
        }
        else{ 
            //add condition for other than hotel travel mode.
            $sql .= " AND bh.onward_depature_date >= now()";
        }
        
        //adding condition for hours.
        if($hours != ''){
            $sql .= " AND TIMESTAMPDIFF(HOUR,bh.booking_date,now()) IN (".$hours.")";
        }
        fileWrite($sql,"approvalRemainderMail","a+");   
        $result = $this->_OcommonDBO->_getResult($sql);
        return $result;
    }

    /**
    * @Description : function used to update the expired time approval status and send mail to next level approval
    * @author Rajesh.U
    * @date 2019-09-09
    */

    public function _sendMailToNextLevel($expiredOrder){

        if(is_array($expiredOrder)){

            foreach ($expiredOrder as $key => $value) {

                //function used to update the time approval expired status
                $this->_updateTimeApprovalExpireStatus($value['r_order_id']);

                //function used to get next level approval info
                $nextLevelApprovalInfo = $this->_nextLevelApprovalInfo($value['r_order_id']);

                //function used to send approval to next level
                $this->_sendApprovalToNextLevel($nextLevelApprovalInfo,'N');

            }
        }
        return true;
    }

    /**
    * @Description : function used to get next level approval info
    * @author Rajesh.U
    * @date 2019-09-10
    */

    public function _nextLevelApprovalInfo($orderId){

        $sql = "SELECT
                    od.order_id,dmp.package_id,dmp.package_type,apt.approver_id AS employeeId,dme.email_id AS mailId,dme.email_id AS approverEmailId,od.r_ticket_status_id,concat(dme.title,'. ',dme.first_name,dme.last_name,' (',dme.email_id,')') AS approverEmailIdInfo
                FROM
                    approval_tracking apt
                INNER JOIN dm_employee dme ON apt.approver_id = dme.employee_id
                INNER JOIN order_details od ON apt.r_order_id = od.order_id 
                #AND od.approval_level = apt.approval_level
                INNER JOIN fact_booking_details fbd ON od.order_id = fbd.r_order_id
                INNER JOIN dm_package dmp ON fbd.r_package_id = dmp.package_id
                WHERE
                    apt.approval_type NOT IN ('TA','IA') AND apt.approval_expired_status = 'N' AND apt.r_order_id = " .$orderId;

        return $this->_OcommonDBO->_getResult($sql)[0];

    }

    /**
    * @Description : function used to update the expired time approval status and update order approval level
    * @author Rajesh.U
    * @date 2019-09-09
    */

    public function _updateTimeApprovalExpireStatus($orderId,$approvalLevel){

        $sql = "UPDATE
                    approval_tracking apt
                INNER JOIN order_details od ON apt.r_order_id = od.order_id
                SET 
                    apt.approval_expired_status = 'Y'
                 WHERE
                    apt.approval_type = 'TA' AND apt.r_order_id = " .$orderId;

        $this->_OcommonDBO->_getResult($sql);

        return true;

    }

    /**
    * @Description : function used to check travel date get expired or not
    * @author Rajesh.U
    * @date 2019-09-19
    */

    public function _getBookingExpireStatus($orderId){

        $sql = "SELECT
                    bk.onward_depature_date,od.workflow_caption
                FROM
                    booking_history bk
                INNER JOIN order_details od ON bk.order_id = od.order_id
                WHERE
                    od.order_id = ".$orderId;

        $travelDate = $this->_OcommonDBO->_getResult($sql)[0];

        $sysdate = strtotime(date("Y-m-d H:i:s"));

        if($travelDate['workflow_caption'] == CMP_ITINERARY_SSR_APPROVAL || $travelDate['workflow_caption'] == CMP_ITINERARY_APPROVAL){
            $expireStatus = ($sysdate > strtotime($travelDate['onward_depature_date'])) ? 'Y' :'N';
            fileWrite($expireStatus,'statsu','a+');
        }
        else{
            $expireStatus = 'N';
        }
        return $expireStatus; 
    }

    public function _setOrderStatus($checkWorkFlow,$input){    
     
        if(($checkWorkFlow == CMP_ITINERARY_SSR_APPROVAL && count($input['approvalTrackingInfo']) > 0 && !in_array(FALSE, $input['approvalTrackingInfo']))){
            $orderDetailsStatus = ITINERARY_SSR_SELECTED;
        }
        else if($checkWorkFlow == CMP_TICKET_APPROVAL && count($input['approvalTrackingInfo']) > 0 && !in_array(FALSE, $input['approvalTrackingInfo']) && $input['settingsDisplayData']['Display_SSR_Request']['status'] == 'Y'){
            $orderDetailsStatus = ITINERARY_SSR_SELECTED;
        }
        else{
            $orderDetailsStatus =  NOT_PAID;
        }
        
        return $orderDetailsStatus;
    }

    public function _setEmployeCodeInMail($emailId){
        return $emailId;
    }

    public function _getTripDetails($packageId){
        return true;        
    }

    public function _deleteMailLog($orderId){
        return true;
    }
}