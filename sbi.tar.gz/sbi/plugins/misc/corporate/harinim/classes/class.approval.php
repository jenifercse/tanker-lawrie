<?php
/* * **************************************************************************
 * @File            create Agency class file
 * @Description     This class file holds all approval related functionalities
 * @Author          Taslim
 * @Created Date    10/06/2016
 * @Tables used     fact_approval_mapping, 
 * *************************************************************************** */
fileRequire("./lib/common/commonMethods.php");

class approval extends employee {
    public function __construct()
    {
        $this->_Objcommon = new commonMethods();
        $this->_ObjDB     = new commonDBO();
    }
    
     /*
     * @Description  function to preload dimension table array values into class objects
     * @param 
     * @return 
     */
    public function _preloadDataTablesArray() 
    {
        $this->_processTypeArray   = $this->_preloadArrayFromTable('dm_process_type', 'dm_process_type_id', 'process_type');
        $this->_travelModeArray    = $this->_preloadArrayFromTable('dm_travel_mode', 'travel_mode_id', 'travel_mode');
        $this->_approvalTypeArray  = $this->_preloadArrayFromTable('dm_approval_type','dm_approval_type_id', 'approval_type');
        $this->_tripTypeArray      = array(0 => 'oneway' , 1 => 'roundtrip', '2' => 'multicity');
    }
    
    /*
     * @Description  function save approver details to db
     * @param 
     * @return 
     */
    public function _saveApprover($employeeId ='') 
    {
        if(isset($employeeId) && !empty($employeeId)) {
            //load dimesion tables values into object arrray
            $this->_preloadDataTablesArray();

            if($this->_IinputData['approval_check'] == 'Y') {

                $this->_AapproverLevelArray = array();

                foreach ($this->_IinputData['email'] as $key => $val) {

                    $this->_AinsertArray           = array();
                    $this->_IfactApprovalMappingId = false;

                    if(isset($this->_AapproverLevelArray[$this->_IinputData['level'][$key]])) {
                        $this->_AapproverLevelArray[$this->_IinputData['level'][$key]] = $this->_AapproverLevelArray[$this->_IinputData['level'][$key]]+1;
                    } else {
                        $this->_AapproverLevelArray[$this->_IinputData['level'][$key]] = 1;
                    }

                    if($this->_checkApproverExists($val)) {
                        
                        //check if already selected email id is replaced with new email id if true remove the old approval mapping
                        // and proceed for new approval mapping
                        if($this->_IinputData['approver_account_id_previous'][$key] > 0 && $this->_IinputData['email_previous'][$key] != $val) {
                             $this->_removeSavedApprover($employeeId, $this->_IinputData['approver_account_id_previous'][$key]); 
                        }

                        //assign approver values 
                        $this->_AinsertArray['r_approver_id']      = $this->_IapproverAccountId;
                        $this->_AinsertArray['r_employee_id']      = $employeeId;
                        $this->_AinsertArray['approval_level']     = $this->_IinputData['level'][$key];

                        $this->_AinsertArray['trip_type']          = array_search($this->_IinputData['trip_type'],  $this->_tripTypeArray);
                        $this->_AinsertArray['r_process_type_id']  = array_search($this->_IinputData['process_type'],  $this->_processTypeArray);
                        $this->_AinsertArray['r_travel_mode_id']   = array_search($this->_IinputData['travel_mode'],  $this->_travelModeArray);
                        $this->_AinsertArray['r_approval_type_id'] = array_search($this->_IinputData['approval_type'],  $this->_approvalTypeArray);
                        $this->_AinsertArray['r_fact_corporate_category_mapping_id'] = 0;

                        if(!$this->_checkApprovalMapAlreadyExists($this->_IinputData['approval_mapping_id'][$key])) {
                            $this->_AinsertArray['approval_limit']  = '0';
                            $this->_AinsertArray['approval_order']  = $this->_AapproverLevelArray[$this->_IinputData['level'][$key]];
                            $this->_AinsertArray['added_by']        = $_SESSION['accountId'];
                            $this->_factApprovalMappingId[] = $this->_ObjDB->_insert('fact_approval_mapping', $this->_AinsertArray);
                        } else {
                            if($this->_IfactPreviousApproverLevel != $this->_IinputData['level'][$key]) { //if same approver of same level not required to update
                                $this->_AinsertArray['approval_level']  = $this->_IinputData['level'][$key];
                                $this->_factApprovalMappingId[] = $this->_ObjDB->_update('fact_approval_mapping', $this->_AinsertArray, 'fact_approval_mapping_id', $this->_IfactApprovalMappingId);
                            }
                        }

                        $this->_ATwigAlertOutput['message']  = 'Approval mapped successfully';
                        $this->_ATwigAlertOutput['type']     = 3;

                    } else {
                        $this->_ATwigAlertOutput['type']    = 0;
                        $this->_ATwigAlertOutput['message'] = 'Approval Mapping not done';
                    }
                } 
            } else {
                //remove the previously save approver as per the arugments passed
               $this->_removeSavedApprover($employeeId); 
               $this->_ATwigAlertOutput['message']  = 'Approval updated successfully';
               $this->_ATwigAlertOutput['type']     = 1;
            }
        } else {
            $this->_ATwigAlertOutput['type']    = 0;
            $this->_ATwigAlertOutput['message'] = 'Approval Mapping not done - employee details not available';
        }
    }
    
     /*
     * @Description  function to removed already saved approver
     * @param 
     * @return mixed|$result
     */
    private function _removeSavedApprover($employeeId, $approverAccountId = '') {

        $where = '';
        
        if(isset($approverAccountId) && !empty($approverAccountId)) {
            $where .= " AND r_approver_id = ".$approverAccountId." ";
        }

        if(isset($this->_IinputData['travel_mode'])) {
            $travelModeId = array_search($this->_IinputData['travel_mode'],  $this->_travelModeArray);
            $where .= " AND r_travel_mode_id = ".$travelModeId." ";
        }

        if(isset($this->_IinputData['process_type'])) {
            $processTypeId = array_search($this->_IinputData['process_type'],  $this->_processTypeArray);
            $where .= " AND r_process_type_id = ".$processTypeId." ";
        }

        if(isset($this->_IinputData['approval_type'])) {
            $approvalTypeId = array_search($this->_IinputData['approval_type'],  $this->_approvalTypeArray);
            $where .= " AND r_approval_type_id = ".$approvalTypeId." ";
        }

        if(isset($this->_IinputData['trip_type'])) {
            $tripTypeId = array_search($this->_IinputData['trip_type'],  $this->_tripTypeArray);
            $where .= " AND trip_type = '".$tripTypeId."' ";
        }
        

        //delete the previously added entries
        $sql    = "DELETE FROM fact_approval_mapping WHERE r_employee_id = ".$employeeId." ".$where."";
        $result = $this->_ObjDB->_getResult($sql);
        
        return $result;
    }
    
     /*
     * @Description  function to check approver already exists in face_approval_mapping table
     * @param 
     * @return mixed|$result
     */
    private function _checkApprovalMapAlreadyExists($factApprovalMappingId = '') 
    {
        
        $sql = "SELECT fact_approval_mapping_id, approval_level FROM fact_approval_mapping ";
        
        $sql .= " WHERE 1 ";
        
        if(isset($factApprovalMappingId) && !empty($factApprovalMappingId)) {
            $sql .= " AND fact_approval_mapping_id = ".$factApprovalMappingId."";
        } else {
            foreach ($this->_AinsertArray as $key=>$val) {
                $sql .= " AND  `$key` = '".$val."'";
            }
        }
        
        $result = $this->_ObjDB->_getResult($sql);
        
        if(isset($result[0]['fact_approval_mapping_id'])) {
            $this->_IfactApprovalMappingId     = $result[0]['fact_approval_mapping_id'];
            $this->_IfactPreviousApproverLevel = $result[0]['approval_level'];
            $returnValue = true;
        } else {
            $returnValue = false;
        }
        
        return $returnValue;
    }
    
    /*
     * @Description  function check if the approverl email id exists in db
     * @param string|$approverEmail
     * @return boolean|$returnValue
     */
    private function _checkApproverExists($approverEmail ='')
    {
        $returnValue = false;
        
        $this->_IapproverAccountId = '';
        
        if($this->_Objcommon->_doEmailValidation($approverEmail)) {
            
            //check email id exists in same corporate
            $sql = "SELECT de.email_id, fe.r_account_id FROM dm_account dm
                    INNER JOIN fact_employee fe ON dm.account_id = fe.r_account_id
                    INNER JOIN dm_employee de ON fe.r_employee_id = de.employee_id
                    WHERE de.email_id = '".$approverEmail."' AND fe.r_corporate_id = ".$_SESSION['corporateId']."";
            $result = $this->_ObjDB->_getResult($sql);
            
            if($result && count($result) > 0) {
                $this->_IapproverAccountId = $result[0]['r_account_id'];
                $returnValue = true;
            } 
        } 
        
        return $returnValue;
    }
    
     /*
     * @Description  generic function to load master table values into array for later use
     * @param string|$table
     * @param int|$key
     * @param string|$key
     * @return array|$returnArray
     */
    private function _preloadArrayFromTable($table, $key, $value)
    {
        $returnArray = array();
        $fieldArray = array($key, $value);
        $result = $this->_ObjDB->_select($table, $fieldArray);
        
        if($result) {
            $returnArray = array_column($result, $value, $key);
        }
        return $returnArray;
        
    }
    
      /*
     * @Description  function gets the approver details tab based as array
     * @param int|$key
     * @param string|$type
     * @return array|$returnArray
     */
    public function _getApproverDetails($key = 1, $employeeId = '')
    {
        $returnArray     = '';
        $whereCondArray = array();
        
        switch ($key) {
            
            default:
            case 1: // common Approver
                
                //for displaying in UI
                //HIDDEN ELEMNTS IN FORM
                $processTypeValue  = 'all'; 
                $approvalTypeValue = 'normal approver';
                $travelMode        = 'all';
                $tripType          = 'roundtrip';
                        
                //DISPLAY ELEMENTS
                $label             = 'Common Approval';
                $elementId         = 'approval_tab1';
                $cbId              = 'approval_check';
                $formName          = 'common_approval';
                $tabId             = 'tab1';
                $showLevel         = true; 
                
                //for usage in query - displaying already existing approvers
                //$where .= " AND r_travel_mode_id = ".$travelModeId." AND r_approval_type_id = ".$approvalTypeId." AND r_process_type_id = ".$processTypeId."  ";  //travel mode type all 
                $whereCondArray = array('r_travel_mode_id' => 7, 'r_approval_type_id' => 1, 'r_process_type_id' => 1);
                
                break;
            
            case 2: //domestic air Approver
            
                //for displaying in UI
                //HIDDEN ELEMNTS IN FORM
                $processTypeValue  = 'all'; 
                $approvalTypeValue = 'normal approver';
                $travelMode        = 'Domestic Air';
                $tripType          = 'roundtrip';
                
                //DISPLAY ELEMENTS
                $label             = 'Domestic Air';
                $elementId         = 'approval_tab2';
                $cbId              = 'approval_check';
                $formName          = 'domestic_approval';
                $tabId             = 'tab2';
                $showLevel         = true; 
                
                //for usage in query
                //$where .= " AND r_travel_mode_id = ".$travelModeId." ";  //travel mode type all
                $whereCondArray = array('r_travel_mode_id' => 1);
                
                break;
            
            case 3: //international air Approver
               
                //for displaying in UI
                $processTypeValue  = 'all'; 
                $approvalTypeValue = 'normal approver';
                $travelMode        = 'International Air';
                $tripType          = 'roundtrip';
                
                //DISPLAY ELEMENTS
                $label             = 'International Air';
                $elementId         = 'approval_tab3';
                $cbId              = 'approval_check';
                $formName          = 'international_approval';
                $tabId             = 'tab3';
                $showLevel         = true; 
                
                //for usage in query
                //$where .= " AND r_travel_mode_id = ".$travelModeId." ";  //travel mode type all
                $whereCondArray = array('r_travel_mode_id' => 2);
                
                break;
            
            case 4: //Reschedule Approver
            
                //for displaying in UI
                $processTypeValue  = 'reschedule';
                $approvalTypeValue = 'normal approver';
                $travelMode        = 'all';
                $tripType          = 'roundtrip';
                
                //DISPLAY ELEMENTS
                $label             = 'Reschedule Approval';
                $elementId         = 'approval_tab4';
                $cbId              = 'approval_check';
                $formName          = 'reschedule_approval';
                $tabId             = 'tab4';
                $showLevel         = true; 
                
                //for usage in query
                //$where .= " AND r_process_type_id = ".$processTypeId." ";  //travel mode type all 
                $whereCondArray = array('r_process_type_id' => 4, 'r_travel_mode_id' => 7);
                
                break;
            
            case 5: //Train Approver
                
                //for displaying in UI
                $processTypeValue  = 'all'; // train - dm_process_type.process_type = 4 
                $approvalTypeValue = 'normal approver';
                $travelMode        = 'Train';
                $tripType          = 'roundtrip';
                
                //DISPLAY ELEMENTS
                $label             = 'Train Approval';
                $elementId         = 'approval_tab5';
                $cbId              = 'approval_check';
                $formName          = 'train_approval';
                $tabId             = 'tab5';
                $showLevel         = true; 
                
                //for usage in query
                //$where .= " AND r_travel_mode_id = ".$travelModeId." ";  //travel mode type all 
                $whereCondArray = array('r_travel_mode_id' => 3);
                break;
            
            case 6: //Hotel Approver

                //for displaying in UI
                $processTypeValue  = 'all'; // all
                $approvalTypeValue = 'normal approver';
                $travelMode        = 'Hotel';
                $tripType          = 'roundtrip';
                
                //DISPLAY ELEMENTS
                $label             = 'Hotel Approval';
                $elementId         = 'approval_tab6';
                $cbId              = 'approval_check';
                $formName          = 'hotel_approval';
                $tabId             = 'tab6';
                $showLevel         = true; 
                
                //for usage in query
                //$where .= " AND r_travel_mode_id = ".$travelModeId." ";  //travel mode type all 
                $whereCondArray = array('r_travel_mode_id' => 6);
                break;
            
            case 7: //Car Approver
                
                //for displaying in UI
                $processTypeValue  = 'all'; // all
                $approvalTypeValue = 'normal approver';
                $travelMode        = 'Car';
                $tripType          = 'roundtrip';
                
                //DISPLAY ELEMENTS
                $label             = 'Car Approval';
                $elementId         = 'approval_tab7';
                $cbId              = 'approval_check';
                $formName          = 'car_approval';
                $tabId             = 'tab7';
                $showLevel         = true; 
                
                //for usage in query
                //$where .= " AND r_travel_mode_id = ".$travelModeId." ";  //travel mode type all
                $whereCondArray = array('r_travel_mode_id' => 5);
                break;
 
            case 8: //Bus Approver

                //for displaying in UI
                $processTypeValue  = 'all'; // all
                $approvalTypeValue = 'normal approver';
                $travelMode        = 'Bus';
                $tripType          = 'roundtrip';
                
                //DISPLAY ELEMENTS
                $label             = 'Bus Approval';
                $elementId         = 'approval_tab8';
                $cbId              = 'approval_check';
                $formName          = 'bus_approval';
                $tabId             = 'tab8';
                $showLevel         = true; 
                
                //for usage in query
                //$where .= " AND r_travel_mode_id = ".$travelModeId." ";  //travel mode type all
                $whereCondArray = array('r_travel_mode_id' => 4);
                break;
            
            case 9: //Trip Approver
                
                //for displaying in UI
                $processTypeValue  = 'all'; // all
                $approvalTypeValue = 'normal approver';
                $travelMode        = 'Trip';
                $tripType          = 'multicity';
                
                //DISPLAY ELEMENTS
                $label             = 'Trip Approval';
                $elementId         = 'approval_tab9';
                $cbId              = 'approval_check';
                $formName          = 'trip_approval';
                $tabId             = 'tab9';
                $showLevel         = true; 
                
                //for usage in query
                //$where .= " AND r_travel_mode_id = ".$travelModeId." ";  //travel mode type all 
                $whereCondArray = array('r_travel_mode_id' => 8);
                break;

            case 10: //Intimation Approver

                //for displaying in UI
                $processTypeValue  = 'all'; // all
                $approvalTypeValue = 'intimation approver';
                $travelMode        = 'all';
                $tripType          = 'multicity';
                
                //DISPLAY ELEMENTS
                $label             = 'Intimation Approval';
                $elementId         = 'approval_tab10';
                $cbId              = 'approval_check';
                $formName          = 'intimation_approval';
                $tabId             = 'tab10';
                $showLevel         = false; 
                
                //for usage in query
                //$where .= " AND r_approval_type_id = ".$approvalTypeId." ";  //Intimation approval category
                $whereCondArray = array('r_approval_type_id' => 4);
                break;
        }
        
        $this->_AapproverDisplay = array();
        
        if(isset($employeeId) && !empty($employeeId)) {
            
            $where  = " WHERE r_employee_id = ".$employeeId." ";
            
            foreach($whereCondArray as $key=>$val) {
                $where .= " AND `".$key."` = ".$val." ";
            }
            
            $sql    = "SELECT * FROM fact_approval_mapping ".$where." ORDER BY approval_level";
            
            $result = $this->_ObjDB->_getResult($sql);
        }
        
        $this->_AapproverDisplay['label']          = $label;
        $this->_AapproverDisplay['elem_id']        = $elementId;
        $this->_AapproverDisplay['cb_id']          = $cbId;
        $this->_AapproverDisplay['form_name']      = $formName;
        $this->_AapproverDisplay['tabid']          = $tabId;
        $this->_AapproverDisplay['showlevel']      = $showLevel;
        $this->_AapproverDisplay['employee_id']    = $employeeId;
       
        if($result && count($result) > 0) { //edit mode
            
            $this->_AapproverDisplay['approval_enable'] = 'Y'; // display the tab since values are avialble
            
            $i = 1;
            foreach($result as $res) {
                
                if(!isset($this->_AapproverDisplay['trip_type'])) {
                    $this->_AapproverDisplay['processtype']    = $this->_processTypeArray[$res['r_process_type_id']];
                    $this->_AapproverDisplay['approval_type']  = $this->_approvalTypeArray[$res['r_approval_type_id']];
                    $this->_AapproverDisplay['travel_mode']    = $this->_travelModeArray[$res['r_travel_mode_id']];
                    $this->_AapproverDisplay['trip_type']      = $this->_tripTypeArray[$res['trip_type']];
                }
                
                $this->_AapproverDisplay['approverArray'][$i]['approver_email']               = $this->_getAccountEmailId($res['r_approver_id']);
                $this->_AapproverDisplay['approverArray'][$i]['approval_level']               = $res['approval_level'];
                $this->_AapproverDisplay['approverArray'][$i]['previous_approver_email']      = $this->_AapproverDisplay['approverArray'][$i]['approver_email'];
                $this->_AapproverDisplay['approverArray'][$i]['approver_account_id_previous'] = $res['r_approver_id'];
                $this->_AapproverDisplay['approverArray'][$i]['current_approver_order']       = $res['approval_order'];
                $this->_AapproverDisplay['approverArray'][$i]['approval_mapping_id']          = $res['fact_approval_mapping_id'];
                /* Set array for insertion in to approval_tracking */
                $this->_AapproverDisplay['approverArray'][$i]['approval_limit']          = $res['approval_limit'];
                $this->_AapproverDisplay['approverArray'][$i]['approval_order']          = $res['approval_order'];
                $this->_AapproverDisplay['approverArray'][$i]['r_approver_id']           = $res['r_approver_id'];
                $this->_AapproverDisplay['approverArray'][$i]['r_travel_mode_id']        = $res['r_travel_mode_id'];
                $this->_AapproverDisplay['approverArray'][$i]['trip_type']               =$res['trip_type'];
                $this->_AapproverDisplay['approverArray'][$i]['r_approval_type_id']      =$res['r_approval_type_id'];
                $this->_AapproverDisplay['approverArray'][$i]['approval_status']      =$res['approval_status'];
                        
                $i++;
            }
        } else { //create new approval mode
            $this->_AapproverDisplay['approval_enable'] = 'Y';  //hide the tab since values are not available
            $this->_AapproverDisplay['processtype']    = $processTypeValue;
            $this->_AapproverDisplay['approval_type']  = $approvalTypeValue;
            $this->_AapproverDisplay['travel_mode']    = $travelMode;
            $this->_AapproverDisplay['trip_type']      = $tripType;
        }
       
        $returnArray = $this->_AapproverDisplay;
        
        return $returnArray;
    }
    
     /*
     * @Description  function gets email id by account id
     * @param int|$accountId
     * @return string|$returnValue
     */
    private function _getAccountEmailId($accountId) {
        
        $returnValue = false;
        
        if($accountId !='') {
            //$fieldArray = array('login_email');
            $query = "SELECT de.email_id FROM fact_employee fe INNER JOIN dm_employee de ON fe.r_employee_id = de.employee_id
                      WHERE fe.r_account_id = ".$accountId."";
            $result = $this->_ObjDB->_getResult($query);
            
            $returnValue = $result[0]['email_id'];
        }
       
        return $returnValue;
    }
    
     /*
     * @Description method returns the list of approval tab under approval for each employee
     * @param 
     * @return array|$approverDetails
     */
    public function _getApproverList($employeeId = '') {
        
        $approverDetails = array();
        
        //pre-load required approval type realted details from dimension tables
        $this->_preloadDataTablesArray();
        
        $totalApprovalCount = 10;
        
        for ($i = 1; $i<=$totalApprovalCount; $i++)
        {
           $approverDetailsArray = array();
           
           $approverDetailsArray = $this->_getApproverDetails($i, $employeeId);
           
           if($approverDetailsArray && count($approverDetailsArray) > 0) {
                $approverDetails[$i] = $approverDetailsArray;
           }
        }
        
        return $approverDetails;
    }
    
     /*
     * @Description  delete approver by face_approvalMapppingID
     * @param 
     * @return mixed|$result
     */
    public function _deleteApprover() {
        $fact_approval_mapping_id  = $this->_IinputData['fact_am_id'];
        $current_approval_level    = $this->_IinputData['approval_level'];
        $current_approval_order    = $this->_IinputData['approval_order'];
        
        //increment next level approvers (approval_level & approver_limit before removing the current appprover
        
        $nextLevelApproverArray = $this->_getNextLevelApprovers($fact_approval_mapping_id, $current_approval_level, $current_approval_order);
        
        //$sql    = "DELETE FROM fact_approval_mapping WHERE fact_approval_mapping_id = ".$fact_approval_mapping_id."";
        //$result = $this->_ObjDB->_getResult($sql);
        
        $result = $this->_ObjDB->_delete('fact_approval_mapping', 'fact_approval_mapping_id', $fact_approval_mapping_id);
        
        if($result > 0) {
            //increment next level approvers
            $this->_incrementNextLevelApprovers($nextLevelApproverArray);
        }
        
        return $result;
    }
    
    private function _incrementNextLevelApprovers($nextLevelApproverArray) {
        
        if(!empty($nextLevelApproverArray) && is_array($nextLevelApproverArray)) {
            foreach ($nextLevelApproverArray as $res) {
                $updateArray = array();
                
                if($res['approval_order'] > 1) {
                   //decrement approval order itself 
                   $updateArray['approval_order'] = (int) $res['approval_order'] - 1; 
                } else if($res['approval_level'] != 1) {
                   $updateArray['approval_level'] = (int) $res['approval_level'] - 1; 
                }
                
                $this->_ObjDB->_update('fact_approval_mapping', $updateArray, 'fact_approval_mapping_id', $res['fact_approval_mapping_id']);
            }
        }
    }
    
    private function _getNextLevelApprovers($fact_approval_mapping_id ='', $approvar_level, $approver_order) {
        
        $approvalMappingDetailsArray = false;
        
        if($fact_approval_mapping_id !='') {
            //pre-load required approval type realted details from dimension tables
            $this->_preloadDataTablesArray();


            //query to get next level approver who are mapped for the tab
            $sql = "SELECT * FROM fact_approval_mapping
                    WHERE fact_approval_mapping_id != ".$fact_approval_mapping_id." AND r_employee_id = ".$this->_IinputData['employeeId']."
                    AND approval_level >= ".$approvar_level." AND approval_order >= ".$approver_order."";

            if(isset($this->_IinputData['travel_mode'])) {
                $travelModeId = array_search($this->_IinputData['travel_mode'],  $this->_travelModeArray);
                $sql .= " AND r_travel_mode_id = ".$travelModeId." ";
            }

            if(isset($this->_IinputData['process_type'])) {
                $processTypeId = array_search($this->_IinputData['process_type'],  $this->_processTypeArray);
                $sql .= " AND r_process_type_id = ".$processTypeId." ";
            }

            if(isset($this->_IinputData['approval_type'])) {
                $approvalTypeId = array_search($this->_IinputData['approval_type'],  $this->_approvalTypeArray);
                $sql .= " AND r_approval_type_id = ".$approvalTypeId." ";
            }

            if(isset($this->_IinputData['trip_type'])) {
                $tripTypeId    = array_search($this->_IinputData['trip_type'],  $this->_tripTypeArray);
                $sql .= " AND trip_type = '".$tripTypeId."' ";
            }

            
            $result = $this->_ObjDB->_getResult($sql);

            $approvalMappingDetailsArray = $result;
        }
        
        return $approvalMappingDetailsArray;
        //iterate and decrement the next level approvers
    }
    
}