<?php

/**
 * @package SAP to SSBT service
 * @created 25-Mar-2019
 * @copyright (c) 2019, Inifiniti Software Solutions Pvt. Ltd
 * @description handles the sap to ssbt service
 */


 class saptossbt{

    public function __construct()
    {
        $this->_OcommonDBO = new commonDBO();
        
    }


    /**
     * function used to update the employee ticket blocking status
     *
     * @param array $_Arequest
     * @return array
     */
    public function _employeeTicketBookingLock($_Arequest = array()){

        $_AreturnResponse = $_AupdateRequestInfo = array();

        $_AemployeeId = $this->_getEmployeeId($_Arequest);

        if($_AemployeeId[0]['employee_id'] > 0){

            // X- Y EMPTY - N
            $_AupdateRequestInfo['ticket_booking_lock'] = $_Arequest['ticketBookingLock'] == 'X' ? 'Y' : 'N';
            $_AupdateRequestInfo['prepTicketLock'] = $_Arequest['prepTicketLock'] == 'X' ? 'Y' : 'N';
            $_AupdateRequestInfo['familyTicketLock'] = $_Arequest['familyTicketLock'] == 'X' ? 'Y' : 'N';
            
            //FUNCTION CALL TO UPDATE THE DETAILS
             $this->_OcommonDBO->_update('sap_employee_dependent_details',$_AupdateRequestInfo,'r_employee_id', $_AemployeeId[0]['employee_id']);
             $_AreturnResponse[] = true;
        }
                
        return in_array(TRUE,$_AreturnResponse) ? array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'Y','responseMessage'=>'Successfully Received') : array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'N','responseMessage'=>'Failure to insert or update the record');
    }

    /**
     * function used to update employee travel booking date details
     *
     * @param array $_Arequest
     * @return array
     */
    public function _employeeTransferOut($_Arequest = array()){

        $_AreturnResponse = $_AupdateRequestInfo = array();

        $_AemployeeId = $this->_getEmployeeId($_Arequest);

        if($_AemployeeId[0]['employee_id'] > 0){
            $_Arequest['employeeStatus'] = 'T';
            $transfeDataForming = $this->_getEmployeeValidFromToDate($_AemployeeId[0]['employee_id'])[0];
            $_Arequest['transfer_from_date'] = $transfeDataForming['transfer_in_date_to_sbt'];
            $_Arequest['transfer_to_date'] = $transfeDataForming['transfer_out_date_from_sbt'];
            $_AkeyValueData = array('preparatory_trip_from_date'=>'preparatoryTourBeginDate','preparatory_trip_to_date'=>'preparatoryTourEndDate',
                                'joining_trip_from_date'=>'joiningTourBeginDate','joining_trip_to_date'=>'joiningTourEndDate',
                                'return_trip_from_date'=>'returnTripBeginDate','return_trip_to_date'=>'returnTripEndDate','employee_sap_status'=>'employeeStatus','transfer_from_date'=>'transfer_from_date','transfer_to_date'=>'transfer_to_date');

            array_walk($_AkeyValueData, function($v, $k) use(&$_AupdateRequestInfo, $_Arequest){
            
                (isset($_Arequest[$v]) && !empty($_Arequest[$v])) ? $_AupdateRequestInfo[$k] = $_Arequest[$v] : '';
            });

            //FUNCTION CALL TO UPDATE THE DETAILS
            $_AreturnResponse[] = $this->_OcommonDBO->_update('sap_employee_dependent_details',$_AupdateRequestInfo,'r_employee_id',$_AemployeeId[0]['employee_id']);
        }
                
        return in_array(TRUE,$_AreturnResponse) ? array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'Y','responseMessage'=>'Successfully Received') : array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'N','responseMessage'=>'Failure to insert or update the record');
    }

    /**
     * function used to update employee master details if exist
     * if employee details not exist need to insert
     * @param array $_Arequest
     * @return array
     */
    public function _sapEmployeeMaster($_Arequest = array()){
        $diviosnArray = array('01' => 'Refineries','02' => 'Pipelines','03' => 'Marketing','04' => 'R&D Centre','05' => 'AOD','06' => 'IOBL','07' => 'Corporate Office','08' => 'Outside IOCL','09' =>'BRPL','10' =>'IBP','11' =>'IPPL','12' =>'CPCL');
        $_Oemployee = common::_checkClassExistsInNameSpace('employee');

        $_AupdateRequestInfo = array();

        $_AemployeeId = $this->_getEmployeeId($_Arequest);


        $_AemployeeId = $_AemployeeId ? $_AemployeeId : false;

        if(!$this->_IcorporateId){
            return array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'N','responseMessage'=>'Failure to insert or update the record');
        }

        if(!$_AemployeeId){

            $stringStartFlag = $this->startsWith($_Arequest['employeeSubGroup'],'H');

            if($_Arequest['paxMail'] != ''){
                // validating domain name for the pax email
                $explodeEmailId = explode("@",$_Arequest['paxMail'])[1];
                //if(strtolower($explodeEmailId) != 'indianoil.in' && ENVIRONMENT_NAME == 'PRODUCTION'){
                if(strtolower($explodeEmailId) != 'indianoil.in' && ENVIRONMENT_NAME == 'PRODUCTION'){
                    return array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'N','responseMessage'=>'Email id not contain valid domain name');
                }
                //$stringStartFlag = $this->startsWith($_Arequest['paxMail'],'@indianoil.in');
            }
            if($_Arequest['paxMail'] == '' && !$stringStartFlag){
                return array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'N','responseMessage'=>'Failure to insert or update the record, email is not available in data');
            }
            elseif($stringStartFlag){
                $_Arequest['paxMail'] = $this->_generateRandomString(8) ."@IOCL.com";
            }
        }
        
        $_Arequest['divisionNo'] = $_Arequest['division'];
        
        $_Arequest['division'] = $_Arequest['division'] != '' ? $diviosnArray[$_Arequest['division']] : '' ;

        $_Arequest['employeesStatus'] = $_Arequest['employeesStatus'] == 'A' ? 'Y' : 'N';

        $_AemployeeDetailsInfo = array('dm_employee'=>array('first_name'=>'firstName','last_name'=>'lastName','email_id'=>'paxMail','status'=>'employeesStatus',
                                'mobile_no'=>'mobileNumber','employee_code'=>'employeeNumber'),
                                'employee_details'=>array('department'=>'division','designation'=>'designation','date_of_birth'=>'dob','division'=>'divisionNo',
                                'branch'=>'location','r_cost_center_code_id'=>'companyCode','r_designation_id'=>'designation','r_branch_id'=>'location','r_band_id'=>'employeeSubGroup','r_department_id'=>'division','r_billto_id'=>'gstNumber'),                                
                                'sap_employee_dependent_details'=>array('division'=>'division','company_code'=>'companyCode',
                                'transfer_in_date_to_sbt'=>'validFromDate','transfer_out_date_from_sbt'=>'validToDate',
                                'vendor_id'=>'vendorId','ioc_gst_in'=>'gstNumber','employee_sap_status'=>'employeesStatus'));
            array_walk($_AemployeeDetailsInfo, function($v, $k) use(&$_AupdateRequestInfo, $_Arequest, $_Oemployee){
                array_walk($v, function($iv, $ik) use(&$_AupdateRequestInfo, $_Arequest, $k, $_Oemployee){

                    (isset($_Arequest[$iv]) && !empty($_Arequest[$iv])) ? $_AupdateRequestInfo[$k][$ik] = $_Arequest[$iv] : '';

                    if($k == 'employee_details'){

                        array_key_exists('r_cost_center_code_id',$_AupdateRequestInfo[$k]) ? $this->cost['cost_center_code'] = $_Arequest['costCenter'] : '';

                        array_key_exists('r_cost_center_code_id',$_AupdateRequestInfo[$k]) ? $_AupdateRequestInfo[$k]['r_cost_center_code_id'] = $_Oemployee->_insertCostcenterCodeDetails($this->cost,$this->_IcorporateId) : '';

                        array_key_exists('r_designation_id',$_AupdateRequestInfo[$k]) ? $this->desig['designation_name'] = $_Arequest['designation'] : '';

                        array_key_exists('r_designation_id',$_AupdateRequestInfo[$k]) ? $_AupdateRequestInfo[$k]['r_designation_id'] = $_Oemployee->_insertDesignationDetails($this->desig,$this->_IcorporateId) : '';


                        array_key_exists('r_branch_id',$_AupdateRequestInfo[$k]) ? $_AupdateRequestInfo[$k]['r_branch_id'] = $_Oemployee->_insertBranchDetails(array('branch_name'=>$_AupdateRequestInfo[$k]['branch']),$this->_IcorporateId) : '';



                        array_key_exists('r_department_id',$_AupdateRequestInfo[$k]) ? $this->department['department_name'] = $_Arequest['division'] : '';

                        array_key_exists('r_department_id',$_AupdateRequestInfo[$k]) ? $_AupdateRequestInfo[$k]['r_department_id'] = $_Oemployee->_insertDepartmentDetails($this->department,$this->_IcorporateId) : '';
                        

                        array_key_exists('r_billto_id',$_AupdateRequestInfo[$k]) ? $_AupdateRequestInfo[$k]['r_billto_id'] = $_Oemployee->_insertBilltoAddressDetails(array('billto_name'=>$_AupdateRequestInfo[$k]['r_billto_id']),$this->_IcorporateId) : '';
                        
                        array_key_exists('r_band_id',$_AupdateRequestInfo[$k]) ? $this->band['band_name'] = $_Arequest['employeeSubGroup'] : '';

                         array_key_exists('r_band_id',$_AupdateRequestInfo[$k]) ? $_AupdateRequestInfo[$k]['r_band_id'] = $_Oemployee->_insertBandDetails($this->band,$this->_IcorporateId) : '';   
                    }
                });
            });
            return $_AemployeeId[0]['employee_id'] > 0 ? $this->_updateEmployeeSapDetails($_AupdateRequestInfo,$_AemployeeId,$_Arequest) : $this->_insertSapEmployeeMasterDetails($_AupdateRequestInfo,$_Arequest);
    }

    /**
     * function handle update functionality of employee master sap details
     *
     * @param array $_AupdateRequestInfo
     * @param array $_AemployeeId
     * @param array $_Arequest
     * @return array
     */
    private function _updateEmployeeSapDetails($_AupdateRequestInfo,$_AemployeeId,$_Arequest){

        $lastData = str_replace('.', '', $_AupdateRequestInfo['dm_employee']['last_name']);

        $_AupdateRequestInfo['dm_employee']['first_name'] = str_replace('.','',$_AupdateRequestInfo['dm_employee']['first_name']);

        $_AupdateRequestInfo['dm_employee']['last_name'] = $lastData == '' ? $_AupdateRequestInfo['dm_employee']['first_name'] : $lastData;

        $this->_OemployeeProfile = common::_checkClassExistsInNameSpace('employeeProfile');

        $_AreturnResponse = array();

        $_AtableUpdateIdRefKey = array('dm_employee'=>'employee_id','sap_employee_dependent_details'=>'r_employee_id','employee_details'=>'r_employee_id');

        array_walk($_AupdateRequestInfo, function($updatevalue, $tablename) use($_AemployeeId,&$_AreturnResponse,$_AtableUpdateIdRefKey){

            unset($updatevalue['email_id'],$updatevalue['employee_code']);

            $_AreturnResponse[] = $this->_OcommonDBO->_update($tablename,$updatevalue,$_AtableUpdateIdRefKey[$tablename],$_AemployeeId[0]['employee_id']) == 0 ? true : false ;
        });
        $this->_OemployeeProfile->_prepareAggregateData($this->band['band_name'],$_AemployeeId[0]['employee_id'],$this->_IcorporateId,$this->_IagencyId);

        return in_array(TRUE,$_AreturnResponse) ? array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'Y','responseMessage'=>'Successfully Received') : array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'N','responseMessage'=>'Failure to insert or update the record');
    }


    /**
     * function used to insert non existing employee details
     *
     * @param array $_ArequestInfo
     * @param array $_Arequest
     * @return array
     */
    private function _insertSapEmployeeMasterDetails($_ArequestInfo,$_Arequest){


        $this->_OemployeeProfile = common::_checkClassExistsInNameSpace('employeeProfile');
        
        $_AreturnResponse = $_AevaluateTableData = array();

            $_ArequestInfo['dm_employee']['title'] = ($_Arequest['gender'] == 'M' || $_Arequest['gender'] == '') ? 'Mr' : 'Ms';
            
            //$_ArequestInfo['dm_employee']['status'] = $_Arequest['employeesStatus'] == 'A' ? 'Y' : 'N';

            $_ArequestInfo['dm_employee']['login_status'] = 'N';
            
            $lastData = str_replace('.','', $_Arequest['lastName']);

            $_ArequestInfo['dm_employee']['first_name'] = str_replace('.','',$_ArequestInfo['dm_employee']['first_name']);

            $_ArequestInfo['dm_employee']['last_name'] = $lastData == '' ? $_ArequestInfo['dm_employee']['first_name'] : $lastData;


            $_ArequestInfo['dm_employee']['created_date'] = date('Y-m-d H:i:s');
            $_ArequestInfo['employee_details']['created_date'] = date('Y-m-d H:i:s');
            $_ArequestInfo['sap_employee_dependent_details']['created_date'] = date('Y-m-d H:i:s');
            $_ArequestInfo['sap_employee_dependent_details']['check_box'] = 'X';
            $_ArequestInfo['sap_employee_dependent_details']['trip_approval_status'] = 'NA';
            $_ArequestInfo['sap_employee_dependent_details']['ticket_approval_status'] = 'NA';
            $_ArequestInfo['sap_employee_dependent_details']['ticket_booking_lock'] = 'N';

            $_Atabledata = array('dm_employee','employee_details','sap_employee_dependent_details');

            array_walk($_Atabledata, function($v,$k) use($_ArequestInfo,&$_AevaluateTableData){

                $_AevaluateTableData[$v] = (array_key_exists($v,$_ArequestInfo) && count($_ArequestInfo[$v]) > 0) ? TRUE : FALSE;
            });

        if(in_array(FALSE, $_AevaluateTableData)){

            return array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'N','responseMessage'=>'Failure to insert or update the record');
        }

            $_Atablecolumn['dm_employee'] = array_fill_keys(array_keys(array_column($this->_OcommonDBO->_getResult("SHOW COLUMNS FROM dm_employee"), 'Key', 'Field')), 0);
            $_Atablecolumn['employee_details'] = array_fill_keys(array_keys(array_column($this->_OcommonDBO->_getResult("SHOW COLUMNS FROM employee_details"), 'Key', 'Field')), 0);
            $_Atablecolumn['sap_employee_dependent_details'] = array_fill_keys(array_keys(array_column($this->_OcommonDBO->_getResult("SHOW COLUMNS FROM sap_employee_dependent_details"), 'Key', 'Field')), 0);

            array_walk($_Atabledata, function($value, $key) use(&$_ArequestInfo,$_Atablecolumn){

                $_ArequestInfo[$value] = array_merge($_Atablecolumn[$value],$_ArequestInfo[$value]);
            });        

            $_IemployeeId = $this->_OcommonDBO->_insert('dm_employee',$_ArequestInfo['dm_employee']);
        
        if(!$_IemployeeId > 0){
            return array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'N','responseMessage'=>'Failure to insert or update the record');
        }
        

        unset($_ArequestInfo['dm_employee']);
        $_ArequestInfo['employee_details']['r_employee_id'] = $_ArequestInfo['sap_employee_dependent_details']['r_employee_id'] = $_IemployeeId;
        

            array_walk($_ArequestInfo,function($tablevalue,$tablename) use(&$_AreturnResponse){

                $_AreturnResponse[] = $this->_OcommonDBO->_insert($tablename,$tablevalue);
            });

        if(in_array(FALSE,$_AreturnResponse)){

            return array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'N','responseMessage'=>'Failure to insert or update the record');
        }

        $this->_OemployeeProfile->_prepareAggregateData($this->band['band_name'],$_IemployeeId,$this->_IcorporateId,$this->_IagencyId);


            $_Oemployee = common::_checkClassExistsInNameSpace('employee');
            $_Oemployee->_IcorporateId = $this->_IcorporateId;
            $_Oemployee->_callCreateAccount($_IemployeeId,4,$_Arequest['paxMail']);
        
        return array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'Y','responseMessage'=>'Successfully Received');
    }

    /**
     * function used to update employee family details if exist
     * if employee family details not exist insert employee family details
     * @param array $_Arequest
     * @return array
     */
    public function _employeeDependent($_Arequest = array()){

        $this->_Oemployee = common::_checkClassExistsInNameSpace('employee');

        $_AreturnResponse = array(); $_AupdateSapemployeeDate = array();

        $_AupdateRequestInfo = array("updated_date"=>date('Y-m-d H:i:s'));

        $_AemployeeId = $this->_getEmployeeId($_Arequest);

        if($_AemployeeId[0]['employee_id'] > 0){


            if($_Arequest['dob'] == ''){
                return  array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'N','responseMessage'=>'Failure to insert or update (DOB Mandiatory)the record');
            }
            $_Arequest['passengerType'] = $this->_Oemployee->_getPaxType($_Arequest['dob']);
            $_Arequest['age'] = $this->_Oemployee->_getAge($_Arequest['dob']);
            $_AinsertRequestInfo = array("employee_family_details_id" => 0,"r_employee_id"=>$_AemployeeId[0]['employee_id'],"created_date"=>date('Y-m-d H:i:s'));

            $_AkeyValueData = array('famsa'=>'familyRelationType','objps'=>'numberOfChild','first_name'=>'firstName','last_name'=>'lastName',
            'dob'=>'dob','age'=>'age','passenger_type'=>'passengerType','gender'=>'gender','transfer_from_date'=>'transferBeginDate','transfer_to_date'=>'transferEndDate');

            array_walk($_AkeyValueData, function($v, $k) use(&$_AupdateRequestInfo, $_Arequest){

                (isset($_Arequest[$v]) && !empty($_Arequest[$v])) ? $_AupdateRequestInfo[$k] = $_Arequest[$v] : '';            
            });            

            array_key_exists('transfer_from_date',$_AupdateRequestInfo) ? $_AupdateSapemployeeDate['transfer_from_date'] = $_AupdateRequestInfo['transfer_from_date']: '';
            array_key_exists('transfer_to_date',$_AupdateRequestInfo) ? $_AupdateSapemployeeDate['transfer_to_date'] = $_AupdateRequestInfo['transfer_to_date']: '';

            unset($_AupdateRequestInfo['transfer_from_date'],$_AupdateRequestInfo['transfer_to_date']);

            //FUNCTION CALL TO UPDATE THE DETAILS
            (is_array($_AupdateSapemployeeDate) && count($_AupdateSapemployeeDate) > 0) ? $this->_OcommonDBO->_update('sap_employee_dependent_details',$_AupdateSapemployeeDate,'r_employee_id',$_AemployeeId[0]['employee_id']) : '';

            $_AemployeeFamilyExist = $this->_checkEmployeeFamilyDetailsExist($_Arequest, $_AemployeeId[0]['employee_id']);
            $_AupdateRequestInfo['booking_type'] = 1;
            $_AinsertRequestInfo = array_merge($_AinsertRequestInfo, $_AupdateRequestInfo);

            if($_Arequest['familyRelationType'] != 'X' ){
                //FUNCTION CALL TO UPDATE THE DETAILS
                $_AreturnResponse [] = (is_array($_AemployeeFamilyExist) && count($_AemployeeFamilyExist) > 0) ? $this->_OcommonDBO->_update('employee_family_details',$_AupdateRequestInfo,'employee_family_details_id',$_AemployeeFamilyExist[0]['employee_family_details_id']) : $this->_OcommonDBO->_insert('employee_family_details',$_AinsertRequestInfo);    
            }else{
                $_AreturnResponse [] =  true;
            }
        }
        return in_array(TRUE,$_AreturnResponse) ? array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'Y','responseMessage'=>'Successfully Received') : array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'N','responseMessage'=>'Failure to insert or update the record');
    }

    /**
     * function used to get employee id based on employee code
     *
     * @param array $_Arequest
     * @return array
     */
    private function _getEmployeeId($_Arequest){

        //$sql = "SELECT corporate_id FROM agency_corporate_mapping INNER JOIN dm_corporate WHERE SAP_id = '".$_Arequest['corporateName']."'";

        $corporateDetails = $this->_OcommonDBO->_getResult("SELECT dmc.corporate_id,acm.agency_id FROM agency_corporate_mapping acm INNER JOIN dm_corporate dmc ON dmc.corporate_id = acm.corporate_id WHERE SAP_id = '".$_Arequest['corporateName']."'");
        $this->_IcorporateId = $corporateDetails[0]['corporate_id'];
        $this->_IagencyId = $corporateDetails[0]['agency_id'];

        if(!$this->_IcorporateId){
            return array();
        }        

        $_Ssql="SELECT 
                        dme.employee_id, fe.r_account_id
                FROM
                        dm_employee dme
                        INNER JOIN fact_employee fe ON fe.r_employee_id = dme.employee_id
                        INNER JOIN sap_employee_dependent_details sed ON sed.r_employee_id = fe.r_employee_id
                WHERE
                       dme.employee_code = '".$_Arequest['employeeNumber']."' AND fe.r_corporate_id = $this->_IcorporateId ";

        $_AemployeeDetails = $this->_OcommonDBO->_getResult($_Ssql);

        return (!empty($_Arequest['employeeNumber']) && count($_AemployeeDetails) > 0) ? $_AemployeeDetails : array();
    }

    /**
     * function used to check email id exits or not
     *
     * @param array $_Arequest
     * @return array
     */
    private function _checkEmailIdExits($_Arequest){

        if(!$this->_IcorporateId){
            return array();
        }        

        $_Ssql="SELECT 
                        dme.email_id
                FROM
                        dm_employee dme
                        INNER JOIN fact_employee fe ON fe.r_employee_id = dme.employee_id
                        INNER JOIN sap_employee_dependent_details sed ON sed.r_employee_id = fe.r_employee_id
                WHERE
                        dme.status = 'Y' AND dme.email_id = '".$_Arequest['paxMail']."' AND fe.r_corporate_id = $this->_IcorporateId ";

        $_AemployeeEmailDetails = $this->_OcommonDBO->_getResult($_Ssql);

        return (!empty($_AemployeeEmailDetails) && count($_AemployeeEmailDetails) > 0) ? $_AemployeeEmailDetails : array();
    }
    /**
     * function used to generate the random string email for 'H' grade employee
     *
     * @param int length
     * @return string
     */
    private function _generateRandomString($length){

        $characters = 'abcdefghijklmnopqrstuvwxyz'; 
        $randomString = substr(str_shuffle($characters),0,$length);
  
    return $randomString; 
    }

    /**
     * function used to check the employee family details exist
     *
     * @param array $_Arequest
     * @param integer $_IemployeeId
     * @return array
     */
    private function _checkEmployeeFamilyDetailsExist($_Arequest, $_IemployeeId){
        $_Ssql="SELECT 
                        efd.*
                FROM
                        employee_family_details efd
                WHERE
                        efd.r_employee_id = $_IemployeeId AND efd.famsa = '".$_Arequest['familyRelationType']."' ";
        $_Ssql.=   ($_Arequest['numberOfChild'] != '' || $_Arequest['numberOfChild'] != 0 ) ? "AND efd.objps = '".$_Arequest['numberOfChild']."'" : "";
        return $this->_OcommonDBO->_getResult($_Ssql);
    }


    /**
     * function used to create approver settings triggered from SAP SSBT
     *
     * @param array $_Arequest
     * @param integer $_IemployeeId
     * @return array
     */
    public function _sapEmployeeApproverInfo($_Arequest){
         $_AemployeeId = $this->_getEmployeeId($_Arequest);
        if($_AemployeeId[0]['employee_id'] > 0){
             // controlling officer validaiton
             if($_Arequest['ControlOfferEmployeeNumber'] != '' &&  $_Arequest['ControlOfferEmployeeNumber'] != 'NA'  && $_Arequest['ControlOfferEmployeeNumber'] != 'NR'){
                if(!$this->_getEmployeeDetailsByEmployeeCode($_Arequest['ControlOfferEmployeeNumber'],$this->_IcorporateId)) 
                 return array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'N','responseMessage'=>'Failure to insert or update the ControlOfferEmployeeNumber record not found');
             }
             // trip officer validatioon
             if($_Arequest['tripApproverEmployeeNumber'] != '' && $_Arequest['tripApproverEmployeeNumber']!='NA' && $_Arequest['tripApproverEmployeeNumber'] != 'NR'){
                 if(!$this->_getEmployeeDetailsByEmployeeCode($_Arequest['tripApproverEmployeeNumber'],$this->_IcorporateId))
                 return array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'N','responseMessage'=>'Failure to insert or update the record tripApproverEmployeeNumber not found');
             }
              // trip officer validatioon
             if($_Arequest['ticketApproverEmployeeNumber'] != '' && $_Arequest['ticketApproverEmployeeNumber'] != 'NR' && $_Arequest['ticketApproverEmployeeNumber'] !='NA'){
                if(!$this->_getEmployeeDetailsByEmployeeCode($_Arequest['ticketApproverEmployeeNumber'],$this->_IcorporateId))
                return array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'N','responseMessage'=>'Failure to insert or update the record ticketApproverEmployeeNumber not found');
             }
              // no show  officer validatioon
             if($_Arequest['noShowApproverEmployeeNumber'] != '' && $_Arequest['noShowApproverEmployeeNumber'] != 'NR' && $_Arequest['noShowApproverEmployeeNumber'] != 'NA'){
                if(!$this->_getEmployeeDetailsByEmployeeCode($_Arequest['noShowApproverEmployeeNumber'],$this->_IcorporateId))
                    return array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'N','responseMessage'=>'Failure to insert or update the record noShowApproverEmployeeNumber not found');
             }
               // no show  officer validatioon
             if($_Arequest['guestApproverEmployeeNumber'] != '' && $_Arequest['guestApproverEmployeeNumber']!='NA' && $_Arequest['guestApproverEmployeeNumber'] !='NR'){
                if(!$this->_getEmployeeDetailsByEmployeeCode($_Arequest['guestApproverEmployeeNumber'],$this->_IcorporateId)) 
                    return array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'N','responseMessage'=>'Failure to insert or update the record Guest approver not found');
             }
            $_AreturnResponse[] = $this->_sapApproverInformationInsertion($_Arequest);
        }
         return in_array(TRUE,$_AreturnResponse) ? array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'Y','responseMessage'=>'Successfully Received') : array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'N','responseMessage'=>'Failure to insert or update the record');

    }   

    public function _sapApproverInformationInsertion($_Arequest = array()){

        $_Aresponse = $_AinsertData = array();
        fileRequire('plugins/admin/corporate/harinim/classesTpl/class.tpl.admin.insertDynamicApprovalSettingsTpl.php');
        if(isset($_Arequest['employeeNumber']) && !empty($_Arequest['employeeNumber'])){

            $_IcorporateDetails =  $this->_OcommonDBO->_select('agency_corporate_mapping', 'agency_id, corporate_id', 'SAP_id', $_Arequest['corporateName'])[0];

            $_employeeDetails = $this->_getEmployeeDetailsByEmployeeCode($_Arequest['employeeNumber'], $_IcorporateDetails['corporate_id']);
           if($_employeeDetails){ // check employee exist

                $_IemployeeDetails  = current($_employeeDetails); //gets first array 
                 $processType       = "Booking";

                // Delete previous approval mappings 
                $sql = "SELECT GROUP_CONCAT(apm.r_approval_settings_id) as setting_id FROM approval_parameter_mapping as apm WHERE apm.parameter_type='employee' AND apm.parameter_value='{$_IemployeeDetails[email_id]}'";

                $result = $this->_OcommonDBO->_getResult($sql);

                if(!empty($result[0]['setting_id'])){
                    $sql ="DELETE das.*, am.*, apm.* 
                            FROM dm_approval_settings as das 
                            INNER JOIN approval_mapping as am ON am.r_approval_settings_id = das.approval_settings_id 
                            Inner Join approval_parameter_mapping as apm  ON apm.r_approval_settings_id = am.r_approval_settings_id
                            WHERE das.approval_settings_id IN ({$result[0][setting_id]})";

                    $this->_OcommonDBO->_getResult($sql);
                }
                // Category details
                $aggregateCategory['aggregateCategoryId']   = $_IemployeeDetails['employee_id'];
                $aggregateCategory['operatorId']            = 1;
                $aggregateCategory['categoryValue']         = $_IemployeeDetails['email_id'];
                $aggregateCategory['aggregateCategoryType'] = "'employee'";

                // Prepare data to insert
                $_AinsertData['validation_string']          = 1;
                $_AinsertData['process_type_id']            = 1;
                $_AinsertData['priority']                   = 1;
                $_AinsertData['start_date']                 = date('Y-m-d');
                $_AinsertData['agency_id']                  = $_IcorporateDetails['agency_id'];
                $_AinsertData['corporate_id']               = $_IcorporateDetails['corporate_id'];
                $_AinsertData['approver_settings_name']     = 'Employee approver - ' . $_IemployeeDetails['email_id'];
                $_AinsertData['aggregateCategory']          =  array($aggregateCategory);

                // Ticket Approver
                if(isset($_Arequest['ticketApproverEmployeeNumber']) && !empty($_Arequest['ticketApproverEmployeeNumber'])){

                    if($_Arequest['ticketApproverEmployeeNumber'] !='NA' && $_Arequest['ticketApproverEmployeeNumber'] != 'NR'){
                        $_AinsertData['approvers'] = $_AinsertData['criteria'] = array();
                        $_IticketApprover = $this->_getEmployeeDetailsByEmployeeCode($_Arequest['ticketApproverEmployeeNumber'],$_IcorporateDetails['corporate_id'])[0];
                        $approverData['approverId'] = $_IticketApprover['employee_id'];
                        $approverData['level'] = 1;
                        $approverData['order'] = 1;
                        $approverData['type'] = "NA";
                        $_AinsertData['approvers'][] = $approverData;
                    }

                    $travelIds = array();
                    $sql = "SELECT GROUP_CONCAT(DISTINCT(r_travel_mode_id )) as travel_modes  FROM  dm_profile_approval_settings WHERE process_type='Booking' and
                        r_corporate_id = '{$_IcorporateDetails[corporate_id]}'
                         AND r_agency_id = '{$_IcorporateDetails[agency_id]}' AND r_travel_mode_id != 3";

                    $result = $this->_OcommonDBO->_getResult($sql);                    
                    $_AinsertData['travelIds'] = explode(',',$result[0]['travel_modes']);
                    $this->_createApproverSettingsWS($_AinsertData,$_Arequest);
                    $this->_checkEmployeeSapDependentInsertion($_Arequest['ticketApproverEmployeeNumber'],$_IemployeeDetails['employee_id'],'ticket_approval_status');
                }else{
                    $this->_checkEmployeeSapDependentInsertion($_Arequest['ticketApproverEmployeeNumber'],$_IemployeeDetails['employee_id'],'ticket_approval_status');
                }

                // Trip Approver
                if(isset($_Arequest['tripApproverEmployeeNumber']) && !empty($_Arequest['tripApproverEmployeeNumber'])){
                    if($_Arequest['tripApproverEmployeeNumber'] != 'NA' && $_Arequest['tripApproverEmployeeNumber'] != 'NR'){   
                        $_AinsertData['approvers'] = $_AinsertData['criteria'] = array();
                        $_ItripApprover = $this->_getEmployeeDetailsByEmployeeCode($_Arequest['tripApproverEmployeeNumber'],$_IcorporateDetails['corporate_id'])[0];

                        
                        $approverData['approverId'] = $_ItripApprover['employee_id'];
                        $approverData['level'] = 1;
                        $approverData['order'] = 1;
                        $approverData['type'] = "NA";

                        $_AinsertData['approvers'][] = $approverData;
                        $_IallowedTravelModes = array('TR');

                        $_ItravelModes = $this->_OcommonDBO->_getResult("SELECT * FROM dm_travel_mode"); 

                        $travelIds = array();
                        foreach($_ItravelModes as $travelMode )
                        {
                            if(in_array($travelMode['travel_mode_code'],$_IallowedTravelModes))
                                $travelIds[] = $travelMode['travel_mode_id'];
                        }
                    }
                    $_AinsertData['travelIds'] = $travelIds;
                    $this->_createApproverSettingsWS($_AinsertData,$_Arequest);
                    $this->_checkEmployeeSapDependentInsertion($_Arequest['tripApproverEmployeeNumber'],$_IemployeeDetails['employee_id'],'trip_approval_status');
                }else{
                     $this->_checkEmployeeSapDependentInsertion($_Arequest['tripApproverEmployeeNumber'],$_IemployeeDetails['employee_id'],'trip_approval_status');
                }
                // No Show Approver
                if(isset($_Arequest['noShowApproverEmployeeNumber']) && !empty($_Arequest['noShowApproverEmployeeNumber'])){

                    if($_Arequest['noShowApproverEmployeeNumber'] != 'NA' && $_Arequest['noShowApproverEmployeeNumber'] != 'NR'){
                        $_AinsertData['approvers'] = $_AinsertData['criteria'] = array();
                        $_InoShowApprover = $this->_getEmployeeDetailsByEmployeeCode($_Arequest['noShowApproverEmployeeNumber'],$_IcorporateDetails['corporate_id'])[0];

                        $approverData['approverId'] = $_InoShowApprover['employee_id'];
                        $approverData['level'] = 1;
                        $approverData['order'] = 1;
                        $approverData['type'] = "NA";

                        $_AinsertData['approvers'][] = $approverData;
                    }

                    $travelIds = array();

                    $sql = "SELECT GROUP_CONCAT(DISTINCT(r_travel_mode_id )) as travel_modes  FROM dm_profile_approval_settings WHERE process_type='NoShowApprover' and
                        r_corporate_id = '{$_IcorporateDetails[corporate_id]}'
                         AND r_agency_id = '{$_IcorporateDetails[agency_id]}' ";

                    $result = $this->_OcommonDBO->_getResult($sql);                    
                    $_AinsertData['travelIds'] = explode(',',$result[0]['travel_modes']);     

                    $this->_createApproverSettingsWS($_AinsertData,$_Arequest,'NoShowApprover');
                     $this->_checkEmployeeSapDependentInsertion($_Arequest['noShowApproverEmployeeNumber'],$_IemployeeDetails['employee_id'],'noshow_approval_status');

                }
                else{
                     $this->_checkEmployeeSapDependentInsertion($_Arequest['noShowApproverEmployeeNumber'],$_IemployeeDetails['employee_id'],'noshow_approval_status');
                }

                // Guest Approver
                if(isset($_Arequest['guestApproverEmployeeNumber']) && !empty($_Arequest['guestApproverEmployeeNumber'])){

                    if($_Arequest['guestApproverEmployeeNumber'] != 'NA' && $_Arequest['guestApproverEmployeeNumber'] != 'NR'){
                        $_AinsertData['approvers'] = $_AinsertData['criteria'] = array();
                        $_IguestApprover = $this->_getEmployeeDetailsByEmployeeCode($_Arequest['guestApproverEmployeeNumber'],$_IcorporateDetails['corporate_id'])[0];


                        $approverData['approverId'] = $_IguestApprover['employee_id'];
                        $approverData['level'] = 1;
                        $approverData['order'] = 1;
                        $approverData['type'] = "NA";

                        $_AinsertData['validation_string']  = "strpos(\'/Y/\', \'/[guest_exits]/\') !== false";

                        $_AinsertData['approvers'][] = $approverData;
                    }
                    $travelIds = array();
                    $sql = "SELECT GROUP_CONCAT(DISTINCT(r_travel_mode_id )) as travel_modes  FROM dm_profile_approval_settings WHERE process_type='Booking' and
                        r_corporate_id = '{$_IcorporateDetails[corporate_id]}'
                         AND r_agency_id = '{$_IcorporateDetails[agency_id]}' AND r_travel_mode_id != 3";

                    $result = $this->_OcommonDBO->_getResult($sql);    
                    $_AinsertData['travelIds'] = array(1,3);//explode(',',$result[0]['travel_modes']); 
                    // Guest Criteria
                    $criteriaData['criteriaId'] = 15;
                    $criteriaData['operatorId'] = 1;
                    $criteriaData['criteriaValue'] = "Y";
                    $_AinsertData['criteria'][] = $criteriaData;
                    $this->_createApproverSettingsWS($_AinsertData,$_Arequest);
                    $this->_checkEmployeeSapDependentInsertion($_Arequest['guestApproverEmployeeNumber'],$_IemployeeDetails['employee_id'],'guest_approval_status');

                } else{
                     $this->_checkEmployeeSapDependentInsertion($_Arequest['guestApproverEmployeeNumber'],$_IemployeeDetails['employee_id'],'guest_approval_status');
                }
                
                // for controlling offiver
                $this->_checkEmployeeSapDependentInsertion($_Arequest['ControlOfferEmployeeNumber'],$_IemployeeDetails['employee_id'],'controlling_approval_status');

               // UPDATE CHECK BOX VALUE
                //if(isset($_Arequest['checkBoxRequest']) && !empty($_Arequest['checkBoxRequest'])){
                    $sql = "UPDATE sap_employee_dependent_details SET check_box = '{$_Arequest[checkBoxRequest]}'
                        WHERE r_employee_id = '{$_IemployeeDetails[employee_id]}' ";

                    $this->_OcommonDBO->_getResult($sql);
                //}


            }
        }
        return array('uidNumber'=>$_Arequest['uidNumber'],'status'=>'Y','responseMessage'=>'Successfully Received');

    }

    /**
     * Get employee details by employee code
     *  
     * @param string $employeeCode
     * @param integer $corporateId
     * @return array
     */
    private function _getEmployeeDetailsByEmployeeCode($employeeCode, $corporateId){

        $sql = "SELECT * FROM dm_employee as dme 
                        INNER JOIN fact_employee fe ON fe.r_employee_id = dme.employee_id
                        WHERE dme.employee_code = '{$employeeCode}' AND fe.r_corporate_id = '{$corporateId}'";

        return $this->_OcommonDBO->_getResult($sql);

    }

     /**
     * sub function used to create approver settings 
     *  
     * @param array $_AinsertData
     * @param array $_Arequest
     * @param string $type
     * @return void
     */
    private function _createApproverSettingsWS($_AinsertData, $_Arequest, $type="Booking"){

        $_AinsertData['process_type'] = $type;

        // Control Officer
        if(isset($_Arequest['ControlOfferEmployeeNumber']) && !empty($_Arequest['ControlOfferEmployeeNumber']) && $_Arequest['ControlOfferEmployeeNumber']!='NA' && $_Arequest['ControlOfferEmployeeNumber']!='NR'){

            $_IcontrolOfficer = $this->_getEmployeeDetailsByEmployeeCode($_Arequest['ControlOfferEmployeeNumber'],$_AinsertData['corporate_id'])[0];
            
            $approverData['approverId'] = $_IcontrolOfficer['employee_id'];
            $approverData['level'] = 1;
            $approverData['order'] = 2;
            $approverData['type'] = "IA";

            $_AinsertData['approvers'][] = $approverData;

            fileWrite(print_r($_AinsertData,1),'BA','a+');
        }

        fileWrite(print_r($_AinsertData,1),'INS','a+');

        foreach($_AinsertData['travelIds'] as $travelId){

            $_AinsertData['travel_mode'] = $travelId;

            $_OdynamicApproverSettings      = new dynamicApproverSettings();
            $resultApprovalSettings         = $_OdynamicApproverSettings->_insertDynamicApprovalSettings($_AinsertData);

            if($resultApprovalSettings>0){

                $_AinsertData['approval_settings_id']= $resultApprovalSettings;
                //Function call to insert approval info details (approval_mapping table insert)
                $resultApprovalParameterMapping=$_OdynamicApproverSettings->_insertApprovalParameterMapping($_AinsertData);

                //Function call to insert approval mapping details (approval_mapping table insert)
                $resultApprovalMapping=$_OdynamicApproverSettings->_insertApproverMapping($_AinsertData);
            }
        }
    }

    public function _checkEmployeeSapDependentInsertion($approverNumber,$employee_id,$indexkey)
    {
        if($approverNumber == 'NR'){
            $employeeTransferData[$indexkey] = 'NR';
        }elseif ($approverNumber == 'NA') {
            $employeeTransferData[$indexkey]= 'NA';
        }elseif ($approverNumber != ''){
            $employeeTransferData[$indexkey]= 'R';
        }
        $this->_pushEmployeeTranferData($employee_id, $employeeTransferData);
    }

      /**
     * @description - do insert/update the employee details information
     * @param string $refEmpId
     * @param array $detailsData
     * @return int
     */
    public function _pushEmployeeTranferData($refEmpId = 0, $detailsData) {
        $idExists = $this->_OcommonDBO->_select('sap_employee_dependent_details', 'r_employee_id', 'r_employee_id', $refEmpId);
        if (!$idExists) {
            $detailsData['created_date'] = date('Y-m-d');
            return $this->_OcommonDBO->_insert('sap_employee_dependent_details', $detailsData);
        } else {
            $detailsData['updated_date'] = date('Y-m-d');
            $result = $this->_OcommonDBO->_update('sap_employee_dependent_details', $detailsData, 'r_employee_id', $refEmpId);
            if ($result !== false) {
                return 1;
            }
        }
    }


    public function _getEmployeeValidFromToDate($refEmpId){
        return $idExists = $this->_OcommonDBO->_select('sap_employee_dependent_details', '*', 'r_employee_id', $refEmpId);
    }

    public function startsWith($string, $startString) 
    { 
        $len = strlen($startString); 
        return (substr($string, 0, $len) === $startString); 
    } 

 }
?>