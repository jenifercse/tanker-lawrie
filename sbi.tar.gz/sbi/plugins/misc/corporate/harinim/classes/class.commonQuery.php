<?php
/* * **************************************************************************
 * @Class           commonQuery
 * @Description     This class file contains methods with commonly used queries
 * @Author          Mercy Chrysolite
 * @Created Date    09 Jan 2017
 * *************************************************************************** */
fileRequire("./lib/common/commonMethods.php");
fileRequire("./plugins/common/interface/commonConstants.php");
fileRequire("lib/system/authToken.php");
class commonQuery implements commonConstants{    

    public function __construct(){
        
        $this->_settingNamePassing = '';
        $this->_OcommonMethods = new commonMethods();
        $this->_manageApp = new manageApplicationSettings();
        $this->_OcommonDBO = new commonDBO();
        $this->_Oagency = new agency();
        $this->_Ocorporate = new corporate();
        $this->_Oworkflow = new workflow();
        $this->_AqueryConstant = array(
                                        "getTripType" => array(0 => "One Way",1 => "Round Trip",2 => "Multicity"),
                                        "getLowFareSelection" => array('Y' => 'Yes','N' => 'No'),
                                        "checkGuestExits" => array('Y' => 'Yes','N' => 'No')
                                      );
    }

    /**
     * used call web service method to get the passed param data response
     * @param string $serviceUrl
     * @param string $serviceMethod
     * @param array $requestData
     * @return array 
     */
        public function _nuSoapCallApi($serviceUrl, $serviceMethod, $requestData){

            fileWrite($serviceUrl,'nuSoapCallApi','a+');
            fileWrite($serviceMethod,'nuSoapCallApi','a+');
            fileWrite(print_r($requestData,1),'nuSoapCallApi','a+');
        fileRequire('classes/class.nusoap.php');
        
        $wsdl = false;
        $proxyhost = false;
        $proxyport = false;
        $proxyusername = false;
        $proxypassword = false;
        $timeout = 0;
        $response_timeout = 600;
        //Webservice call for get gds pnr booking 
        $client = new nusoap_client($serviceUrl, $wsdl, $proxyhost, $proxyport, $proxyusername, $proxypassword, $timeout, $response_timeout);

        $searchResult = $client->call($serviceMethod, array('details' => $requestData));
fileWrite(print_r($searchResult,1),'nuSoapCallApi','a+');
        return $searchResult;
    }
    /*
    * @Description  This method returns the category list
    * @param int|$agencyId,$corporateId
    * @return array|$corporateList
    * @date|24.12.2016
    * @author|Karthika.M
    */
    public function _getCategoryList($agencyId="",$corporateId=""){
       $sql = "SELECT
                    dma.aggregate_id,dma.aggregate_name,dma.aggregate_type_id
               FROM
                    dm_aggregate dma
               WHERE
                    dma.aggregate_parent_id = 0 AND dma.status = 'Y'" ;

       if($agencyId != '')
       {
           $sql = $sql." AND dma.r_agency_id = ".$agencyId;
       }
       if($corporateId != '')
       {
           $sql = $sql." AND dma.r_corporate_id =".$corporateId;
       }
        $result = $this->_OcommonDBO->_getResult($sql);
        if($result != "")
        {
            return $result;
        }
    }

     /*
     * @Description  This method returns the criteria list
     * @param int|$agencyId,$corporateId,$travelModeId
     * @return array|$criteriaList
     * @date|24.12.2016
     * @author|Karthika.M
     */
    public function _getCriteriaList($agencyId = "",$corporateId = "",$travelModeId = ""){
        
        if($agencyId  != ''){
          $agencyId = '(0,'.$agencyId.')';
        }
        else{
           $agencyId = '(0)';
        }
        
        if($corporateId != ''){
           $corporateId = '(0,'.$corporateId.')';
        }
        else{
            $corporateId = '(0)';
        }
        
        if($travelModeId != ''){
            if($travelModeId == 3){
                $comboTravelMode = $this->_getComboTravelMode();
                $travelModeId = '(7,'.$comboTravelMode.')';
            }
            else{
                $travelModeId = '(7,'.$travelModeId.')';
            }
        }
        else{
            $travelModeId = '(7)';
        }

       $sql =  "SELECT
                    dmc.criteria_id, dmc.criteria_name,dmc.criteria_logical_name, dmc.criteria_type,dmc.criteria_avail_type,dmc.query_constant
                FROM
                    dm_criteria dmc
                WHERE
                    dmc.status = 'Y'  AND dmc.r_agency_id IN ".$agencyId." AND dmc.r_corporate_id IN ". $corporateId.
                    " AND dmc.r_travel_mode_id IN ". $travelModeId;
        $sql .= " ORDER BY dmc.criteria_name";
        $result = $this->_OcommonDBO->_getResult($sql);
        foreach($result as $key => &$value){
             if($value['query_constant'] != ''){
                $travelDetails = constant("commonConstants::".$value['query_constant']);
                if($travelDetails != ''){
                  $value['criteriaDetails'] =  array_column($this->_OcommonDBO->_getResult($travelDetails),'criteria_value_name','criteria_value_id');
                }
                else{
                  $value['criteriaDetails'] = $this->_AqueryConstant[$value['query_constant']];
                }
            }
        }
        if($result != ""){
            return $result;
        }
    }


    public function _getAggregateByType($input){
        $sql =  "SELECT
                    dat.aggregate_type_id, dat.aggregate_type
                FROM
                    dm_aggregate_type dat
                WHERE
                    1";
        $sqlAgencyBasedCorporate .= " AND dat.r_agency_id IN (".$input['agencyId'].")" ;
        $sqlAgencyBasedCorporate .= " AND dat.r_corporate_id IN(". $input['corporateId'].")";
        $sqlAgencyBasedCorporate .= " ORDER BY dat.aggregate_type";
        if(isset($input) && $input['agencyId'] != ''){
            $sqlFinal  .= $sql;
            $sqlFinal  .= $sqlAgencyBasedCorporate;
            $result = $this->_OcommonDBO->_getResult($sqlFinal);
        }
        if($result == ""){
            $sqlAllCorporate .= " AND dat.r_agency_id = 0 AND dat.r_corporate_id = 0 ORDER BY dat.aggregate_type" ;
            $sqlAllCorporateDetails .= $sql;
            $sqlAllCorporateDetails .= $sqlAllCorporate;
            $resultAllCorporate = $this->_OcommonDBO->_getResult($sqlAllCorporateDetails);
            return $resultAllCorporate;
        }
        else{
            return $result;
        }
    }
    
    /*
     * @Description  This method returns the logical operator list
     * @param int|
     * @return array|$logicalOperatorInfo
     * @date|24.12.2016
     * @author|Karthika.M
     */
    public function _getLogicalOperatorInfo(){
        
        $operatorFieldsArray = array('operator_id','operator_logical_id', 'operator_type', 'operator_name');
        $logicalOperatorInfo = $this->_OcommonDBO->_select('dm_operator', $operatorFieldsArray,'status','Y');

        foreach($logicalOperatorInfo as $key => $value){
            $string = substr($value['operator_type'], 0,1);
            $this->_Aoperators[$string][] = $value;
        }
        return $logicalOperatorInfo;
    }

    /*
    * @Description     This method checks whether a given component exists in the user's worklflow
    * @param           string|$flowType - B : booking , C : cancellation
    * @return          boolean|if caption exists in session
    * @date            28.01.2017
    * @author          Mercy Chrysolite
    */
    public function _checkWorkflow($flowType,$travelMode,$caption,$checkFrom = 'session',$input=array()){

        if($checkFrom == 'session'){
            $checkArray = isset($_SESSION['userWorkflow'][$flowType][$travelMode]) ? $_SESSION['userWorkflow'][$flowType][$travelMode] : (isset($_SESSION['userWorkflow'][$flowType][7]) ? $_SESSION['userWorkflow'][$flowType][7] : array());
            $result = in_array($caption,$checkArray);
        }
        else if($checkFrom == 'order'){
            $checkArray = $this->_getWorkFlowForOrder($input['orderId'],'workflow');
            $result = in_array($caption,$checkArray);
        }
        else{
           $checkWorkflow = $this->_Oworkflow->_getWorkflow($input);
           $checkArray = isset($checkWorkflow[$flowType][$travelMode]) ? $checkWorkflow[$flowType][$travelMode] : (isset($checkWorkflow[$flowType][7]) ? $checkWorkflow[$flowType][7] : array());
           $result = in_array($caption,$checkArray);
        }
        return $result;
    }

    public function _assignArray($outputArray,$categoryId,$inputArray,$keyArray,$parent_category_id){
        
        if(isset($outputArray[$parent_category_id])){
            $outputArray[$parent_category_id]['child'][$categoryId]['main'] = $inputArray;
        }
        elseif(isset($outputArray[$keyArray[0]]['child'][$parent_category_id])){
            $outputArray[$keyArray[0]]['child'][$parent_category_id]['child'][$categoryId]['main'] = $inputArray;
        }
        elseif(isset($outputArray[$keyArray[0]]['child'][$keyArray[1]]['child'][$parent_category_id])){
            $outputArray[$keyArray[0]]['child'][$keyArray[1]]['child'][$parent_category_id]['child'][$categoryId]['main']= $inputArray;
        }
        elseif(isset($outputArray[$keyArray[0]]['child'][$keyArray[1]]['child'][$keyArray[2]]['child'][$parent_category_id])){
            $outputArray[$keyArray[0]]['child'][$keyArray[1]]['child'][$keyArray[2]]['child'][$parent_category_id]['child'][$categoryId]['main'] = $inputArray;
        }
        elseif(isset($outputArray[$keyArray[0]]['child'][$keyArray[1]]['child'][$keyArray[2]]['child'][$keyArray[3]]['child'][$parent_category_id])){
            $outputArray[$keyArray[0]]['child'][$keyArray[1]]['child'][$keyArray[2]]['child'][$keyArray[3]]['child'][$parent_category_id]['child'][$categoryId]['main'] = $inputArray;
        }
        return $outputArray;
    }


    public function _createCategorySubArray($input){
        
        $this->_OmanageAggregate = new createManageAggregate();
        $this->_AaggregateArray  = array();
        
        $selectField = 'aggregate_name,aggregate_id,aggregate_desc,aggregate_type_id';
        $subAggregateName = $this->_OmanageAggregate->_getAggregateByActionBased('dm_aggregate',$selectField,$input['action'],$input);

        if(empty($subAggregateName)){
            return $subAggregateName;
        }
        for($i=0; $i<sizeof($subAggregateName); $i++){
            
            //here we need to find all sub categories
            $pos_category_id = $subAggregateName[$i]['aggregate_id'];
            $this->_parentCategoryId = $subAggregateName[$i]['aggregate_id'];
            if(count($this->_AaggregateArray)>0 && !in_array($subAggregateName[$i]['aggregate_id'],$this->_AaggregateArray)){
                $this->_AaggregateArray[]=$subAggregateName[$i]['aggregate_id'];
                $cat_list[$pos_category_id]['main']=$subAggregateName[$i];
                $cat_list[$pos_category_id]['child'] = $this->_recursiveCategory($pos_category_id,array(),$input);
            }
            else if(count($this->_AaggregateArray)==0){
                $this->_AaggregateArray[]=$subAggregateName[$i]['aggregate_id'];
                $cat_list[$pos_category_id]['main']=$subAggregateName[$i];
                $cat_list[$pos_category_id]['child'] = $this->_recursiveCategory($pos_category_id,array(),$input);
            }
        }
        return $cat_list;
    }

    public function _recursiveCategory($pos_category_id, $array,$input,$parent_category_id=0,$parentChildKeyArray='',$parentIndex=0){
      
        $input['aggregate_id'] = $pos_category_id;
        $selectField = 'aggregate_name,aggregate_id,aggregate_desc,aggregate_type_id';
        $return = $this->_OmanageAggregate->_getAggregateByActionBased('dm_aggregate',$selectField,'getChildAggregateDetails',$input);
        if($parent_category_id!=0){
            $parentChildKeyArray[$parentIndex]=$parent_category_id;$parentIndex+=1;
        }

        if(is_array($return) && count($return)>0){
            for($i=0; $i<count($return); $i++){
                $sub_cat = $return[$i]['aggregate_id'];
                $this->_AaggregateArray[] = $return[$i]['aggregate_id'];
                if($parent_category_id != 0){
                    $array = $this->_assignArray($array,$sub_cat,$return[$i],$parentChildKeyArray,$parent_category_id);
                }
                else{
                    $array[$sub_cat]['main'] = $return[$i];
                }
               $array = $this->_recursiveCategory($sub_cat, $array,$input,$sub_cat,$parentChildKeyArray,$parentIndex);
            }
        }
        return $array;
    }

    public function _corporateAgencyPermission(){
        if($_SESSION['permissions']['permissionName'] == 'Self Corporate') {
            $corporateList = $this->_Ocorporate->_getCorporateAccessByPermission($_SESSION['permissions']['fieldList']['corporateList']);
            $data = array('corporate'=>$corporateList);
        }
        elseif ($_SESSION['permissions']['permissionName'] == 'All') {
            $corporateList = $this->_Ocorporate->_getCorporateAccessByPermission();
            $fieldArr = array('dm_agency_id','agency_name');
            $agencyList = $this->_Oagency->_getAgencyList($fieldArr);
            $data = array('corporate'=>$corporateList, 'agency'=>$agencyList);
        }
        elseif ($_SESSION['permissions']['permissionName'] == 'Other Corporate') {
            $corporateList = $this->_Ocorporate->_getCorporateAccessByPermission($_SESSION['permissions']['fieldList']['corporateList']);
            $data = array('corporate'=>$corporateList);
        }
        elseif ($_SESSION['permissions']['permissionName'] == 'Agency Corporate') {
            $fieldArr = array('dm_agency_id','agency_name');
            $agencyList = $this->_Oagency->_getAgencyList($fieldArr, $_SESSION['permissions']['access']['agencyId']);
            $corporateList = $this->_Ocorporate->_getCorporateAccessByPermission($_SESSION['permissions']['fieldList']['corporateList'], $_SESSION['agencyId']);
            filewrite('corporateist=>'.print_r($corporateList,1),'agecnycorporatemapping','a+');
            $data = array('corporate'=>$corporateList, 'agency'=>$agencyList);
        }
        return $data;
    }

    public function _getWorkFlowForOrder($orderId, $type = ''){
        // fetching work flow for given order id
        $_AorderDetail = $this->_OcommonDBO->_select('order_details', array('workflow_caption','r_workflow_id'), 'order_id', $orderId);
        
        // fetching components for set workflow
        $this->_Oworkflow = new workflow();
        $_Acomponents = $this->_Oworkflow->_getMappedComponents(array('workflowId'=>$_AorderDetail[0]['r_workflow_id']));
        $_Acaptions = array_column($_Acomponents,'component_caption');

        switch($type){

            case 'workflow':
                //assigning all components
                $_workFlow = $_Acaptions;
                break;

            default:
                //assigning array of approval components
                $_AapprovalComponents = array(CMP_REQUEST_APPROVAL,CMP_ITINERARY_APPROVAL,CMP_TICKET_APPROVAL,CMP_NO_APPROVAL,CMP_ITINERARY_SSR_APPROVAL);

                //checking which approval component exists in workflow
                foreach($_AapprovalComponents as $value) {
                    if(in_array($value,$_Acaptions)) {
                        $_workFlow = $value;
                        break;
                    }
                }
                break;
        }
        return $_workFlow;
    }

    /*
    * @Description fetch table key from the value specified
    * @param string|$tablename
    * @param int|$pkId
    * @param string|$field
    * @return mixed|$insertValue
    */
    public function _fetchTableId($tablename,$pkId,$field,$value){
        
        $returnValue = false;

        $result = $this->_OcommonDBO->_select($tablename, $field, $pkId, $value);
        if($result){
            $result = $this->_OcommonDBO->_select($tablename, $field, $pkId, $value);
            $returnValue = $result[0][current($field)];
        }
        return $returnValue;
    }


    /**
     * used to check the order has trip request etails
     *
     * @param string $_SorderIds
     * @param int $travelMode
     * @return array
     */
    public function _checkOrderTripRequestDetails($_SorderIds, $travelMode){

        $_Ssql = "SELECT trd.*, ard.customize_fields FROM trip_request_details trd 

                  INNER JOIN fact_trip_order_details ftod ON ftod.r_trip_request_details_id = trd.trip_request_details_id
                  
                  INNER JOIN fact_booking_details fbd ON fbd.r_package_id = ftod.r_package_id

                  INNER JOIN air_request_details ard ON ard.air_request_id = fbd.r_request_id

                  WHERE fbd.r_order_id IN ($_SorderIds) AND fbd.travel_mode = $travelMode ";

        return $this->_OcommonDBO->_getResult($_Ssql);
    }

    /**
    * @Description :This function is used to update the workflow for given order
    * @param : array |$orderId - array consisting of order_id
    * @return: string | $workFlowCaption - approval component in workflow that is set
    */
    public function _updateWorkFlowForOrder($orderId = array(), $flowType = 'B', $travelMode = 1,$workFlowInfo = array()){

        $_ArequestTripDetails = array();

        //fetching components for given input
        $input = array(
            'type' => count($workFlowInfo) > 0 ? 'passenger_based' :'session',
            'flowType' => $flowType,
            'travelMode' => $travelMode
        );
        
        //To get all the components for set workflow
        $_Acomponents =  count($workFlowInfo) > 0  ? $this->_Oworkflow->_getWorkflow($input,$workFlowInfo) : $this->_Oworkflow->_getWorkflow($input);

        // check order has trip request details
        $flowType == 'B' ? $_ArequestTripDetails = $this->_checkOrderTripRequestDetails(implode(',', $orderId), $travelMode) : '';

        // set ticket approval flow
        if($_ArequestTripDetails[0]['approval_type'] == '1' || json_decode($_ArequestTripDetails[0]['customize_fields'], TRUE)['orderPostApproval'] == 'Y'){

            $_Acomponents[0] = 'CMP_TICKET_APPROVAL';
        }

        fileWrite('component : '.print_r($_Acomponents,1),'wfcheck','a+');
        if(count($_Acomponents) > 0){
            
            //To get workflow id
            $_IworkFlowId = $this->_Oworkflow->_getWorkFlowUsingComponents($_Acomponents);

            //To get approval caption from the components
            $_SapprovalCaption = reset(preg_grep('/APPROVAL$/', $_Acomponents));
        }
        else{
            //To get workflow id
            $_IworkFlowId = $flowType == 'B' ?  1 : 6; 

            //To get approval caption from the components
            $_SapprovalCaption = 'CMP_NO_APPROVAL';    
        }

        // update workflow component in order_details
        $updateOrderArray['r_workflow_id'] = $_IworkFlowId;
        $updateOrderArray['workflow_caption'] = $_SapprovalCaption;
        fileWrite('updateOrderArray : '.print_r($updateOrderArray,1),'wfcheck','a+');

        $this->_Opackage = new package();
        foreach ($orderId as $key => $value){
            $this->_Opackage->_updateOrderDetails($updateOrderArray,$value);
        }
        return $_SapprovalCaption;
    }

    /*
    * @Description  This method returns the travel mode id for the trip
    * @param |
    * @return string|$comboModeInfo
    * @date|08.05.2017
    * @author|Karthika.M
    */
    public function _getComboTravelMode() {

        $comboModeInfo = array();
        // combo travel mode id
        $comboModeInfo = [3];
        // get the combo details from session.
        $comboModeArray = $_SESSION['userApplicationSettings']['COMBO_REQUEST_FORM'];
        //if air is present
        if(in_array("Air",$comboModeArray)) {
           array_push($comboModeInfo,1);
        }
        //if hotel is present
        if(in_array("Hotel",$comboModeArray)) {
           array_push($comboModeInfo,2);
        }
        // Convert array to string
        $comboModeInfo = implode(",",$comboModeInfo);
        return $comboModeInfo;
    }
    
    /*
    * function name    :-_checkTravelPlanOrders
    * description      :- this function check the existence of travel plan and take the orders related to that travel plan
    * Author           :- Lakshmi
    */
    public function _checkTravelPlanOrders($orderId = 0){
        $travelPlanOrderDetails = array();
        $this->_Opackage = new package();
        $travelPlanDetails = $this->_Opackage->_getTravelPlan(0,0,$orderId);
        if(is_array($travelPlanDetails) && count($travelPlanDetails) > 0){
            $travelPlanId = $travelPlanDetails[0]['travel_plan_id'];
            $travelPlanOrder = $this->_Opackage->_getTravelPlanOrders($travelPlanId);
            if(is_array($travelPlanOrder) && count($travelPlanOrder) > 0){
                foreach($travelPlanOrder as $value){
                    if($value['r_order_id'] != $orderId){
                        $travelPlanPackageDetails = $this->_Opackage->_getTravelType($value['r_order_id']);
                        if(is_array($travelPlanPackageDetails) && count($travelPlanPackageDetails) > 0){
                            $travelModeId = $travelPlanPackageDetails[0]['r_travel_mode_id'];
                            if($travelModeId == SELF::DOMESTIC_AIR_MODE_ID){
                                $travelPlanOrderDetails[$travelModeId][]=$this->_getAirDetails($travelPlanPackageDetails[0]['r_order_id'],$travelPlanPackageDetails[0]['r_request_id']);
                            }
                        }
                    }
                }
            }
        }
        return $travelPlanOrderDetails;
    }
    
    //for getting air details
    public function _getAirDetails($orderId = 0,$requestId = 0){
        
        $this->_OairRequest = new airRequest();
        $this->_Opackage = new package();
        $airRequestDetails = $this->_OairRequest->_getAirRequestDetails($orderId);
        $orderInfo=$this->_Opackage->_getOrderDetails($orderId,array('total_amount','r_ticket_status_id'));
        $airRequestDetails[0]['totalAmount']=$orderInfo[0]['total_amount'];
        $airRequestDetails[0]['status']=$orderInfo[0]['r_ticket_status_id'];
        $airRequestDetails[0]['statusValue'] = $this->_OcommonDBO->_select('dm_status',array('status_value','status_code'),'status_id',$orderInfo[0]['r_ticket_status_id'])[0]['status_value'];
        return $airRequestDetails;
    }
    
    
    
    //get workflow caption id and update the workflow details in order_details.
    public function _getExceptionWorkFlowId($orderId){        
        
        $order_id = is_array($orderId) ? $orderId[0] : $orderId;
        
        //get the travel mode name without hite spaces preg_replace
        $travelModeName = preg_replace('/\s+/','',$this->_OcommonDBO->_select('dm_travel_mode', 'travel_mode', 'travel_mode_id', $this->_OcommonDBO->_select('fact_booking_details', 'travel_mode', 'r_order_id', $order_id)[0]['travel_mode'])[0]['travel_mode']);
        
        //get exception workflow from application settinngs for corporate based travelmode.
        $workFlowCaption  = array_search("YES",$_SESSION['userApplicationSettings']['expWorkFlow_'.$travelModeName]);
        if($workFlowCaption == ''){
            return false;
        }
        
        //get work flow id  
        $workFlowId = $this->_OcommonDBO->_select('workflow_component_mapping', 'r_workflow_id', 'r_component_id', $this->_OcommonDBO->_select('dm_component', 'component_id', 'component_caption', $workFlowCaption)[0]['component_id'])[0]['r_workflow_id'];
        
        // update workflow component in order_details
        $updateOrderArray['r_workflow_id'] = $workFlowId;
        $updateOrderArray['workflow_caption'] = $workFlowCaption;
        
        $this->_Opackage = new package();        
        //update the exception workflow caption in order details.
        if(is_array($orderId)){            
            foreach ($orderId as $key => $value){
                $this->_Opackage->_updateOrderDetails($updateOrderArray,$value);
            }
        }
        else{
            $this->_Opackage->_updateOrderDetails($updateOrderArray,$orderId); 
        }
        return $workFlowCaption;        
    }
    
    
    //function used to check whether policy is violated for corresponding order id.
    public function _checkPolicyViolation($orderId){
        //set the flag.
        $policyViolation = false;
        $violatedPolicyArray = $this->_OcommonDBO->_select('policy_Violation_log','*','r_order_id',$orderId);       
        if(count($violatedPolicyArray) && ($violatedPolicyArray)){
            //policy is violated.
           $policyViolation = true;
        }
        return $policyViolation;
    }
    
    //delete policy violation log.
    public function _deletePolicyViolationLogInLevel($orderId,$policyType){
        $sql = "DELETE FROM policy_Violation_log WHERE r_order_id = ".$orderId." AND policy_violated_level= '".$policyType."'";
        $result = $this->_OcommonDBO->_getResult($sql);
        return $result;
    }
    
    
    //function used to show the corporate and agency id based on the permission level.
    public function _permissionCheck(){        
        $agencyList = 'N';
        $recieveData = $this->_corporateAgencyPermission();
        $this->_Ocorporate->_Sstatus = 'Y';
        $this->_Aagency = array_column($recieveData['agency'], 'agency_name', 'dm_agency_id');        
        if(is_array($this->_Aagency) && count($this->_Aagency) > 0){
           $agencyList = 'Y';
           $this->_AtwigOutputArray['agencyListStatus'] = $agencyList;
           $this->_AtwigOutputArray['agency'] = $recieveData['agency']; 
        }
        else{
            
            $agencyList = 'N';
            $this->_AserviceResponse['agencyListStatus'] = $agencyList;           
            $this->_AserviceResponse['agencyId'] = $_SESSION['agencyId']; 
            $agencyNameArray = array('agency_name');      
            $agencyName = $this->_OcommonDBO->_select('dm_agency', $agencyNameArray,'dm_agency_id',$_SESSION['agencyId'])[0];  
            $this->_AserviceResponse['agencyName'] =  $agencyName['agency_name'];
        }
        if(count($recieveData['corporate']) > 0 )
        {           
            if(count($recieveData['corporate']) == 1)
            {
                $corporateList = 'N';
                $this->_AserviceResponse['corporateListStatus'] = $corporateList;
                $this->_AserviceResponse['corporateId'] = $_SESSION['corporateId'];                
                $corporateNameArray = array('corporate_name');      
                $corporateName = $this->_OcommonDBO->_select('dm_corporate', $corporateNameArray,'corporate_id',$_SESSION['corporateId'])[0];  
                $this->_AserviceResponse['corporateName'] =  $corporateName['corporate_name'];
            }  
            else 
            {
                $corporateList = 'Y';
                $this->_AserviceResponse['corporate'] = $recieveData['corporate']; 
                $this->_AserviceResponse['corporateListStatus'] = $corporateList; 
            }             
        }
        else 
        {
            $corporateList = 'N';
            $this->_AserviceResponse['corporateListStatus'] = $corporateList;
            $this->_AserviceResponse['corporateId'] = $_SESSION['corporateId']; 
            $corporateNameArray = array('corporate_name');      
            $corporateName = $this->_OcommonDBO->_select('dm_corporate', $corporateNameArray,'corporate_id',$_SESSION['corporateId'])[0];  
            $this->_AserviceResponse['corporateName'] =  $corporateName['corporate_name'];
        }        
        return array('agencyListStatus' => $this->_AtwigOutputArray['agencyListStatus'],
                     'agency'=> $this->_AtwigOutputArray['agency'], 
                     'corporate' => $this->_AserviceResponse['corporate'],'corporateListStatus'=> $this->_AserviceResponse['corporateListStatus'] );        
    }
    
    /**
     * used to get settings display data array
     * @param type $packageId int
     * @param type $getFareArrayKeyValue string
     * @return type Description array
     */
    public function _getSettingsDisplayData($packageId = 0, $getFareArrayKeyValue = '', $employeeId ='', $corporateId ='',$flowCheck = ''){

        fileWrite('$packageId'.print_r($packageId,1),'baskarSTART','a+');
        $guestBookingFlag = false;
        $this->_getAggregate = new createManageAggregate();        
        $corporate = new corporateCustomization();

        // to check whether package id is empty or not        
        if($packageId != 0){
            $sql = "SELECT od.order_id AS orderData, od.r_travel_mode_id AS travel_mode_id, dp.package_type, ard.trip_type AS trip_type FROM fact_booking_details fbd JOIN dm_package dp ON fbd.r_package_id=dp.package_id LEFT JOIN air_request_details ard ON ard.air_request_id = fbd.r_request_id JOIN order_details od ON od.order_id=fbd.r_order_id WHERE fbd.r_package_id = $packageId";
            fileWrite('sql'.print_r($sql,1),'baskarSTART','a+');
            $travelData = $this->_OcommonDBO->_getResult($sql);
            
            //get fact employee id based on package id
            $paxEmpSql = "SELECT fbd.* FROM fact_booking_details fbd JOIN passenger_details pd ON fbd.r_order_id=pd.r_order_id WHERE fbd.r_package_id =".$packageId." LIMIT 1";
            fileWrite('paxEmpSql'.print_r($paxEmpSql,1),'baskarSTART','a+');

            $bookingDetails = $this->_OcommonDBO->_getResult($paxEmpSql);

            fileWrite('bookingDetails'.print_r($bookingDetails,1),'baskarSTART','a+');

            $factEmployeeId = $bookingDetails[0]['r_employee_id'];
            fileWrite('factEmployeeId'.print_r($factEmployeeId,1),'baskarSTART','a+');

            if($factEmployeeId == 0){
                fileWrite('GUEST EXIST','baskarSTART','a+');
                $factEmployeeId = $_SESSION['employeeId'];
            }
        }
        else{
            $factEmployeeId = $employeeId != '' ? $employeeId : $_SESSION['employeeId'];
            (isset($this->_AtravelModeInfo) && count($this->_AtravelModeInfo) > 0 ) ? $travelData = $this->_AtravelModeInfo : '';
        }        
        $guestBookingFlag = $_SESSION['userTypeId'] == 2 ? true : false ;
        
        fileWrite('$factEmployeeId'.print_r($factEmployeeId,1),'baskarSTART','a+');
        fileWrite('$travelData'.print_r($travelData,1),'baskarSTART','a+');
        
        // get employee corporate and user type id
        $fieldsArray = array('r_user_type_id', 'r_corporate_id');
        $employeeCorporateAndUserTypeId = (!empty($factEmployeeId)) ? $this->_OcommonDBO->_select('fact_employee', $fieldsArray, 'r_employee_id', $factEmployeeId)[0] : FALSE;
        fileWrite('$employeeCorporateAndUserTypeId'.print_r($employeeCorporateAndUserTypeId,1),'baskarSTART','a+');
        
        if($packageId != 0){
            // to set corporate based on employee flow
            $corporate->_IcorporateId = $bookingDetails[0]['r_corporate_id'];
            //to get booking type by using package id
            $booking_type = $this->_OcommonDBO->_select('dm_package','booking_type','package_id',$packageId)[0]['booking_type'];
            $booking_type = ($booking_type == 1) ? 'corporate/' : 'personal/';
            $_AsettingsArray = $corporate->_getCorporateSettingsFromJSON('',$booking_type);
        }
        else{
            $corporate->_IcorporateId = $corporateId != '' ? $corporateId : $_SESSION['corporateId'];
            $_AsettingsArray = $corporate->_getCorporateSettingsFromJSON();
        }
       
        $flowTypeFromJSON =  array_search('YES', $_AsettingsArray['settings']['FARE_PROFILE_FLOW_TYPE']);
        fileWrite('$flowTypeFromJSON'.print_r($flowTypeFromJSON,1),'baskarSTART','a+');
        
        // flow based on applicaton settings USER TYPE OR AGGREGATE
        $settingsData['flowType']  = $flowTypeFromJSON == 'User Type' ? 'U' : 'A';
        $settingsData['type'] = $employeeCorporateAndUserTypeId['r_user_type_id'];
        
        //flow based on aggraegate
        if($settingsData['flowType'] == 'A'){
            $aggregate = $this->_getAggregateData($factEmployeeId,$guestBookingFlag,$flowCheck);
            fileWrite('aftter imploeeaggregate'.print_r($aggregate,'1'),'baskarSTART','a+');
            $settingsData['type'] = $aggregate;
        }
        // to get employee based aggregate data from database
        $settingsData['travelMode'] = $travelData[0]['travel_mode_id'];
        
        //to check travel data based on package type process        
        if(!empty($travelData) && $travelData[0]['package_type'] == 0){
            if($travelData[0]['trip_type'] == 1){       
                $settingsData['tripType'] = 2;
            }
            else if($travelData[0]['trip_type'] == 0){
                $settingsData['tripType'] = 1;
            }
        }
        else if($travelData[0]['package_type']==1){
            $settingsData['tripType'] = 3;
        }
        
        $settingsData['corporateId'] = $employeeCorporateAndUserTypeId['r_corporate_id'];
        fileWrite('$settingsData'.print_r($settingsData,'1'),'baskarSTART','a+');
        
        if($settingsData['type'] != '' || $packageId == 0){
            $settingsName = $this->_manageApp->_getFareProfileSettingsName($settingsData)[0]['fare_profile_setting_name'];
        }
        else{
            $settingsName = '';
        }
        fileWrite('$settingsName'.print_r($settingsName,'1'),'baskarSTART','a+');
        
        // get display settings data array based on corporate and user type id of employee
        $this->_settingNamePassing = $settingsName;
        return  $this->_getFareSettingsDisplayData($getFareArrayKeyValue,$settingsName,$settingsData['travelMode'],$settingsData['tripType'],$settingsData['corporateId']);
    }    


    public function _getAggregateData($factEmployeeId,$guestBookingFlag,$flowtype){
        $aggregate  = $this->_getAggregate->_checkEmployeeAggregateForSettings($factEmployeeId);
        fileWrite('$aggregate'.print_r($aggregate,'1'),'baskarSTART','a+');
        // to call and settings name from database
        $aggregate = implode(',',array_column($aggregate,'r_aggregate_id'));
        return $aggregate;
    }
/**
     * used to get the fare setting display configuration array settings data
     * @param type $getFareArrayKeyValue | string
     * @param type $corporateId | int
     * @param type $userTypeId | int
     * @return type Description array
     * @author SATHEES
     **/

    public function _getFareSettingsDisplayData($getFareArrayKeyValue,$settingsFileName,$travelModeId = 1,$tripId = 0,$corporateId = 0){

        /*purify the INPUTS*/
        $_OauthToken = new authToken();

        //Write the input params to check
        fileWrite("Input - ".'Get Key :'.$getFareArrayKeyValue.'   File Name : '.$settingsFileName,"fareProfileSettings","a+");
     
        //Initialized the array
        $settingsArray = array();
        
        $fileName = ($settingsFileName != '') ? str_replace(' ', '_',$settingsFileName).".json" : 'Product_Default_Settings_'.$corporateId.'.json' ;
        
        //get fare profile path based on application type
        $fareProfilePath = (INDEXNAME != 'personal') ? FARE_PROFILE_SETTING_JSON_FILE_PATH : FARE_PROFILE_SETTING_JSON_FILE_PATH_PER;
        $fareProfilePathAndFile = $_OauthToken->_purifyInputData(APPLICATION_BASE_PATH.$fareProfilePath.$fileName);

        fileWrite("Input - ".'Get Key :'.$fareProfilePathAndFile.'   File Name : '.$settingsFileName,"fareProfileSettings","a+");
        
        $settingsArray = json_decode(file_get_contents($fareProfilePathAndFile), true);

        //if fare profile does not exist fetch from default session json file
        if(count($settingsArray) == 0){
            $fileName = 'Product_Default_Settings.json';
            $purifiedValue= $_OauthToken->_purifyInputData(APPLICATION_BASE_PATH.$fareProfilePath.$fileName);
            $settingsArray = json_decode(file_get_contents($purifiedValue),true);
        }
        
        $data = (isset($settingsArray[$getFareArrayKeyValue])) ? $settingsArray[$getFareArrayKeyValue] : $settingsArray ;

        fileWrite("Output - "." File Refered : ".$fileName,"fareProfileSettings","a+");
        fileWrite("Result : ".print_r($data,1),"fareProfileSettings","a+");        
        return $data;
    }
    
    
    function _setRequestFormConfigurations($formSetting,$cabinClass,$getEnabled,$setEnable) {
        
        foreach($formSetting AS $key => $value) {
            $k = strtolower($key);
            $arrayFormation[$setEnable] = $getEnabled;
            $arrayFormation[$k] = array();
            foreach($value AS $innerKey => $innerValue) {
                $arrayFormation[$k][$cabinClass[$innerKey]] = $innerValue;
            }
        }
        
        return $arrayFormation;
        
    }
    
    public function _getAddtionalEmailIds($passengerId) {
        
        $sql = "SELECT
                        pd.alternate_email_id  
                FROM 
                        passenger_details pd 
                WHERE 
                        pd.passenger_id = ".$passengerId;
        
        $result =  $this->_OcommonDBO->_getResult($sql);
        
        return ($result[0]['alternate_email_id']!='') ? $result[0]['alternate_email_id'] : '' ;
        
    }

    /**
     * @Description : This method is used to send data for agency auto back end for requested key
     * @Param : param1 is requested key, param2 given array
     * @Author : SatheesKumar
     */
    public function _setFareSettingArrayForBackEnd($getFareArrayKeyValue,$request) {
        
        if($getFareArrayKeyValue=="Request_Form_Configurations") {
            
            //get travel type and trip type wise setting file names after checking aggregate or user type
            $resultArray = $this->_getAllAggregateCorporate($request);
                
            //Initialize the values
            $travelMode = array('1'=>'domestic','9'=>'international'); 
            $tripMode = array('1'=>'oneWay','2'=>'roundTrip','3'=>'multiCity');
            $cabinValues = array('Economy'=>'E','Premium_Economy'=>'P','First'=>'F','Business'=>'B');
            $key = $request['fareProfileSettings']['request_configuration'];
            $settingArray = array();

            //Get values from given files to corresponding travel and trip type
            foreach($travelMode AS $travelKey => $travelValue) {
                foreach($tripMode AS $tripKey => $tripValue) {
                    $cabin = $this->_getFareSettingsDisplayData($key,$resultArray[$travelKey][$tripKey]['fare_profile_setting_name'],'','',$request['fareProfileSettings']['corporate_id']);  
                    foreach($cabin['Cabin'] AS $class => $status) {
                        $settingArray[$travelValue]['tripType'][$tripValue]['cabin'][$cabinValues[$class]] = $status;
                    }
                }
            }
            
            //Intenational multi city not available so unset here
            unset($settingArray['international']['tripType']['multiCity']);
            
            //Assign the prepared array to return
            $preparedArray = $settingArray;            
        } 
        elseif($getFareArrayKeyValue == "Cancellation_Configurations") {
            
            //get travel type and trip type wise setting file names after checking aggregate or user type
            $resultArray = $this->_getAllAggregateCorporate($request);
            
            //Initialize the values
            $travelMode = array('1'=>'domestic','9'=>'international'); 
            $tripMode = array('1'=>'oneWay','2'=>'roundTrip','3'=>'multiCity');
            $key = $request['fareProfileSettings']['request_configuration'];
            $travelType = (isset($request['fareProfileSettings']['travelType'])) ? $request['fareProfileSettings']['travelType'] : 1 ;
            $tripType = (isset($request['fareProfileSettings']['tripType'])) ? $request['fareProfileSettings']['tripType'] : 1 ;
            $fileName = $resultArray[$travelType][$tripType]['fare_profile_setting_name'];
            $settingArray = array();
            $preparedArray = array();
            
            //Get the settings by given file name
            $settingsArray = $this->_getFareSettingsDisplayData($key,$fileName,'','',$request['fareProfileSettings']['corporate_id']); 
            
            //Prepare the array for backend
            foreach($settingsArray AS $key => $value) {
                if($key == "LCC_Auto_cancellation_and_Refund_with_Airlines") {
                    foreach($value as $innerKey => $innerValue) {
                        $preparedArray['autoCancellation']['fareType']['all']['airlines'][] = substr($innerKey, -2);
                        $preparedArray['autoRefund']['fareType']['all']['airlines'][] = substr($innerKey, -2);
                    }
                    $preparedArray['autoRefund']['fareType']['all']['description'] = "Auto refund for all this airlines for all fare types";
                } elseif($key == "GDS_Auto_Cancellation_With_Airlines") {
                    foreach(explode(",", $value['textBoxValue']) AS $innerKey => $innerValue) {
                        $preparedArray['autoCancellation']['fareType']['all']['airlines'][] = $innerValue; 
                    }
                } elseif($key == "Auto_Refund_GDS_Retail_Fare") {
                    $preparedArray['autoRefund']['fareType']['retailFare']['airlines'] = explode(",", $value['textBoxValue']);; 
                    $preparedArray['autoRefund']['fareType']['retailFare']['description'] = "Auto refund GDS retail fare";
                } elseif($key == "Auto_Refund_GDS_Corporate_Fare_From_CAT_16") {
                    $preparedArray['autoRefund']['fareType']['corporateFare']['airlines'] = explode(",", $value['textBoxValue']);; 
                    $preparedArray['autoRefund']['fareType']['corporateFare']['description'] = "Auto refund GDS corporate fare from CAT 16";
                }
            }            
        }
        elseif($getFareArrayKeyValue=="General_configurations"){        
            //Get package id
            $packageId = (isset($request['fareProfileSettings']['packageId'])) ? $request['fareProfileSettings']['packageId'] : 0 ;
            
            //get eticket content.      
            $this->_OeTicket = new eTicketMail();
            $preparedArray['footerContent'] = $this->_OeTicket->_getEticketMailContent($packageId);
            $preparedArray['maxTimeForBooking'] = $this->_getTimeViolationCount();
            $ssrdetails = $this->_getSSROptionInfo();
            $preparedArray['ssrOptions'] = $ssrdetails['ssrSettingsInfo'];            
        } 
        else{
           //Given key not valuable
           $preparedArray = $getFareArrayKeyValue." key not available"; 
        }
        //Prepared result send to called function
        return $preparedArray;
    }
    
    //get the booking time violation count for corporate.
    public function _getTimeViolationCount($packageId){
        
        //get settings info for the corporate.
        $fareProfileSettingsInfo = $this->_getSettingsDisplayData($packageId,'General_configurations');
        
        //assign the value.
        $minutesCount = $fareProfileSettingsInfo['Minutes_To_Complete_The_Booking']['textBoxValue'];
        $violationTimeMin = $minutesCount > 0 ? $minutesCount : 0;
        $violationTimeSec = 0;
        
        //calculate the timer count for the minutes
        $totalviolationTime  = ($violationTimeMin * 60) + $violationTimeSec;
        return $totalviolationTime;
    }
    
    //function used to show the corporate and agency id based on the permission level.
    public function _getAgencyCorporatePermissionCheck(){
        
        $this->_Opermission = new getPermission();
        $permissionData = $this->_Opermission->_getDataAccessPermission();
        fileWrite(print_r($permissionData,1),'permissionData','a+');
                
        //get corporate list.
        foreach ($permissionData['access']['agencyId'] as $key => $value){
            $agencyInfo = $this->_OcommonDBO->_select('dm_agency','*','dm_agency_id',$value);
            $agencyList[$key]['dm_agency_id'] = $agencyInfo[0]['dm_agency_id'];
            $agencyList[$key]['agency_name'] = $agencyInfo[0]['agency_name'];
        }

        //get agency list.
        foreach ($permissionData['access']['corporateId'] as $key => $value){
            $corporateInfo = $this->_OcommonDBO->_select('dm_corporate','*','corporate_id',$value);
            $corporateList[$key]['corporate_id'] = $corporateInfo[0]['corporate_id'];
            $corporateList[$key]['corporate_name'] = $corporateInfo[0]['corporate_name'];
        }
        //check status.
        if($permissionData['fieldList']['agencyList'] == 'YES'){
            $this->_AtwigOutputArray['agency'] = $agencyList;
            $this->_AtwigOutputArray['agencyListStatus'] = 'Y';
            $this->_AserviceResponse['agencyId'] = $agencyList;
        }
        else{
            $this->_AserviceResponse['agencyId'] = $_SESSION['agencyId'];
        }
        if(count($corporateList) >= 1){
            $this->_AserviceResponse['corporate'] = $corporateList;                    
        }
        else{
            $this->_AserviceResponse['corporateId'] = $_SESSION['corporateId'];
        }
        $this->_AserviceResponse['agencyListStatus'] = $permissionData['fieldList']['agencyList'] == 'YES' ? 'Y' :'N';
        $this->_AserviceResponse['corporateListStatus'] = count($corporateList) > 1 ? 'Y' :'N'; 
        $this->_AtwigOutputArray['corporateListStatus'] = count($corporateList) > 1 ? 'Y' :'N';       
        fileWrite(print_r($this->_AserviceResponse,true),"serviceResponse");
    }
    
    /*
    *@author      :A.kaviyarasan
    *Function Name:getpermission
    *Description  :This function is used to get the user type to show the details  
    */  
    public function _getUserTypePermissionCheck(){
        // set the input values
        if($_SESSION['permissions']['permissionId'] == 2){
            $inputInfo['agencyId'] = $_SESSION['agencyId'];
            $inputInfo['corporateId'] = $_SESSION['corporateId'];
        }
        else if($_SESSION['permissions']['permissionId'] == 3){
            $inputInfo['agencyId'] = $_SESSION['agencyId'];
            $inputInfo['corporateId'] = $_SESSION['permissions']['fieldList']['corporateList'];
        }
        else if($_SESSION['permissions']['permissionId'] == 4){
            $inputInfo['agencyId'] = $_SESSION['agencyId'];
            $inputInfo['corporateId'] = $_SESSION['corporateId'];
        }
        else if($_SESSION['permissions']['permissionId'] == 5){
            $inputInfo['agencyId'] = $_SESSION['agencyId'];
            $inputInfo['corporateId'] = $_SESSION['corporateId'];
        }
        else if($_SESSION['permissions']['permissionId'] == 6){
            $inputInfo['agencyId'] = $_SESSION['agencyId'];
            $inputInfo['corporateId'] = $_SESSION['permissions']['fieldList']['corporateList'];
        }
        return $inputInfo;
    }
    
    /**
     * used to evaluate the module and payment type mapping for corporate and user group id
     * @param type $corporateId int
     * @param type $userGroupId int
     * @param type $paymentTypeCode array or string
     * @return boolean
     */
    public function _eveluateModuleAndPaymentTypeMaping($corporateId, $userGroupId, $paymentTypeCode = 'CT') {
        
        $paymentTypeId = $result = array();
        // evaluate payment mapping
        $result = $this->_eveluatePaymentTypeMaping($corporateId, $userGroupId, $paymentTypeCode);
        
        $paymentTypeId = count($result) > 0 ? array_column($result, 'payment_type_id') : FALSE;
                
        return count($paymentTypeId) > 0 ? $this->_insertPaymentCorporateGroupMapping($paymentTypeId, $corporateId, $userGroupId) : FALSE;
    }
    /**
     * used to insert payment mapping for corporate and user group
     * @param type $paymentTypeId
     * @param type $corporateId
     * @param type $userGroupId
     * @return type array or boolean
     */
    public function _insertPaymentCorporateGroupMapping($paymentTypeId, $corporateId, $userGroupId) {
        
        $insertPaymentMapping = array();
        
        foreach ($paymentTypeId as $key => $value) {
            $insertPaymentMapping[$key]['r_corporate_id'] = $corporateId;
            $insertPaymentMapping[$key]['r_group_id'] = $userGroupId;
            $insertPaymentMapping[$key]['r_payment_type_id'] = $value;
            $insertPaymentMapping[$key]['r_airline_id'] = 0;
        }
        
        return (!empty($corporateId) && !empty($userGroupId) && count($paymentTypeId) > 0) ? $this->_OcommonDBO->_insertMultipleValues('payment_type_mapping', $insertPaymentMapping) : FALSE;
    }
    /**
     * evaluate mapping for payment type for corporate and user group id
     * @param type $corporateId int
     * @param type $userGroupId int
     * @param type $paymentTypeCode string
     * @return type array
     */
    public function _eveluatePaymentTypeMaping($corporateId, $userGroupId, $paymentTypeCode) {
        
        $paymentEvaluateSql = " SELECT
                                        ptm.payment_type_mapping_id, dpt.payment_type_id
                                FROM 
                                        payment_type_mapping ptm
                                        
                                INNER JOIN dm_payment_type dpt ON dpt.payment_type_id = ptm.r_payment_type_id
                                
                                WHERE 
                                        ptm.r_corporate_id = $corporateId AND ptm.r_group_id = $userGroupId 
                                        AND dtm.payment_type_code = '".$paymentTypeCode."' ";
        
        // check the function param not empty and get the query result or return false
        return (!empty($corporateId) && !empty($userGroupId) && !empty($paymentTypeCode)) ? $this->_OcommonDBO->_getResult($paymentEvaluateSql) : FALSE;
    }
    
      /**
     * function to get all agggregate for the corporate ID
     * @param type $corporateId int
     * @param type $userGroupId int
     * @param type $paymentTypeCode string
     * @return type array
     */
    
    public function _getAllAggregateCorporate($input) {
        $createManageAggregate = new createManageAggregate();
        $manageAppSett = new manageApplicationSettings();
        $searchResultValue = $this->_manageApp->_getSpecificDataFromJSON($input['fareProfileSettings']['corporate_id'],'FARE_PROFILE_FLOW_TYPE');
        fileWrite('$searchResultValue'.print_r($searchResultValue,1),'satSYNC','a+');
        $settArray['corporateId'] = $input['fareProfileSettings']['corporate_id'];
        $settArray['flowType'] = $searchResultValue == 'User Type'  ? 'U' : 'A';
        fileWrite('$settArray'.print_r($settArray,1),'satSYNC','a+');
        if($searchResultValue == 'User Type'){
            if($input['fareProfileSettings']['group_id'] != '' && $input['fareProfileSettings']['group_id'] !=0){
                $settArray['type'] = $input['fareProfileSettings']['group_id'];
                fileWrite('$settArray'.print_r($settArray,1),'satSYNC','a+');
                $settingName[] = $manageAppSett->_getFareProfileSettingsName($settArray);
                fileWrite('$settingName'.print_r($settingName,1),'satSYNC','a+');
            }
        }elseif($searchResultValue == 'Aggregate Type'){
            $input['fareProfileSettings']['employeeDetails'] = array_change_key_case($input['fareProfileSettings']['employeeDetails'],CASE_UPPER);
            fileWrite('$corpoateBasedAggregate'.print_r($input,1),'satSYNC','a+');
            $corpoateBasedAggregate = $createManageAggregate ->_getCorporateAggregates($input['fareProfileSettings']['corporate_id']);
            if(!empty($corpoateBasedAggregate) && count($corpoateBasedAggregate)>0){
                foreach ($corpoateBasedAggregate as $key => $value) {
                    fileWrite('$corpoateBasedAggregate'.print_r($corpoateBasedAggregate,1),'satSYNC','a+');
                    fileWrite('$value'.print_r($value,1),'satSYNC','a+');
                    if($value['aggregate_name'] == strtoupper($input['fareProfileSettings']['employeeDetails'][$value['aggregate_type']])){
                        $settArray['type'] = $value['aggregate_id'];
                        fileWrite('insideif'.print_r($settArray,1),'satSYNC','a+');
                        $settingName[] = $manageAppSett->_getFareProfileSettingsName($settArray);
                    }
                }
            }
        }
        if(!empty($settingName) && count($settingName)>0){
            $resultData = $manageAppSett->_setArrayFormationBackEnd($settingName);
        }else{
            $resultData = '';
        }
        return $resultData;
    }

    /**
     * function to get all promocode related data
     * @param type $date int
     * @param type $corporateId int
     * @param type $requestedData array
     * @return type array
     */
    public function _discountFareFlightsPromoCode($date,$airlineCode='',$corporateId,$requestedData,$cabinClass,$orderId = 0,$bookingMode = 'C'){        

        //get the boooking mode info.
        if($orderId != 0){
            $packageId = $this->_OcommonDBO->_select('fact_booking_details','r_package_id','r_order_id',$orderId)[0]['r_package_id']; 
            $booking_mode = $this->_OcommonDBO->_select('dm_package','booking_type','package_id',$packageId)[0]['booking_type']; 
        }
        else{
            //set booking mode as corporate
            $booking_mode = ($bookingMode == 'P') ? '0' : '1';
        }
        
        $promoResultFareTypeSpecific = '';
        $promoResultBookingClassSpecific='';
        $promoResultNotSpecific = '';
        $promoResultFareTypeClassSpecific ='';
        $promoResultTravelSpecific = '';
        $sqlPromocodeMain = "SELECT
                            pcd.marketing_airline_code as airlineCode,
                            pcd.booking_class as bookingClass,
                            pcd.fare_type as fareType,  
                            pcm.r_corporate_id as corporateid,
                            pcd.fare_basis_code as fareBasisCode,
                            pcd.promo_code_value as promoCode,
                            pcd.promo_code_id
                        FROM
                            dm_promo_code pcd 
                            INNER JOIN promo_code_mapping pcm ON pcd.promo_code_id = pcm.r_promo_code_id
                        WHERE
                            pcm.r_promo_code_id=pcd.promo_code_id
                            AND pcm.r_corporate_id='".$corporateId."'
                            AND pcm.status='Y'
                            AND pcm.booking_mode = '".$booking_mode."'
                            AND  '".$date."' between pcd.start_date and pcd.end_date";

        if($airlineCode!=''){
            $sqlPromocodeMain.=" AND pcd.marketing_airline_code='".$airlineCode."'";
        }
        $sqlWhereSpecific .= "  AND travel_type IN (".$requestedData['travelMode'].", 0)";
        $sqlWhereSpecific .= $cabinClass!='' ? " AND pcd.cabin_class='".$cabinClass."'" : " "; 
        $sqlPromocode = $sqlPromocodeMain ;
        $sqlPromocode.= $sqlWhereSpecific;
        filewrite(print_r($sqlPromocode,1),"sqlPromocode","a+");
        $result =  $this->_OcommonDBO->_getResult($sqlPromocode);
        if(!$result){
            $sqlWhereSpecific = "  AND travel_type IN (".$requestedData['travelMode'].", 0) AND pcd.cabin_class= '*' ";
            $sqlPromocode = $sqlPromocodeMain ;
            $sqlPromocode.= $sqlWhereSpecific;
            $result =  $this->_OcommonDBO->_getResult($sqlPromocode);
            if(!$result){
                $promoResultFareTypeSpecific='';
                $promoResultBookingClassSpecific='';
                $promoResultNotSpecific='';
                $promoResultFareTypeClassSpecific='';
                $promoResultTravelSpecific='';
            }
            else{
                if(isset($requestedData['fareType']) && $requestedData['fareType']!=''){
                    $promoCount=count($result);
                    for($i=0;$i<$promoCount;$i++){
                        if($requestedData['fareType'] == $result[$i]['fareType']){
                            if(isset($requestedData['bookingClass']) && $requestedData['bookingClass']!=''){
                                if($requestedData['bookingClass'] == $result[$i]['bookingClass'])
                                    $promoResultFareTypeClassSpecific= $result[$i];
                                else if($result[$i]['bookingClass']=='')
                                    $promoResultFareTypeSpecific= $result[$i];
                            }
                            else
                                $promoResultFareTypeSpecific= $result[$i];
                        }
                        else if($result[$i]['fareType']=='*'){
                            if(isset($requestedData['bookingClass']) && $requestedData['bookingClass']!=''){
                                if($requestedData['bookingClass'] == $result[$i]['bookingClass'])
                                    $promoResultBookingClassSpecific= $result[$i];
                                else if($result[$i]['bookingClass']=='')
                                    $promoResultNotSpecific = $result[$i];
                            }
                            else
                                $promoResultNotSpecific= $result[$i];
                        }
                    }
                }
                else{
                     $promoResultTravelSpecific= $result;
                }
            }
        }
        else{
            if(isset($requestedData['fareType']) && $requestedData['fareType']!=''){
                $promoCount=count($result);
                for($i=0;$i<$promoCount;$i++){
                    if($requestedData['fareType'] == $result[$i]['fareType']){
                        if(isset($requestedData['bookingClass']) && $requestedData['bookingClass']!=''){
                            if($requestedData['bookingClass'] == $result[$i]['bookingClass'])
                                $promoResultFareTypeClassSpecific= $result[$i];
                            else if($result[$i]['bookingClass']=='')
                                $promoResultFareTypeSpecific= $result[$i];
                        }
                        else
                            $promoResultFareTypeSpecific= $result[$i];
                    }
                    else if($result[$i]['fareType']=='*'){
                        if(isset($requestedData['bookingClass']) && $requestedData['bookingClass']!=''){
                            if($requestedData['bookingClass'] == $result[$i]['bookingClass'])
                                $promoResultBookingClassSpecific= $result[$i];
                            else if($result[$i]['bookingClass']=='')
                                $promoResultNotSpecific = $result[$i];
                        }
                        else
                            $promoResultNotSpecific= $result[$i];
                    }
                }
            }
            else{
                 $promoResultTravelSpecific= $result;
            }
        }
        if(is_array($promoResultTravelSpecific))
            $result=$promoResultTravelSpecific;
        else if(is_array($promoResultFareTypeClassSpecific) && isset($promoResultFareTypeClassSpecific['promoCode']))
            $result=$promoResultFareTypeClassSpecific;
        else if(is_array($promoResultFareTypeSpecific) && isset($promoResultFareTypeSpecific['promoCode']))
            $result=$promoResultFareTypeSpecific;
        else if(is_array($promoResultBookingClassSpecific) && isset($promoResultBookingClassSpecific['promoCode']))
             $result=$promoResultBookingClassSpecific;
        else if(is_array($promoResultNotSpecific) && isset($promoResultNotSpecific['promoCode']))
             $result=$promoResultNotSpecific;
        else
            $result='';
        foreach($result as $key => $value){
            if($value['bookingClass']=='CF-W'){
                $result[$key]['bookingClass']='CF';
            }
        }
	
        return $result;
    }

    /*
     * @Description  get policy violation log info.
     * @param int|$orderId,$policyType
     * @return array|$result
     * @date|06.12.2017
     * @author|Karthika.M
     */
    public function _getPolicyViolationLogInLevel($orderId,$policyType){
        $sql = "SELECT  * FROM policy_Violation_log WHERE r_order_id = ".$orderId." AND policy_violated_level= '".$policyType."'";
        $result = $this->_OcommonDBO->_getResult($sql);
        return $result;
    }
    
    /**
    * _checkApprovalFlow to check the bookings with approver process 
    * @param  $_IinputData | array
    * @return $response | array 
    */
    public function _checkApprovalFlow($_IinputData){
        
        $result = array();
        if(isset($_IinputData['packageId']) && $_IinputData['packageId'] != ''){
           $sqlCheck = "SELECT fbd.r_order_id,od.approval_level,GROUP_CONCAT(DISTINCT(pd.email_id)) as paxEmailId
                        FROM fact_booking_details fbd,order_details od,passenger_details pd
                        WHERE fbd.r_order_id = od.order_id AND pd.r_order_id = od.order_id AND od.approval_level>0 AND fbd.r_package_id=".$_IinputData['packageId']." GROUP BY pd.r_order_id";
           $result = $this->_OcommonDBO->_getResult($sqlCheck);           
        }
        return $result;
    }
    
    /**
     * _paymentFailIndicationMailForPassenger to send mail for passenger while booking cancelled
     * @param  $approvalOrderArray | array
     * @return $mailResponse | array 
     */
    public function _paymentFailIndicationMailForPassenger($approvalOrderArray,$failureType){
        
        $mailResponse=array();
        foreach($approvalOrderArray as $key=>$value){ 
            if($failureType=='THRESHOLD_CHECK'){
                $mailSubject = "Booking with order id:".$key." has cancelled ";
                $mailContent = "Booking with order id:".$key." has been cancelled, because increased fare amount is greater than your threshold amount.";
            }
            else{
                $mailSubject = "Booking with order id:".$key."has cancelled ";
                $mailContent = "Booking with order id:".$key."has been cancelled, because you have rejected the fare check confirmation";
            }
            filewrite("In mailSubject:".$mailSubject,"CheckApproval","a+");
            filewrite("In mailContent:".$mailContent,"CheckApproval","a+");
            $mailResponse[] = $this->_OcommonMethods->_sendMail($value,'support@atyourprice.in',$mailSubject,$mailContent);
        }
        return $mailResponse;
    }
    
    
    /*
    * @Description  get the user application settings info
    * @param int|$orderId
    * @return array|$_AsettingsArray['settings']
    * @date|23.01.2018
    * @author|Karthika.M
    */
    public function _getUserApplicationSettingsInfo($orderId){
        
        //get corporate id. 
        $corporateId = $this->_OcommonDBO->_select('fact_booking_details',array('r_corporate_id'),'r_order_id',$orderId)[0]['r_corporate_id'];
        
        //object declaration.
        $Ocorporate = new corporateCustomization(); 

        //set corporate id.
        $Ocorporate->_IcorporateId = $corporateId;
        
        //calling the function for getting the user application settings info from the json.
        $_AsettingsArray = $Ocorporate->_getCorporateSettingsFromJSON();
        return $_AsettingsArray['settings'];          
    }    
    
    /*
    * @Description  get the ssr enabled options info.
    * @param int|$orderId
    * @return array|$result
    * @date|08.01.2018
    * @author|Karthika.M
    */
    public function _getSSROptionInfo($orderId = ''){     
        
        //get ssr settings info from the json.
        $userApplicationSettings = $this->_getUserApplicationSettingsInfo($orderId);
       
        //get package details 
        $packageId = $orderId != '' ?  $this->_OcommonDBO->_select('fact_booking_details','r_package_id','r_order_id',$orderId)[0]['r_package_id'] : ''; 
        
        //get general setting 
        $generalSettings = $this->_getSettingsDisplayData($packageId,'General_configurations');
        
        $ssrOptions['ssrOptionsInfo']['seat_enabled'] = $generalSettings['Ancillary']['Seat'];
        $ssrOptions['ssrOptionsInfo']['meal_enabled'] = $generalSettings['Ancillary']['Meal'];
        $ssrOptions['ssrOptionsInfo']['baggage_enabled'] = $generalSettings['Ancillary']['Baggage'];
        
        $ancillaryArr = array('0' => 'Seat','1' => 'Meal','2' => 'Baggage' );
        $ancillaryInfo = array();        
        foreach($ancillaryArr as $key => $value) {
            if($generalSettings['Ancillary'][$value] == 'Y'){               
                array_push($ancillaryInfo,$value);
            }
        }      
       
        $ssrOptions['ssrSettingsInfo'] = $ancillaryInfo;
        $ssrOptions['userApplicationSettings'] = $userApplicationSettings;
        return $ssrOptions;          
    }
    
    /*
    * @Description  get fare profile settings info with respect to the inputs
    * @param array|$input
    * @return array|$fareProfileSettingsInfo
    * @author|Karthika.M
    */
    public function _getFareProfileSettingsInfo($input){
        $packageType = 0;
        if($input['tripType'] == 2){
            $packageType = 1;
        }        
        //set the travel mode info
        $this->_AtravelModeInfo[0] = array('travel_mode_id' => $input['travelMode'],'trip_type' => $input['tripType'],'package_type' => $packageType); 
        
        //get the fare profile settings info.
        return $this->_getSettingsDisplayData(0,$input['configuration']);
    }
    
    /**
    * @Description  function used to get the itinerary info based on the travel mode.
    * @param array,string|$input,$buttonStatus
    * @return string|$_SmailContent
    * @date|12.03.2018
    * @author|Karthika.M
    */
    public function _callingItineraryBasedTravelMode($input,$renderDiv = 'Y',$buttonStatus = 'N'){
        
        //get the travel mode name without hite spaces preg_replace
        $travelModeName = preg_replace('/\s+/','',$this->_OcommonDBO->_select('dm_travel_mode', 'travel_mode', 'travel_mode_id', $this->_OcommonDBO->_select('fact_booking_details', 'travel_mode', 'r_order_id', $input['orderId'])[0]['travel_mode'])[0]['travel_mode']);
        
        //get function name based on the travel mode.
        $travelModeName = ($travelModeName == 'InternationalAir') ? 'DomesticAir' : $travelModeName;
        
        //dynamic class name formation based on travel mode and creat object        
        $classname = 'common'.$travelModeName.'ItineraryDisplay';
        $this->objClass = common::_checkClassExistsInNameSpace($classname);
        
        //dynamic method name based on travel maode name        
        $methodName = '_get'.$travelModeName.'ItineraryInfo';
        
        //call the class function to initiate the call_user_func with parameter     
        $this->_AtwigOutputArray = call_user_func( array($this->objClass, $methodName),$input);
        
        //call send mail function  if the $this->_AtwigOutputArray is grater than 0
        if(count($this->_AtwigOutputArray > 0) && $renderDiv == 'Y'){   
            
            //set button status
            $this->_AtwigOutputArray['showButton'] = $buttonStatus;
            
            //set template name based on the travel mode.
            $tplName = lcfirst($travelModeName).'MailItinerary.tpl';
            $_SmailContent = $this->_Otwig->render($tplName, $this->_AtwigOutputArray);
            return $_SmailContent;
        }
        return $this->_AtwigOutputArray;
    }
    
    /*
    * @Description  this function is used to get the automation retry count with respect to the order id.
    * @param array | $input 
    * @return array |$result
    */
    public function _retryBookingAutomation($input){
        
        global $CFG;
        
        $this->_Opackage = new package();
        $this->_Osync = new sync();     
        
        //booking status.
        $tickettedStatus = array(8,10,11,12,13,14);       
       
        //get order info.
        $orderInfo = $this->_Opackage->_getOrderCorporateInfo($input['orderId'])[0];
        
        //get automation retry count.        
        $automationRetryCount = $this->_OcommonDBO->_select('automation_retry_status','*','r_order_id',$input['orderId'])[0]['automation_retry_count'];
       
        //checking the ticket status id
        if(in_array($orderInfo['r_ticket_status_id'],$tickettedStatus)){
            return array("status" => "FAILURE","responseCode" => "1","message" => "Booking has already ticketed");
        }   
        else if($automationRetryCount && ($automationRetryCount) > 0){
            return array("status" => "FAILURE","responseCode" => "1","message" => "This booking has already been tried for ticket booking.");
        }
        else{
            //update the automation retry status.
            $retryInfo['r_order_id'] =  $orderInfo['order_id'];
            $retryInfo['automation_retry_count'] = 1;
            $retryInfo['automation_retried_by'] = $input['employeeId'];
            $retryInfo['created_date'] = $CFG['created_date'];
            $retryInfo['updated_date'] = $CFG['created_date'];
            $automationRetryId = $this->_OcommonDBO->_insert('automation_retry_status',$retryInfo);
            
            if($automationRetryId != 0){
                //form input to trigger the automation process.
                $data['retryAutomationFailure']['requestInfo']['syncOrderId'] = $orderInfo['sync_order_id'];
                $data['retryAutomationFailure']['requestInfo']['orderId'] = $orderInfo['order_id'];
                $data['retryAutomationFailure']['requestInfo']['retryAutomationType'] = 'userRetry';
                $data['retryAutomationFailure']['requestInfo']['retryAutomation'] = 'Booking';
                $data['retryAutomationFailure']['requestInfo']['retryPersonMailId'] = $input['emailId']; 
                $data['corporateId'] = $orderInfo['r_corporate_id'];
                $data['syncCorporateId'] = $orderInfo['sync_corporate_id'];        
                $returnresponse = $this->_Osync->_retryAutomation($data,'retryAutomationFailure',$orderInfo['agency_id']); 
                if($returnresponse['status'] == 'SUCCESS' && $returnresponse['responseData']['status'] == 'FAILURE' ){
                    return array("status" => "FAILURE","responseCode" => "1","message" => "There is an issue while processing your request. Please contact our help desk for details. Regret inconvenience caused.");
                }else{
                    return array("status" => "SUCCESS","responseCode" => "1","message" => $returnresponse['responseData']['message']);
                }
            }
            else{
                return array("status" => "FAILURE","responseCode" => "1","message" => "This booking has already been tried for ticket booking.");
            }
        }
    }
  
    /*
    * @Description  this function is used to get booking reference prefix string
    * @param int | $corporateId 
    * @return string |$booking_reference_prefix
    */
    public function _getBookingReferencePrefixSting($corpId='') {
     $corporateId = $corpId =='' ? $_SESSION['corporateId'] : $corpId;
      $sql = "SELECT DISTINCT da.booking_reference_prefix 
                FROM   dm_corporate dc 
                       INNER JOIN agency_corporate_mapping acm 
                               ON dc.corporate_id = acm.corporate_id 
                       INNER JOIN dm_agency da 
                               ON acm.agency_id = da.dm_agency_id 
                WHERE  acm.corporate_id =".$corporateId.
                " LIMIT  1";
        $result = $this->_OcommonDBO->_getResult($sql)[0]['booking_reference_prefix'];
        return $result;
    }
    
    /*
    * @Description  this function is used to get booking reference prefix string based on order details
    * @param int | $orderId 
    * @return string |$booking_reference_prefix
    */
    public function _getBookingReferencePrefixStingBasedOnOrder($orderId){
        if(isset($orderId) && !empty($orderId)){
            $_NagencyId = $this->_OcommonDBO->_select('booking_history','r_agency_id', 'order_id', $orderId)[0]['r_agency_id'];
            $bookingReferencePrefix = $this->_OcommonDBO->_select('dm_agency','booking_reference_prefix', 'dm_agency_id', $_NagencyId)[0]['booking_reference_prefix'];
        }
        else {
            $bookingReferencePrefix ='';
        }   
        return $bookingReferencePrefix;
    }
    
    /*
    * @Description  this function is used to get booking info
    * @param int | $orderId 
    * @return array
    */
    public function _getOrderAgencyInfo($orderId){
        
        $sql = "SELECT bh.*,da.* 
                FROM
                    booking_history bh
                    INNER JOIN dm_agency da ON bh.r_agency_id = da.dm_agency_id
                WHERE bh.order_id = ".$orderId;
        
        return $this->_OcommonDBO->_getResult($sql); 
    }
    
    /*
    * @Description  this function is used to get booking info
    * @param int | $orderId 
    * @return array
    */
    public function _orderMailInfo($orderId){
        
        $_Oairline = new airline();
        $_Oemployee = new employee();
        
        $mailInfo = array();
        
        //get sector info.
        $bookingInfo  = $this->_getOrderAgencyInfo($orderId)[0];
        
        //set trip type
        $tripType =  ($bookingInfo['trip_type'] == 1) ? '0,1' : '0';
        
        //set inputs
        $mailInfo['sector'] = ($bookingInfo['trip_type'] == 1) ? $bookingInfo['sector_from'].'-'.$bookingInfo['sector_to'].'-'.$bookingInfo['sector_from'] :  $bookingInfo['sector_from'].'-'.$bookingInfo['sector_to'];
        $mailInfo['booking_id'] = $bookingInfo['booking_reference_prefix'].$orderId;
        $mailInfo['sender']  = $bookingInfo['agency_name'];
        $mailInfo['departureDate']  = $bookingInfo['onward_depature_date'];
        $mailInfo['requestDate']  = $bookingInfo['request_date'];
        $mailInfo['bookingPerson']  = $_Oemployee->_getRequestByInfo($orderId)['employee_name'];
        
        //get airline info
        $mailInfo['airline']  = $_Oairline->_getAllAirline($orderId,$tripType);
        return $mailInfo;
    }
    
    /*
    * @Description  this function is used to approver name for the order 
    * @param int | $orderId 
    * @return array
    */
    public function _getApproverNameForOrder($orderId){
        
        $sql = "SELECT 
                    od.approver_account_id,
                    CONCAT(title, '.', first_name, last_name) as approverName 
                FROM 
                    order_details od 
                    INNER JOIN dm_employee de ON employee_id = od.approver_account_id
                    WHERE od.order_id = ".$orderId;        
        return $this->_OcommonDBO->_getResult($sql);
    }
    
    /*
    * @Description  this function is used to get the travel mode based on the corporate application settings.
    * @return array
    */
    public function _getTravelModes(){
        
        $this->_CcorporateCustomization = new corporateCustomization();

        // get travel type enabled for corporate
        $travelMode = $this->_CcorporateCustomization->_getCorporateEnabledTravleModesList($this->_CcorporateCustomization->_getCorporateEnabledTravleModes('TRAVEL_MODES'));
        
        //including All Travel Modes
        $allTravelMode[]  = array('travel_mode_id' => 7, 'travel_mode' => 'All');
        $travelMode = array_merge($allTravelMode, $travelMode);
        return $travelMode;        
    }

    /*
    * @Description function used to set the reload to view travel request for iocl corporate
    */
    public function _getCorporateFlag(){
        return $corporate = 'N';   
    }     

    /*
    * @Description  This function is used to get the booking type with respect to the corporate id.
    * @return array
    */
    public function _getCorporateEnabledType($corporateId){

        $bookingType = array();

        //get corporate info
        $corporateInfo = $this->_OcommonDBO->_select('sync_corporate_details','booking_mode','r_corporate_id',$corporateId);

        $bookingModeInfo = array_column($corporateInfo,'booking_mode');

        $bookingModeInfo = array_values(array_unique($bookingModeInfo));

        foreach($bookingModeInfo as $key => $value){
            if($value == 1){
                $bookingType[$key]['booking_type'] = 'Corporate';
            }
            else{
                $bookingType[$key]['booking_type'] = 'Personal';   
            }
        }
        return $bookingType;
    }


    public function _setCabinClass($cabinClass){
        return array(0=>$cabinClass);
    }

    public function _sendMailRequestPerson($orderId,$message){
        $this->_OflightItinerary = new flightItinerary();
        $result = $this->_OflightItinerary->_getApporvedFareCheck($orderId);
            if($result){
                $twigOutputArray['message'] = $message;
                $twigOutputArray['paxName'] = $result[0]['name'];
                $twigOutputArray['mailSignature'] = EMAIL_SIGNATURE; 
                $this->_Otwig = init(); 
                
                //render the tpl for mail content.
                $_SmailContent = $this->_Otwig->render('approverFareCheckError.tpl',$twigOutputArray);
               
                //sending the mail.
                if($result[0]['requested_by'] != ''){
                    $subject ="Fare Check Error While Approve - For the Booking Id : ".$orderId;
                    $sendMailResponse[] = $this->_ObjcommonMethods->_sendMail($result[0]['requested_by'],'support@atyourprice.in',$subject ,$_SmailContent,'','',BALMER_MAIL_REQUEST_BCC_PASSENGER);
                }
            }
        return true;
    }

   
}