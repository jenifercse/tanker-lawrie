<?php
/* * **************************************************************************
 * @File             : class.cancellationdetails.php
 * @Description      : This file is used to insert,update,delete and get trans_cancellation,cancellation_details
 * @dimensionTables  : trans_cancellation,cancellation_details
 * @Author           : Muthukumar
 * @Created Date     : 23/08/2016
 * @Modified Date     : 
 * ****************************************************************************/
fileRequire('classes/class.commonDBO.php');
class cancellationdetails{
    
   private $_OcommonDBO;
    
   public function __construct() {
       $this->_OcommonDBO=new commonDBO();
       $cancellationDetails=array();
   }
   
   /**
     * @Description :This function is used to insert the trans_cancellation. 
     * @param :array   | $cancellationDetails - holds array of cancellation details
     * @return integer |$resultCancellationId - inserted cancellation Id
     */
   public function _insertCancellationMainDetails($cancellationDetails){
        $tableName  = 'trans_cancellation';
        $resultCancellationId  = $this->_OcommonDBO->_insert($tableName, $cancellationDetails);        
        return $resultCancellationId ;
   }
   
   
  
   /**
     * @Description :This function is used to insert the cancellation other details 
     * @param :array   | $cancellationOtherDetails - holds array of cancellation_details
     * @return integer |$resultCancellationId - inserted cancellation Id
     */
   public function _insertCancellationOtherDetails($cancellationOtherDetails){
        $tableName        = 'cancellation_details';
        $resultPassengerId  = $this->_OcommonDBO->_insert($tableName, $cancellationOtherDetails);       
        return $resultPassengerId ;
   }
   
   
   /**
     * @Description :This function is used to get the count of cancelled room of order id
     * @param :int   | $orderId - order id
     * @return int | cancellation details id count
     */
   public function _getCancellationDetailsCount($orderId){
   
       $sql = "SELECT 
                    count(cd.cancellation_details_id) as count
               FROM 
                    cancellation_details cd
                    INNER JOIN trans_cancellation tc ON cd.r_cancellation_id = tc.cancellation_id
               WHERE 
                    r_order_id = '$orderId'";
       
       $result = $this->_OcommonDBO->_getResult($sql);
       
       if($result  != "")
        {
            return $result[0]['count'];
        }
   }
   
   public function _fetchCancellationDetails($orderId){
			/*Fetch cancellation details */
			$_Ssql = "SELECT 
                                                        tc.cancellation_id,
							tc.r_travel_mode_id,
                                                        tc.comments,
                                                        tc.cancel_date,
                                                        tc.r_order_id,
                                                        cd.r_passenger_id,
							cd.reference_id,
                                                        od.order_id,
                                                        od.sync_order_id as sync,
                                                        hgrm.sync_room_id as roomId,
                                                        fbd.r_package_id as packageId
					  FROM
					  		cancellation_details cd,
					  		trans_cancellation tc,
                                                        hotel_guest_room_mapping hgrm,
                                                        order_details od,
                                                        fact_booking_details fbd
					  WHERE
					   		tc.cancellation_id = cd.r_cancellation_id
                                                        AND fbd.r_order_id = od.order_id
                                                        AND hgrm.hotel_guest_mapping_id = cd.reference_id
                                                        AND tc.r_order_id = od.order_id
					   		AND od.order_id = ".$orderId;
			$_Aresult = $this->_OcommonDBO->_getResult($_Ssql);
			return $_Aresult;
    }
    
     /*
    This method updates the cancel status in cancellation details.
    */
    public function _updateSyncCancellaionDetails($cancellationDetails)
    {
            $_Ssql = "UPDATE cancellation_details cd,trans_cancellation tc
                             SET cd.r_cancel_status_id = ".CANCELLATION_DETAILS_CANCELLED.",
                                 cd.penalty_charge = ".$cancellationDetails['cancel_penalty'].",
                                 cd.refund_amount = ".$cancellationDetails['refund_amount']."
                         WHERE
                                cd.r_cancellation_id = tc.cancellation_id
                                AND tc.sync_cancellation_id = ".$cancellationDetails['cancellation_id'];

            $this->_OcommonDBO->_getResult($_Ssql);	
    }
    
     /*
    This method updates the cancel status in hotel guest room mapping.
    */
    public function _updateSyncRoomStatus($cancellationId)
    {
            $_Ssql = "UPDATE cancellation_details cd,hotel_guest_room_mapping hgrm
                             SET hgrm.r_status_id = ".CANCELLED."
                         WHERE
                                hgrm.hotel_guest_mapping_id = cd.reference_id
                                AND hgrm.r_status_id = ".PASSENGER_VIA_DETAILS_CANCEL_REQUESTED." 
                                AND cd.r_cancellation_id = ".$cancellationId;

            $this->_OcommonDBO->_getResult($_Ssql);	
    }
    
    public function _getCancellationPassengerDetails($orderId) {
        
        $cancelArray = false;
        
        if($orderId !='') {
            
            $sql = "SELECT ds.status_value, CONCAT(p.title, '. ',p.first_name, ' ',p.last_name) as passenger_name, pv.r_passenger_id, tc.comments, tc.cancel_date, vf.trip_type 
                    FROM trans_cancellation tc JOIN cancellation_details cd ON tc.cancellation_id = cd.r_cancellation_id 
                    INNER JOIN via_flight_details vf ON cd.reference_id = vf.via_flight_id
                    INNER JOIN passenger_via_details pv ON vf.via_flight_id = pv.r_via_flight_id
                    INNER JOIN passenger_details p ON p.passenger_id = pv.r_passenger_id
                    INNER JOIN dm_status ds ON cd.r_cancel_status_id = ds.status_id
                    WHERE tc.r_order_id = ".$orderId." AND pv.r_booking_status_id !=".NOTHING_REQUESTED."";
            $result = $this->_OcommonDBO->_getResult($sql);	

            /*foreach($result as $res) {
                
                if($res['trip_type'] == 0) {
                    $cancelArray[$res['r_passenger_id']]['onward_passenger_name']   = $res['passenger_name'];
                    $cancelArray[$res['r_passenger_id']]['onward_passenger_id']     = $res['r_passenger_id']; 
                    $cancelArray[$res['r_passenger_id']]['onward_comments']         = $res['comments']; 
                    $cancelArray[$res['r_passenger_id']]['onward_cancel_date']      = $res['cancel_date'];
                } else {
                    $cancelArray[$res['r_passenger_id']]['return_passenger_name']   = $res['passenger_name'];
                    $cancelArray[$res['r_passenger_id']]['return_passenger_id']     = $res['r_passenger_id']; 
                    $cancelArray[$res['r_passenger_id']]['return_comments']         = $res['comments']; 
                    $cancelArray[$res['r_passenger_id']]['return_cancel_date']      = $res['cancel_date'];
                }
                
            }*/
            
        }
        
        return $result;
        
    }
}
?>