<?php
/* * **********************************************************************
 * @Class Name	: createProfile
 * @Created on	: 2016-06-06
 * @Created By	: Thirumal
 * @Updated By  : --
 * @Update Info : -- 
 * @Description	: This class will do all insert edit update functionlity of employee profile
 * ************************************************************************ */
//fileRequire("/services/wrapper.php");
class createProfile{
    public $_action='create';//create view by default
    public $_Oemployee='';
    public $_OcorporateSettings='';
    public $_OcommonFunctions='';
    public $_OapplicationSettings='';
    public $_AtwigOutputArray=array();
    public $_Oconnection='';
    public $_empArray=array();
    public $_IemployeeId=0;
    //Response array 
    public $_AfinalResponse=array('status'=>0,'status_message'=>'success','error_alert'=>'');
             
    //constructor 
    function __construct() {
       $this->_Oemployee = new employee();
       $this->_OcorporateSettings = new corporateSettings();
       $this->_OcommonArrayFunctions = new commonArrayFunctions();
       $this->_OapplicationSettings = new applicationSettings();
    }
    //Method to call current class methods
     public function _getDisplayInfo(){

         //echo '<pre>'; print_r($this->_IinputData); exit;
         
         $this->_action = isset($this->_IinputData['action'])? $this->_IinputData['action'] : 'create';
         $modeType = isset($this->_IinputData['mode'])? $this->_IinputData['mode'] : '';
         $this->_IemployeeId = isset($this->_IinputData['employeeId'])?$this->_IinputData['employeeId']:0;
         
         switch($this->_action){
             
             case 'create'://Create Profile
                 $this->_displayEmployeeProfile();
                 $this->_getApproverList();
                 break;
             
             case 'insert'://Insert Profile
                 $this->_insertEmployeeInfo($modeType);
                 $this->_displayEmployeeProfile();
                 break;
             
             case 'edit'://Edit Profile
                 $this->_getApproverList($this->_IemployeeId);
                 $this->_editEmployeeInfo($this->_IemployeeId,$modeType);
             
                 break;
             
             case 'addapproval'://add new approval
                 $this->_insertApprover($this->_IemployeeId);
                 $this->_getApproverList($this->_IemployeeId);
                 $this->_editEmployeeInfo($this->_IemployeeId,$modeType);
                 break;
             
             case 'listapproval':
                 $this->_getApproverList();
                 break;
             
             case 'search_employee': //search employee
                 $ajaxResult = $this->_searchemployee();
                 break;
             
             case 'deleteapprover':
                 $this->_deleteApprover();
                 $this->_getApproverList($this->_IemployeeId);
                 $this->_displayEmployeeProfile();
                 break;
         }
         
         //Call to template assign method
         if(!isset($this->_IinputData['ajaxMethodName'])) {
            $this->_templateAssign();
         } else {
             return $ajaxResult;
         }
     }
     
      /**
      * @description : insert approver details to table
      * @param int|$employeeId
      * @return 
      */
     private function _insertApprover($employeeId='') {
         $this->_approval = new approval();
         $this->_approval->_IinputData = $this->_IinputData;
         $this->_approval->_Otwig      = $this->_Otwig;
         $this->_approval->_saveApprover($employeeId);
         
         //to dispaly already availbale list of approvers
         $approvalListArray = $this->_approval->_getApproverList();
         $this->_AtwigOutputArray['approvalListArray'] = $approvalListArray;
             
         if(isset($this->_approval->_ATwigAlertOutput))
         {
           $this->_ATwigAlertOutput = $this->_approval->_ATwigAlertOutput;
         }
        
         $this->_AfinalResponse = $this->_approval->_AfinalResponse;

         return;
     }
     
      /**
      * @description : delete approver details to table
      * @param 
      * @return int|$returnValue
      */
     private function _deleteApprover() {
         $this->_approval = new approval();
         $this->_approval->_IinputData = $this->_IinputData;
         $returnValue = $this->_approval->_deleteApprover();
         
         //to dispaly already availbale list of approvers
         $approvalListArray = $this->_approval->_getApproverList();
         $this->_AtwigOutputArray['approvalListArray'] = $approvalListArray;
         
         return $returnValue;
     }
     
      /**
      * @description : get the list of approver avialble for an employee
      * @param int|$employeeId
      * @return 
      */
     private function _getApproverList($employeeId = '') {
         
         $this->_approval = new approval();
         $this->_approval->_IinputData = $this->_IinputData;
         $approvalListArray = $this->_approval->_getApproverList($employeeId);
         $this->_AtwigOutputArray['approvalListArray'] = $approvalListArray;
     }
     
     /**
      * @description : search employee by email id
      * @param 
      * @return array|$returnValue
      */
      private function _searchemployee() {
          
         $this->_Oemployee->_IinputData = $this->_IinputData; 
         $returnValue = $this->_Oemployee->_searchEmployee();
         return $returnValue;
     }
     
     /**
      * @description : get employee information based on the mode
      * @param int|$empId
      * @param string $mode holds the profile mode to be edited,by default if will fetch all the informations
      */
     private function _editEmployeeInfo($empId=0,$mode=''){
        $this->_displayEmployeeProfile();
        //Assign the employeeId for hidden variable, used for insertion purpose
        $this->_AtwigOutputArray['employeeId']=$empId;
        $this->_AtwigOutputArray['empPreference'] = $this->_Oemployee->_getEmployeePreferences($empId);
        $this->_AtwigOutputArray['empProfile']    = $this->_Oemployee->_getEmployeeInfo($empId);
        $this->_AtwigOutputArray['empPassport']   = $this->_Oemployee->_getPassportInfo($empId);
        $this->_AtwigOutputArray['empProfile']['eventTypeStatus']  = $this->_Oemployee->_employeeEventTypeMapping($empId,'CALENDAR_EVENT',1);
        $this->_AtwigOutputArray['empVisa']       = $this->_Oemployee->_getVisaInfo($empId);
        
        //values assigned empty for edit view, to avoid the angular to assign a default empty option in select element
             
        if($this->_AtwigOutputArray['empProfile']['r_cost_center_code_id']==0){
            $this->_AtwigOutputArray['empProfile']['r_cost_center_code_id']='';
        }
        
        if($this->_AtwigOutputArray['empProfile']['r_billto_id']==0){
           
            $this->_AtwigOutputArray['empProfile']['r_billto_id']='';
        }
        if($this->_AtwigOutputArray['empProfile']['r_band_id']==0){
            
            $this->_AtwigOutputArray['empProfile']['r_band_id']='';
        }
        if($this->_AtwigOutputArray['empProfile']['r_user_type_id']==0){
            
            $this->_AtwigOutputArray['empProfile']['r_user_type_id']='';
        }
        if($this->_AtwigOutputArray['empPreference'][0]['seat_preference']==''){
            
            $this->_AtwigOutputArray['empPreference'][0]['seat_preference']='';
        }
        if($this->_AtwigOutputArray['empPreference'][0]['r_meal_id']==0){
            
            $this->_AtwigOutputArray['empPreference'][0]['r_meal_id']='';
        }
     }
     /**
      * @description : to get all default profile related master informations
      */
     private function _displayEmployeeProfile(){
         
        //get country list for visa details country from table
        $this->_AtwigOutputArray['titleArray']= $this->_OcommonArrayFunctions->_arrayCombine(explode(',', TITLE)); 
        $this->_AtwigOutputArray['seatPreferenceArray']=$this->_OcommonArrayFunctions->_arrayCombine(explode(',', EMPLOYEE_PREFERENCE)); 
        $this->_AtwigOutputArray['carTypeArray']=$this->_OcommonArrayFunctions->_arrayCombine(explode(',', EMP_FREQUENT_CARDTYPE)); 
        
        //build params as array to pass through function 
        $params = array('userTypeArray'       => array($this->_OapplicationSettings, '_getUserTypes','user_type_id', 'user_type_name'), 
                        'mealTypeArray'       => array($this->_OapplicationSettings, '_getMealCodeDetails', 'meal_code_id','meal_description'),
                        'costCenterCodeArray' => array($this->_OapplicationSettings,'_getCostCenterCode', 'category_value_id','category_value', $_SESSION['corporateId']),
                        'bandArray'           => array($this->_OcorporateSettings,'_getBandDetails', 'band_id', 'band_name', $_SESSION['corporateId']),
                        'billToArray'         => array($this->_OcorporateSettings,'_getBillToMapping', 'billto_id', 'billto_name', $_SESSION['corporateId'],'','','Y'),
                        'airlineNameArray'    => array($this->_OapplicationSettings,'_getAirlineDetails', 'airline_id', 'airline_name', 'L', array('airline_id','airline_name')),
                        'countryDetailsArray' => array($this->_OapplicationSettings, '_getCountryDetails', 'country_id', 'country_name'));
        
        $this->_getTwigArrayParams($params);
     }
     
    /**
      * @description : to get all the user types master info using call user func array
      */
     private function _getTwigArrayParams($parms){

         foreach($parms as $key=>$val){
            $funcParams = array_slice($val, 4);
            $result     = call_user_func_array(array($val[0], $val[1]), $funcParams);

            if(is_array($result)){
                $this->_AtwigOutputArray[$key] = $this->_OcommonArrayFunctions->_getMultiDimenKeyValues($result, $val[2], $val[3]);
            }
         }
     }
     
     /**
      * @description : method to insert employee profile details
      * @param type $mode
      * @return boolean
      */
     private  function _insertEmployeeInfo($mode){
         
          //Check for the mode of the profile to be inserted
          switch ($mode){
             case 'preference':
                    $prefData=  json_decode($this->_IinputData['preferences'],true);
                     
                    if($this->_IemployeeId!=0){
                        $this->_AfinalResponse['employeeId']= $this->_IemployeeId;
                        $response = $this->_Oemployee->_pushEmployeePreferences($this->_IemployeeId,$prefData['preferences']);
                        
                        if(!$response){
                            
                             $this->_setResponseMessage(1,'Something went wrong');
                             
                        }else{
                            
                            $result = $this->_Oemployee->_pushEmployeeDetailsData($this->_IemployeeId,$this->_IinputData['prefValue']);
                           
                            if(!$result){
                                
                                $this->_setResponseMessage(1,'Something went wrong');
                                
                            }else{
                                
                                $this->_setResponseMessage(3,'Preference Updated Successfully');
                            }
                        }
                       
                    }else{
                        $this->_setResponseMessage(1,'Something went wrong');
                    }
                    
                 break;
                 
             case 'passport':
                    
                    $empId = isset($this->_IinputData['passportInfo']['r_employee_id'])?$this->_IinputData['passportInfo']['r_employee_id']:0;
                    if($empId!=0){
                        $this->_AfinalResponse['employeeId']= $empId;
                        $result = $this->_Oemployee->_pushPassportInfo($empId,$this->_IinputData['passportInfo']);
                        
                        if(!$result){
                            
                            $this->_setResponseMessage(1,'Something went wrong');

                        }else{
                            
                            $result = $this->_Oemployee->_pushEmployeeDetailsData($empId,$this->_IinputData['uploadFiles']);
                            
                            if(!$result){
                                
                                $this->_setResponseMessage(1,'Something went wrong');
                                
                            }else{
                                
                                $this->_setResponseMessage(3,'Passport updated successfully');
                                
                            }
                        }
                    }
                    $this->_setResponseMessage(3,'Passport Updated Successfully');
                 break;
                 
             case 'profile':
                    //To get create or update status
             
                    $response = $this->_Oemployee->_pushEmployeeInfo($this->_IemployeeId, $this->_IinputData['empMasterInfo'],$this->_IinputData['empDetailsInfo'],$this->_IinputData['userTypeId']);
                    //set employee id in response message
                 
                    if($response===2){
                        
                        $this->_setResponseMessage(1,'Email id already exists');
                        $this->_AfinalResponse['employeeId']=0;
                        return;
                    }
                    if(!$response){
                        $this->_setResponseMessage(1,'Something went wrong..');
                         
                    }else{
                            $result= $this->_Oemployee->_employeeEventTypeMapping($this->_Oemployee->_IemployeeId,'CALENDAR_EVENT',0,$this->_IinputData['empEventStatus']);
             
                            if($result){
                                
                                if($this->_IemployeeId!=0){
                                    
                                    $this->_setResponseMessage(3,'Profile Updated Successfully');
                                    
                                }else{
                                    
                                    $this->_setResponseMessage(3,'Profile Created Successfully');
                                }
                                
                            } else {
                                $this->_setResponseMessage(1,'Something went wrong');
                            }
                            
                    }
                    //To set the created / updated employee id to the scope variable
                    $this->_AfinalResponse['employeeId'] = ($this->_IemployeeId!=0)?$this->_IemployeeId:$this->_Oemployee->_IemployeeId;
             
                 break;
                 
             case 'saveVisaDetails' :
                 
                 $response = $this->_Oemployee->_pushVisaInfo($this->_IemployeeId, $this->_IinputData);
                 
                 if($response > 0) {
                      $this->_setResponseMessage(3,'Visa Details updated Successfully');
                 } else {
                      $this->_setResponseMessage(1,'Something went wrong');
                 }
                 
                 break;
         }
     }
     
     /**
      * @description : method to set response code and message
      */
     private function _setResponseMessage($code,$message){
         $this->_AfinalResponse['status']=$code;
         $this->_AfinalResponse['error_alert']=$message;
     }

     /**
      * @description to get the billto mapping address
      */ 
     private function _templateAssign(){
        $this->_AtwigOutputArray['action'] = $this->_action;
        $this->_AtwigOutputArray['moduleName'] = $this->_SmoduleName;
    }
}
?>