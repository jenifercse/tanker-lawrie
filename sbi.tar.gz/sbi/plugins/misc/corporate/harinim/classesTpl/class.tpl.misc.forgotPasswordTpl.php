<?php

/*
 * @fileName    :   forgot.......php
 * @description :   To handle forgot ...... requests
 * @author      :   Mercy Chrysolite
 * @createdDate :   6 June, 2016
 */
pluginFileRequire('misc/corporate/harinim/', 'classes/class.login.php');
fileRequire("lib/common/commonMethods.php");
fileRequire("classes/class.sync.php");

class forgotPasswordTpl {

    var $_Aresponse;

    public function __construct() {
        
    }

    /*
     * @functionName    :   _callAjaxFunction()
     * @description     :   default ajax method
     */

    public function _getDisplayInfo(){

        $this->_OcommonMethods = new commonMethods();
        //loginEmail will be set when forgot ...... request is raised
        if($this->_IinputData['action'] == "forgotPassword") {
            //Calling function to verfiy user
            $this->_verifyUser();
            if ($this->_SuserExists['valid']) {
                //Sending credentials in mail
                $this->_sendLinkMail();
                $this->_AfinalResponse['alert'] = 'A reset link has been sent to your registered email id. Kindly use the link to set a new password.';
                $this->_AfinalResponse['status'] = true;
            }
            else if(isset($this->_SuserExists['isTravelAdmin']) && $this->_SuserExists['isTravelAdmin'] == 'Y'){
                $this->_AfinalResponse['alert'] = 'Please use travel agency login to reset the password.';
                $this->_AfinalResponse['status'] = false;
            }
            else{
                $this->_AfinalResponse['alert'] = 'The given email id does not exist in our system. Please check the email id you have entered.';
                $this->_AfinalResponse['status'] = false;
            }
        } 
        elseif ($this->_IinputData['action'] == "resetPassword"){//user will be set when new ........ is submitted       
            //validating csrf token with current session csrf token.
            // if($_SESSION['csrf_token']['forgotPwd'] != $this->_IinputData['forgotPwdCSRF']){
            //     $this->_AfinalResponse['status'] = 0;
            //     $this->_AfinalResponse['message'] = "Unauthorized request";
            //     return false;
            // }     
            $checkPasswordExit = $this->_checkUpdatePassword();            
            if($checkPasswordExit){
                //Calling function to update .....
                $success = $this->_updatePassword();
            } 
            else{
                $this->_AfinalResponse['status'] = 0;
                $this->_AfinalResponse['message'] = "Your old passwords are not allowed";
                return false;
            }
            if($success){
                $this->_userPasswordHistory();   
                //set email id
                $this->_SuserExists['details']['email_id'] = explode("$$", base64_decode($this->_IinputData['user']))[1];

                $this->_sendNewPasswordMail();
                unset($_SESSION['csrf_token']['forgotPwd']);
            }
        }
        elseif($this->_IinputData['action'] == "verifyOtp"){

            return $this->_verifyUserOtp();

        }
        elseif($this->_IinputData['action'] == "captchacode"){

                $validCaptchaInfo=$this->_captchaCodeValidate();
                  $this->_AfinalResponse['message'] = $validCaptchaInfo;
        }
        elseif($this->_IinputData['action'] == "resendOTP"){

            return $this->_resendOtpToUser();
        }elseif($this->_IinputData['action'] == "validateData"){
            $this->_AfinalResponse['errorMessage'] = '';
            $this->_AfinalResponse['message'] =$this->_checkEmployeeCodeExist($this->_IinputData);
            $this->_AfinalResponse['status'] =  $this->_AfinalResponse['message'] ? true : false;
            if($this->_AfinalResponse['status']){
                
                $this->_IinputData['loginEmail'] = substr(trim($this->_IinputData['loginEmail']),0,3) == 'IOC' ? substr(trim($this->_IinputData['loginEmail']),3) : $this->_IinputData['loginEmail'];
                $this->_Ologin = new login();
                $checkStatus  = $this->_Ologin->_checkEmployeeSapStatus($this->_IinputData['loginEmail']);
                $this->_AfinalResponse['errorMessage']  = $checkStatus ? true : "As your status is inactive, you aren't allowed to access the SBT application";
                $this->_AfinalResponse['status'] = $checkStatus ? true : false;
            }
            return true ;
        }
        elseif($this->_IinputData['action'] == "updateMailandSendforgotPassword"){
            $this->_AfinalResponse['message'] =$this->_updateMailandSendPassword($this->_IinputData);
            return true ;
        }
    }

    /*
     * @functionName    :   _sendMail()
     * @description     :   method to send mail credentials
     */

    protected function _sendLinkMail(){
        if($this->_IinputData['noMail']){
            $this->_sendPasswordLink();
        }else{
            $this->_sendCredentials();
        }
    }

     /*
     * @functionName    :   _sendPasswordLink()
     * @description     :   method to _sendPasswordLink
     */
    public function _sendPasswordLink(){
        // check employe corporate check 
        $resultFlag = $this->_checkEmployeeCorporate($this->_IinputData['loginEmail']);
        if($resultFlag){
            $this->_sendCredentials();
        }else{
            $returnData = $this->_commonInsertForgorPassword();
            $this->_AtwigOutputArray['message'] = " Dear ".$userName.",<br> We have received a forgot password request. Please click <a href='".HTTP_TYPE.$_SERVER['HTTP_HOST'] . "/forgotPassword.php?user=" . $returnData[0] . "'>here</a> to reset your password<br><br>Regards,<br>".EMAIL_SIGNATURE;
            $this->_AtwigOutputArray['host'] =  HOST_URL;
            $message = $this->_Otwig->render('mailLayout.tpl', $this->_AtwigOutputArray);
            $this->_Omail = new commonMethods();
            $this->_Omail->_sendMail($this->_SuserExists['details']['email_id'], 'support@atyourprice.in', $returnData[1], $message);
        }
    }
     /*
     * @functionName    :   _commonInsertForgorPassword()
     * @description     :   method to _commonInsertForgorPassword for user 
     */
    public function _commonInsertForgorPassword(){
        $_OcommonDBO = new commonDBO();
        $_Ocommon = new common();
        $subject = "Balmer lawrie : Forgot password";
        $text = $this->_SuserExists['details']['account_id'] . "$$" . $this->_SuserExists['details']['email_id'];
        $sql="SELECT max(link_id) 'Count' FROM forgot_password_link";
        $getLinkId=$_OcommonDBO->_getResult($sql)[0];
        $count= ($getLinkId!="") ? $getLinkId['Count']+1 : '';
        $randElement =$_Ocommon->_generateRandomString(7,'NUMBERS');
        $user = base64_encode($text."$$".$count."$$". $randElement);
        $userName = $this->_SuserExists['details']['title'].'.'.$this->_SuserExists['details']['first_name'].' '.$this->_SuserExists['details']['last_name'];
        $insertValues=array(
            'link_id'=>0,
            'r_employee_id'=>$this->_SuserExists['details']['r_employee_id'],
            'reset_link'=>$user,
            'updated_date'=>date('Y-m-d H:i:s'),
            'status'=>'Y'
        );
        $result= $_OcommonDBO->_insert('forgot_password_link', $insertValues);
        return array($user,$subject);
    }
    /*
     * @functionName    :   _send......Mail()
     * @description     :   method to send new mail credentials
     */

    protected function _sendNewPasswordMail() {
        $_OcommonDBO = new commonDBO();
        $subject = "Balmer lawrie : Login Credentials";
        $text = $this->_SuserExists['details']['account_id'] . "$$" . $this->_SuserExists['details']['email_id'];
        $user = base64_encode($text);
        $empName = $_OcommonDBO->_select('dm_employee','*','email_id',$this->_SuserExists['details']['email_id'])[0];
        $userName = $empName['title'].'.'.$empName['first_name'].' '.$empName['last_name'];
        $this->_AtwigOutputArray['message'] = " Dear ".$userName.",<br> Your password has been successfully reset.<br><br>Regards,<br>".EMAIL_SIGNATURE;
        $this->_AtwigOutputArray['host']    = HOST_URL;  
        $message = $this->_Otwig->render('mailLayout.tpl', $this->_AtwigOutputArray);
        $this->_Omail = new commonMethods();
        $this->_Omail->_sendMail($this->_SuserExists['details']['email_id'], 'support@atyourprice.in', $subject, $message);
    }

    /*
     * @functionName    :   _verifyUser()
     * @description     :   method to verfiy if given email is a valid user
     */

    protected function _verifyUser() {
        $this->_verify = new login();
        $this->_verify->_Oconnection = $this->_Oconnection;
        $this->_verify->_IinputData = $this->_IinputData;
        $this->_SuserExists = $this->_verify->_validateUserCredentials();
    }

    /*
     * @functionName    :   _update......()
     * @description     :   method to update ............ as given by user
     */

    protected function _updatePassword(){
        $this->_OcommonDBO = new commonDBO();
        $this->_OauthToken = new authToken();        
        $O_Agency = new agency();

        if($this->_IinputData['password'] != $this->_IinputData['checkPassword']) {
            $this->_AfinalResponse['status'] = 0;
            $this->_AfinalResponse['message'] = "The passwords which you have entered doesn’t match. Please enter the same password in both the fields.";
            return false;
        } 
        elseif(strlen($this->_IinputData['password']) < 8) {
            $this->_AfinalResponse['status'] = 0;
            $this->_AfinalResponse['message'] = "Password must be atleast 8 characters";
            return false;
        }

        $user = explode("$$", base64_decode($this->_IinputData['user']));

        $this->_Oemployee = new employee();
        $result = $this->_Oemployee->_getEmployeeInfo(0, $user[0]);
        //removes the unwanted symbols
        $user[1] = $this->_OauthToken->_purifyInputData($user[1]);
        
        $sql="SELECT * FROM forgot_password_link WHERE link_id=".$user[2];
        $resetLink=$this->_OcommonDBO->_getResult($sql)[0];
        if($resetLink['status']=='Y'){
            
            if ($result['email_id'] == $user[1]) {

        
            
                $_OcommonEncryptDecrypt = new commonEncryptDecrypt();
				$password =commonEncryptDecrypt::_encryptData($this->_IinputData['password']);
                $fieldArray = array(":pwd" => $password);

                $sql = "UPDATE dm_account da SET  da.login_password = :pwd, da.password_updated_date = NOW()
                        WHERE da.account_id = " . $user[0] . "";
                
                
                
                $update = $this->_OcommonDBO->tryCatchDBStmt($sql, 'update', $fieldArray);

                //$update = $this->_OcommonDBO->_update('dm_account',$fieldArray,'account_id',$user[0]);
                //getcorporate details
                $corporateDetArray = $O_Agency->_getAgencyCorporateList('', $result['r_corporate_id']);

                if($this->_IinputData['email'] !='' ){
                    $sql = "UPDATE dm_employee dme SET  dme.email_id = '".$this->_IinputData['email']."'
                        WHERE dme.employee_id = " . $result['employee_id'] . "";
                    $this->_OcommonDBO->_executeQuery($sql);
                }        

                //sync the update ...... with AYP side
                $_Osync = new sync();
                $_Osync->_syncUpdatedPassword($result['email_id'], $result['r_corporate_id'], $corporateDetArray[0]['sync_corporate_id'], $fieldArray['login_password'], $corporateDetArray[0]['agency_id']);

                if ($update !== false) {
                    $this->_AfinalResponse['status']  = 3;
                    $this->_AfinalResponse['message'] = "Password has been updated successfully!";
                    $sql="UPDATE forgot_password_link SET updated_date=now(),status='N' WHERE link_id=".$user[2];
                    $this->_OcommonDBO->_getResult($sql);
                    return true;
                }
            }
        }        

        $this->_AfinalResponse['status'] = 0;
        $this->_AfinalResponse['message'] = "Sorry! Already password reseted by this link.";
        return false;
    }

    /*
     * @functionName    :   _checkUpdate........()
     * @description     :   check whether updated ....... already exit
     */

    protected function _checkUpdatePassword() {

        //creating the object 
        $_OcommonDBO = new commonDBO();
        $_OcommonEncryptDecrypt = new commonEncryptDecrypt();

        $returnValue = TRUE;
        $user = explode("$$", base64_decode($this->_IinputData['user']));
        
        //query for checking the enter ..... already exit

        if ($user[0] > 0) {
            $sql = "SELECT * FROM user_password_details upd WHERE upd.r_account_id = " . $user[0] . " AND upd.login_password = " . "'" . commonEncryptDecrypt::_encryptData($this->_IinputData['password']) . "' ";
            
            $result = $_OcommonDBO->_getResult($sql);
        }
        if (!empty($result)) {
            $returnValue = FALSE;
        }
        return $returnValue;
    }

    /*
     * @functionName    :   _user.....History
     * @author          :   Deepak Pande
     * @description     :   To check whether the enter ...... is already exit
     * @params          :   -
     * @returnType      :   -
     */

    protected function _userPasswordHistory() {


        $_OcommonDBO = new commonDBO();
        //calling the function for getting the user account id
        $user = explode("$$", base64_decode($this->_IinputData['user']));
        if ($user[0] > 0) {

            $sql = "SELECT * FROM user_password_details upd WHERE upd.r_account_id = " . $user[0] . " ORDER BY upd.r_account_id ASC";
            $result = $_OcommonDBO->_getResult($sql);
            if (!empty($result) && count($result) == 4) {
                $deleteQuery = $_OcommonDBO->_delete('user_password_details', 'user_password_details_id', $result[0]['user_password_details_id']);
                if ($deleteQuery > 0) {
                    $this->_updateUserPasswordHistory();
                }
            } else {
                $this->_updateUserPasswordHistory();
            }
        }
    }

    /*
     * @functionName    :   _updateUser.........History
     * @author          :   Deepak Pande
     * @description     :   To update the user  ......... History
     * @params          :   -
     * @returnType      :   -
     */

    protected function _updateUserPasswordHistory() {

        $_OcommonEncryptDecrypt = new commonEncryptDecrypt();
        $_OcommonDBO = new commonDBO();
        $user = explode("$$", base64_decode($this->_IinputData['user']));
        if ($user[0] > 0) {
            $sql = "INSERT INTO user_password_details(`r_account_id`, `login_password`) "
                    . "VALUES (" . $user[0] . ",'" . commonEncryptDecrypt::_encryptData($this->_IinputData['password']) . "')";
            $result = $_OcommonDBO->_getResult($sql);
        }
        return $result;
    }
    //function to verify the user otp
    protected function _verifyUserOtp(){

        $_OcommonDBO = new commonDBO();
        $result = $this->_checkOtpStatus($this->_IinputData['employeeOTP'],$this->_IinputData['employeeId'],'Y')[0];
        if(isset($result)){
            if($this->_IinputData['smsFlow'] == "REG"){
                $currentDateTime = strtotime(date("d-m-Y H:i:s"));
                $otpGeneratedTime =strtotime($result['created_date']);
                $timeDiff = ($currentDateTime - $otpGeneratedTime)/(60);
                if($timeDiff > 10){
                    $returnArray = array('status' => 0, 'Message' => 'OTP Validity Expired!' );
                }else{
                    $this->_updateOtpExpire($this->_IinputData['employeeOTP'],$this->_IinputData['employeeId']);
                    $returnArray = array('status' => 3, 'Message' => 'OTP verify successfully!' );
                }
            }          
        }else{
            $checkExpire = $this->_checkOtpStatus($this->_IinputData['employeeOTP'],$this->_IinputData['employeeId'],'N')[0];
            if(isset($checkExpire)){
                $returnArray = array('status' => 0, 'Message' => 'OTP Expire!' );
            }
            else{
                $returnArray = array('status' => 0, 'Message' => 'Entered Invalid OTP!' );
            }
        }   
        return $returnArray;
    }

    public function _checkOtpStatus($otp,$employeeId,$status){

        $_OcommonDBO = new commonDBO();

        $sql = "SELECT * FROM employee_otp_details eop 
                WHERE eop.r_employee_id = ".$employeeId." AND eop.otp_key = ".$otp." AND eop.otp_status = '".$status."'";

        return $_OcommonDBO->_getResult($sql);

    }

    public function _updateOtpExpire($otp,$employeeId){

        $_OcommonDBO = new commonDBO();

        $sql = "UPDATE 
                    employee_otp_details eop
                SET
                    eop.otp_status = 'N'
                 WHERE 
                    eop.r_employee_id = ".$employeeId." AND eop.otp_key = ".$otp;

        return $_OcommonDBO->_getResult($sql);

    }
    //function to resend the OTP
    protected function _resendOtpToUser(){

        $_OcommonDBO = new commonDBO();
        $employeeInfo['employee_id']    = $this->_IinputData['employeeId'];
        $employeeInfo['r_corporate_id'] = $this->_IinputData['corporateId'];
        $employeeInfo['mobile_no'] = $_OcommonDBO->_select('dm_employee','mobile_no','employee_id',$this->_IinputData['employeeId'])[0]['mobile_no']; 
        $smsFlow = 'REG';
        $smsType = 'Forgot Password';
        $_Oemployee = new employee();

        $_Oemployee->_generateAuthOTP($employeeInfo,$smsFlow,$smsType);
        $this->_AfinalResponse = true;
        return TRUE;

    }
    public function _checkEmployeeCodeExist($data){
        if(substr(trim($data['loginEmail']),0,3) == 'IOC'){
          $data['loginEmail'] = substr(trim($data['loginEmail']),0,3) == 'IOC' ? substr(trim($data['loginEmail']),3) : $data['loginEmail'];
            $_OcommonDBO = new commonDBO();
            $sql = "SELECT employee_code,band_name,dme.email_id FROM 
                            dm_employee dme INNER JOIN fact_employee fe ON dme.employee_id = fe.r_employee_id
                            INNER JOIN agency_corporate_mapping acm ON acm.corporate_id = fe.r_corporate_id
                            INNER JOIN employee_details ed ON ed.r_employee_id = dme.employee_id
                            INNER JOIN dm_band dmb ON dmb.band_id = ed.r_band_id
                            WHERE dme.employee_code = '".$data['loginEmail']."' AND SAP_id = 'IOCL' ";
            $result = $_OcommonDBO->_getResult($sql)[0];
        }else{
            return false;
        }
        return $result ;
    }

    public function _sendCredentials($emailId,$accountId,$empId) {
        $showEmailInput = $this->_getUserBand($this->_SuserExists['details']['r_employee_id']) ? 'Y' : 'N';
        $showEmailInput = $this->_IinputData['action'] == 'updateMailandSendforgotPassword' ? 'N' : $showEmailInput;
        $_Ocommon = new common();
        $_OcommonDBO = new commonDBO();
        $subject = "Balmer lawrie : Forgot password";
         $text = $this->_SuserExists['details']['account_id'] . "$$" . $this->_SuserExists['details']['email_id'];
        $sql = "SELECT max(link_id) 'Count' FROM forgot_password_link";
        $getLinkId = $_OcommonDBO->_getResult($sql)[0];
        $count = ($getLinkId != "") ? $getLinkId['Count'] + 1 : '';
        $rand =  $_Ocommon->_generateRandomString(7,'NUMBERS');
        $user = base64_encode($text . "$$" . $count . "$$" .  $rand."$$".$showEmailInput);
        $userName = $this->_SuserExists['details']['title'].'.'.$this->_SuserExists['details']['first_name'].' '.$this->_SuserExists['details']['last_name'];
        $forgotPwdLink = "http://" . $_SERVER['HTTP_HOST'] . "/forgotPassword.php?user=" . $user;
        $insertValues = array(
            'link_id' => 0,
            'r_employee_id' => $this->_SuserExists['details']['r_employee_id'],
            'reset_link' => $user,
            'updated_date' => date('Y-m-d H:i:s'),
            'status' => 'Y'
        );
        $result = $_OcommonDBO->_insert('forgot_password_link', $insertValues);
        $otpLinkInfo = base64_encode($text."$$".$forgotPwdLink."$$".$result);
        $email  = explode('@',$this->_IinputData['emailId'])[1];

        $startString = $this->startsWith($this->_IinputData['bandname'],'H');
        if($startString && $email == 'IOCL.com'){
            $this->_AfinalResponse['status'] = true;
            $this->_AfinalResponse['redirect'] = true;
            $this->_AfinalResponse['link'] =  $forgotPwdLink;//"http://" . $_SERVER['HTTP_HOST'] . "/verifyOtp.php?otpInfo=" . $otpLinkInfo;
        }else{
            $this->_AtwigOutputArray['message'] = " Dear ".$userName.",<br> We have received the request for password retrieval. Please click <a href='".HTTP_TYPE.$_SERVER['HTTP_HOST'] . "/verifyOtp.php?otpInfo=" . $otpLinkInfo . "'>here</a> to reset your password<br><br>Regards,<br>".EMAIL_SIGNATURE;
            $this->_AtwigOutputArray['host'] =  HOST_URL;
            $message = $this->_Otwig->render('mailLayout.tpl', $this->_AtwigOutputArray);
            $this->_Omail = new commonMethods();
            $this->_Omail->_sendMail($this->_SuserExists['details']['email_id'], 'support@atyourprice.in', $subject, $message);
            $this->_AfinalResponse['alert'] = 'A reset link has been sent to your registered email id. Kindly use the link to set a new password.';
            $this->_AfinalResponse['status'] = true;
            $this->_AfinalResponse['redirect'] = false;
        }
        // settings emp name for the user creation
    }

    public function _getUserBand($employee_id){

        $_OcommonDBO = new commonDBO();
        $sql= "SELECT band_name FROM dm_band 
                INNER JOIN employee_details ed ON ed.r_band_id = band_id
                INNER JOIN dm_employee  dme ON dme.employee_id = ed.r_employee_id
                 WHERE r_employee_id='".$employee_id."' AND band_name like 'H%' and email_id like '%IOCL.com%'";
        $bandName = $_OcommonDBO->_getResult($sql);
        if($bandName){
          return true;  
        }else{
            // dont show email id
            return false;
        }
    
    }
    public function _checkEmailIdChanges($employee_id){
        $_OcommonDBO = new commonDBO();
        $sql = "SELECT * FROM dm_employee WHERE employee_id ='".$employee_id."' AND email_id like '%IOCL.com%'";
        return $_OcommonDBO->_getResult($sql);
    }

    public function _updateMailandSendPassword(){
        $user = explode("$$", base64_decode($this->_IinputData['user']));
        $_OcommonDBO = new commonDBO();

        // check email already exist in system
        $checkEmployee = $this->_checkEmployeeCorporate($this->_IinputData['loginEmail']);
        if($checkEmployee){
                 $this->_AfinalResponse['alert'] = 'Sorry Email id already exist in system';
            $this->_AfinalResponse['status'] = false;
            return false;
        }
        $sql = "UPDATE dm_employee dme SET  dme.email_id = '" . $this->_IinputData['loginEmail'] . "'
                        WHERE dme.email_id = '" . $user[1] . "'";
        $_OcommonDBO->_getResult($sql);
        $this->_verifyUser();
        $this->_sendLinkMail();
        $this->_AfinalResponse['alert'] = 'A reset link has been sent to your registered email id. Kindly use the link to set a new password.';
        $this->_AfinalResponse['status'] = true;
    }

    public function _checkEmployeeCorporate($emailId){
        $_OcommonDBO = new commonDBO();
        $sql = "SELECT employee_id 
                FROM dm_employee  dme INNER JOIN fact_employee fe on fe.r_employee_id = dme.employee_id 
                INNER JOIN agency_corporate_mapping acm ON acm.corporate_id = fe.r_corporate_id 
                WHERE email_id ='".$emailId."' and acm.SAP_id = 'IOCL'";
        $employeeExist = $_OcommonDBO->_getResult($sql);
        if($employeeExist){
          return true;  
        }else{
            return false;
        }
    }

    /**
     * @Description  verify the capcha code
     * @return array
     * @date|20.12.2018
     * @author|Muruganandham.M
     */
    public function _captchaCodeValidate() {
        if(!isset( $_SESSION['securimage_code_value'])) {
            $_SESSION['feedback_capcha_val']='12345';
        }
        $namespace = $this->_IinputData['namespace']; 
        if($_SESSION['securimage_code_value'][$namespace]) {
            if($_SESSION['securimage_code_value'][$namespace] ==trim($this->_IinputData['captcha_value'])) {
               return true;
            }
            else {
                return false;
            }      
        } 
    }

     public function startsWith($string, $startString) 
    { 
        $len = strlen($startString); 
        return (substr($string, 0, $len) === $startString); 
    } 
}
?>
