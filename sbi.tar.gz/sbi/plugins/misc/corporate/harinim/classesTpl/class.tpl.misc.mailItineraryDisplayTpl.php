<?php
/* * **************************************************************************
 * @File             : class.tpl.approvalFlowTpl.php
 * @Description      : This file is used to send approval and insert the flight itinerary details
 * @Tables Affected  :1.air booking details 2.via_fare_details 3.via_flight_details 4.fact_air_itinerary 5.passenger_via_details
 * @Author           : Karthika
 * @Created Date     : 08/12/2016
 * @Modified Date    : 
 * ****************************************************************************/
fileRequire("./plugins/common/traits/trait.itineraryDisplay.php");
fileRequire("./plugins/common/interface/commonConstants.php");

class mailItineraryDisplayTpl implements commonConstants{  

    use itineraryDisplayTrait;
    
    public function __construct(){ 
        
        $this->_OcommonDBO=new commonDBO();
        $this->_itineraryDisplayTraitConstruct();
    }

    public function _getDisplayInfo()
    {
        $this->_itineraryDisplayTraitMethod();
    }    
}
?>