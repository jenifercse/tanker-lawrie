<?php
/*******************************************************************************
 * @class			editMenuDetailsTpl phpfunction 
 * @author      	Mercy Chrysolite
 * @created date	08 - 04 - 2016
 ******************************************************************************/ 	
fileRequire("classes/class.commonDBO.php");
class createCorporateTpl
{
	//variable declaration
	var $_Oconnection;
	var $_ImenuId;
	var $_SmenuName;
	var $_SmenuLink;
	var $_SfuncName;
	var $_SmoduleName;
	var $_SformName;
	var $_Sresult;

	function __construct()
	{
		//variable initialization
		$this->_Oconnection='';
		$this->_ImenuId=0;
		$this->_SmenuName='';
		$this->_SmenuLink='';
		$this->_SfuncName='';
		$this->_SmoduleName='';
		$this->_SformName='';
		$this->_Sresult='';
	}
        
        function _getDisplayInfo() {

            switch($this->_SmoduleName) {
                case 'createCorporate' :
                    $this->_createCorporate();
                    break;
                
                case 'updateCorporate':
                    $this->_updateCorporate();
                    break;
                
                default:
                    $this->_viewCorporates();
                    $this->_getApplicationSettingOptions();
            }
            
            $this->_smartyAssign();
        }
	
	function _createCorporate()
	{
            $this->_OcommonDB = new commonDBO();
            $this->_OcommonDB->_Oconnection = $this->_Oconnection;
            $input['corporate_id'] = 0;
            $input['corporate_name'] = $this->_IinputData['corporateName'];
            $input['corporate_type'] = $this->_IinputData['corporateType'];
            $input['status'] = $this->_IinputData['status'];
            $this->_IcorporateId = $this->_OcommonDB->_insert('corporate',$input);

            foreach($this->_IinputData['selectedValues'] as $settingId => $settingValue)
            {
                $input = array();
                $input['corporate_id'] = $this->_IcorporateId;
                $input['r_setting_id'] = $settingId;
                $input['assigned_value'] = $settingValue;
                $input['status'] = 'Y';
                $this->_OcommonDB->_insert('corporate_setting_details',$input);
            }

            $this->_OobjResponse->script("$('#closeCreate').click();wrapperScript('createCorporateView','')");
	}
	
	function _updateCorporate()
	{
		$sql = " UPDATE corporate SET
					corporate_type = '".$this->_IinputData['editCorporateType']."',
					status = '".$this->_IinputData['editStatus']."'
			WHERE
				corporate_id = ".$this->_IinputData['editCorporateId'];

		if (DB::isError($result= $this->_Oconnection->query($sql)))
		{
			fileWrite($sql,"SqlError","a+");
		}
		
		$sql = " DELETE FROM corporate_setting_details WHERE
				corporate_id = ".$this->_IinputData['editCorporateId'];

		if (DB::isError($result= $this->_Oconnection->query($sql)))
		{
			fileWrite($sql,"SqlError","a+");
		}

                $this->_OcommonDB = new commonDBO();
                $this->_OcommonDB->_Oconnection = $this->_Oconnection;
		foreach($this->_IinputData['selectedValues'] as $settingId => $settingValue)
                {
                    $input = array();
                    $input['corporate_id'] = $this->_IinputData['editCorporateId'];
                    $input['r_setting_id'] = str_replace('edit', '', $settingId);
                    $input['assigned_value'] = $settingValue;
                    $input['status'] = 'Y';
                    $this->_OcommonDB->_insert('corporate_setting_details',$input);
                }
                
                $this->_OobjResponse->script("$('#closeEdit').click();wrapperScript('createCorporateView','')");
	}	
	
	function _viewCorporates()
	{
		$sql=	"SELECT
				corporate_id,
				corporate_name,
                                corporate_type,
				status
			FROM
				dm_corporate";
		if(DB::isError($result=$this->_Oconnection->query($sql)))
		{
			fileWrite($sql,'SqlError','a+');
			return false;
		}
		
		while($row = $result->fetchRow(DB_FETCHMODE_ASSOC))
		{
			$this->_Acorporates[] = $row;
		}
	}
	
	function _getApplicationSettingOptions()
	{
            $sql = "SELECT
				ast.setting_id,
				ast.setting_name,
				ast.setting_type,
                                asd.settings_details_id,
				asd.value,
				ast.default_value
			FROM
				application_settings ast,
				application_settings_details asd
			WHERE
				ast.setting_id = asd.r_setting_id
				and ast.status = 'Y'";
		if(DB::isError($result=$this->_Oconnection->query($sql)))
		{
			fileWrite($sql,'SqlError','a+');
			return false;
		}
                $i = 0;
		while($row = $result->fetchRow(DB_FETCHMODE_ASSOC))
		{
                    if(!in_array($row['setting_id'], $this->_Asettings)) {
                        $this->_Asettings[$row['setting_id']]['setting_name'] = $row['setting_name'];
                        $this->_Asettings[$row['setting_id']]['setting_id'] = $row['setting_id'];
                    }
                    $this->_Asettings[$row['setting_id']]['value'][$i] = $row['value'];
                    $this->_Asettings[$row['setting_id']]['id'][$i] = $row['settings_details_id'];
                    $i++;
                }
	}

	function _smartyAssign() {
            
            $this->_Osmarty->assign('objCorp',$this);
        }
}
?>
