<?php
/**
 * @File             : class.tpl.misc.displayCreditnoteTpl.php
 * @Description      : This file is used to view credit note details 
 * @Author           : Sivaprakash
 * @Created Date     : 03/12/2018
 */
class displayCreditnoteTpl{

    public function __construct(){

        $this->_OcommonDBO = new commonDBO();
    }
    
    /**
    * @functionName    :   _getDisplayInfo()
    * @description     :   
    */
    public function _getDisplayInfo(){
        
        $_OcreditnoteDetails = new creditnoteDetails();
        $this->_Oeticket = common::_checkClassExistsInNameSpace('eTicketMail');
        require_once 'classes/class.numberToWords.php';
        $this->_Damountinwords = new numberToWords();

        fileWrite(print_r($this->_IinputData,1),'creditnotedisplay'.$this->_IinputData['order_id']);

        $_AcancellationDetails = $_OcreditnoteDetails->_getPassengerOrderCancellationDetails($this->_IinputData['order_id']);
        
        $_AfareType = array_column($this->_OcommonDBO->_getResult("SELECT fare_type_code FROM dm_fare_type WHERE fare_type_id IN (".implode(',',array_column($_AcancellationDetails, 'r_fare_type_id')).")"), 'fare_type_code');

        fileWrite(print_r($_AfareType,1),'creditnotedisplay'.$this->_IinputData['order_id'],'a+');
        
        $_BrtFareRoundTrip = in_array('RT', $_AfareType) ? TRUE : FALSE;

        $_ApassengerType = array('ADT' => 0, "CNN" => 1, "INF" => 2);
        //get the pnr and passenger based array with respect to the orderId.
        $this->_OflightItinerary = new flightItinerary();
        $flightInfo = $this->_OflightItinerary->_getFlightDetailsBasedPNR($this->_IinputData['order_id']);
        foreach ($_AcancellationDetails as $key => $value) {
            

            ($this->_IinputData['trip_type'] == 1 && $_BrtFareRoundTrip) ? $value['trip_type'] = '0,1' : '';

            $this->_AcreditNoteDetails[$value['r_passenger_id']][$value['trip_type']] = $_OcreditnoteDetails->_fetchCreditNoteDetails($value);

            $passengerType = $this->_OcommonDBO->_select('passenger_details', 'passenger_type', 'passenger_id', $value['r_passenger_id'])[0]['passenger_type'];

            $this->_fareSplitup = $this->_Oeticket->_eticketFareSplitUp($this->_IinputData['order_id'],$flightInfo[0]['viaFlightIds'],$value['trip_type'],$value['r_passenger_id'],$_ApassengerType[$passengerType]);

            $travelDate = $this->_OcommonDBO->_select("via_flight_details","departure_date","via_flight_id",$value["r_via_flight_id"])[0]['departure_date'];

            $this->totalAmount['grossTotal'] = (int)$this->_fareSplitup['taxBreakUp']['original_base_fare'] + (int)$this->_fareSplitup['taxBreakUp']['original_tax'] + (int)$this->_fareSplitup['GSTsplitup'];

            $sum = 0;
            foreach ($this->_fareSplitup['SSR'] as $ssrkey => $ssrvalue){
                $sum += $ssrvalue;
            }
            $this->_fareSplitup['SSR']['amount'] = $sum;

            $this->totalAmount['finalAmount'] = $this->totalAmount['grossTotal'] - $value['cancellation_penalty'];

            $this->_Damountinwords->toWords($this->totalAmount['finalAmount'], NUMBER_TO_WORDS);

            $this->totalAmount['inWords'] = strtoupper(ucwords($this->_Damountinwords->words));
            $this->_fareSplitup['baseAirFare'] = 0;
                foreach ($this->_fareSplitup['taxBreakUp'] as $k => $v) {
                    ($k != 'original_tax') ? $this->_fareSplitup['baseAirFare'] += $v : '';
                }
            $this->_AcreditNoteDetails[$value['r_passenger_id']][$value['trip_type']]['fareSplitup'] = $this->_fareSplitup;
            $this->_AcreditNoteDetails[$value['r_passenger_id']][$value['trip_type']]['totalAmount'] = $this->totalAmount;

        }

        $this->_AtwigOutputArray['paxId'] = array_unique(array_column($_AcancellationDetails, 'r_passenger_id'));
        //template assign function.
        $this->_templateAssign($travelDate);
    }
    
    /* Function name: _templateAssign
    * @Description  this function assigns the values to be sent to the template view
    * @param |array
    * @return 
    */
    public function _templateAssign($travelDate){
        
        $this->_OgstCostCenter = new gstCostCenter();

        $this->_AtwigOutputArray['creditnoteDetails'] = $this->_AcreditNoteDetails;
        $this->_AtwigOutputArray['travelDate'] = $travelDate;
        $this->_AtwigOutputArray['BL_GST_NUMBER']     = BL_GST_NUMBER;
        $this->_AtwigOutputArray['orderGstDetails']   = $this->_OgstCostCenter->_getOrderGSTDetails($this->_IinputData['order_id']);
        fileWrite(print_r($this->_AtwigOutputArray,1),'creditnotedisplay'.$this->_IinputData['order_id'],'a+');
    } 
}