<?php

/* * **************************************************************************
 * @File            misc.manageModule.php
 * @Description     This does all operations for module mappings
 * @Author          Sri muthu rajesh
 * @Created Date    1/08/2017
 * *************************************************************************** */

class manageModuleTpl {


    public function __construct() {
        $this->_OmanageModuleClass = new manageModuleClass();
    }

    /*
     * @Description  this function handles the all module management operations via switch cases
     * @param 
     * @return 
     */

    public function _getDisplayInfo() {
        switch ($this->_IinputData['action']){
            case 'getTravelTypeFolder':
                $this->_AfinalResponse = $this->_OmanageModuleClass->_getTravelTypeFolder();
                break;
            case 'getModuleList':
                $this->_AfinalResponse = $this->_OmanageModuleClass->_getModuleList();
                break;
            case 'getPluginFolder':
                $this->_AfinalResponse = $this->_OmanageModuleClass->_getPluginFolder($this->_IinputData['data']);
                break;
            case 'getViewTypeFolder':
                $this->_AfinalResponse = $this->_OmanageModuleClass->_getViewTypeFolder();
                break;
            case 'getViewFolder':
                $this->_AfinalResponse = $this->_OmanageModuleClass->_getViewFolder($this->_IinputData['data']);
                break;
            case 'getBookingTypeFolder':
                $this->_AfinalResponse = $this->_OmanageModuleClass->_getBookingTypeFolder($this->_IinputData['travelType']);
                break;
            case 'getCorporateFolder':
                $this->_AfinalResponse = $this->_OmanageModuleClass->_getCorporateFolder($this->_IinputData['travelType'],$this->_IinputData['bookingType']);
                break;
            case 'getClassTplFiles':
                $this->_AfinalResponse = $this->_OmanageModuleClass->_getClassTplFiles($this->_IinputData['travelType'],$this->_IinputData['bookingType'],$this->_IinputData['corporate']);
                break;
            case 'checkModule':
                $checkModuleResult = $this->_OmanageModuleClass->_checkModule($this->_IinputData['moduleName']);
                if(is_array($checkModuleResult) && count($checkModuleResult)>0){
                $this->_AfinalResponse = array('result'=>true);
                return true;
                }else {
                $this->_AfinalResponse = array('result'=>false);
                    return false;
                }
                break;
                
            case 'moduleInsert':
                foreach ($this->_IinputData['className'] as $classnameVal){
                    $className=$classnameVal;
                    foreach ($this->_IinputData['groupId'] as $groupIdVal){
                        $groupId=$groupIdVal;
                        $moduleId = $this->_OmanageModuleClass->_moduleInsert($this->_IinputData['moduleName']);
                        $templateId = $this->_OmanageModuleClass->_templateInsert($this->_IinputData['templateName'],$className,$this->_IinputData['templateType']);
                        $mapsettingResult = $this->_OmanageModuleClass->_mappsetting($groupId,$moduleId,$templateId,$this->_IinputData['displayOrder'],$this->_IinputData[displayStatus],$this->_IinputData['stdTplId']);
                        //writing values to csv files
                            $list = array(  $this->_IinputData['moduleName'],
                                           $this->_IinputData['templateName'],
                                           $className,
                                           $this->_IinputData['templateType'],
                                           $this->_IinputData['displayOrder'],
                                           $this->_IinputData['displayStatus'],
                                           $groupId,
                                           $this->_IinputData['stdTplId']);
                           $file = fopen('../lib/work/mappingScript.csv',"a");
                           fputcsv($file,$list);
                           $this->_AfinalResponse = array('message' => 'Values are inserted and csv file created');
                    }
                }
                break;
        }
    }
}
?>