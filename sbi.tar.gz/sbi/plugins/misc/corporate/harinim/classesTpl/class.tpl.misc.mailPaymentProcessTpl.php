<?php
/* * **************************************************************************
 * @File             : class.tpl.approvalFlowTpl.php
 * @Description      : This file is used to send approval and insert the flight itinerary details
 * @Tables Affected  :1.air booking details 2.via_fare_details 3.via_flight_details 4.fact_air_itinerary 5.passenger_via_details
 * @Author           : Karthika
 * @Created Date     : 08/12/2016
 * @Modified Date    : 
 * ****************************************************************************/
pluginFileRequireBasic('common/','interface/commonConstants.php');
class mailPaymentProcessTpl implements commonConstants{  
    
    public function __construct(){ 
        $this->_OcommonDBO = new commonDBO();
        $this->_OcommonQuery = new commonQuery();
    }

    public function _getDisplayInfo(){
        
        //set inputs
        $input = $this->_IinputData;        
        
        switch($input['action']){
            
            case 'updateFare':
                
                //set the messages
                if($input['paymentResponse']['paymentStatus']){
                    $message =  $input['message'];
                }
                else{
                    $message =  $input['paymentResponse']['status']['error_alert'];
                }
                //calling the function for showing the itinerary.
                $this->showingTemplate($message,$input);
                break;
                
            case 'proceedRetry':                
                $this->proceedRetryAutomation($input);
                break;

            default:
                
                //set the messages when click the the 'NO' button in fare check alert while approve from mail.
                $message = ($input['message']) ? $input['message'] : 'Fullfilment not completed for this booking.';
                
                //calling the function for showing the itinerary.
                $this->showingTemplate($message,$input);
                break;
        }
    }
    
    /**
    * @Description  function used to showing the itinerary
    * @param array,string|$input,$message
    * @return string|$_SmailContent
    * @date|12.03.2018
    * @author|Karthika.M
    */  
    public function showingTemplate($message,$input){
       
        //set inputs
        $inputData = $input;
        $this->_IinputData['orderId'] = $input['orderId'];
        $this->_IinputData['contentIdData'] = $input['contentIdData'];
        
        //set package id
        $packageId = ($input['paymentResponse']['packageId']) ? $input['paymentResponse']['packageId'] : $input['packageId'];
        
        //get package info.
        $packageType = $this->_OcommonDBO->_select('dm_package', 'package_type', 'package_id',$packageId)[0]['package_type'];
        if($packageType == SELF::COMBO_PACKAGE_TYPE){
            
            //Assign the travel mode name for cart 
            $travleModeName = 'Cart';
            
            //set inputs
            $this->_IinputData['packageId'] = $packageId;
            $this->objClass = new cartItinerary();         
            
            //set method name.
            $methodName = '_getCartItineraryInfo';
        
            //call the class function to initiate the call_user_func with parameter     
            $this->_AtwigOutputArray = call_user_func( array($this->objClass, $methodName), $this->_IinputData);
            $this->_AtwigOutputArray['showButton'] = 'N';
            $this->_AtwigOutputArray['message'] = $message;
            
            //call send mail function  if the $this->_AtwigOutputArray is grater than 0
            if(count($this->_AtwigOutputArray > 0)){   
                $tplName = lcfirst($travleModeName).'MailItinerary.tpl';
                $this->_AfinalResponse['template'] = $this->_Otwig->render($tplName,$this->_AtwigOutputArray);
            }
        }
        else{
            //get the template.
            $inputData['message'] = ($inputData['message']) ? $inputData['message'] : $message;
            $this->_OcommonQuery->_Otwig = $this->_Otwig;
            $this->_AfinalResponse['template'] = $this->_OcommonQuery->_callingItineraryBasedTravelMode($inputData);
          
        }
    }
    
    /*
    * @Description  this function is used to calling function for trigger the automation based on the inputs
    * @param array | $input 
    * @return array |$result
    */
    public function proceedRetryAutomation($input){  
        
        $_OcommonQuery = new commonQuery();
        
        //trigger the automation.
        $response = $_OcommonQuery->_retryBookingAutomation($input);
        //calling the function for showing the itinerary.
        $this->_AfinalResponse['message'] = $response['message'];
        $this->showingTemplate('',$input);
    }
}