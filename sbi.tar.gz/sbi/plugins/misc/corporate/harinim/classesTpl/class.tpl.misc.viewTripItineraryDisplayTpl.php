<?php
/**
 * This class is to fetch the itinerary information of the trip
 */

class viewTripItineraryDisplayTpl {
   
   public function __construct() {
       $this->_OtripCreation = new tripCreation();
    }

    public function _getDisplayInfo()
    {

         switch ($this->_IinputData['action']) { 
           case 'viewItinerary':
                $paidArray = array(REQUESTED,ITINERARY_SSR_SELECTED,TICKET_STATUS_CHANGE);
                $this->_AtwigOutputArray['tripDetails']   = $this->_OtripCreation->_getTripdetails($this->_IinputData['trip_id']);
                $this->_AtwigOutputArray['ticketDetails'] = $this->_OtripCreation->_getTripTicketDetials($this->_IinputData['trip_id'],'',$paidArray,'NOT');
                $this->_AtwigOutputArray['trip_status'] = $this->_AtwigOutputArray['tripDetails']['r_status_id'] == TRIP_SEND_FOR_APPROVAL ? 'Y' : 'N';
                $this->_AtwigOutputArray['buttonDisplay'] = $this->_IinputData['tpl'] == 'pendingApprovedList' ? 'Y' : 'N';
                $this->_AtwigOutputArray['Status_Display'] = $this->_AtwigOutputArray['tripDetails']['r_status_id'];
                $this->_AtwigOutputArray['cancel_Staus'] = $this->_IinputData['cancel'] !=''? 'Y':'N';
                return $this->_AtwigOutputArray;
           break;

         }
    }
}
