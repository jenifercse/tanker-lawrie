<?php
/* * *****************************************************************************
 * @class		applicationSettings class TPl file
 * @author      	Mercy Chrysolite
 * @created date	08 - 04 - 2016
 * **************************************************************************** */
fileRequire("lib/common/commonMethods.php");
fileRequire("classes/class.autoLogin.php");
class applicationSettingsTpl{

    public function __construct(){
        $this->_ODBC = new commonDBO();
        $this->_OAgency = new agency();
        $this->_OAppSetting = new applicationSettings();
        $this->_OcommonQuery = new commonQuery();
        $this->_OAppSetting->_ODBC = $this->_ODBC;
    }

    public function _getDisplayInfo(){

        //set return value.
        $returnValue = array('status' => 0, 'status_message' => 'success', 'error_alert' => '', 'result' => array());       
        
        //set action
        $this->action = $this->_IinputData['action'];
        switch($this->action){

            case 'createApplicationSettings' :
                $this->_createApplicationSettings();
                break;

            case 'editApplicationSettings':
            case 'updateApplicationSettings':
                $this->_updateApplicationSettings();
                break;

            case 'generateAuthKey':
                $this->autologin = new checkWSAutoLogin();
                $this->autologin->_generateAuthKey($this->_IinputData['accountId'], $this->_IinputData['email'], $this->_IinputData['corporateId']);
                return $this->_AfinalResponse = $this->autologin->_SaypAuthKey;
                break;

            case 'displaySettings':                
                $this->_AfinalResponse = $this->_displaySettings($this->_IinputData['agencyId'], $this->_IinputData['corporateId'], $this->_IinputData['bookingType'], $this->_IinputData['settings']);
                break;
            
            case 'updateApplicationForm':                
                $this->_AfinalResponse = $this->_updateApplicationData($this->_IinputData);
                break;
            
            case 'getCorporateList':
                $this->_AfinalResponse = $this->_getCorporateListForCorporate($this->_IinputData['agencyId']);
                break;
            
            case 'setUpPortalType':                
                $this->_AfinalResponse = $this->_setUpPortal($this->_IinputData['agencyId'], $this->_IinputData['corporateId'], $this->_IinputData['bookingType']);
                break;

            case 'portalType':   
                $this->_AfinalResponse = $this->_portalType($this->_IinputData['agencyId'], $this->_IinputData['corporateId'], 0);
                break;

            case 'addNewApplication':
                $this->_AfinalResponse = $this->_createApplicationSettings();
                break;

            case 'exportAppSettings':                
                //save user data to DB               
                $settingsArray = $this->_IinputData['settings'];
                unset($this->_IinputData['settings']);
                $result = $this->_updateApplicationData($this->_IinputData);
                if($result['status'] == 1){
                    //export application settings to json file
                    $this->_IinputData['settings'] = $settingsArray;
                    $this->_AfinalResponse = $this->_exportApplicationSettings($this->_IinputData);
                } 
                else{
                    $this->_AfinalResponse = $result;
                }
                break;

            case 'ADDLOGO':
                $corporateLogoId = $this->_addLogoInformation();
                $this->_AfinalResponse = array('status' => 0, 'corporate_logo_id' => $corporateLogoId, 'logo_name' => $this->_IinputData['uploadFiles']['logoupload1']);
                break;

            case 'REMOVELOGO':
                $logoId = $this->_IinputData['logoId'];
                $logoName = $this->_IinputData['logoName'];
                $response = $this->_removeLogoInformation($logoId, $logoName);
                $this->_AfinalResponse = array('status' => 0, 'message' => $response);
                return;
                break;
            
            case 'login':
                $this->_Ologin = new login();
                $this->_Ologin->_IinputData = $this->_IinputData;
                $this->_Ologin->_authenticateUser();
                $this->_AfinalResponse =  $this->_Ologin->_AfinalResponse;
                break;
            
            case 'checkFirstTimeLogin':
                $this->_Ologin = new login();
                $this->_Ologin->_IinputData = $this->_IinputData;
                $loginStatus  = $this->_Ologin->_getUserLoginHistory();
                if($loginStatus == 'Y' || $loginStatus == ''){
                    $responseStatus['status'] = 'Y';
                    $responseStatus['message'] = 'First Time Login';
                }
                else if($loginStatus == 'N'){
                    $responseStatus['status'] = 'N';
                    $responseStatus['message'] = 'Already Login';
                }
                else{
                    $responseStatus['status'] = 0;
                    $responseStatus['message'] = 'Invalid User Name or Password';
                }
                $this->_AfinalResponse =  $responseStatus;
                break;
            
            case 'logoutUser':
                $this->_Ologin = new login();
                $this->_Ologin->_logout();
                $this->_AfinalResponse =  $this->_Ologin->_AfinalResponse;
                break;

            case 'generateAuthKeyCancel':
                $this->autologin = new checkWSAutoLogin();
                $this->autologin->_generateAuthKey($this->_IinputData['accountId'], $this->_IinputData['email'], $this->_IinputData['corporateId']);
                return $this->_AfinalResponse = $this->autologin->_SaypAuthKey;
                break;
            
            case 'getEmailAndAccountId':
                return $this->_getAuthenticationKey();
                
            case 'updateNewPassword':
                $this->_Ologin = new login();
                $this->_Ologin->_IinputData = $this->_IinputData;
                $this->_Ologin->_checkPasswordAlreadyExit();
                $this->_AfinalResponse =  $this->_Ologin->_AfinalResponse;
                break;

            case 'checkOldPassword':
                $this->_Ologin = new login();
                $this->_Ologin->_IinputData = $this->_IinputData;
                $this->_Ologin->_checkOldPassword();
                $this->_AfinalResponse =  $this->_Ologin->_AfinalResponse;
                break;

            case 'logoutUserUpdateReload':
               $this->_OauthToken = new authToken();
               $this->_OauthToken->_updateUserLoginCredentials('browserUnLoad');
                break;

            case 'deleteLoginDetails':
               $this->_AfinalResponse = $this->_deleteUserLoginCredentials();
                break;

            case 'loadHomeModule':            
               $this->_AfinalResponse = $this->_OAppSetting->_loadDefaultModule();
                break;

            default:
                $this->_permissionCheck();
        }
        $this->_templateAssign();
        return $returnValue;
    }

    /* @Description for inserting the application settings values */
    public function _createApplicationSettings(){
               
        $insertArray = array();
        $insertArray['setting_id'] = 0;
        $insertArray['setting_name'] = $this->_IinputData['settingName'];
        $insertArray['setting_type'] = $this->_IinputData['settingType'];
        $insertArray['default_value'] = $this->_IinputData['default'];
        $insertArray['status']  = $this->_IinputData['status'];
        $insertArray['sorting']  = 1;        
        
        $this->_IsettingId = $this->_ODBC->_insert('application_settings', $insertArray);

        foreach ($this->_IinputData['values'] as $key => $value){            
            
            $insertArray = array();
            $insertArray['settings_details_id'] = 0;
            $insertArray['r_setting_id'] = $this->_IsettingId;
            $insertArray['value'] =  "$value";
            $insertArray['status'] = "Y";                      
        
            $this->_IValue = $this->_ODBC->_insert('application_settings_details', $insertArray);
        
            $sql = " SELECT DISTINCT r_corporate_id,r_agency_id,booking_type FROM application_settings_value WHERE booking_type !='0' GROUP BY r_corporate_id,r_agency_id,booking_type";

            $resultArray = $this->_ODBC->_getResult($sql);                       
        
            foreach ($resultArray as $arrayValue){
                $insertArrayValue = array();
                $insertArrayValue['application_settings_value_id'] = 0;
                $insertArrayValue['r_setting_id'] = $this->_IsettingId;
                $insertArrayValue['value'] = $this->_IValue;
                $insertArrayValue['enabled'] = $this->_IinputData['defaultValue'][$key];
                $insertArrayValue['r_corporate_id'] = $arrayValue['r_corporate_id'];
                $insertArrayValue['r_agency_id'] = $arrayValue['r_agency_id'];
                $insertArrayValue['booking_type'] = $arrayValue['booking_type'];
                $resultArray = $this->_ODBC->_insert('application_settings_value', $insertArrayValue);            
            }            
        }        
        $returnArray = array('status' => 1, 'message' => 'Settings Added successfully');
        return $returnArray;        
    }

    /*  @Description for updating the application settings values */
    public function _updateApplicationSettings(){
        
        $sql = " UPDATE 
                    application_settings 
                SET
					setting_type  = '" . $this->_IinputData['settingType'] . "',
					default_value = '" . $this->_IinputData['default'] . "',
					`status`      = '" . $this->_IinputData['status'] . "'
			    WHERE
				    setting_id = " . $this->_IinputData['settingId'];

        if(DB::isError($result = $this->_Oconnection->query($sql))){
            fileWrite($sql, "SqlError", "a+");
        }

        $sql = "DELETE FROM application_settings_details WHERE r_setting_id = " . $this->_IinputData['settingId'];

        if(DB::isError($result = $this->_Oconnection->query($sql))){
            fileWrite($sql, "SqlError", "a+");
        }

        foreach ($this->_IinputData['values'] as $value){

            $sql = " INSERT INTO application_settings_details(settings_details_id,r_setting_id,value,status)
					 VALUES(
						0,
						" . $this->_IinputData['settingId'] . ",
						'" . $value . "',
						'Y'
					)";

            if(DB::isError($result = $this->_Oconnection->query($sql))) {
                fileWrite($sql, "SqlError", "a+");
            }
        }
    }

    /*  @Description for mapping the application settings with corporate */
    public function _createApplicationMapping(){

        foreach($this->_IinputData['values'] as $value){

            $sql = "INSERT INTO corporate_setting_details(corporate_setting_id,r_setting_id,corporate_id,assigned_value,status)
    				VALUES(
    					0,
    					'" . $value['settingId'] . "',
    					'" . $this->_IinputData['corporateId'] . "',
    					'" . $value['assignedValue'] . "',
    					'" . $value['status'] . "'
    				)";
            if(DB::isError($result = $this->_Oconnection->query($sql))){
                fileWrite($sql, "SqlError", "a+");
            }
        }
    }

    /*  @Description For setting up the portaltype status and for checking and inserting the application settings values)
        function _setUpPortal
        @input agencyId,corporateId,bookingType       
    */
    public function _setUpPortal($agencyId = 0,$corporateId = 0,$bookingType){
        
        $resultValue = $this->_portalTypeStatus($agencyId, $corporateId,$bookingType);        
        $applicationSetingsValueArray = $this->_OAppSetting->_checkAndInsertApplicationSettingsValue($agencyId, $corporateId, $bookingType);
        return $applicationSetingsValueArray;
    }

    /*  @Description For getting the portal type status from application setting value table
        function _portalTypeStatus
        @input agencyid,corporateid,bookingType
        @output portaltype --personal/corporate  enabled or not
     */
    public function _portalTypeStatus($agencyId,$corporateId,$bookingType){
        
        $result      = $this->_OAppSetting->_getApplicationSettingsValues($agencyId, $corporateId, $bookingType);
        $searchFor   = PORTAL_TYPE;        
        $returnArray = $this->_arrayFilter($result,$searchFor);        
        return $returnArray;        
    }

    /*  @Description For getting the array based on values search
        function _arrayFilter
        @input array,searchFor
        @output return all rows of array
     */
    public function _arrayFilter($array,$searchFor){
        $filteredArray = array_filter($array, function($element) use($searchFor){
            return isset($element['setting_name']) && $element['setting_name'] == $searchFor;
        });
        return $filteredArray;        
    }

    /* @Description For taking the details of portal type for corporate and agency id
        function _portalType
        @input agencyId,corporateId,bookingType
        @output portaltype --personal/corporate  enabled or not
    */
    public function _portalType($agencyId = 0,$corporateId = 0,$bookingType = 0){
        
        $portalTypeStatusArray = $this->_portalTypeStatus($agencyId, $corporateId, $bookingType);

        //check booking type
        $bookingType  = $this->_ODBC->_select('dm_corporate',array('personal_booking_enable','corporate_booking_enable'),'corporate_id',$corporateId)[0];

        //set booking type list array
        $bookingTypeList =  ($bookingType['personal_booking_enable'] == 'Y' && $bookingType['corporate_booking_enable'] == 'Y') ? array('corporate','personal') : ($bookingType['corporate_booking_enable'] == 'Y' ? array('corporate') : array('personal'));

        $resultValue = array_column($portalTypeStatusArray,enabled,value);
        $resultValue['bookingType'] = $bookingTypeList;
        $this->_AtwigOutputArray['portStatus'] = $resultValue;
        if(empty($resultValue))
            $returnArray = array('status' => 0);
        else 
            $returnArray = array('status' => 1, 'result' => $resultValue);
        
        return $returnArray;
    }

    public function _viewSettings(){
        $fieldsArray = array('dm_agency_id', 'agency_name');
        $this->_AagencyList = $this->_OAgency->_getAgencyList($fieldsArray);
        $this->_AagencyCorporateList = array_column($this->_OAgency->_getAgencyCorporateList(), 'corporate_name', 'corporate_id');
    }

    /*  @Description For displaying the settings by loading from application_settings_value and 
        if setting not exists, insert into application_setting_value based on default corporate
        function _displaySettings
        @input agencyId,corporateId,bookingType,$settings
        @return $this->_AfinalResponse;
    */
    public function _displaySettings($agencyId = 0,$corporateId = 0,$bookingType,$settings = ''){
        
        $_AapplicationSettingList = $this->_OAppSetting->_getApplicationSettings();

        //get personal booking enabled status.
        $personalBookingStatus = $this->_ODBC->_select('dm_corporate','personal_booking_enable', 'corporate_id', $corporateId)[0]['personal_booking_enable'];
        $personalDetails = $this->_ODBC->_select('application_settings', '*', 'setting_name','PERSONAL_BOOKING')[0];
        $lastkey = array_pop(array_keys($_AapplicationSettingList));
        if($bookingType == 2 ){
            foreach ($_AapplicationSettingList as $key => $value){
                if($value['setting_name'] == 'PERSONAL_BOOKING'){
                    $value['status'] = $personalBookingStatus;
                    break;
                }
                else if($key == $lastkey){
                    $newLastKey = $lastkey + 1;
                    $personalDetails['status'] = 'N';
                    $_AapplicationSettingList[$newLastKey] =$personalDetails;
                }
            }
        }
        $searchFor = PORTAL_TYPE;

        $filteredArray = $this->_arrayFilter($_AapplicationSettingList,$searchFor);
        unset($_AapplicationSettingList[key($filteredArray)]);          
        $applicationSetingsValueArray = 
        $this->_OAppSetting->_checkAndInsertApplicationSettingsValue($agencyId, $corporateId, $bookingType,$portalType = 1,0);

        $applicationValueArray = array();
        foreach($applicationSetingsValueArray as $res){
            $applicationValueArray[$res['r_setting_id']][] = $res;
        }
        
        $applicationValueArray = $this->_incorporateExistingSettingsValue($_AapplicationSettingList, $applicationValueArray, $settings);
        
        //get logo with respect to the corporate id
        $currentLogoDetails = $this->_OAppSetting->_getUploadedLogoForCorporate($corporateId);

        $_AtwigOutputArray['agencySetting']            = $_AapplicationSettingList;
        $_AtwigOutputArray['applicationSettingValue']  = $applicationValueArray;
        $_AtwigOutputArray['logoData']                 = $currentLogoDetails;
        $_AtwigOutputArray['corporateId']              = $corporateId;
        $_AtwigOutputArray['agencyId']                 = $agencyId;
        $_SsettingDisplay = $this->_Otwig->render('applicationSettingDisplay.tpl', $_AtwigOutputArray);
        $result = array('status' => 0, 'status_message' => 'success', 'error_alert' => '', 'result' => array(), 'template' => $_SsettingDisplay);
        return $result;
    }    
    
    private function _getCorporateListForCorporate($agencyId){
        //get corporate list with respect to the agency id.
        $responseArray = $this->_OAgency->_getAgencyCorporateList($agencyId);
        if($responseArray){
            $returnArray = array('status' => 1, 'result' => $responseArray);
        } 
        else{
            $returnArray = array('status' => 0, 'result' => '', 'message' => 'Unable to load corporate details');
        }
        return $returnArray;
    }
    
    public function _incorporateExistingSettingsValue($applicationSetting,$applicationSettingDBArray,$settingsJSONArray){        

        //prepare array to identify settings id and settings name
        $settingNameArray = array_column($applicationSetting, 'setting_id', 'setting_name');        

        //prepare application setting array for accessing type
        foreach($applicationSetting as $res){
            $settingDetailsArray[$res['setting_id']] = $res;
        }
        
        foreach($settingsJSONArray as $keyjson => $keyval){
            
            if($settingDetailsArray[$settingNameArray[$keyjson]]['setting_type'] == 'R') { //RADIO INPUT
                if(is_array($keyval)) { 
                    //handle multiple values stored
                    foreach($keyval as $key => $val){
                        foreach($applicationSettingDBArray[$settingNameArray[$keyjson]] as $keydb => $keydbval){
                            if(stristr($key, $applicationSettingDBArray[$settingNameArray[$keyjson]][$keydb]['value'])){
                                $applicationSettingDBArray[$settingNameArray[$keyjson]][$keydb]['enabled'] =  $val == 'YES' ? 'Y' : 'N'; 
                            } 
                        }
                    }
                } 
                else{ 
                    //handle single values stored
                    foreach($applicationSettingDBArray[$settingNameArray[$keyjson]] as $keydb => $keydbval){
                        if(stristr($keyval, $keydbval['value'])){
                            $applicationSettingDBArray[$settingNameArray[$keyjson]][$keydb]['enabled'] =  'Y'; 
                        } 
                        else{
                            $applicationSettingDBArray[$settingNameArray[$keyjson]][$keydb]['enabled'] =  'N'; 
                        }
                    }
                }
            } 
            else if($settingDetailsArray[$settingNameArray[$keyjson]]['setting_type'] == 'CB'){ //CHECKBOX INPUT
                foreach($applicationSettingDBArray[$settingNameArray[$keyjson]] as $keydb=>$keydbval){
                    if(in_array($keydbval['value'], $keyval)){
                        $applicationSettingDBArray[$settingNameArray[$keyjson]][$keydb]['enabled'] =  'Y'; 
                    } 
                    else{
                        $applicationSettingDBArray[$settingNameArray[$keyjson]][$keydb]['enabled'] =  'N'; 
                    }
                }
            }
        }
        return $applicationSettingDBArray;
    }
    
    public function _updateApplicationData($userSettingsArray){

        $corporateId = $userSettingsArray['corporateId'];
        $agencyId    = $userSettingsArray['agencyId'];
        $bookingType = $userSettingsArray['bookingType'];
        
        unset($userSettingsArray['corporateId']);
        unset($userSettingsArray['agencyId']);
        unset($userSettingsArray['action']);
        unset($userSettingsArray['tplClassFile']);
        unset($userSettingsArray['bookingType']);
        
        $returnValue = $this->_OAppSetting->_updateApplicationSettingsData($userSettingsArray, $agencyId, $corporateId,$bookingType);        
        $returnArray = array('status' => 1, 'message' => 'Settings Updated Successfully');
        return $returnArray;
    }
    
    public function _exportApplicationSettings($userSettingsArray){
        
        $corporateId = $userSettingsArray['corporateId'];
        $agencyId    = $userSettingsArray['agencyId'];
        $bookingType = $userSettingsArray['bookingType'];
        
        unset($userSettingsArray['corporateId']);
        unset($userSettingsArray['agencyId']);
        unset($userSettingsArray['action']);
        unset($userSettingsArray['tplClassFile']);
        unset($userSettingsArray['bookingType']);

        /* Application Type 1.pesonal 2.corporate*/
        if($bookingType == 1){
            $jsonFileCreationPath = APP_BASE_PATH ."appSettings/personal/corporate<corporate_id>.json";
        }
        else if($bookingType == 2){
           $jsonFileCreationPath = APP_BASE_PATH ."appSettings/corporate/corporate<corporate_id>.json";
        }
        $settingInfo['settings']= $userSettingsArray['settings'];
        if(isset($userSettingsArray) && $userSettingsArray != ''){            
            $filePath    = str_replace('<corporate_id>', $corporateId, $jsonFileCreationPath);
            $fh          = fopen($filePath, 'w');
            chmod($filePath,0777);
            $returnValue = fwrite($fh, json_encode($settingInfo));            
        }
        $returnArray = array('status' => 1, 'message' => 'Settings Updated Successfully');
        return $returnArray;
    }

    public function _updateApplicationMapping(){

        $sql = " DELETE FROM corporate_setting_details WHERE
				corporate_id = " . $this->_IinputData['corporateId'];

        if(DB::isError($result = $this->_Oconnection->query($sql))){
            fileWrite($sql, "SqlError", "a+");
        }
        $this->_createApplicationMapping();
    }

    public function _viewMapping(){

        $sql = "SELECT
				om.organization_id,
				om.organization_name as corporate_name,
				csd.r_setting_id as setting
			FROM
				organization_master om LEFT JOIN
				corporate_setting_details csd ON om.organization_id = csd.corporate_id
				group by om.organization_id";

        if(DB::isError($result = $this->_Oconnection->query($sql))){
            fileWrite($sql, 'SqlError', 'a+');
            return false;
        }

        while($row = $result->fetchRow(DB_FETCHMODE_ASSOC)){

            if($row['setting'] != ''){
                $this->_AmappedCorporates[] = $row;
            }
            $this->_AcorporateDetails['corporateId'][] = $row['organization_id'];
            $this->_AcorporateDetails['corporateName'][] = $row['corporate_name'];
        }
        $this->_getApplicationSettingOptions();
    }

    public function _getApplicationSettingOptions(){

        $_AsettingValues = "";

        $sql = "SELECT
				ast.setting_id,
				ast.setting_name,
				ast.setting_type,
                                asd.settings_details_id,
				asd.value,
				ast.default_value
			FROM
				application_settings ast,
				application_settings_details asd
			WHERE
				ast.setting_id = asd.r_setting_id
				and ast.status = 'Y'";

        if(DB::isError($result = $this->_Oconnection->query($sql))){
            fileWrite($sql, 'SqlError', 'a+');
            return false;
        }

        $i = 0;
        while($row = $result->fetchRow(DB_FETCHMODE_ASSOC)){

            if(!in_array($row['setting_id'], $this->_Asettings)){
                $this->_Asettings[$row['setting_id']]['name'][] = $row['setting_name'];
            }
            $_AsettingValues[$row['setting_id']][$i]['value'] = $row['value'];
            $_AsettingValues[$row['setting_id']][$i]['id'] = $row['settings_details_id'];
            $i++;
        }
        $this->_AsettingValues = json_encode($_AsettingValues, true);
    }

    /**
     * @description : add logo information to table
     * @param 
     * @return int|$corporateLogoId
     */
    private function _addLogoInformation(){

        $corporateLogoId = 0;
        
        $this->common = new common();

        $ipAddress = $this->common->getIPAddress();

        $insertArray = array();
        $insertArray['r_corporate_id'] = $this->_IinputData['corporateId'];
        $insertArray['image_path']     = $this->_IinputData['uploadFiles']['logoupload1'];
        $insertArray['status']         = 'Y';
        $insertArray['ip_address']     = $ipAddress;

        $corporateLogoId = $this->_ODBC->_insert('dm_corporate_logo', $insertArray);

        if($corporateLogoId > 0){
          $updateArray['status'] = 'N';
          $sql  = " UPDATE 
                        dm_corporate_logo 
                    SET 
                        status = 'N' 
                    WHERE 
                        dm_corporate_logo_id != ".$corporateLogoId." AND r_corporate_id = ".$insertArray['r_corporate_id']."";
          $result = $this->_ODBC->_getResult($sql);
        }
        return $corporateLogoId;
    }

    private function _removeLogoInformation($logoId,$logoName){

        $returnValue = 'Unable to delet Logo';
        if($logoId > 0){

            $result = $this->_ODBC->_delete('dm_corporate_logo', 'dm_corporate_logo_id', $logoId);
            if($result){
                $filePath = LOGO_UPLOAD_PATH . $logoName;
                if(file_exists($filePath)){
                    unlink($filePath);
                    $returnValue = 'Logo deleted successfully!';
                }
            }
        }
        return $returnValue;
    }
    
    public function _permissionCheck(){

        $agencyList = 'N';
        $recieveData = $this->_OcommonQuery->_corporateAgencyPermission();
        $this->_Ocorporate->_Sstatus = 'Y';
        $this->_Aagency = array_column($recieveData['agency'], 'agency_name', 'dm_agency_id');        
        if(count($this->_Aagency) > 0){
           $agencyList = 'Y';
           $this->_AtwigOutputArray['agencyListStatus'] = $agencyList;
           $this->_AtwigOutputArray['agencyList'] = $recieveData['agency']; 
        }
        else{
            $agencyList = 'N';
            $this->_AserviceResponse['agencyListStatus'] = $agencyList;           
            $this->_AserviceResponse['agencyId'] = $_SESSION['agencyId']; 
            $agencyNameArray = array('agency_name');      
            $agencyName = $this->_ODBC->_select('dm_agency', $agencyNameArray,'dm_agency_id',$_SESSION['agencyId'])[0];  
            $this->_AserviceResponse['agencyName'] =  $agencyName['agency_name'];
        }

        if(count($recieveData['corporate']) > 0){

            if(count($recieveData['corporate']) == 1){
                $corporateList = 'N';
                $this->_AserviceResponse['corporateListStatus'] = $corporateList;
                $this->_AserviceResponse['corporateId'] = $_SESSION['corporateId'];                
                $corporateNameArray = array('corporate_name');      
                $corporateName = $this->_ODBC->_select('dm_corporate', $corporateNameArray,'corporate_id',$_SESSION['corporateId'])[0];  
                $this->_AserviceResponse['corporateName'] =  $corporateName['corporate_name'];
            }  
            else{
                $corporateList = 'Y';
                $this->_AserviceResponse['corporate'] = $recieveData['corporate']; 
                $this->_AserviceResponse['corporateListStatus'] = $corporateList; 
            }             
        }
        else{
            $corporateList = 'N';
            $this->_AserviceResponse['corporateListStatus'] = $corporateList;
            $this->_AserviceResponse['corporateId'] = $_SESSION['corporateId']; 
            $corporateNameArray = array('corporate_name');      
            $corporateName = $this->_ODBC->_select('dm_corporate', $corporateNameArray,'corporate_id',$_SESSION['corporateId'])[0];  
            $this->_AserviceResponse['corporateName'] =  $corporateName['corporate_name'];
        }
    }

    public function _templateAssign(){        
        $this->_AtwigOutputArray['agencyCorporateList'] = json_encode($this->_AagencyCorporateList);
    }    
 
    public function _getAuthenticationKey(){

        $this->_OflightItinerary = new flightItinerary();

        $result = $this->_OflightItinerary->_getEmailAndAccountInfo($this->_IinputData['pnr']);
           
        if(!empty($result)){
            // get the authenticationKey by sending accountId, emailId, sycCorporateId
            $this->autologin = new checkWSAutoLogin();
            $result['authenticationKey'] = $this->autologin->_generateAuthKey($result['account_id'], $result['email_id'], $result['syncCorporateId']);
        }      
        return $this->_AfinalResponse = $result;
    }

    public function _deleteUserLoginCredentials(){
        $updateSql = "UPDATE user_login_details SET status = 'N' WHERE login_email = '".$_SESSION['employeeEmailId']."'";
        $UpdateId =  $this->_ODBC->_getResult($updateSql);
        return true;
    }
}
?>
