<?php
/* * **************************************************************************
 * @File             : class.tpl.costCenterApprovalMappingTpl.php
 * @Description      : This file is used set cost center approvals
 * @Author           : Sivaprakash.M
 * @Created Date     : 30/05/2017
 * @Modified Date    : 
 * ****************************************************************************/
class costCenterApprovalMappingTpl
{
    public function __construct() {
        $this->_CcostCenterApproval = new costCenterApproval();
    }
    /*
     * @functionName    :   _getDisplayInfo()
     * @description     :   common module function
     */
    public function _getDisplayInfo() 
        {
        
        
            $message = '';
            $_SESSION['corporateName'] = $this->_CcostCenterApproval->_OcommonDBO->_select('dm_corporate', 'corporate_name', 'corporate_id', $_SESSION['corporateId'])[0]['corporate_name'];
            $data = '';
        switch ($this->_IinputData['action']) 
            { 
                case 'getApprovar':
        // to get the approvar for cost center code            
                    $data = $this->_CcostCenterApproval->_getCostCenterEmployeeDetails();

                    $this->_AfinalResponse = $data ? array('status' => 1, 'employeeData' => $data) : array('status' => 0);

                break;
            
                case 'deleteCostCenterApproval':
        // delete the cost center approval mapping            
                    $data['costCenterApproval'] = $this->_CcostCenterApproval->_deleteCostCenterApproval($this->_IinputData);
                    
                    $message = $this->_CcostCenterApproval->_message ? $this->_CcostCenterApproval->_message : 'Project code approval mapping not deleted successsfully';
                    
                    $this->_AfinalResponse = $this->_CcostCenterApproval->_message ? array('status' => 1,'message' => $message,'template' => $this->_Otwig->render('costCenterApproval.tpl', $data)) : array('status' => 0, 'error_alert'=> $message);

                break;     
            
                case 'overRideAndUpdateExistingCostCenterApprover':
        // to over ride the existing approvar and set new approvar for the cost center code approval mapping            
                    $overrideApprovar = $this->_CcostCenterApproval->_overRideAndUpdateExistingCostCenterApprover($this->_IinputData);
                    
                    $data['costCenterApproval'] = !empty($overrideApprovar) ? $this->_CcostCenterApproval->_getCostCenterApprovalList(array('costcenterCode'=> $this->_IinputData['costcenterCode'])) : FALSE;

                    $this->_AfinalResponse = $data['costCenterApproval'] ? array('status' => 1, 'message'=> "Existing project code approval over-ridden and updated successfully", 'template' => $this->_Otwig->render('costCenterApproval.tpl', $data)) : array('status' => 0, 'error_alert'=> 'Existing project code approval not over-ridden and updated successfully');
                    
                break;  
            
                case 'createCostCenterApprovar':
        // to create new cost center approval mapping            
                    $checkBeforeInsert = $this->_CcostCenterApproval->_checkCostCenterApprovar($this->_IinputData);
        // check the approvar already exist or any other approval is mapped to the cost center code            
                    $checkAprovar = $this->_CcostCenterApproval->_checkCostCenterApprovarValidation($this->_IinputData);
        // if exist return the approval data            
                    if(!empty($checkAprovar) && empty($checkBeforeInsert))
                    {
                        $data['costCenterApproval'] = $this->_CcostCenterApproval->_getCostCenterApprovalList(array('costcenterCode'=> $this->_IinputData['costcenterCode']));
                        return $this->_AfinalResponse = array('status' => 3, 'approverId'=> $checkAprovar[0]['approver_id'], 'message'=> 'Project code already has approval mapping are you sure want to change project code approval mapping', 'template' => $this->_Otwig->render('costCenterApproval.tpl', $data));
                    }
                    
                    $error_alert = !empty($checkBeforeInsert) ? "Project code approval already exist" : 'Project code approval mapping not inserted successfully';
        // to insert the cost center mapping data            
                    $data['costCenterApproval'] = empty($checkBeforeInsert) ? $this->_CcostCenterApproval->_createCostCenterApprovar($this->_IinputData) : $this->_CcostCenterApproval->_getCostCenterApprovalList(array('costcenterCode'=> $this->_IinputData['costcenterCode']));

                    $this->_AfinalResponse = $data['costCenterApproval'] ? array('status' => 1, 'message'=> !empty($checkBeforeInsert) ? "Project code approval already exist" : 'Project code approval inserted successfully', 'template' => $this->_Otwig->render('costCenterApproval.tpl', $data)) : array('status' => 0, 'error_alert'=> $error_alert);

                break;            
                
                default:
        // default to load the cost center code and approval mapping list in the ui            
                    $this->_costCenterDetails = $this->_CcostCenterApproval->_getCostCenterDetailsBasedOnCorporate();
                    $this->_costCenterApproval = $this->_CcostCenterApproval->_getCostCenterApprovalList();
            }
            $this->_templateAssign();
        }     
    /*
     * @functionName    :   _templateAssign()
     * @description     :   common module function
     */        
        public function _templateAssign() {
            $this->_AtwigOutputArray['costCenterApproval'] = $this->_costCenterApproval ? $this->_costCenterApproval : '';
            $this->_AtwigOutputArray['costCenterDetails'] = $this->_costCenterDetails ? $this->_costCenterDetails : '';
            $this->_AtwigOutputArray['corporateName'] = $_SESSION['corporateName'];
        }
}
?>