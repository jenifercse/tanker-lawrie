<?php
/* * **************************************************************************
 * @Class           modifyBookingListTpl
 * @Description     This class has the cancel request itinerary and passenger info
 * @Author          Karthika
 * @Created Date    25/08/2016
 * @update Date
 * @update By
 * *************************************************************************** */
fileRequire('classes/class.commonDBO.php');

class viewMenuDetailsTpl {

  

    public function __construct() {
        
        $this->_OcommonDBO=new commonDBO();
       
    }

    public function _getDisplayInfo()
    {
        
        $this->_AmenuInfo = $this->_getMenuDetails();
        $this->_templateAssign();
        
    }
    
    public function _getMenuDetails() 
    {
        $sql = "SELECT * from core_menu_details";
        $result = $this->_OcommonDBO->_getResult($sql); 
        if($result != "")
        {
            return $result;
        }
        
    }
    
    public function _templateAssign() 
    {    
       
        $this->_AtwigOutputArray['menuInfo'] = $this->_AmenuInfo;
    }
    

}

?>