<?php
/** * **************************************************************************
 * @File             : class.tpl.misc.invoiceDisplayTpl.php
 * @Description      : This file is used to view invoice 
 * @Author           : Deepak Pande
 * @Created Date     : 11/10/2018
 * @Modified Date    : 
 * *************************************************************************** */
class invoiceDisplayTpl{

    public function __construct(){
        $this->_Opassenger = new passenger();
        $this->_OcommonDBO = new commonDBO();
        $this->_Oinvoice   = new invoice();
    }
    
    /**
    * @functionName    :   _getDisplayInfo()
    * @description     :   
    */
    public function _getDisplayInfo(){
        
    	$input = $this->_IinputData;
        //get order id 
        $input['order_id'] ?  $passengerId = array_column($this->_Opassenger->_getPassengerDetails($input['order_id']),'passenger_id') : '';
        //calling eticket function based on travel mode and package type.
        count($passengerId) > 0 ? $this->_Oinvoice->_callingInvoiceDetailsFunction($passengerId,$input['order_id']) :'';
        $employeeId = $this->_OcommonDBO->_select("dm_employee","employee_code","employee_id",$_SESSION['employeeId'])[0]['employee_code'];
        //template assign function.
        $this->_templateAssign($input,$passengerId,$employeeId); 
    }
    
    /* Function name: _templateAssign
    * @Description  this function assigns the values to be sent to the template view
    * @param |array
    * @return 
    */
    public function _templateAssign($input,$passengerId,$employeeId){
        
        $this->_OgstCostCenter = new gstCostCenter();
        $this->_AtwigOutputArray['invoiceInfo'] = $this->_Oinvoice->_AinvoiceDetails;
        $this->_AtwigOutputArray['paxId'] = $passengerId;
        $this->_AtwigOutputArray['employeeId'] = $employeeId;
        $this->_AtwigOutputArray['BL_GST_NUMBER'] = BL_GST_NUMBER;
        $this->_AtwigOutputArray['orderGstDetails']  = $this->_OgstCostCenter->_getOrderGSTDetails($input['order_id']);
        filewrite(print_r($this->_AtwigOutputArray,1),'invoiceDetails'.$this->_IinputData['order_id']);
    } 
}