<?php
/* * **************************************************************************
 * @File             : class.tpl.setApprovalProcessTpl.php
 * @Description      : This file is used to set the approval
 * @Tables Affected  : approval_tracking,dm_approval_settings,approval_mapping,approval_parameter_mapping
 * @Author           : Karthika
 * @Created Date     : 08/12/2016
 * @Modified Date    : 
 * ****************************************************************************/
pluginFileRequire('common/', 'interface/commonConstants.php');


class setApprovalProcessTpl implements commonConstants{ 
    
    public function __construct(){ 
        
        $this->_OsetApproval   = common::_checkClassExistsInNameSpace('setApprovalProcess'); 
    }

    public function _getDisplayInfo(){

        $input = $this->_IinputData;
        
        // once click send to approval means , it comes to this function                   
        $approvalStatus = $this->_OsetApproval->_setApprovalProcessMethod($input);
    }
    
    // function used to send to approval for approval process.
    public function _getApprovalInfo($input,$approverType = "NA','IA','TA"){
        
        if($input['approvalCheckFor'] ==  'COMBO'){       

           $finalInfo = $this->_OsetApproval->_checkComboApprovalExist($input,$approverType); 
        }
        else{
           $finalInfo = $this->_OsetApproval->_checkApprovalExist($input,$approverType);
        }
        return $finalInfo;
    }     
}
?>