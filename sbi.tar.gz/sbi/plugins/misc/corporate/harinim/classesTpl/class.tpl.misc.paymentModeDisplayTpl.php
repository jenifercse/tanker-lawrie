<?php

/* * **********************************************************************
 * @Class Name	:   class.tpl.paymentModeDisplayTpl.php
 * @Description	:   This file is used to set data to display flight request form
 * @Author      :   Lakshmi.S
 * ************************************************************************ */

class paymentModeDisplayTpl {

    public function __construct() {
         $this->_OairRequest   = new airRequest();
         $this->_Opackage   = new package();
         $this->_Opayment   = new payment();
    }

    /*
     * @functionName    :   _getDisplayInfo()
     * @description     :   default module method
     */

    public function _getDisplayInfo() {
        
        $orderId=0;
        if($this->_IinputData['action']=='packagePayment'){
            $orderArray=$this->_Opayment->_getPackageOrderIds($this->_IinputData['packageId']);
            if(is_array($orderArray) && count($orderArray)>0){
                $orderId=$orderArray[0];
            }
        }
        else{
            $orderId=$this->_IinputData['orderId'];
        }
        if($orderId!=0){
            $travelTypeResult=$this->_Opackage->_getTravelType($orderId);
            
            if(is_array($travelTypeResult) && count($travelTypeResult)>0){
                $travelModeId=$travelTypeResult[0]['r_travel_mode_id'];
            }          
        }
        
        //define default template names avialbles
        $paymentTemplates = array('CC' => 'payment_creditcard.tpl', 'EBS' => 'payment_netdebit.tpl', 'BTA' => 'payment_bta.tpl', 'CTA' => 'payment_cta.tpl', 'CT' => 'payment_creditterms.tpl','SPG'=>'payment_sabrePaymentGateway.tpl');
        $corporateId=isset($_SESSION['corporateId'])?$_SESSION['corporateId']:$this->_IinputData['corporateId'];
        if($_SESSION['LoginType'] != 'offLinePayment') {
            $groupId=isset($_SESSION['groupId'])?$_SESSION['groupId']:$this->_IinputData['groupId'];
        } else {
            $groupId      = OFFLINE_PAYMENT_USER_GROUP;
            $travelModeId = 'OFFLINE';
        }
        $paymentOptionsArray = $this->_Opayment->_getPaymentOptions($corporateId, $groupId);
        $paymentTemplateArray = array();
        fileWrite($_SESSION['userApplicationSettings']['FARE_INCREASE_REDIRECT'],"FAREINCREASE");
        $this->_AtwigOutputArray['FARE_INCREASE_REDIRECT']=$_SESSION['userApplicationSettings']['FARE_INCREASE_REDIRECT'];
        if($_SESSION['userApplicationSettings']['FARE_INCREASE_REDIRECT']=='YES' && $orderId!=0 && ($travelModeId==1 || $travelModeId==9)){
                        
            $requestData=$this->_OairRequest->_getAirRequestDetails($orderId);
            fileWrite("RequestData:".print_r($requestData,true),"FAREINCREASE","a+");
            if(is_array($requestData) && count($requestData)>0){
                $packageId=$requestData[0]['r_package_id'];
                $packageType=0;
                $packageResult=$this->_Opackage->_getPackage($packageId,array('package_type'));
                fileWrite("packageResult:".print_r($packageResult,true),"FAREINCREASE","a+");
                if(is_array($packageResult) && count($packageResult)>0){
                    $packageType=$packageResult[0]['package_type'];
                }
                
                $orderResult=$this->_Opackage->_getOrderDetails($orderId,array('workflow_caption'));
                fileWrite("orderResult:".print_r($orderResult,true),"FAREINCREASE","a+");
                if(is_array($orderResult) && count($orderResult)>0){
                    $this->_AtwigOutputArray['orderWorkFlow']=$orderResult[0]['workflow_caption'];
                }
                $this->_AtwigOutputArray['contentId']=$requestData[0]['r_package_id'].":".$requestData[0]['r_order_id'].":".$packageType.":".$requestData[0]['travel_type'].":".$requestData[0]['trip_type'];
            }fileWrite("TwigOutputArray:".print_r($this->_AtwigOutputArray,true),"FAREINCREASE","a+");
        }
        
        $i = 1;
        foreach ($paymentOptionsArray as $key => $val) {
            if (isset($paymentTemplates[$val['payment_type_code']]) && !empty($paymentTemplates[$val['payment_type_code']])) {
                $paymentTemplateArray[$i] = array('id' => $val['payment_type_id'],'code' => $val['payment_type_code'],'name' => $paymentTemplates[$val['payment_type_code']], 'desc' => $val['payment_type_description']);
                $i++;
            }
        }
        
        $this->_AtwigOutputArray['mobileNo'] = isset($_SESSION['mobileNo'])?$_SESSION['mobileNo']:$this->_IinputData['mobileNo'];;
        $this->_AtwigOutputArray['employeeEmailId'] = isset($_SESSION['employeeEmailId'])?$_SESSION['employeeEmailId']:$this->_IinputData['employeeEmailId'];
        $this->_AtwigOutputArray['packageId'] = $this->_IinputData['packageId'];
        $this->_AtwigOutputArray['orderId'] = $orderId;
        $this->_AtwigOutputArray['travelModeId'] = $travelModeId;
        $this->_AtwigOutputArray['paymentProcessType'] = $this->_IinputData['action'];
        $this->_AtwigOutputArray['paymentoptions'] = $paymentTemplateArray;
    }

}

?>