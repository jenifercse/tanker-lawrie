<?php
/** * **************************************************************************
 * @File             : class.tpl.pendingTripApprovalListTpl.php
 * @Author           : Muruganandham.M
 * @Created Date     : 19/02/2019
 * @Modified Date    : 
 * ****************************************************************************/
class pendingTripApprovalListTpl{
    
    public function __construct(){
        $this->_objTripListDisplay = common::_checkClassExistsInNameSpace('tripListDisplay');
        $this->_OlistDisplay = common::_checkClassExistsInNameSpace('listDisplay');
        $this->_Oreport = new report();
        $this->_OcommonQuery = new commonQuery();
    }
    
    /**
     * @functionName    :   _getDisplayInfo()
     * @description     :   common module function
     */
    public function _getDisplayInfo(){
        
        $this->_AtwigOutputArray['userTypeId'] = $_SESSION['userTypeId']; 
        $_SESSION['order_id'] = $this->_IinputData['orderId'] ? $this->_IinputData['orderId'] : 0 ;

        if((isset($this->_IinputData['recordLimit']) || !isset($this->_IinputData['recordLimit'])) && $this->_IinputData['fileDownload'] != 'Y'){
            $this->_IinputData['recordLimit'] = $this->_Oreport->_recordLimit($this->_IinputData['recordLimit']);
        }
        fileWrite(print_r($this->_IinputData,1),'BASKAR','a+');
        
        $this->_IinputData['process_type'] = 'Booking';
        $this->_IinputData['r_employee_id'] = $_SESSION['employeeId'];
        $PENDINGAPPROVALBOOKINGS = $this->_objTripListDisplay->_getTripBookingsList('PENDINGAPPROVALBOOKINGS',$this->_IinputData, 'returnQuery');
        $POSTAPPROVALBOOKINGS = $this->_objTripListDisplay->_getTripBookingsList('POSTAPPROVALBOOKINGS', $this->_IinputData, 'returnQuery');
        $viewRequestData = $this->_objTripListDisplay->_getCombinedQueryResult($PENDINGAPPROVALBOOKINGS, $POSTAPPROVALBOOKINGS);
        $viewRequestData ? $viewRequestData[0]['listBookingReferences'] = $this->_objTripListDisplay->_referenceValueOfCorporate : ''; 
        $viewRequestData = $this->_OlistDisplay->_checkApprovalActionExpire($viewRequestData);
        $this->_AserviceResponse['viewRequestList'] = commonArrayFunctions::_formatSameArrayValueInArrayKey($viewRequestData);
         $this->_AserviceResponse['recordLimit'] = $this->_IinputData['recordLimit'];
         $this->_AserviceResponse['total'] = $this->_AtwigOutputArray['total'] = ($viewRequestData != '') ? sizeof($viewRequestData) : 0;
        
        // //File download by checking the flag
        if ($this->_IinputData['fileDownload'] == 'Y') {
           $this->_AserviceResponse['fileDownload'] =  $this->_objTripListDisplay->_fileDownload($action, $this->_AserviceResponse['viewRequestList'],'PENDINGAPPROVALBOOKINGS', $this->_IinputData['fileTypeId']);
         }

         // set BookingReferencePrefixString
         $this->_AtwigOutputArray["BookingReferencePrefixString"]= $this->_OcommonQuery->_getBookingReferencePrefixSting($_SESSION['corporateId']);
        $this->_AtwigOutputArray['fieldList'] = $_SESSION['permissions']['fieldList'];
         

    }
}
?>



