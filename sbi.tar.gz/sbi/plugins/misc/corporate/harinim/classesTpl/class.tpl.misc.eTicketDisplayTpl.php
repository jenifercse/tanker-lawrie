<?php
/* * **************************************************************************
 * @File            E ticket display
 * @Description     This class used to e ticket display process
 * @Author          Selvakumar.S
 * @Created Date    12/09/2016
 * @update Date     24/07/2017
 * @update By       Karthika.M
 * ****************************************************************************/
pluginFileRequire('common/', 'interface/commonConstants.php');
class eTicketDisplayTpl implements commonConstants{

    public function __construct(){
        
        $this->_OpackageDetails = new package();
        $this->_Oeticket = common::_checkClassExistsInNameSpace('eTicketMail');        
    }
    
    /* @Function name: _getDisplayInfo
     * @Description: this function is to get E-Ticket details and to assign details to template
     * @param: No param
     * @return: 
     */
    public function _getDisplayInfo(){
        $input = $this->_IinputData; 
        $_SESSION['order_id'] = $this->_IinputData['order_id'] ? $this->_IinputData['order_id'] : 0 ;
        if($input != "")
        {           
            switch ($input['action']) {
                case 'htmlGeneration':
                    $this->_AfinalResponse =  $this->_Oeticket->eTicketHtmlGeneration($input);
                    break;
                
                case 'sendEticketMail':
                    $this->_OcommonDBO = new commonDBO();
                    $this->_Oeticket->_OorderId = $input['orderId'];

                    foreach ($input['orderId'] as $key => $ordervalue){ 
                        $packageId = $this->_OcommonDBO->_select('fact_trip_order_details','r_package_id','r_order_id',$ordervalue)[0]['r_package_id'];
                        $this->_Oeticket->_AEticketDetails[$ordervalue] = $this->_Oeticket->_getEticketFlightInfo($ordervalue,$packageId);             
                    }
                    
                    $this->_AfinalResponse =  $this->_Oeticket->_sendEticket($input);
                    break;

                default:
                    $this->displayEticket($input);
                    break;
            }
        }
    }
    //calling the function for getting the eticket info based on package type.
    public function displayEticket($input){
        
        //get order id 
        $input['package_id'] ? $orderId = $this->_OpackageDetails->_getPaidPackageDetails($input['package_id'], '', 'ticketed') : '';
        $input['order_id'] ? $orderId = $this->_OpackageDetails->_getPaidPackageDetails('', '', 'ticketed', $input['order_id']) : '';
        
        //calling eticket function based on travel mode and package type.
        count($orderId) > 0 ? $this->_Oeticket->_callingEticketFunctionByMode($input,$orderId) :'';
        
        //template assign function.
        return $this->_templateAssign($input);
    }   

    
    /* Function name: _templateAssign
     * @Description  this function assigns the values to be sent to the template view
     * @param |array
     * @return 
     */     
    public function _templateAssign($input){        

        global $CFG;
        $this->_AtwigOutputArray['eTicketAction'] = $input['package_type'];
        $this->_AtwigOutputArray['eticketInfo'] = $this->_Oeticket->_AEticketDetails;
        $this->_AtwigOutputArray['pluginName'] = OVERRIDE_PACKAGE_NAME;       
        $this->_AtwigOutputArray['orderId'] = $this->_Oeticket->_OorderId;
        $this->_AtwigOutputArray['eticketType'] = 'SBT';
        $this->_AtwigOutputArray['eticketContent'] = $this->_Oeticket->_eticketContent;
        $this->_AtwigOutputArray['buttonStatus'] = 'Y';
        $this->_AtwigOutputArray["BookingReferencePrefixString"]= $this->_Oeticket->_SbookingPrefixSting;  
        $this->_AtwigOutputArray['ltcFare']= $this->_Oeticket->_AltcFareType;
    } 
}
?>
