<?php
/* * *****************************************************************************
 * @class           sync
 * @author          karthika.M
 * @created date    31-10-2018
 * @description     added for ongc customization
 * ***************************************************************************** */
namespace ongc;

fileRequire('classes/class.sync.php');

class sync extends \sync{

    public function __construct(){
        parent::__construct();
    }
    
    public function putOfflineCancellation($request){
        
        fileWrite("request Data".print_r($request,1),"offlineRES","a+");  
        $cancelDetails = $request['data']['cancelDetails'];
        
        //get order details.
        $orderDetails = $this->_getOrderPNRDetails($cancelDetails['pnr'],$cancelDetails['orderId'],$cancelDetails['corporateId'])[0];
        
        //check the booking status.
        if($orderDetails['r_booking_status_id']!=NOTHING_REQUESTED){ //No request raised for cancellation
            $response = array('response' => 'FAILED', 'data' => '', 'message' => 'Cancellation already in process');
        } else if($orderDetails['date_depature'] < date("Y-m-d H:i:s")){ // Departure date already passed
            $response = array('response' => 'FAILED', 'data' => '', 'message' => 'Cancellation not Possible. Flight already departed.');
        }  else if($orderDetails['date_depature'] < date("Y-m-d H:i:s", strtotime('+2 hours'))){ // Departure date time about to come with in 2Hrs
            $response = array('response' => 'FAILED', 'data' => '', 'message' => 'Cancellation not Possible. Within 2Hrs to departure, flight can not be cancelled.');
        }
        else{
            try{
                //initiate cancellation
                $input = array('pnr' => $cancelDetails['pnr'], 'order_id' => $orderDetails['r_order_id'], 'cancelReason' => $cancelDetails['cancellationRemarks']);
                $this->_OcommonServices->_SagentEmailId = $cancelDetails['agentEmail'];
                $cancelresponse = $this->_OcommonServices->_onlineCancellationProcess($input,'Offline');
                //error is there,
                if($cancelresponse['errorStatus'] == 'Y'){
                    $message = $cancelresponse['message'];
                    $response = 'FAILED';
                    $_ArequestData = array();
                }        
                else{
                    //forming the sync details.
                    $this->_Ocancellation = new \cancellation();
                    $_ArequestData = $this->_Ocancellation->_getCancellationSyncReqInfo($this->_OcommonServices->_cancellationId);        
                    $_ArequestData['cancellationRemarks'] = $cancelDetails['cancellationRemarks'];      
                    $_ArequestData['employeeRemarks'] = $cancelDetails['employeeRemarks'];       
                    $_ArequestData['approverDetails'] = $cancelDetails['approverDetails'];      
                    $_ArequestData['corporateId'] = $cancelDetails['corporateId'];      
                    $_ArequestData['agentEmail'] = $cancelDetails['agentEmail'];      
                    $_ArequestData['syncCorporateId'] = $this->db->_select('agency_corporate_mapping','sync_corporate_id','corporate_id',$cancelDetails['corporateId'])[0]['sync_corporate_id'];
                    $message = 'Cancellation done successfully';
                    $response = 'SUCCESS';
                }
            } 
            catch(Exception $ex){
                $message = $ex->getMessage();
                $response = 'FAILED';
                $_ArequestData = array();
            }
            //set the response array.
            $response = array('response' => $response, 'data' => $_ArequestData, 'message' => $message);
        }        
        return $response;
    }
}