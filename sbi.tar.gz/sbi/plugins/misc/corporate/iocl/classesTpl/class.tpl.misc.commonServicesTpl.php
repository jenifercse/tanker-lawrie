<?php
/**
 * @File             : class.tpl.commonServicesTpl.php
 * @Author           : sivaprakash
 * @Created Date     : 21/02/2019
 * @Modified Date    :
 */
namespace iocl;

pluginFileRequireByTravelMode('classesTpl/class.tpl.misc.commonServicesTpl.php', true);

class commonServicesTpl extends \commonServicesTpl{

    public function __construct() {

        parent::__construct();

    }


    /**
     * used to update the trip status onces its send to ticket approver
     * @param $packageId
     * @return array
     * @author Rajesh U
     */

     public function _updateTripStatus($packageId){
        $updateStatus = $this->_OtripCreation->_updateStatusWhileTicketApprove($packageId);
        return true;
    }
}