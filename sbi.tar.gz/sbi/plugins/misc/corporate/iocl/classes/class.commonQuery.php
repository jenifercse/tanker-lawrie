<?php
/* * **************************************************************************
 * @Class           commonQuery
 * @Description     This class file contains methods with commonly used queries
 * @Author          Baskar
 * @Created Date    30 Mar 2019
 * *************************************************************************** */
namespace iocl;

pluginFileRequireByTravelMode('classes/class.commonQuery.php', true);

class commonQuery extends \commonQuery{

    public function __construct(){
        parent::__construct();
    }

    //function to override and get aggregate for the corporate 
    public function _getAggregateData($factEmployeeId,$guestBookingFlag,$flowtype){
        // array formation for higher aggregate
        global $CFG;
        $higherBandAggregate = array('AJ');
        $regularizationFlag = true;
        if(in_array($_SESSION['loginEmail'],$CFG['offlineEmailId'])){
             $regularizationFlag = false;
        }
        $aggregateData['aggregate_name'] = implode(",", $higherBandAggregate);
        $aggregateData['r_corporate_id'] = $_SESSION['r_corporate_id'];
        fileWrite('IOCL $guestBookingFlag'.print_r($guestBookingFlag,'1'),'baskarSTART','a+');
        fileWrite('IOCL $guestBookingFlag'.print_r($flowtype,'1'),'baskarSTART','a+');
        
        if(!$guestBookingFlag && ($flowtype == 'NG' || $flowtype == '') && $regularizationFlag){
           $aggregate =  $this->_getAggregate->_checkEmployeeAggregateForSettings($factEmployeeId);
           $aggregate = implode(',',array_column($aggregate,'r_aggregate_id'));
        }elseif($guestBookingFlag && ($flowtype == 'NG' || $flowtype == '') && $regularizationFlag){
           $aggregate =  $this->_getAggregate->_checkEmployeeAggregateForSettings($factEmployeeId);
           $aggregate = implode(',',array_column($aggregate,'r_aggregate_id'));
        }
        else{
            $aggregate = $this->_getAggregate->_getAggregate($aggregateData);
            $aggregate = implode(',',array_column($aggregate,'aggregate_id'));
        }
        fileWrite('IOCL $aggregate'.print_r($aggregate,'1'),'baskarSTART','a+');
        return $aggregate;
        
    }
    /*
    * @Description function used to set the reload to view travel request for iocl corporate 
    */
    public function _getCorporateFlag()
    {
        return $corporate = 'Y';   
    }

    public function _setCabinClass($cabinClass){
        $cabinclassArray = array();
        switch ($cabinClass) {
             case 'E':
                 $cabinclassArray = array(0=>'E',1=>'P');
                 break;
             case 'B':
                 $cabinclassArray = array(0=>'B');
                 break;
             case 'P':
                 $cabinclassArray = array(0=>'P');
                 break;
             default:
                 break;
         }

        return $cabinclassArray;
    }

    public function _sendMailRequestPerson($orderId,$message){
        return true;
    }
}