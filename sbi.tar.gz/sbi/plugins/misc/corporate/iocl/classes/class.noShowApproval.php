<?php
/* 
 * @File            create Agency class file
 * @Description     This class file holds all approval related functionalities
 * @Author          Puroskhan.M
 * @Created Date    14/03/2018
 * @Tables used     fact_approval_mapping, 
*/


namespace iocl;

pluginFileRequireByTravelMode('classes/class.noShowApproval.php', true);

class noShowApproval extends \noShowApproval
{
  public function __construct()
  {
   parent::__construct();     
  }
  
  public function _callStatusUpdateNoShow($orderId,$noShowId =''){
      $this->_OssbtToSAP = new \ssbtToSAP();
      $data['order_id'] = $orderId;
      $data['noShowId'] = $noShowId !='' ? $noShowId : '';
      $response = $this->_OssbtToSAP->_updateTicketStatusToSap($data,'NOSHOW');
      $this->_OssbtToSAP->updateTicketStatusWs($response['response'],$response['insertId']);
      return true;
  }

  /* 
     * @Function Name             : _checkNoShowSameApprovalExits
     * @Description               : this function used to check same approval exits(NA==IA)
     * @Author                    : Rajesh U
     * @Created Date              : 17/06/2019
     */

  public function _checkNoShowSameApprovalExits($noShowapprovalIds){

    $sameApproval = count($noShowapprovalIds) > 1 && $noShowapprovalIds[0] == $noShowapprovalIds[1] ? 'Y' : 'N' ;
    return $sameApproval;
  }

}
?>