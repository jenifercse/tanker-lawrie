<?php
/* * **************************************************************************
 * @Class           approvalProcess
 * @Description     
 * @Author          Deepak P
 * @Created Date    19/03/2019
 * *************************************************************************** */

namespace iocl;

pluginFileRequireByTravelMode('misc/corporate/harinim/classes/class.approvalProcess.php', true);

class approvalProcess extends \approvalProcess{ 

    public function __construct(){
        
        parent::__construct();
    }

    /**
     * _sendMailForApprovar to send mail for approval
     * @param type $mailInfo
     * @param type $tplName
     * @return array
     */
    public function _sendMailForApprovar($mailInfo, $tplName) {

            $this->_Otwig = init();

        foreach($mailInfo['email_id'] as $key => $val){
            
            // set url and server path
            $url            = HTTP_HOST;
            $serverProtocol = HTTP_TYPE;

            $fieldArray = array('employee_id','title','first_name','last_name');
            $approverDetails = $this->_Oemployee->_getEmployeeByEmail($val,$fieldArray);
            
            // assign the url for approval process 
            $this->_assignTempleteValue($approverDetails, $mailInfo, $key, $val, $serverProtocol, $url);
            $_SmailContent = $this->_Otwig->render($tplName, $this->_AtwigOutputArray);
            
            $this->_OtripCreation = new \tripCreation();

            $tripStatus = $this->_OtripCreation->_getTripDetailsOrderPackage('',$mailInfo['order_id'])[0]['r_status_id'];

            (isset($mailInfo['checkTripApproveStatus']) && $tripStatus == TRIP_SEND_FOR_APPROVAL && $mailInfo['checkTripApproveStatus'] =='Y' && $mailInfo['mailType'] !== 'I') ? $this->_insertMailLogInfo($mailInfo['order_id'],$val,$mailInfo['subject'],$_SmailContent) : $this->_OcommonMethods->_sendMail($val,'support@atyourprice.in',$mailInfo['subject'],$_SmailContent);
            
        }   
        return $mailResponse;        
    }

    //function for insert mail log
    public function _insertMailLogInfo($orderId,$mailto,$subject,$content){

        $this->_OmailLog = new \mailLog();

        $this->_OmailLog->_logMail($mailto,'',$subject,$content,'','','',$orderId);

        return TRUE;


    }

    //function for sending the mail to the approver 

    public function _sendMailToApprover($orderIds){

        foreach ($orderIds as $key => $value) {

            $this->_getmailApproverInfo($value['order_id'],$value['approval_type']);

            $this->_checkApprovalUpdate($value['order_id'],$value['approval_type'],$value['approval_status']);

        }

        return TRUE;

    }

    //function to get and send mail to approver after the trip is approved
    public function _getmailApproverInfo($orderId,$tripApprovalStatus){
        
        fileWrite("orderId" . $orderId ,'TicketApprovalInfo','a+');

        $sql = "SELECT ml.mail_to,uncompress(ml.mail_contents) as mailContents,ml.mail_subject 
                FROM mail_log ml 
                WHERE ml.r_order_id = ".$orderId. " AND ml.mail_sent_status = 'N'";

        $mailInfoResult = $this->_OcommonDBO->_getResult($sql)[0];

        if($mailInfoResult){
            $updateArray['approve_sent_date'] = date('Y-m-d H:i:s');
            $this->_OcommonDBO->_update('approval_tracking',$updateArray,'r_order_id',$orderId);
        }
        if($tripApprovalStatus == 1 && $mailInfoResult ){
           $this->_updateApprovalDetails($orderId);
        }

        $_SmailContent = base64_decode($mailInfoResult['mailContents']);
        $this->_OcommonMethods->_sendMail($mailInfoResult['mail_to'],'support@atyourprice.in',$mailInfoResult['mail_subject'],$_SmailContent);
        $updateValue['mail_sent_status'] = 'Y';
        $this->_OcommonDBO->_update('mail_log',$updateValue,'r_order_id',$orderId);
        if($mailInfoResult){
            $this->_approvalSMSArrayFormation($orderId);
        }
        return TRUE;
    }

    public function _setMessageForReject($overrideMsg,$approverId,$workFlow){
        $rejectMessage['rejectMessage'] ='Booking is sent for reconsideration. Mail has been successfully sent to the passenger(s).';
        $rejectMessage['subject'] = "Booking Reconsider for Booking ID ";
        $rejectMessage['message'] = "Your booking has been reverted for reconsideration by ";
        $rejectMessage['button'] = "reconsider";
        if($workFlow == CMP_TICKET_APPROVAL){
            $rejectMessage['ApproveSubject'] = "Your booking has been approved ".$overrideMsg."by ".$approverId.".";
        }
        else{
            $rejectMessage['ApproveSubject'] = "Your booking has been approved ".$overrideMsg."by ".$approverId.".  To book the ticket, please log on to the SBT and proceed for ticket booking within 12 hours from the approved time";
        }
        return $rejectMessage;
    }

     /**
    * @Description : this function used to check the approval and controlling officer is same or not
    * @param int $controllingOfficerId
    * @author Rajesh U 
    * @date  22-06-2019
    */

    public function _checkSameTicketApprovalExits($controllingOfficerId,$orderId){

        $approvalAcountId = $this->_OcommonDBO->_select('approval_tracking','approver_id',array('r_order_id','process_type','approval_type'),array($orderId,'Booking','NA'))[0]['approver_id'];
        $checkSameApprovalExits = $controllingOfficerId == $approvalAcountId ? 'Y' : 'N';

        return $checkSameApprovalExits;

    }
     /**
    * @Description : this function used to send sms to ticket approval while approval mail has send
    * @param int $orderId
    * @author Rajesh U 
    * @date  01-07-2019
    */

    public function _approvalSMSArrayFormation($orderId){

        $orderInfo = $this->_OcommonDBO->_select('booking_history','*','order_id',$orderId)[0];

        $orderInfo['orderMailInfo'] = $this->_OcommonQuery->_orderMailInfo($orderId);

        $approvalId = array($this->_OcommonDBO->_select('approval_tracking','*',array('r_order_id','approval_type'),array($orderId,'NA'))[0]['approver_id']);

        $this->_OsendSms->_sendMessagetoApprover($orderInfo,$approvalId);

        return true;

    }

    /**
    * @Description : update the approval status once reconsider booking is send to approval again
    * @param string $ordeId
    * @author Rajesh U 
    * @date  14-06-2019
    */

     public function _updateApprovalDetails($orderId){

        $sql = " UPDATE 
                    order_details od 
                INNER JOIN approval_tracking apt ON od.order_id = apt.r_order_id
                SET 
                    apt.approval_expired_status = 'N',
                    apt.approval_view_status = 'N',
                    apt.approve_sent_date = '".date('Y-m-d H:i:s')."',
                    od.approval_level = '1',
                    od.approval_status = " .POSTAPPROVAL_NOT_APPROVED_BOOKINGS. " WHERE od.order_id = " .$orderId;

        $this->_OcommonDBO->_getResult($sql);

        return true;
    }


    /**
    * @Description : update the approval status once reconsider booking is send to approval again
    * @param string $ordeId
    * @author Rajesh U 
    * @date  14-06-2019
    */

     public function _updateTripRejected($orderId){
        $sql = " UPDATE 
                    trip_request_details trd 
                INNER JOIN fact_trip_order_details ftod ON trd.trip_request_details_id = ftod.r_trip_request_details_id
                SET 
                    trd.r_status_id = " .TRIP_REJECTED. " WHERE ftod.r_order_id = " .$orderId;
        $this->_OcommonDBO->_getResult($sql);
        // get Trip Id 
        $tripId = $this->_OcommonDBO->_select('fact_trip_order_details','r_trip_request_details_id','r_order_id',$orderId)[0]['r_trip_request_details_id'];
       $this->_OssbtToSAP = new \ssbtToSAP();
       $this->_OssbtToSAP->_insertSAPRequestInfo($tripId);
       return true;
    }

      /**
    * @Description : funtion is used to upadte SAP approve or reject to SAP
    * @param string $ordeId
    * @author Baskar.V.P
    * @date  14-06-2019
    */

    public function _sapUpdateApproveReject($orderId){
       $orderTicketStatus = $this->_OcommonDBO->_select('order_details',array('workflow_caption','r_ticket_status_id','approval_status'),'order_id',$orderId)[0];
       $sqlData = "SELECT approval_type FROM  trip_request_details trd INNER JOIN fact_trip_order_details ftod ON ftod.r_trip_request_details_id = trd.trip_request_details_id WHERE r_order_id =  ".$orderId." AND ftod.trip_sap_sync_status = 'N'";
       $approvalType = $this->_OcommonDBO->_getresult($sqlData)[0]['approval_type']; 
       if($orderTicketStatus['r_ticket_status_id'] == TICKETTED && $approvalType == 1){
            $this->_OssbtToSAP = new \ssbtToSAP();
            $input['order_id'] = $orderId;
            if($orderTicketStatus['approval_status']=='2'){
                $input['action'] = 'APPROVE';
                $input['status'] = 'A';
                $response = $this->_OssbtToSAP->_updateTicketStatusToSap($input);
                $this->updateFactSapSyncStatus($input['order_id']);
            }
            else if($orderTicketStatus['approval_status']=='3'){
                $input['action'] = 'REJECT';
                $input['status'] = 'X';
                $response = $this->_OssbtToSAP->_updateTicketStatusToSap($input);
            }
            else if($orderTicketStatus['approval_status']=='' && $orderTicketStatus['r_ticket_status_id'] == 8){
                $input['action'] = 'APPROVE';
                $input['status'] = 'A';
                $response = $this->_OssbtToSAP->_updateTicketStatusToSap($input);
                $this->updateFactSapSyncStatus($input['order_id']);
            }
            else if($orderTicketStatus['approval_status']== POSTAPPROVAL_NOT_APPROVED_BOOKINGS || $orderTicketStatus['approval_status'] == WAITING_FOR_TRIP_APPROVAL){
                $input['action'] = 'PENDINGAPPROVE';
                $input['status'] = 'Y';
                $response = $this->_OssbtToSAP->_updateTicketStatusToSap($input);
            }
            $this->_OssbtToSAP->updateTicketStatusWs($response['response'],$response['insertId']);
       }
    }

    public function _checkApprovalUpdate($orderId,$approvalType,$approvalStatus){
        if($approvalType == 1){
            $sqlSelect = "SELECT * FROM approval_tracking WHERE r_order_id =".$orderId." AND approval_type = 'NA'";
            $checkApprovalTracking = $this->_OcommonDBO->_getResult($sqlSelect);
            if(!$checkApprovalTracking && $approvalStatus == POSTAPPROVAL_REJECTED_BOOKINGS){
                 $sql = "UPDATE order_details od
                       SET od.approval_status = '' WHERE od.order_id  = ".$orderId." AND od.approval_status = " . POSTAPPROVAL_REJECTED_BOOKINGS;
                $this->_OcommonDBO->_getResult($sql);
            }else if($checkApprovalTracking && $approvalStatus == POSTAPPROVAL_REJECTED_BOOKINGS){
                $sql = "UPDATE order_details od INNER JOIN approval_tracking at  ON at.r_order_id = od.order_id
                       SET od.approval_status = '1',at.approval_view_status = 'N',od.approval_level = '1' WHERE od.order_id  = ".$orderId." AND od.approval_status = " . POSTAPPROVAL_REJECTED_BOOKINGS;
                $this->_OcommonDBO->_getResult($sql);
            }
        }
        return true;
    }

    public function updateFactSapSyncStatus($orderId)
    {
        $sql = "UPDATE fact_trip_order_details 
                       SET trip_sap_sync_status = 'Y' WHERE r_order_id  = ".$orderId;
        $this->_OcommonDBO->_getResult($sql);
        return true;
    }
}
?>