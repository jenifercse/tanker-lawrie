<?php
fileRequire('plugins/payment/corporate/harinim/abstract/class.paymentGateway.php');
fileRequire('lib/common/commonMethods.php');
/* * ****************************************************************************************
 * @File             : class.pgHdfc.php
 * @Description      : This file is used to handle Bill Desk payment gateway request and response
 * 
 * @Author           : Taslim
 * @Created Date     : 12/06/2018
 * @Modified Date    : 
  /* * ************************************************************************************* */

class pgBillDesk extends paymentGateway {

    public function __construct() {

        ### call the parent construct
        parent::__construct();

        ### define PG type and PG name
        $this->_SPGTYPE         = 'BILLDESK_PG';
        $this->_SpayGatewayName = 'Bill Desk';

        ### if payment mode is not set set from config file
        if(!isset($this->_SPaymentMode)) {
            $this->_SPaymentMode = BDESK_PG_MODE;
        }

        //if (strtolower($this->_AFPPayMode) == 'live') {
	if (strtolower($this->_SPaymentMode) == 'production') {
            ### for production
            $this->_SmerchantId        = BILLDESK_PG_MERCHANT_ID;
            $this->_SsecurityId        = BILLDESK_PG_SECURITY_ID;
            $this->_SPaymentRequestURL = BILLDESK_PAYMENT_URL;
            $this->_SSecretKey         = BILLDESK_PG_SECRET_KEY;
        } else {
            ### for test environment 
            $this->_SmerchantId        = BILLDESK_PG_TEST_MERCHANT_ID;
            $this->_SsecurityId        = BILLDESK_PG_TEST_SECURITY_ID;
            $this->_SPaymentRequestURL = BILLDESK_PAYMENT_TEST_URL;
            $this->_SSecretKey         = BILLDESK_PG_SECRET_TEST_KEY;
        }

        fileWrite('Payment Mode:'.$this->_SPaymentRequestURL, 'BillDesk','a+');

        
    }

    /**
     * @Description : Function is used to prepare non seamless post array to Bill Desk
     * @param :array | $inputArray
     * @return array | $paymentDetailsArray
     */
    public function preparePGNonSeamlessPostArray($inputArray, $paymentAmount = '') {

       $pgPostArray = array();
        
        $pgPostArray['MerchantID']      = $this->_SmerchantId;
        $pgPostArray['CustomerID']      = $inputArray['payment_id'];
        $pgPostArray['Filler1']         = 'NA';
        $pgPostArray['TxnAmount']       = round($paymentAmount, 2);
        $pgPostArray['BankID']          = 'NA';
        $pgPostArray['Filler2']         = 'NA';
        $pgPostArray['Filler3']         = 'NA';
        $pgPostArray['CurrencyType']    = 'INR';
        $pgPostArray['ItemCode']        = 'NA';
        $pgPostArray['TypeField1']      = 'R';
        $pgPostArray['SecurityID']      = $this->_SsecurityId;
        $pgPostArray['Filler4']         = 'NA';
        $pgPostArray['Filler5']         = 'NA';
        $pgPostArray['TypeField2']      = 'F';
        $pgPostArray['AdditionalInfo1'] = $inputArray['mobile'];
        $pgPostArray['AdditionalInfo2'] = $inputArray['email_id'];
        $pgPostArray['AdditionalInfo3'] = $inputArray['action'] ? $inputArray['action'] : 'NA';
        $pgPostArray['AdditionalInfo4'] = 'NA';
        $pgPostArray['AdditionalInfo5'] = 'NA';
        $pgPostArray['AdditionalInfo6'] = 'NA';
        $pgPostArray['AdditionalInfo7'] = 'NA';
        $pgPostArray['RU']              = BILLDESK_PAYMENT_CALLBACK_PERSONAL_URL;
        $pgPostArray['Checksum']        = $this->_generatePaymentHash($pgPostArray);

        $paymentDetailsArray['msg'] = implode("|", $pgPostArray);
        return $paymentDetailsArray;
    }

    /**
     * @Description :Function is used to generate HDFC payment gateway Hash
     * @param :array | $pgPostArray
     * @return string | $checksum
     */
    public function _generatePaymentHash($pgPostArray,$overWriteKey ='') {
       
        $secretKey =  $overWriteKey != '' ?  $overWriteKey : $this->_SSecretKey; 
        $hashStr  = implode("|", $pgPostArray);
        $checksum = hash_hmac('sha256', $hashStr, $secretKey,false);
        $checksum = strtoupper($checksum);

        return $checksum;
    }

    /**
     * @Description : Function to check if the mandaotry value exists
     * @param       : array | $postArray
     * @return      : boolean | $responseValue
     */
    protected function _checkPGMandatoryValueExists($postArray) {

        $responseValue = true;

        return $responseValue;
    }

    /**
     * @Description : Function to check the response checksum
     * @param       : array | $responseArray
     * @return      : string | $paymentHash
     */
    public function _checkResponseCheckSum($responseArray) {

        ### Re-construct checksum from the respone value
        $checkSumArray = array();

        $checkSumArray['MerchantID']      = $responseArray[0];
        $checkSumArray['CustomerID']      = $responseArray[1];
        $checkSumArray['Filler1']         = 'NA';
        $checkSumArray['TxnAmount']       = $responseArray[4];
        $checkSumArray['BankID']          = 'NA';
        $checkSumArray['Filler2']         = 'NA';
        $checkSumArray['Filler3']         = 'NA';
        $checkSumArray['CurrencyType']    = $responseArray[8];
        $checkSumArray['ItemCode']        = 'NA';
        $checkSumArray['TypeField1']      = 'R';
        $checkSumArray['SecurityID']      = $this->_SsecurityId;
        $checkSumArray['Filler4']         = 'NA';
        $checkSumArray['Filler5']         = 'NA';
        $checkSumArray['TypeField2']      = 'F';
        $checkSumArray['AdditionalInfo1'] = $responseArray[16];
        $checkSumArray['AdditionalInfo2'] = $responseArray[17];
        $checkSumArray['AdditionalInfo3'] = 'NA';
        $checkSumArray['AdditionalInfo4'] = 'NA';
        $checkSumArray['AdditionalInfo5'] = 'NA';
        $checkSumArray['AdditionalInfo6'] = 'NA';
        $checkSumArray['AdditionalInfo7'] = 'NA';
        $checkSumArray['RU']              = BILLDESK_PAYMENT_CALLBACK_PERSONAL_URL;

        $paymentHash = $this->_generatePaymentHash($checkSumArray);

        return $paymentHash;
    }

    /**
     * @Description : Function to handle the response code
     * @param       : mixed | $responseCode
     * @return      : string | $responseMsg
     */
    public function _handleResponseCode($responseCode) {

        #### handle Bill desk response code

        switch ($responseCode) {
            ### success response code
            case '0300' :
                $responseMsg = 0;
                break;

            ### failure, Error condition, Pending/Abandoned, Error at Bill Desk
            case '0399':
            case 'NA'  :
            case '002' :
            case '001' :
                $responseMsg = 1;
                break;

            ### other cases
            default:
                $responseMsg = 1;
        }

        return $responseMsg;
    }

    /**
     * @Description : Function to handle the response code
     * @param       : int   | $customerId // order id or package id
     * @return      : mixed | $response
     */
    public function _getTransactionStatus($customerId) {
        
        $requestArray['RequestType'] = "0122";
        $requestArray['merchantId']  = (BDESK_PG_MODE == 'TEST') ? BILLDESK_PG_TEST_MERCHANT_ID : BILLDESK_PG_MERCHANT_ID; // live details 
        $requestArray['customerId']  = $customerId;
        $requestArray['timestamp']   = date('YmdHis');
        $requestArray['Checksum']    = $this->_generatePaymentHash($requestArray);
        
        filewrite("API_RequestDetails : ".print_r($requestArray,1),"queryAPILogs","a+");
        
        
        $request ='msg='.implode('|', $requestArray); // bill desk payment request

        
        filewrite("API_RequestDetails : ".print_r($request,1),"queryAPILogs","a+");

        $_OCommon = new commonMethods();
        $response = $_OCommon->_curlRequest(BILLDESK_PAYMENT_QUERY_API_URL, 'POST', $request, 'urlEncoded');
        
        filewrite("API_Response : ".print_r($response,1),"queryAPILogs","a+");
        return $response;
        
    }

    /**
     * @Description : Function to generate checksum from the received payment response
     * @param       : string   | $msg 
     * @return      : mixed | $response
     */

    public function _responseCheckSumFormation($msg){

        $common_string = $this->_SSecretKey;

        $code = substr(strrchr($msg, "|"), 1); //Last check sum value

        fileWrite(print_r($code,1),'billDeskPaymentResponse','a+');

        $string_new=str_replace("|".$code,"",$msg);//string replace : with empy space

        fileWrite('string_new'.print_r($string_new,1),'billDeskPaymentResponse','a+');

        $checksum = strtoupper(hash_hmac('sha256',$string_new,$common_string, false));

        fileWrite('checksum :'.print_r($checksum,1),'billDeskPaymentResponse','a+');

        return $checksum;


    }

    /* 
     * @Description : check and insert bill desk payment response (server response)
     * @Param       : --
     * @return      : INT | updatedresponse
     */
    public function _inserBillDeskServerResponse($recievedDataFromServer){

        $updateArray = array();
        $_ApaymentDetails = explode("|", $recievedDataFromServer['msg']);
        $_IpaymentId = $_ApaymentDetails[1];

        //update server response in pg_payment_details
        $updateArray['server_response_data'] = $recievedDataFromServer['msg'];
        $this->db->_update('pg_payment_details', $updateArray, 'r_request_id', $_IpaymentId);

        //update server response in payment_details
        $updatePaymentDetails['payment_response'] =  json_encode($recievedDataFromServer);
        $this->db->_update('payment_details', $updatePaymentDetails, 'payment_id', $_IpaymentId);

        return TRUE;        
    }
    
    /* 
     * @Description : check and insert bill desk payment response (server response)
     * @Param       : --
     * @return      : INT | updatedresponse
     */
    public function _checkBillDeskServerResponse($transactionId){
         $requestData = $this->db->_select('pg_payment_details',array('server_response_data'),'pg_payment_details_id',$transactionId)[0]['server_response_data'];
         fileWrite("Before decode------> ".print_r($requestData,1),"billDeskPaymentResponsePersonal","a+");
        return $requestData;//json_decode($requestData,1);
    }

}
