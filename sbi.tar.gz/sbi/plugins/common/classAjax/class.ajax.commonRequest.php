<?php
/* * **********************************************************************
 * @Class Name	: class.ajax.commonRequest
 * @Created on	: 2016-07-11
 * @Created By	: Taslim
 * @Updated By  : --
 * @Update Info : -- 
 * @Description	: This handles common ajax request and functionality
 * ************************************************************************ */
fileRequire('classes/class.baseModule.php');

class commonRequest {
    
    ### Class variables
    var $_Aresponse=array();
    var $_SpluginName='common';
    
    ### constructor to initialize the varable
    public function __construct() {
        
        $this->_OBaseModule = new baseModule;
        
        $this->_Aresponse['status'] = array('status_code'    => 0, 
                                            'status_message' => 'success', 
                                            'error_alert'    => 'Response sent successfully');
        $this->_Aresponse['result'] = '';
        
    }
    
    /*
     * @Description : call Ajax function to include classTpl dynamica
     * @param 
     * @return
     */
    public function _callAjaxFunction() {
        
        if($this->_StplClassName!=''){
            
            ### assing default plugin path as class tpl path ###
            $classTplPath   = DEFAULT_PLUGIN_FOLDER;
            
            ### if details package name is not as default plugin name then append package name to plugin name ###
  
            if($this->_SpackageName != DEFAULT_PLUGIN_FOLDER){
                $classTplPath    = PLUGIN_NAME.$this->_SpackageName;
                $secClassTplPath = SECONDARY_PLUGIN_NAME.$this->_SpackageName;
            }
            
            ### to check if override package name exists for class tpl files ###
            $this->_OBaseModule->_getOverridePackageName();
            
            
            ### if sub-modules are set redirect to sub-module path else look in main directory ###
            
            $_SclassPropertiesArray = explode(".", $this->_StplClassName);
            $_IclassPropertiesCount = count($_SclassPropertiesArray);
            
            if($_IclassPropertiesCount == 2) {
                 $_SSubModulePath   = $_SclassPropertiesArray[0].'/';
                 $classestplName    = $_SclassPropertiesArray[1];
                 $classNameWithPath = $this->_StplClassName;
            } else {
                $classNameWithPath  = $this->_StplClassName;
                $classestplName     = $this->_StplClassName;
                $_SSubModulePath    = '';
            }
            
            ### check multple plugin path settings exists and overide 
            ### the namespace which exists according to priority
            $this->_OBaseModule->checkFileExistsinOverRidePluginMultiple($_SSubModulePath, $classestplName, $classNameWithPath);
            
            ### conditon added to include overridden class tpl file ###
            if ($this->_OBaseModule->_BOverRidePlugin && pluginFileRequireBasic($_SSubModulePath . $this->_OBaseModule->_SoverRidePluginPathName . '/', "classesTpl/class.tpl." . $classNameWithPath . ".php")) {
                $className = $this->_OBaseModule->_SoverRidePackageName.'\\'.$classestplName;
            } else if (pluginFileRequireBasic($_SSubModulePath . $classTplPath . '/', "classesTpl/class.tpl." . $classNameWithPath . ".php")) {
                $className = $classestplName;
            } else if (pluginFileRequireBasic($_SSubModulePath . $secClassTplPath . '/', "classesTpl/class.tpl." . $classNameWithPath . ".php")) {
                $className = $classestplName;
            } 
            
            if(class_exists($className)){                
           
                $this->_OclassTplObj = new $className;

                fileWrite("classesTpl/class.tpl." . $classNameWithPath . ".php", 'request','a+');
                fileWrite(print_r($this->_IinputData,1), 'request','a+');
            
                ### Set data to classtpl file ###
                $this->_OclassTplObj->_IinputData = $this->_IinputData;
                $this->_OclassTplObj->_Otwig      = $this->_Otwig;

                ### Call class file for insert/update operation ###
                $status = $this->_OclassTplObj->_getDisplayInfo();

                ### Override the default status with classtpl status message ###
                if(isset($this->_OclassTplObj->_AfinalResponse['status']) && is_array($this->_OclassTplObj->_AfinalResponse['status'])){
                    $this->_Aresponse['status'] = $this->_OclassTplObj->_AfinalResponse['status'];
                }

                ### Push the final result ###
                $this->_Aresponse['result']          = $this->_OclassTplObj->_AfinalResponse;
                $this->_Aresponse['callback_params'] = $status;
            }
        }
    }
}