<?php

/* * **********************************************************************
 * @Class Name	: checkDebitInsertion
 * @Created By	: Jagan
 * @Updated By  : --
 * @Update Info : -- 
 * @Description	: set amount in session
 * ************************************************************************ */
pluginFileRequire('common/', "lib/common/commonFunctions.php");

class checkDebitInsertion {

    //Class variable initialized
    public $_Aresponse = array();
    public $_Oconnection = '';
    public $_IinputData = array();
    

    //constructor to intilialize the employee profile class
    public function __construct() {
       
    }

    /**
     * @description - Default method call from ajax class
     * @return type
     */
    public function _getDisplayInfo($fileInfoArray = array()) {

      if(isset($_SESSION['bookingInsertion']) && $_SESSION['bookingInsertion']!=''){
          $response['packageId'] = $_SESSION['bookingInsertion']['packageId'];
          $response['status']   =  $_SESSION['bookingInsertion']['status'];
          $response['response'] =  $_SESSION['bookingInsertion']['response'];
          unset($_SESSION['bookingInsertion']);
      }else{
          $response['status']='no';
      }
       $this->_Aresponse=$response; 
       return $this->_Aresponse;
    }

}
?>