<?php
//need to define constant values that will be used in plugin folder
//define('PLUGIN_NAME' , 'default/');
define('SERVICE_ROOT' , 'default');
//To display employee seat preference list in employee profile creation
define('EMPLOYEE_PREFERENCE','Any,Window,Middle,Aisle');
define('EMP_FREQUENT_CARDTYPE','Platinum,Gold,Silver');
define('TITLE','Mr,Ms,Dr');
define('FILTER','Today,Yesterday,Last week,Last Month');
define('ENCRYPT','md5');
define('PORTAL_TYPE','PORTAL_TYPE');
define('PERSONAL_BOOKING_TYPE','14');
define('CORPORATE_BOOKING_TYPE','15');
define('OTP_TIME_DIFF','5');



$custom = array();
$custom['grid']['core_employee_details'] = array('employee_no' => 'Employee Id', 
                                                 'employee_first_name' => 'First Name', 
                                                 'employee_last_name' => 'Last Name',
                                                 'email_id' => 'Email',
                                                 'mobile_number' => 'Mobile');
$custom['grid']['booking_details'] = array('employee_first_name' => 'First Name', 
                                                 'organization_name' => 'Organization Name');
$custom['grid']['billto_mapping'] = array('billto_name' => 'Bill-To Address','status'=>'Status','edit'=>'Edit');
$custom['grid']['promocode_detaiils'] = array('promo_code_value' => 'Promo Code Value','r_airline_id' => 'Airline','start_date' => 'Start Date','end_date' => 'End Date','status'=>'Status','edit'=>'Edit');

//Search Airline Codes with Fare Types
 
$custom['searchAirlineCodes']=array('6E'=>array('RF'),'SG'=>array('RF'));
//Airline base tax splitup for service tax calculation
$custom['AIRLINETAXTOBASEFARE']=array('SG'=>array('WO'=>'','YQ'=>'','CMF'=>''),'6E'=>array('PHF'=>'','YQ'=>'','TTF'=>''),'G8'=>array('PHF'=>'','YQ'=>''),'9W'=>array('YR'=>'','YQ'=>''),'AI'=>array('YR'=>'','YQ'=>''),'UK'=>array('YR'=>'','YQ'=>''));

$custom['trainRequestForm'] = 5;
$custom['busRequestForm'] = 4;
$custom['hotelRequestForm'] = 3;

$GLOBALS['custom'] = $custom;
 

?>
