<?php
/* ***********************************************************************
 * @Class Name	:   class.tpl.flightRequestDisplayTpl.php
 * @Description	:   This file is used to set data to display flight request form
 * @Author      :   Mercy Chrysolite
 * ************************************************************************ */
fileRequire('plugins/misc/personal/harinim/classes/class.commonQuery.php');

class flightRequestDisplayTpl{

    public function __construct(){
        $this->_Sdomestic = true;        
    }

    /*
    * @functionName    :   _getDisplayInfo()
    * @description     :   default module method
    */
    public function _getDisplayInfo(){

        $this->_Ocorporate = new corporateSettings();
        $this->_OPayment   = new payment();
        $_OgstCostCenter = new gstCostCenter();
        $_OcommonDBO = new commonDBO();
    
        //set inputs
        if($this->_IinputData['action'] == 'CONTINUE_FLIGHT_SEARCH'){
            $contentId = explode(':',$this->_IinputData['contentIdData']);
            $this->_IinputData['packageId'] = $contentId[0];
            $this->_IinputData['orderId']   = $contentId[1];
        }

        $action = $this->_IinputData['action'];
        $this->_AtwigOutputArray['action'] = $action;
        
        //Check the action and call the function based on action
        switch($action){
            
            case 'QUICK_BOOKING':
                //Function call to get promocode details
                $this->_getQuickRequestFormData();
                break;

            case 'CONTINUE_FLIGHT_SEARCH':                
                $this->_getQuickRequestFormData();
                $this->_AserviceResponse['continueFlightSearchInfo'] = $this->_formExisitingOrderInfo($this->_IinputData['contentIdData']);
                $this->_AserviceResponse['CONTINUE_FLIGHT_SEARCH'] = $this->_AtwigOutputArray['CONTINUE_FLIGHT_SEARCH'] = $_SESSION['CONTINUE_FLIGHT_SEARCH'] =  Y;
                //get previous applied deal code details
                $this->_AtwigOutputArray['previousVoucherCode'] = $_OcommonDBO->_select('deal_code_order_mapping','*',array('r_order_id','code_type'),array($this->_IinputData['orderId'],'deal_code'))[0]['deal_code_value'];
                break;
            
            default:
                $this->_getQuickRequestFormData();
                break;
        }       
            
        $this->_AtwigOutputArray['TABSHOW']   =  'YES';
        $this->_AtwigOutputArray['corporateId']   =  $_SESSION['corporateId'];
        
        //set override plugin name
        $this->_AserviceResponse['overRidePluginName'] = array_search('YES',$_SESSION['userApplicationSettings']['OVERRIDE_PLUGIN_NAME']);
        $this->_AserviceResponse['bookingLinkFlag'] = $this->_IinputData['flag'];
        $this->_AserviceResponse['stateValue'] = $_OgstCostCenter->_getGSTStateValue();
        //get employee address info
        $this->_AserviceResponse['employeeAddressInfo'] = $_OcommonDBO->_select('employee_address_details','*','r_employee_id',$_SESSION['employeeId'])[0];
    }

    /*
    * @functionName    :   _getQuickRequestFormData()
    * @description     :   Method to set data for load the quick booking request form
    */
    private function _getQuickRequestFormData(){

        //To get currency mapped for the corporate
        $this->_getCurrencyType();

        //To get class options for corporate
        $this->_getTravelClassDetails();
        
        //To get paymnet method display
        $this->_displayPaymentOptions();

        //To get Fare Profile setting Info
        $this->_getPersonalFareProfileSetting();

        $this->_getSSROptionInfo(); 

        //get fare profile enabled airline
        $this->_getEnabledAirlinesForAdvancedSearch();

        //get passenger details
        if($this->_IinputData['orderId']){
            $this->_AserviceResponse['fareProfileSettingsTravelClass']['Family']['status']  = 'Y';
            $this->_getPassengerDetailsInfo($this->_IinputData['orderId']);         
        }
        else{
            //to get family details of the login employee
            if($this->_AserviceResponse['fareProfileSettingsTravelClass']['Family']['status'] == 'Y'){
                $this->_getFamilyDetailsAll($this->_IinputData['packageId']);
            }
        }        
    }

    /*
    * @functionName    :   _getRequestFormData()
    * @description     :   Method to set data for load the normal request form
    */
    private function _getRequestFormData(){

        //To get allowed trip types for the corporate
        $this->_getTripTypes();

        //To get currency mapped for the corporate
        $this->_getCurrencyType();

        //To get purpose of travel options for corporate
        $this->_getPurposeOfTravel();

        //To get band based policies for the user
        $this->_getBandBasedPolicy();

        //To get class options for corporate
        $this->_getTravelClassDetails();

        //To set passenger details
        if($_SESSION['userApplicationSettings']['AUTO_POPULATE_PAX_DETAILS'] == "YES") {
            $this->_setPassengerDetails();
        }

        //To set booking type
        $this->_setBookingType();
    }

   /**
    *  function used to get enabled  airlines in fare profile settings
    *  @return |array preferredAirlines
    *  @author Puroskhan.M
    */
     public function _getEnabledAirlinesForAdvancedSearch(){

        $this->_ocommonDBO = new commonDBO();

        //for view travel request
        if(isset($this->_IinputData['orderId']) && !empty($this->_IinputData['orderId'])){
            $packageId = $this->_ocommonDBO->_select('fact_booking_details', 'r_package_id','r_order_id',$this->_IinputData['orderId'])[0]['r_package_id'];
            $allAirlines = $this->_OcommonQuery->_getSettingsDisplayData($packageId,'Flight_Search_Configurations');
        }         
        else{//for new request
            $allAirlines = $this->_OcommonQuery->_getSettingsDisplayData('','Flight_Search_Configurations');
        } 
        
        $airLineArray = array();
        $FSCairliesSelected = "N";
        $fareprofileAirlineName = array();
        foreach ($allAirlines['Airlines'] as $key => $value){
            if($key == 'GDS_Carrier' && $value =='Y' && $allAirlines['Source']['GDS']=="Y"){
                $FSCairliesSelected="Y";
            }
            else{
                if($value == 'Y' && $allAirlines['Source']['LCC']=="Y"){
                    $airLineArray['LCC'][] = substr($key,-2);
                    $fareprofileAirlineName[substr($key,-2)]=$key;
               }
            }
        }
        $_Sairline = implode(",",$airLineArray['LCC']);
        $_Sairline = str_replace(',','","',$_Sairline);
        $fareProfileSelectedAirline ='"'.$_Sairline.'"';
        
        //airline class obj
        $_Oairline = new airline();
        $this->_AtwigOutputArray['preferredAirlines'] = $_Oairline->_getfareProfileEnabledAirLines($fareProfileSelectedAirline,$FSCairliesSelected,$fareprofileAirlineName);
        $this->_AserviceResponse['preferredAir'] = $_Oairline->_getfareProfileEnabledAirLines($fareProfileSelectedAirline,$FSCairliesSelected,$fareprofileAirlineName);        
    }

    /*
    * @functionName    :   _getCurrencyType()
    * @description     :   Method to set currency type for the corporate
    */
    private function _getCurrencyType(){
        $this->_Ocorporate->_IcorporateId = $_SESSION['corporateId'];
        $this->_AtwigOutputArray['corporateCurrency'] = $this->_Ocorporate->_getCorporateCurrency();
    }

    /*
    * @functionName    :   _getPurposeOfTravel()
    * @description     :   Method to get purpose of travel options for the corporate
    */
    private function _getPurposeOfTravel(){

        //getting options from purpose_of_travel table
        $this->_Ocorporate->_IcorporateId = $_SESSION['corporateId'];
        $purposeOfTravel = $this->_Ocorporate->_getCorporatePurposeOfTravel();

        //Sorting purpose into primary and secondary purposes
        foreach ($purposeOfTravel as $key => $value){
            if($value['parent_id'] == 0){
                $this->_AtwigOutputArray['purposeOfTravel'][$value['purpose_travel_id']]['travel_purpose'] = $value['travel_purpose'];
            } 
            else{
                $this->_AtwigOutputArray['purposeOfTravel'][$value['parent_id']]['subPurpose'][] = $value;
            }
        }
    }

    /*
    * @functionName    :   _getTravelClassDetails()
    * @description     :   Method to get allowed flight travel classes based on policy
    */
    private function _getTravelClassDetails(){

        $airline = new airline();

        //Travel Mode 1 : Domestic Air | Travel Mode 2 : International
        $result = $airline->_getTravelClassInformation(1);

        //$common = new commonArrayFunctions();
        $domesticClass = $result[1];
        
        //travel mode details        
        $this->_AtwigOutputArray['travelMode'] = array("name" => $domesticClass[0]['travel_mode'], "id" => $domesticClass[0]['travel_mode_id']);

        if(isset($_SESSION['userApplicationSettings']['POLICY_SETTINGS']) && $_SESSION['userApplicationSettings']['POLICY_SETTINGS'] == "Y") {
            
            //removing classes that are not applicable for the employee's band
            foreach ($domesticClass as $classKey => $classValue) {

                $policyClassName = str_replace(" ", "_", strtoupper($classValue['class_name']));

                if(!$this->_AtwigOutputArray['bandSettings'][$policyClassName]){
                    unset($domesticClass[$classKey]);
                }
            }
        }
        $this->_AtwigOutputArray['domesticClass'] = $domesticClass;
    }

    /*
    * @functionName    :   _getBandBasedPolicy()
    * @description     :   Method to get band based policy settings
    */
    private function _getBandBasedPolicy(){
        $policy = new policy();
        $policy->_SpolicyModule = "flightRequestPageDisplay";
        $this->_AtwigOutputArray['bandSettings'] = $policy->_getPolicy();
    }

    /*
    * @functionName    :   _setPassengerDetails()
    * @description     :   Method to set passenger information for harinim
    */
    private function _setPassengerDetails(){
        //setting from session for harinim SSO
        $this->_AtwigOutputArray['passenger'] = $_SESSION['travellerInfo']['traveller'];
        $this->_AtwigOutputArray['AUTO_POPULATE_PAX_DETAILS'] = true;
    }

    /*
    * @functionName    :   _setBookingType()
    * @description     :   Method to set type of booking to be made; Official / Personal
    */
    private function _setBookingType(){
        //setting from session for harinim SSO
        $this->_AtwigOutputArray['bookingType'] = $_SESSION['userApplicationSettings']['EXPENSE_BORNE'];
    }    
    
    /*
    * @Description get the display options values and display template by passing values to templatez
    * @param 
    * @return 
    */
    private function _displayPaymentOptions(){

        global $CFG;

        //define default template names avialbles
        $paymentTemplates = $CFG['paymentTemplates'];
        
        $paymentOptionsArray = $this->_OPayment->_getPaymentOptions($_SESSION['corporateId'],$_SESSION['groupId'],0);

        $paymentTemplateArray = array();

        $i = 1;
        foreach ($paymentOptionsArray as $key => $val) {
            if (isset($paymentTemplates[$val['payment_type_code']]) && !empty($paymentTemplates[$val['payment_type_code']])) {
                $paymentTemplateArray[$i] = array('name' => $paymentTemplates[$val['payment_type_code']], 
                                                  'desc' => $val['payment_type_description'],
                                                  'type' => $val['payment_type_code'],
                                                  'id' => $val['payment_type_id']);
                $i++;
            }
        }
        $this->_ApaymentOptionsArray = $paymentTemplateArray;        
        $this->_AtwigOutputArray['paymentoptions'] = $this->_ApaymentOptionsArray;
        $this->_AtwigOutputArray['dealCodeEnable'] = $_SESSION['userApplicationSettings']['DISCOUNT_VOUCHER'];
    }

    //function is to get the request level fare profile setting details
    public function _getPersonalFareProfileSetting(){
        
        $this->_OcommonQuery = new commonQuery();

        if($this->_IinputData['packageId'] != ''){
            $travelClassFareProile = $this->_OcommonQuery->_getSettingsDisplayData($this->_IinputData['packageId'],'Request_Form_Configurations');    
        }
        else{
            $travelClassFareProile = $this->_OcommonQuery->_getSettingsDisplayData('','Request_Form_Configurations');    
        }        
        
        $airline = new airline();
        
        //Travel Mode 1 : Domestic Air | Travel Mode 2 : International
        $domesticClass = $airline->_getTravelClassInformation(1)[1];

        $this->_AserviceResponse['domesticClass'] = $domesticClass;
        foreach ($travelClassFareProile['Cabin'] as $key => $value){
            $keyValue = str_split($key, 1);
            if($value == 'N' ){
                $travelClassCount[] = $keyValue[0];
            }
        }
        
        foreach ($domesticClass  as $dckey => $dcvalue) {
            foreach ($travelClassCount as $tcckey => $tccvalue) {
                if(ucwords($dcvalue['class_code']) == ucwords($tccvalue)){
                    unset($domesticClass[$dckey]);
                }   
            }
        }
        $this->_AtwigOutputArray['childTab']  = $travelClassFareProile['Passenger_Type']['Child'];
        $this->_AtwigOutputArray['infantTab'] = $travelClassFareProile['Passenger_Type']['Infant'];;
        $this->_AtwigOutputArray['domesticClass'] = $domesticClass;
        $this->_AtwigOutputArray['domesticTab'] = $travelClassFareProile['Trip_Type']['Domestic'];
        $this->_AtwigOutputArray['internationalTab'] = $travelClassFareProile['Trip_Type']['International'];
        $this->_AtwigOutputArray['LTCflight'] = $travelClassFareProile['LTCflight']['status'];
        $this->_AtwigOutputArray['GoAirDefenseFare'] = $travelClassFareProile['GoAirDefenseFare']['status'];

        //set trip type
        $this->_getTripTypes($travelClassFareProile['Travel_Type']);

        //assigining value to service response fare profile settings travel class
        $this->_AserviceResponse['fareProfileSettingsTravelClass'] = $travelClassFareProile;
        return true;
    }
    
    public function _getSSROptionInfo(){     
        
        //get ssr settings info from the json.
        $userApplicationSettings = $this->_getCorporateBaseSetting();

        //set package id
        $packageId = ($this->_IinputData['packageId'] != '') ? $this->_IinputData['packageId'] : 0;

        //get fare profile settings with respect to the package id.
        $generalSettings = $this->_OcommonQuery->_getSettingsDisplayData($packageId,'General_configurations');
        
        $ssrOptions['ssrOptionsInfo']['seat_enabled'] = $generalSettings['Ancillary']['Seat'];
        $ssrOptions['ssrOptionsInfo']['meal_enabled'] = $generalSettings['Ancillary']['Meal'];
        $ssrOptions['ssrOptionsInfo']['baggage_enabled'] = $generalSettings['Ancillary']['Baggage'];
        $ssrOptions['ssrSettingsInfo'] = $userApplicationSettings['SSR_OPTIONS'];
        $ssrOptions['userApplicationSettings'] = $userApplicationSettings;

        //set user applications info.
        $this->_AtwigOutputArray['userApplicationSettings'] = $ssrOptions['userApplicationSettings'];
        $this->_AtwigOutputArray['SSR_OPTIONS'] = $ssrOptions['ssrOptionsInfo'];   
        $ancillaryArr = array('0' => 'Seat','1' => 'Meal','2' => 'Baggage' );
        $ancillaryInfo = [];
        foreach ($ancillaryArr as $key => $value) {
            if($generalSettings['Ancillary'][$value] == 'Y'){
                array_push($ancillaryInfo, $value);
            }
            
        }

        //set ssr options enabled for the corporate
        $ssrCaptions = implode(" and ",$ancillaryInfo);
        $this->_AtwigOutputArray['SSR_CAPTION'] = count($ancillaryInfo) > 2 ? preg_replace('/ and /', ',',$ssrCaptions, 1):$ssrCaptions;  

        //get the itinerary level configurations
        $SSREnable =  $this->_OcommonQuery->_getSettingsDisplayData($packageId,'Itinerary_Level_Configurations');
        $this->_AtwigOutputArray['SSR_SELECTION'] = $SSREnable['Display_SSR_Request']['status'] == 'Y' ? 'YES' : 'NO';
        $this->_AtwigOutputArray['frequentFlyerNoFlag'] = $SSREnable['Frequent_Flyer']['status'];
        return true;          
    }

    public function _getCorporateBaseSetting(){

        $Ocorporate = new corporateCustomization(); 
        
        //set corporate id.
        $Ocorporate->_IcorporateId = $_SESSION['corporateId'];
        
        //calling the function for getting the user application settings info from the json.
        $_AsettingsArray = $Ocorporate->_getCorporateSettingsFromJSON();
        return $_AsettingsArray['settings']; 
    }

   /*
    * @functionName    :   _getFamilyDetails()
    * @description     :   to get family details of the employee
    */
    public function _getFamilyDetailsAll(){

        if(!isset($_SESSION['loginName']) && $_SESSION['loginName'] !='ssoPersonal'){

            $_Oemployee = new employee();
            $_OcommonDBO = new commonDBO();
            $_Opassport = new passport();

            //get employee info
            $employeeInfo = $_OcommonDBO->_select('dm_employee','*','employee_id',$_SESSION['employeeId']);

            //get family info with respect to the employee
            $familyInfo = $_Oemployee->_getFamilyDetails();

            //merge employee and family info            
            if(is_array($familyInfo) && count($familyInfo) > 0){
                $employeeInfo = array_merge((array)$employeeInfo,(array)$familyInfo);
            }
            
            //form passenger info            
            foreach($employeeInfo as $key => $value){                

                if(isset($value['employee_id'])){
                    //set passenger type.
                    $employeeInfo[$key]['passenger_type'] = 'ADT';
                }

                //get frequent flyer info
                $frequentFlyerDetails = $_Opassport->_getFFNBasedAirline($value['employee_id'],$value['employee_family_details_id']);                    
                if(is_array($frequentFlyerDetails) && count($frequentFlyerDetails) > 0){
                    $employeeInfo[$key]['frequentFlyerNo'] = $frequentFlyerDetails;
                }                    

                //get passport info
                $passportDetails = $_Opassport->_getPassportDetails($value['employee_id'],$value['employee_family_details_id'])[0];
                ($passportDetails['dob']) ? $passportDetails['dob'] = date('d-M-Y',strtotime($passportDetails['dob'])) : '';
                ($passportDetails['issuedate'] && $passportDetails['issuedate'] !='0000-00-00') ? $passportDetails['issuedate'] = date('d-M-Y',strtotime($passportDetails['issuedate'])) : '';
                ($passportDetails['expirydate'] && $passportDetails['issuedate'] !='0000-00-00') ? $passportDetails['expirydate'] = date('d-M-Y',strtotime($passportDetails['expirydate'])) : '';
                if(is_array($passportDetails) && count($passportDetails) > 0){
                    $employeeInfo[$key]['passportDetails'] = $passportDetails;
                }                

                $employeeInfo[$key]['employee_id'] = (isset($value['r_employee_id'])) ? $value['r_employee_id'] : $value['employee_id']; 
                $employeeInfo[$key]['employee_family_details_id'] = (isset($value['employee_family_details_id'])) ? $value['employee_family_details_id'] : 0;
                $employeeInfo[$key]['type'] = (isset($value['employee_family_details_id'])) ? 'F' : 'E';
            };
         
            $this->_AserviceResponse['familyDetails'] = $employeeInfo;
            $this->_AtwigOutputArray['familyDetails'] = $employeeInfo;
            $this->_AserviceResponse['passengerEmail']  = $_SESSION['employeeEmailId'];
            $this->_AserviceResponse['passengerMobile'] = $_SESSION['mobileNo'];
            $this->_AtwigOutputArray['passengerEmail']  = $_SESSION['employeeEmailId'];
            $this->_AtwigOutputArray['passengerMobile'] = $_SESSION['mobileNo'];     
        }
    }
    

    /**
     *  Method to set allowed trip types for the corporate
     * @author Baskar.V.P
     */
    public function _getTripTypes($checkTripTypes){
        $tripArray = array();
        foreach ($checkTripTypes as $key => $value) {
            if($value == 'Y'){
                $tripArray[] = str_replace('_', ' ', $key); 
            }
        }
        $this->_AtwigOutputArray['tripTypes'] = $this->_AtwigOutputArray['internationaltripTypes']  = $tripArray;
    }


    /**
     *  Method to get the order info 
     * @author Karthika.M
     */
    public function _formExisitingOrderInfo($contentIdData){

        $bookingInfo = array();

        $_OcommonDBO = new commonDBO();
        $_OcommonBookFlightRequest = new commonbookFlightRequest();

        $contentId = explode(':',$contentIdData);

        $packageId = $contentId[0];
        $orderId   = $contentId[1];
        $packageType = $contentId[2];

        //get fact booking details info.
        $factBookingDetails = $_OcommonDBO->_select('fact_booking_details','*','r_order_id',$orderId)[0];

        //get air request details info
        $requestDetails = $_OcommonBookFlightRequest->_setAirRequestDetails($factBookingDetails['r_request_id']);

        //get travel Class code.
        $travelClassInfo = $_OcommonDBO->_select('dm_travel_class','*','travel_class_id',$requestDetails['r_travel_class_id'])[0];
        $travelClassCode = $travelClassInfo['class_code'];

        //get customized Field value.
        $customizeData = json_decode($requestDetails['customize_fields'],1);

        //get previous selected flight time.
        $selectedPreviousTime  = $_OcommonBookFlightRequest->_getSelectedTime($orderId);

        //set master Info
        $bookingInfo['masterInfo']['requestTableData']['trip_type'] = ($requestDetails['trip_type'] == 2) ? 0 : $requestDetails['trip_type'];

        $bookingInfo['masterInfo']['requestTableData']['adult_count'] = $requestDetails['adult_count'];
        $bookingInfo['masterInfo']['requestTableData']['child_count'] = $requestDetails['child_count'];
        $bookingInfo['masterInfo']['requestTableData']['infant_count'] = $requestDetails['infant_count'];
        $bookingInfo['masterInfo']['requestTableData']['num_passenger'] = $requestDetails['num_passenger'];
        $bookingInfo['masterInfo']['requestTableData']['r_travel_class_id'] = $requestDetails['r_travel_class_id'];
        $bookingInfo['masterInfo']['requestTableData']['travel_type'] = $requestDetails['travel_type'];
        $bookingInfo['masterInfo']['requestTableData']['return_date'] = ($requestDetails['return_date'] != '' && $requestDetails['return_date'] != '0000-00-00') ? $requestDetails['return_date'] : '';
        $bookingInfo['masterInfo']['oldCabinClass']    = $requestDetails['r_travel_class_id'].':'.$travelClassCode;
        $bookingInfo['masterInfo']['cabinClass']       = explode(':',$bookingInfo['masterInfo']['oldCabinClass']);
        $bookingInfo['masterInfo']['cabinClassName']   = $travelClassInfo['class_name'];
        $bookingInfo['masterInfo']['r_travel_mode_id'] = $factBookingDetails['travel_mode'];
        $bookingInfo['masterInfo']['onwardTimeStart']  =  $selectedPreviousTime[0]['time_departure'];
        $bookingInfo['masterInfo']['onwardTimeEnd']    = $customizeData['onwardTimeEnd'];
        $bookingInfo['masterInfo']['returnTimeStart']  = $selectedPreviousTime[1]['time_departure'];
        $bookingInfo['masterInfo']['returnTimeEnd']    = $customizeData['returnTimeEnd'];

        /*set advanced search details input for flight search */  
        if($requestDetails['validAdvancedSearchDetails']['preferredAirlinesFlag'] === true) {
            $bookingInfo['masterInfo']['advancedsearch'] = $requestDetails['validAdvancedSearchDetails'];

            $preferredAirlines = array_keys($bookingInfo['masterInfo']['advancedsearch']['preferredAirlines']);
            $bookingInfo['masterInfo']['advancedsearch']['preferredAirlines'] = $preferredAirlines;
        }

        $bookingInfo['travelModeType'] = $factBookingDetails['travel_mode'];
        $bookingInfo['packageType'] = $packageType; 

        $LTCFlights = ($requestDetails['validAdvancedSearchDetails']['LTCEnable'] == 'Y') ? 'Y' : 'N';
        $defenseFare = ($requestDetails['validAdvancedSearchDetails']['defenseFare'] == 'Y') ? 'Y' : 'N';

        $bookingInfo['specialSearch']['LTCFlights'] =  $LTCFlights;
        $bookingInfo['specialSearch']['goAirDefenseFare'] = $defenseFare;

        $bookingInfo['LTCFlights'] =  ($LTCFlights == 'Y') ? true : false;
        $bookingInfo['goAirDefenseFare'] = ($defenseFare == 'Y') ? true : false;

        //get air request details info
        $airRequestDetailsInfo = $this->_formAirRequestDetailsInfo($orderId,$requestDetails);

        $bookingInfo['airRequestDetails'] = $airRequestDetailsInfo['airRequestDetails'];
        $bookingInfo['showRequestDetails'] = $airRequestDetailsInfo['showRequestDetails'];
        $bookingInfo['packageId'] = $packageId;
        $bookingInfo['orderId'] = $orderId;
        fileWrite(print_r($bookingInfo,1),"bookingInfo","a+");
        return $bookingInfo;
    }


    /**
     *  Method to get the request info 
     * @author Karthika.M
     */
    public function _formAirRequestDetailsInfo($orderId,$requestDetails,$key = 0){

        $_OcommonDBO = new commonDBO();

        $airRequestDetails = array();

        //get booking history info
        $sectorFromTo = $_OcommonDBO->_select('booking_history  ','sector_from, sector_to','order_id',$orderId)[0];

        //set air request details array
        $airRequestDetails[$key]['originCode']  = $sectorFromTo['sector_from'];
        $airRequestDetails[$key]['destinationCode'] = $sectorFromTo['sector_to'];

        $onwardAirportInfo = $this->_getAirportInfo($requestDetails['r_origin_airport_id']);
        $returnAirportInfo = $this->_getAirportInfo($requestDetails['r_destination_airport_id']);

        $airRequestDetails[$key]['requestTableData']['r_origin_airport_id'] = $onwardAirportInfo;
        $airRequestDetails[$key]['requestTableData']['r_destination_airport_id'] = $returnAirportInfo;

        $airRequestDetails[$key]['requestTableData']['onward_date'] = $requestDetails['onward_date'];
        if($requestDetails['return_date'] != '' && $requestDetails['return_date'] != '0000-00-00'){
            $airRequestDetails[$key]['requestTableData']['return_date'] = $requestDetails['return_date'];
        }
        $airRequestDetails[$key]['requestTableData']['customize_fields'] = $requestDetails['customize_fields'];

        //set data
        $showRequestDetails[$key]['sectorFrom'] = explode("(",$onwardAirportInfo['airport_desc'])[0];
        $showRequestDetails[$key]['sectorTo'] = explode("(",$returnAirportInfo['airport_desc'])[0];   
        $showRequestDetails[$key]['startDate'] = $requestDetails['onward_date'];   
        if($requestDetails['return_date'] != '' && $requestDetails['return_date'] != '0000-00-00')
            $showRequestDetails[$key]['endDate'] = $requestDetails['return_date'];


        //set response
        return array('airRequestDetails' => $airRequestDetails,'showRequestDetails' => $showRequestDetails);         
    }


    /**
     *  Method to get the passenger info 
     * @author Sandhiya.C
     */
    public function _getPassengerDetailsInfo($orderId){

        $_OcommonDBO = new commonDBO();
        $_Opassport = new passport();
        $passengerDetails = $_OcommonDBO->_select('passenger_details','*','r_order_id', $orderId);
        $passengerPassport = $_Opassport->_getPassportDetails($passengerDetails[0]['r_employee_id'],0,0,"CFS");
        foreach ($passengerDetails as $key => $value) {

            if($value['passenger_type'] == "INF"){
                $passengerDetails[$key]['adultAssigned'] = $_OcommonDBO->_select("passenger_infant_mapping","r_passenger_id","r_infant_id",$value['passenger_id'])[0]['r_passenger_id'];
            }

            $passengerFFN = $_Opassport->_getPassengerFrequentFlyer($value['passenger_id']);

            if(is_array($passengerFFN) && count($passengerFFN) > 0){
                $passengerDetails[$key]['frequentFlyerNo'] = $passengerFFN;
            }

            foreach ($passengerPassport as $passKey => $passValue) {

                ($passValue['dob']) ? $passValue['dob'] = date('d-M-Y',strtotime($passValue['dob'])) : '';
                ($passValue['issuedate']) ? $passValue['issuedate'] = date('d-M-Y',strtotime($passValue['issuedate'])) : '';
                ($passValue['expirydate']) ? $passValue['expirydate'] = date('d-M-Y',strtotime($passValue['expirydate'])) : '';

                if($passValue['first_name'] == $value['first_name'] && $passValue['last_name'] == $value['last_name']){
                    $passengerDetails[$key]['passportDetails'] = $passValue;
                }
            }

            $passengerDetails[$key]['employee_family_details_id'] = $passengerDetails[$key]['r_employee_family_details_id'];
            $passengerDetails[$key]['employee_id'] = $passengerDetails[$key]['r_employee_id'];
            $passengerDetails[$key]['flag'] = "BE";
            $passengerDetails[$key]['dob'] = $passengerDetails[$key]['DOB'];
            $passengerDetails[$key]['type'] = (isset($value['r_employee_family_details_id'])) ? 'F' : 'E';
        }

        $this->_AserviceResponse['familyDetails'] = $passengerDetails;
        $this->_AtwigOutputArray['familyDetails'] = $passengerDetails;
        $this->_AserviceResponse['passengerEmail']  = $passengerDetails[0]['email_id'];
        $this->_AserviceResponse['passengerMobile'] = $passengerDetails[0]['mobile_no'];
        $this->_AtwigOutputArray['passengerEmail']  = $passengerDetails[0]['email_id'];
        $this->_AtwigOutputArray['passengerMobile'] = $passengerDetails[0]['mobile_no'];
    }

    /**
     *  Method to get the airport info 
     * @author Karthika.M
     */
    public function _getAirportInfo($airportId){

        $_OcommonDBO = new commonDBO();

        //set array
        $airportInfo = array();

        //get airport info with respect to the airport id.
        $result  = $_OcommonDBO->_select('dm_airport','*','airport_id',$airportId)[0];
        $airportInfo['cityCode'] = $result['airport_code'];
        $airportInfo['cityId'] = $result['airport_id'];
        $airportInfo['cityName'] = $result['city_name'];
        $airportInfo['airport_desc'] = $result['airport_desc'];
        return $airportInfo;
    }
}    
?>
