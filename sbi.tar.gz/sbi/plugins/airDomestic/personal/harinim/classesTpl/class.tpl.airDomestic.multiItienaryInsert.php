<?php

/* * **************************************************************************
 * @File             : class.tpl.multiItienareyInsert.php
 * @Description      : This file is used to insert itienary details for the multi city
 * @Author           : M.Jagan
 * *************************************************************************** */
fileRequire('plugins/airDomestic/personal/harinim/classes/class.airMultiCity.php');
fileRequire('plugins/airDomestic/personal/harinim/classes/class.package.php');
fileRequire('plugins/airDomestic/personal/harinim/classes/class.airMultiCity.php');

class multiItienaryInsert {

    public function __construct(){    
        $this->_multi = new personal\airMultiCity();
        $this->_Opackage = new personal\package();
        $this->_OpassengerDetails = new personal\passenger();
    }

    public function _getDisplayInfo(){
        
        
        $finalArray = $this->_IinputData;
        $countMultiCity = count($this->_IinputData['flightSearchData']['multicity']) - 1;
        $this->_IinputData['flightSearchData']['employeeInfo'] = $this->_IinputData['factBookingDetails'];

        if($this->_IinputData['flightSearchData']['displayTripType'] == 2){
            $this->_IinputData['New']['transactionFee'] = $this->_IinputData['fareSplitUp']['transactionFee'] / $countMultiCity;
            $this->_IinputData['New']['discountAmount'] = $this->_IinputData['fareSplitUp']['discountAmount'] / $countMultiCity;
            $this->_IinputData['New']['systemUsageFee'] = $this->_IinputData['fareSplitUp']['systemUsageFee'] / $countMultiCity;
        }
        
        $this->_IinputData['flightSearchData']['employeeInfo']['travel_mode_id'] = $this->_IinputData['requestFormData']['masterInfo']['r_travel_mode_id'];
        $this->_IinputData['flightSearchData']['employeeInfo']['class_id'] = $this->_IinputData['requestFormData']['masterInfo']['requestTableData']['r_travel_class_id'];
        
        //noOfPassenger
        $noOfPax = $this->_IinputData['requestFormData']['masterInfo']['requestTableData']['num_passenger'];
        $tripType = $this->_IinputData['flightSearchData']['displayTripType'];
        $travelModeId = $this->_IinputData['requestFormData']['masterInfo']['r_travel_mode_id'];
        
        //set gst amount
        $gstAmount = ($this->_IinputData['agencyFeeDetails']['responseData']['gstAmount']) ? $this->_IinputData['agencyFeeDetails']['responseData']['gstAmount'] : 0;
            
        $viaGSTAmount = 0;
        
        // //set the gst amount.
        // if($gstAmount > 0){
        //     //for round trip
        //     if($tripType == 1 && $travelModeId == 1){
        //         $viaGSTAmount = ($gstAmount/2)/$noOfPax;
        //     } 
        //     else{
        //         $viaGSTAmount = $gstAmount/$noOfPax;
        //     }
        // }
        
        //assigining the fareSplitUp and  flightSearchData for insert flight details 
        $this->_IinputData['tempData'] = array_merge($this->_IinputData['fareSplitUp'], $this->_IinputData['flightSearchData']);
        $package = $this->_Opackage->_getPaidPackageDetails($this->_IinputData['tempData']['employeeInfo']['r_package_id']);

        //pacakge_type = 1 multicity
        if ($package[0]['package_type'] == 1 && $_SESSION['CONTINUE_FLIGHT_SEARCH'] != 'Y'){
            foreach($this->_IinputData['tempData']['multicity'] as $key => $value){
                if($key != 0) {
                    $this->_IinputData['multicity'][$key]['employeeInfo'] = $this->_IinputData['tempData']['employeeInfo'];
                    $this->_IinputData['multicity'][$key]['fareSplitUp'] = $this->_IinputData['New'];
                    $this->_IinputData['multicity'][$key]['employeeInfo']['r_order_id'] = $package[$key - 1]['r_order_id'];
                    $this->_IinputData['multicity'][$key]['selectedOnwardFlight'] = $this->_IinputData['tempData']['multicity'][$key]['selected'];
                }
            }
            $this->_IinputData[0]['multicity'] = $this->_IinputData['multicity'];
             
            $asd = $this->_multi->_insertMultipleBookingAirDetails($this->_IinputData['multicity'],$this->_IinputData['agencyFeeDetails'],$viaGSTAmount,$this->_IinputData['frequentFlyerNo'],$this->_IinputData['discountFeeDetails']);
        } 
        else{
            //package type 0 = onward / return
            pluginFileRequire('airDomestic/', 'personal/harinim/classesTpl/class.tpl.airDomestic.insertFlightItinerary.php');
            $this->insertFlightItienary = new insertFlightItinerary();
            //passing reasssigned tempData to insert flight itinerary details

            $this->insertFlightItienary->_IinputData = $this->_IinputData['tempData'];
            $this->insertFlightItienary->_IinputData['agencyFeeDetails'] = $this->_IinputData['agencyFeeDetails'];   
            $this->insertFlightItienary->_IinputData['discountFeeDetails'] = $this->_IinputData['discountFeeDetails'];          
            $this->insertFlightItienary->_IinputData['viaGSTAmount'] = $viaGSTAmount;
            $this->insertFlightItienary->_IinputData['frequentFlyer'] = $this->_IinputData['frequentFlyerNo'];   

            $this->insertFlightItienary->_getDisplayInfo();
            $_SESSION['total_amount'] = $this->_IinputData['tempData']['selectedOnwardFlight']['newTotalFare'];
        }
        
        $finalArray['flightSearchData'] = $this->_IinputData['tempData'];        
        $this->_IinputData['packageId'] = $finalArray['flightSearchData']['employeeInfo']['r_package_id'];
        $this->_IinputData['total_amount'] = $_SESSION['total_amount'];
        
        //get orderInfo        
        $orderInfo = array_column($package,'r_order_id');       
        
        //calling the function to insert the ssr details based on the application settings.
        $this->_IinputData['ssrSelectionFlag'] ? $this->_getSelectedSSRInfo($orderInfo,$this->_IinputData) : ''; 
    }
    
    /*
    * @Description  Function used to update the selected ssr info.
    * @param array|$orderIdInfo,$inputData
    * @author|Karthika.M
    */
    public function _getSelectedSSRInfo($orderIdInfo,$inputData){
        
        $this->_OpassengerPreferences = new passengerPreferences();      
        $this->_OflightItinerary = new personal\flightItinerary();  
        
        //forming the selected meal and baggage array.
        count($inputData['selectedMealBaggageInfo']) > 0 ? $this->_insertSelectedMealBaggageArray($orderIdInfo,$inputData) : '';
        
        //forming the selected seat array.
        count($inputData['seatInfo'] > 0) ? $this->_insertSelectedSeatInfo($orderIdInfo,$inputData):'';        
        
        //update the total amount after select the ssr in order_details.
        return $this->_updateTotalAmountAfterSSR($orderIdInfo,$inputData);
    }     
    
   /*
    * @Description  function used to form the array and insert the selected seat info.
    * @param array|$orderIdInfo,$inputData
    * @author|Karthika.M
    */
    public function _insertSelectedSeatInfo($orderIdInfo,$inputData){
        
        $selectedSeatInfo = array();       
        
        //set order count
        $orderCount = 0;
        
        //looping the order id.
        foreach($orderIdInfo as $orderKey => $orderValue){            
            
            //if order is present only
            if($orderValue != ''){   
                
                //get pax info.
                $paxInfo[$orderValue] = $this->_OpassengerDetails->_getAllPassengerDetailsByOrderId($orderValue);   
                
                //get flight details.
                $_viaFlightDetails = $this->_OflightItinerary->_getFlightItineraryDetails($orderValue);    
                if(count($_viaFlightDetails) > 0){
                    $_AitineraryDetails = $this->_OflightItinerary->_getItineraryInfo($_viaFlightDetails);
                }       
                
                //looping the itinerary details.
                foreach($_AitineraryDetails as $itineraryKey => $itineraryValue){ 
                    
                    //set itinerary key based on the trip tyep
                    $itineraryCount = ($this->_IinputData['flightSearchData']['displayTripType'] == 2) ? $orderCount : $itineraryKey;
                    
                    foreach ($itineraryValue['viaInfo'] as $viaKey => $viaValue){
                        foreach ($paxInfo[$orderValue] as $paxKey => $paxValue){         
                            if($paxValue['passenger_type'] != 'INF'){                                
                                $this->_IinputData['seatInfo'][$itineraryCount][$viaKey][$paxKey]['packageId'] = $inputData['packageId'];
                                $this->_IinputData['seatInfo'][$itineraryCount][$viaKey][$paxKey]['viaFlightId'] = $viaValue['via_flight_id'];
                                $this->_IinputData['seatInfo'][$itineraryCount][$viaKey][$paxKey]['orderId'] = $orderValue;
                                $this->_IinputData['seatInfo'][$itineraryCount][$viaKey][$paxKey]['tripType'] = $viaValue['trip_type'];
                                $this->_IinputData['seatInfo'][$itineraryCount][$viaKey][$paxKey]['passengerId'] = $paxValue['passenger_id']; 
                            }
                        }                    
                    }                
                }          
            }  
            $orderCount++;
        }
        //calling the function to insert the seat info.
        return $this->_OpassengerPreferences->_insertSelectedSeatDetails($this->_IinputData);  
    }
    
    /*
    * @Description  function used to form the array and insert the selected meal and baggage info
    * @param array|$orderIdInfo,$inputData
    * @author|Karthika.M
    */
    public function _insertSelectedMealBaggageArray($orderIdInfo,$inputData){
        
        //looping the selected meal and baggage info.      
        foreach($inputData['selectedMealBaggageInfo'] as $key => $value){
            
            //form array.
            $mealBaggageInfo = $this->_getAllPaxInfo($value,$key);
            
            //set order id.
            $orderId = $orderIdInfo[$key-1];
            
            //get pax info.
            $paxInfo[$orderId] = $this->_OpassengerDetails->_getAllPassengerDetailsByOrderId($orderId);   
          
            //looping the pax info.
            foreach($paxInfo[$orderId] as $paxKey => $paxValue){  
                
                //get flight details info
                $_viaFlightDetails = $this->_OflightItinerary->_getFlightItineraryDetails($orderId);
                if(count($_viaFlightDetails) > 0){
                    $_AitineraryDetails = $this->_OflightItinerary->_getItineraryInfo($_viaFlightDetails);
                }               
                
                //again looping the selected meal baggage info with corresponding value.
                foreach($mealBaggageInfo as $paxSSRKey => $paxSSRVal){                 
                    
                    //check if the key tommy pax key with real pax info array
                    if($paxSSRKey == $paxKey+1){
                    
                        //looping the itinerary details
                        foreach($_AitineraryDetails as $flightKey => $flightValue){
                            
                            //looping the via flight details.
                            foreach($flightValue['viaInfo'] as $viaKey => $viaValue){ 
                                
                                //looping the pax ssr value. 
                                foreach($paxSSRVal as $ssrTripKey => $ssrTripValue){                                    
                                    foreach($ssrTripValue as $ssrInfo => $ssrInfoVal){   
                                        //set sector.
                                        $sector = $viaValue['origin'].'-'.$viaValue['destination'];
                                        if($ssrInfo == $sector){
                                            $selectedMealBaggageInfo[$orderId][$paxValue['passenger_id']][$viaValue['trip_type']][$viaValue['via_flight_id']] = $ssrInfoVal;  
                                        }
                                    }
                                }                                
                            }                            
                        }                        
                    }
                }
            }  
        }  
        
        //set inputs.
        $mealBaggageInput['mealBaggageInfo'] = $selectedMealBaggageInfo;
        $mealBaggageInput['packageId'] = $inputData['packageId'];
        $mealBaggageInput['orderId'] = $inputData['order_id'];
        $inputData['packageType'] == 1 ? $mealBaggageInput['paymentProcessType'] = 'packagePayment' : 'orderPayment';
        
        //calling function to insert the meal and baggage info.
        return $this->_OpassengerPreferences->_insertSelectedMealBaggageDetails($mealBaggageInput);           
    }
    
    /*
    * @Description  Function used to update the ssr amount in order details.
    * @param array|$orderIdInfo,$inputData
    * @author|Karthika.M
    */
    public function _updateTotalAmountAfterSSR($orderIdInfo,$inputData){
        
        foreach ($orderIdInfo as $orderId){
            
            //find total meal & baggage fare for update in order_details.
            $ssrTotalFareAfterUpdate = $this->_OpassengerPreferences->_mealBaggageSSRfare("'meal','baggage','seat'",$orderId)[0]['ssrTotalFare'];

            //update the meal and baggage amount in order_details.
            $response = $this->_OpassengerPreferences->_updateSSRfareinOrder($orderId,$ssrTotalFareAfterUpdate);
        } 
        return $response;
    }
    
    /*
    * @Description  Function used to form the passenger info with respect to the order id
    * @param array,int|$mealBaggageValue,$orderId
    * @author|Karthika.M
    */
    public function _getAllPaxInfo($mealBaggageValue,$orderId){   
        $k = 1;
        foreach($mealBaggageValue as $key => $value){           
            $finalMealBaggageInfo[$orderId][$k] = $value;
            $k++;
        }
        return $finalMealBaggageInfo[$orderId];
    }
}
?>