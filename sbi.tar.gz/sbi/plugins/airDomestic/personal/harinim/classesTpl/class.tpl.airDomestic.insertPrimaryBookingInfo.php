<?php
/* * **************************************************************************
 * @File             : class.tpl.insertPrimaryBookingDetails.php
 * @Description      : This file is used to insert primary booking request details
 * @Tables Affected  : package_details,order_details,passenger_details,fact_booking_details
 * @Author           : Priyadharsini.M
 * *************************************************************************** */
fileRequire('plugins/airDomestic/personal/harinim/classes/class.flightItinerary.php');
fileRequire('plugins/airDomestic/personal/harinim/classes/class.passenger.php');
fileRequire('plugins/airDomestic/personal/harinim/classes/class.applicationSettings.php');
fileRequire('plugins/airDomestic/personal/harinim/classes/class.airline.php');
fileRequire('plugins/airDomestic/personal/harinim/classes/class.package.php');
class insertPrimaryBookingInfo {

    public function __construct() {
        $this->_Oemployee = new employee();
        $this->_Olocation = new location();
        $this->_OapplicationSettings = new personal\applicationSettings();
        $this->_Opackage = new personal\package();
        $this->_Opassenger = new personal\passenger();
        $this->_OcommonDBO = new commonDBO();
        $this->_Itineray=new personal\flightItinerary();
        $this->_request = new personal\airRequest();
        
        $this->_AfinalResponse['error_alert'] = '';
        $this->_AfinalResponse['status']      = 0;
     }
    /*
     * @functionName    :   _getDisplayInfo()
     * @description     :   default module method
     */
     
     public function _getDisplayInfo() {
        /* To get order id based on package details*/
        $package=$this->_IinputData['factBookingDetails']['r_package_id'];
        $this->_IinputData['passengerDetails']['passenger']=$this->_IinputData['addPassengerData']['ADT'];
        $this->_IinputData['paxPassportDetails'] = $this->_IinputData['addPassengerData']['passportDetails']['ADT'];
        
        foreach($this->_IinputData['addPassengerData']['CNN'] as $key=>$value){
            $this->_IinputData['passengerDetails']['passenger'][$key+count($this->_IinputData['addPassengerData']['ADT'])]=$this->_IinputData['addPassengerData']['CNN'][$key];
        }
        foreach($this->_IinputData['addPassengerData']['passportDetails']['CNN'] as $key=>$value){
            $this->_IinputData['paxPassportDetails'][$key+count($this->_IinputData['addPassengerData']['passportDetails']['ADT'])]=$this->_IinputData['addPassengerData']['passportDetails']['CNN'][$key];
        }
        $this->_IinputData['passengerDetails']['infant']=$this->_IinputData['addPassengerData']['INF'];
        $orderId=$this->_Opackage->_getPaidPackageDetails($package);
        $itinerayDetails = $this->_Itineray->_getOrderBookingDetails($orderId[0]['r_order_id']);
        $fieldArray=array('trip_type','adult_count','child_count','infant_count','onward_date');
        $requestDetails = $this->_request->_getAirRequest($itinerayDetails['r_request_id'],$fieldArray);
        foreach ($requestDetails[0] as $key => $value) {
           $this->_IinputData[$key] = $requestDetails[0][$key];
        }
        foreach ($orderId as $key => $value) {
            $this->_IinputData['order_id']=$value['r_order_id'];
            foreach ($this->_IinputData as $key => $value) {
        $this->_AtwigOutputArray[$key]=$this->_IinputData[$key];
            }
        $this->_AtwigOutputArray['email']=$_SESSION['employeeEmailId'];
        $this->_passengerInsertForPersonalBooking();
        }
        $this->_setBookingType();
        $this->_templateAssign();
    } 

    /**
     * @Description :This function is used to insert the passenger details
     * @param :
     * @return integer |$factBookingId - inserted fact booking id
     */
    public function _passengerInsertForPersonalBooking() {
        
        $passenger = $this->_IinputData['passengerDetails'];         
        $passengerDetails = isset($passenger['passenger']) ? array($passenger['passenger']) : '';          
        $infantDetails = isset($passenger['infant']) ? array($passenger['infant']) : '';           
        // Insert Passenger details.
        $paxIds = $this->_insertpassenger($passengerDetails);
        // Insert Infant Details.
        $infantIds = $this->_insertInfant($infantDetails,$paxIds);
    }

    /**
    * @Description :This function is used to insert the infant details
    * @param :infant details and paxids to maps 
    * @return boolean (true) 
    */
    public function _insertInfant($infantDetails,$paxIds){
             
        // Infant Insertions.
        foreach ($infantDetails as $key => $infants){      
              
            foreach ($infants as $index => $infant){

                $infant['DOB'] = date("Y-m-d", strtotime($infant['DOB']));

                // To remove the adultAssigned from the array.
                $assignedAdults = $paxIds[$infant['adultAssigned']];
                 
                $infant['r_order_id'] = $this->_IinputData['order_id'];
                unset($infant['adultAssigned']);
                unset($infant['city']);
                unset($infant['statedata']);

                $infantId = $this->_Opassenger->_insertPassengerMainDetails($infant);                    
                $this->_insertPassengerInfantDetails($assignedAdults, $infantId, $infant['DOB']);
                $this->_Opassenger->_insertPassengerPassportDetails($this->_IinputData['addPassengerData']['passportDetails'][$infant['passenger_type']][$index],$infantId,$infant['r_employee_family_details_id'],$infant['r_employee_id']);             
            }
        }
        return true; 
     }
     /**
     * @Description :This function is used to insert the passenger details
     * @param :passenger details
     * @return boolean (true) 
     */
     public function _insertpassenger($passengerDetails){
        $_OcommonInsertFlightItinerary = new commonInsertPrimaryBookingInfo();

        // Passenger Insertions.  
        $passengerIds = array();
        $cnt = 1;

        foreach($passengerDetails as $key => $passenger){
            foreach ($passenger as $index => $pas){
                if(!empty($pas['frequentFlyerNo']) && $pas['employee_code'] != 'GUEST'){
                    $ffn = array();
                    $ffn['r_employee_id'] = $pas['r_employee_id'];
                    $ffn['r_employee_family_details_id'] = $pas['r_employee_family_details_id'];
                    foreach ($pas['frequentFlyerNo'] as $k => $value) {
                        $ffn['r_airline_id'] = $this->_OcommonDBO->_select("dm_airline","airline_id","airline_code",$k)[0]['airline_id'];
                        $ffn['frequent_flyer_no'] = $value;
                        $this->_Opassenger->_insertFrequentFlyerDetails($ffn);
                    }                    
                }
                unset($pas['frequentFlyerNo']);
                $pas['first_name']=addslashes($pas['first_name']);
                $pas['last_name']=addslashes($pas['last_name']);
                
                // adding the DateofBirth field if the user is Adult, Just adding 20yrs for adult for webservice default parameter.
                if($pas['passenger_type'] == 'ADT'){
                    if($pas['r_employee_family_details_id'] == 0){
                        $getAdultDob = $this->_Oemployee->_getEmployeeDOB($pas['r_employee_id']);
                        if($getAdultDob){
                            $pas['DOB'] = $getAdultDob;
                        }
                        else{
                            $pas['DOB'] = date('Y-m-d', strtotime('-30 years'));
                        }
                    }
                    else{
                        $pas['DOB'] = $this->_OcommonDBO->_select('employee_family_details','dob','employee_family_details_id',$pas['r_employee_family_details_id'])[0]['dob'];
                    }
                }
                else{

                    if(array_key_exists('DOB', $passenger)) { // this will be handle for both adult and child .           
                        $pas['DOB'] = date("Y-m-d", strtotime($pas['DOB']));
                    } 
                    else{
                        $pas['DOB'] = date("Y-m-d", strtotime(date('Y-m-d', strtotime($pas['DOB']))));
                    }

                }
                $pas['r_order_id'] = $this->_IinputData['order_id'];

                //set passenger details.
                $paxInfo = $pas;

                //unset the unwanted fields.
                unset($paxInfo['city']);
                unset($paxInfo['statedata']);

                // Insert the passenger_id.    
                $passengerIds[$index] = $this->_Opassenger->_insertPassengerMainDetails($paxInfo);  

                //insert into passenger passport details
                $this->_Opassenger->_insertPassengerPassportDetails($this->_IinputData['paxPassportDetails'][$index],$passengerIds[$index],$pas['r_employee_family_details_id'],$pas['r_employee_id']);                

                //insert into passenger_other_details
                $empOtherData = $this->_Oemployee->_getEmployeeOtherDetails($_SESSION['employeeId'])[$_SESSION['employeeId']][0];
                $passOther['project_code'] = $_OcommonInsertFlightItinerary->_getPassengerCostCenterCode($_SESSION['employeeEmailId']);
                $passOther['department'] = $empOtherData['department_name']; 
                $passOther['designation'] = $empOtherData['designation_name'];
                $passOther['band'] = $empOtherData['band_name'];
                $passOther['branch'] = $empOtherData['branch_name'];
                $passOther['city'] = $empOtherData['city'];
                $passOther['country'] = $empOtherData['country'];
                $passOther['pin_code'] = $empOtherData['pin_code'];
                $passOther['contact_no'] = $empOtherData['contact_no'];
                $passOther['city'] = $pas['city'];
                $passOther['state'] = $pas['statedata'];
                $passOther['r_passenger_id'] = $passengerIds[$index];
                $this->_Opassenger->_insertPassengerOtherDetails($passOther);
            }
        }

        //set employee address info
        $empAddrInfo['r_employee_id'] = $_SESSION['employeeId'];        
        $empAddrInfo['r_gst_state_master_id'] = $passengerDetails[0][1]['statedata'];
        $empAddrInfo['city'] = $passengerDetails[0][1]['city'];

        //get the employee_address_details
        $empAddrDetails = $this->_OcommonDBO->_select('employee_address_details','*','r_employee_id',$_SESSION['employeeId'])[0];
        if(!$empAddrDetails){
            //insert          
            $empAddId = $this->_OcommonDBO->_insert('employee_address_details',$empAddrInfo);
        }
        else{
            //update
            $empAddId = $this->_OcommonDBO->_update('employee_address_details',$empAddrInfo,'r_employee_id',$_SESSION['employeeId']);
        }     
        return $passengerIds;
    }

    /**
     * @Description :This function is used to get guest details
     * @param : integer | $orderId - order id 
     * @return array |$returnValue - Booked employee designation,department,branch details
     */
    private function _getGuestDetails($orderId){

        $sqlEmployee = "SELECT ed.designation,ed.department,ed.branch 
                            FROM employee_details ed,fact_booking_details fbd
                            WHERE fbd.r_order_id='" . $orderId . "' AND fbd.r_employee_id=ed.r_employee_id";
        $result = $this->_OcommonDBO->_getResult($sqlEmployee);
        return $result;
    }

    /**
     * @Description :This function is used to infant and adult details
     * @param : integer | $passengerId,$infantId array |$infantDetails
     */
    private function _insertPassengerInfantDetails($passengerId, $infantId, $infantDetails){
        
        $requestDetails['r_passenger_id'] = $passengerId;
        $requestDetails['r_infant_id'] = $infantId;        
        $requestDetails['DOB'] = date("Y-m-d", strtotime($infantDetails));

        //to insert into table
        $this->_Opassenger->_insertPassengerInfant($requestDetails);        
    }
    
    /**
     * @Description :This function is used to infant and adult details
     * @param : integer | $passengerId,$infantId array |$infantDetails
     */
    private function _setBookingType(){
        
        //setting from session for harinim SSO
        $bookingType = array("N"=>array("id"=>0,"value"=>"Official"),"Y"=>array("id"=>0,"value"=>"Personal"));
        $this->_AtwigOutputArray['bookingType'] = $bookingType[$_SESSION['travellerInfo']['is_personal']];
        
    }
    
    private function _templateAssign(){
        //setting from session for harinim SSO
        $this->_AtwigOutputArray['bookingType'] = $_SESSION['userApplicationSettings']['EXPENSE_BORNE'];
    }
}
?>
