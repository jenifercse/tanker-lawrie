<?php
/* * **************************************************************************
 * @File            class.tpl.airDomestic.continueFlightSearch.php
 * @Description     This tpl file is used for continue flgiht search
 * @Author          Muruganandham M
 * @Created Date    01/07/2019
 * *************************************************************************** */
fileRequire('plugins/airDomestic/personal/harinim/classes/class.airRequest.php');
fileRequire('plugins/airDomestic/personal/harinim/classes/class.passenger.php');
fileRequire('plugins/airDomestic/personal/harinim/classes/class.package.php');
fileRequire('plugins/airDomestic/personal/harinim/classes/class.flightItinerary.php');
fileRequire('lib/common/commonMethods.php');


class continueFlightSearchInsertTpl {

    public function __construct() {
    	$this->_OcommonDBO = new \commonDBO();
        $this->_OcommonMethods = new commonMethods();
    }

    public function _getDisplayInfo(){

        //set inputs
        $inputData = $this->_IinputData;
    	switch($inputData['action']){

    	   	case 'sendPaymentLink':
                //calling function based on the action.
                if($inputData['continueFlightSearchAction'] == 'BOOK'){
                    $this->_AfinalResponse = $this->_proceedToBook($inputData);
                }
                else{
                    $this->_AfinalResponse = $this->_sendPaymentLink($inputData);
                }    	   		
    	   		break;     	
    	      
    	    default:
                fileWrite(print_r($inputData,1),"itineraryInsertion","a+");
			   	$this->_getFactBookingDetails();   
    	    	break;
    	}
    }
     
    /*
    * @FunctionName    :   _getFactBookingDetails
    * @Description     :   This function is used to set InputData for Itinerary insert
    * @author          :   Muruganandham M
    */
    public function _getFactBookingDetails(){

        $_OflightItinerary = new flightItinerary();

        //get fact booking details.
    	$factBookingDetails = $this->_OcommonDBO->_select('fact_booking_details','*','r_order_id',$this->_IinputData['orderId'])[0];

        //set inputs
    	$this->_IinputData['factBookingDetails'] = $factBookingDetails;
    	$this->_IinputData['tempData']['employeeInfo'] = $factBookingDetails;

        //get order details
    	$orderFieldsArray =  array('r_currency_type_id','r_travel_mode_id','r_ticket_status_id','r_payment_status_id','created_date');
    	$orderDetails = $this->_OcommonDBO->_select('order_details',$orderFieldsArray,'order_id',$this->_IinputData['orderId'])[0];
        
        //set order details
    	$this->_IinputData['orderDetails'] = $orderDetails;

        //get air request details
    	$this->_IinputData['airRequestDetails'] = $this->_OcommonDBO->_select('air_request_details','*','air_request_id',$factBookingDetails['r_request_id'])[0];

        //check itinerary insertion.
        if($_OflightItinerary->_checkItineraryExist($this->_IinputData['orderId'])){
            $_OflightItinerary->_deleteExistingAirItineraryInfo($this->_IinputData['orderId'],'CONTINUE_FLIGHT_SEARCH_FARE_CHECK');
        }
    }    

    /*
    * @FunctionName    :   _sendPaymentLink 
    * @Description     :   This function is used to send payment link Mail
    * @author          :   Muruganandham M
    */
    public function _sendPaymentLink(){

        $_Opayment = new payment();

        //get payment type id
       	$paymentTypeId =  $this->_OcommonDBO->_select('payment_details','r_payment_type_id','payment_id',$this->_IinputData['paymentId'])[0]['r_payment_type_id'];

        //total Amount
       	$totalAmount =  $this->_OcommonDBO->_select('order_details','total_amount','order_id',$this->_IinputData['orderId'])[0]['total_amount'];

        //last paid amount of the order.
       	$paidAmount =  $this->_OcommonDBO->_select('booking_history',array('booking_type','paid_amount'),'order_id',$this->_IinputData['orderId']);

        //payable amount without pg charges
       	$payableAmountWithoutPgCharges = $totalAmount - $paidAmount[0]['paid_amount'];

		//Pgcharges Calculation    	
	    $pgChargesValues = $_Opayment->_getPGcharges($paymentTypeId,$this->_IinputData['travelMode']);
	    if($pgChargesValues['valueType'] == 'Percentage'){
       		$pgCharges = round(($pgChargesValues['value'] * $payableAmountWithoutPgCharges )/100);
     	}
        else{
       		$pgCharges = $pgChargesValues['value'];
       	}

        //find pg charges GST
       	$pgChargesGst = round(($pgCharges * PG_GST_PERCENTAGE)/100);

        //final payable amount
        $payableAmountWithPgCharges = $payableAmountWithoutPgCharges + $pgCharges + $pgChargesGst;

        //booking History updation
        $paymentDetails = array();
        $paymentDetails['package_amount'] = $totalAmount;
        $paymentDetails['total_amount'] = $payableAmountWithPgCharges;
        $paymentDetails['extra_charges'] = $pgCharges;
        $paymentDetails['extra_charges_gst'] = $pgChargesGst;
        $paidAmount[0]['booking_type'] == '0' ? $paymentDetails['payment_link_sent_time'] = date('Y-m-d H:i:s') : '';
        $insertBookingHistory = $this->_OcommonDBO->_update('booking_history',$paymentDetails,'order_id',$this->_IinputData['orderId']);
        $sendPaymentLinkUrlResponse = $this->_generatePaymentLinkMail($this->_IinputData,$paymentDetails);

        if($sendPaymentLinkUrlResponse){
			return $this->_AfinalResponse = array('status' => 'SUCCESS','message' => 'Payment link send successfully');               
		}
        else{
 			return $this->_AfinalResponse = array('status' => 'FAILURE','message' => "Payment link not sent,Contact Admin");  
 		}          
    }

   /*
    * @FunctionName    :   _generatePaymentLinkMail 
    * @Description     :   This function is used to generate payment link 
    * @author          :   Muruganandham M
    */
    public function _generatePaymentLinkMail($inputs,$paymentDetails){
        $this->_Otwig = init();
    	
    	$url = HTTP_HOST;
        $serverProtocol = HTTP_TYPE;

        //set twig output array
        $this->_AtwigOutputArray['host'] = HOST_URL;
        $this->_AtwigOutputArray['packageId'] = $inputs['packageId'];
        $this->_AtwigOutputArray['orderId'] = $inputs['orderId'];
        $this->_AtwigOutputArray['payableAmount'] = $paymentDetails['total_amount'];
        $this->_AtwigOutputArray['pgCharges'] = $paymentDetails['extra_charges'];
       	$mailSubject = "Balmer Lawrie - Continue Payment Link";

        $this->_formMailInputs($inputs['orderId'],$inputs['tripType']);
       	//user email Id
       	$userMailId = $this->_OcommonDBO->_select('passenger_details','email_id','r_order_id',$inputs['orderId'])[0]['email_id'];
 
        //Url Formation
        $urlFormation = 'CFSPAY'.'$$'.$inputs['orderId'] .'$$'.$inputs['packageId'].'$$'.$paymentDetails['total_amount'].'$$'.date('Y-m-d H:i:s');
        $urlFormation = base64_encode($urlFormation);

        //set payment url
        $this->_AtwigOutputArray['paymentUrl'] = $serverProtocol . $url . "/controller/continueFlightSearchPayment.php?input=".$urlFormation;
        //render template
        $_SmailContent = $this->_Otwig->render('sendPaymentLink.tpl', $this->_AtwigOutputArray);

        //function to send mail to user
        return $this->_OcommonMethods->_sendMail($userMailId, 'support@atyourprice.in', $mailSubject, $_SmailContent);   
    }

    /*
    * @FunctionName    :   _proceedToBook
    * @Description     :   Function used to sync the booking to backend.
    * @author          :   Karthika.M
    */
    public function _proceedToBook($input){

        //object declaration.
        $_ObookingDetailsSync = new bookingDetailsSync();
        $_OapplicationSettings = new applicationSettings();

        //update status in order details
        $updateArray['r_payment_status_id'] = PAYMENT_DONE;
        $updateArray['r_ticket_status_id'] = PAID;
        $this->_OcommonDBO->_update('order_details',$updateArray,'order_id',$input['orderId']);

        //calling function for sync.
        $_ObookingDetailsSync->_syncBookingDetails(0,$input['orderId']);

        //send booking mail to developer.
        $_OapplicationSettings->_Otwig = $this->_Otwig;
        $_OapplicationSettings->_mailBookingInfo($packageId, $packageType, $paymentResponse, $PGType);

        //set response
        return array('status' => 'SUCCESS','message' => 'Payment Done successfully');
    }

    public function _formMailInputs($orderId,$tripType){
         $this->_Opayment = new payment();
        $sql = "SELECT dme.title,dme.first_name,dme.last_name,dme.email_id,
                od.updated_date,dme.mobile_no,fbd.r_package_id,bh.booking_date,ard.trip_type,
                (SELECT city_name FROM dm_airport WHERE airport_id = ard.r_origin_airport_id ) as origin_city, 
                (SELECT city_name FROM dm_airport WHERE airport_id = ard.r_destination_airport_id ) as destination_city,ard.onward_date,ard.return_date,ard.r_origin_airport_id,ard.r_destination_airport_id
                FROM fact_booking_details fbd
                INNER JOIN dm_employee dme ON dme.employee_id = fbd.r_employee_id
                INNER JOIN order_details od ON od.order_id = fbd.r_order_id
                INNER JOIN air_request_details ard ON ard.air_request_id = fbd.r_request_id
                INNER JOIN airport_details ad ON ad.airport_name_id = ard.r_origin_airport_id
                INNER JOIN dm_airport dma ON dma.airport_id  = ad.r_airport_id
                INNER JOIN booking_history bh on bh.order_id = fbd.r_order_id 
                WHERE r_order_id = ".$orderId;

        $empDetails = $this->_OcommonDBO->_getResult($sql)[0];
        $this->_AtwigOutputArray['customerName']    = $empDetails['title'] . '.' . $empDetails['first_name'] . ' ' . $empDetails['last_name'];
        $this->_AtwigOutputArray['origin_airport_name']=$empDetails['origin_city'];
        $this->_AtwigOutputArray['dest_airport_name']=$empDetails['destination_city'];
        $this->_AtwigOutputArray['booking_date']    = $empDetails['booking_date'];
        $this->_AtwigOutputArray['tripType']    = $empDetails['trip_type'] == '1' ? 'return' : 'onward';
        if($empDetails['trip_type'] == 1){
            $returnSum += $requestData['amountDifference'];
            $traveldate['onward_date'] = date_format(date_create($empDetails['onward_date']),"d, M Y");
            $traveldate['return_date'] = date_format(date_create($empDetails['return_date']),"d, M Y");
            $returnFlight = $this->_Opayment->_getFlightNumberInfo($orderId,1);
             $this->_AtwigOutputArray['returnFlightName'] = $returnFlight['flightName'];
             $this->_AtwigOutputArray['returnFlightNumber'] = $returnFlight['flightNumber'];
             $this->_AtwigOutputArray['trip_type'] = 1;
        }
        // if($requestData['tripType'] == 0 || ($requestData['tripType'] == 1 && count($getPnrDetails) == 1) && $requestData['paymentTitle'] == "Fare Difference"){
        if($empDetails['trip_type'] == 0 || $empDetails['trip_type'] == 2){
            $onwardSum += $requestData['amountDifference'];
            $traveldate['onward_date'] = date_format(date_create($empDetails['onward_date']),"d, M Y");
            $onwardFlight = $this->_Opayment->_getFlightNumberInfo($orderId,0);
             $this->_AtwigOutputArray['onwardFlightName'] = $onwardFlight['flightName'];
             $this->_AtwigOutputArray['onwardFlightNumber'] = $onwardFlight['flightNumber'];
             $this->_AtwigOutputArray['trip_type'] = 0;
        }
        $this->_AtwigOutputArray['traveldate']      = $traveldate;
        $fltNo[] = $this->_Opayment->_getFlightNumberInfo($orderId,$tripType)['flightNumber'];
        $this->_AtwigOutputArray['flightNumber']    = implode(",",array_unique($fltNo));


    }   
}
?>
