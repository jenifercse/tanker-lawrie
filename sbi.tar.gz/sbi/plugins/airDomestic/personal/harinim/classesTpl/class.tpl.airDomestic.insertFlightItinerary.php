<?php
/* * **********************************************************************
 * @Class Name	: insertFlightItinerary
 * @Created on	: 2016-06-06
 * @Created By	: Thirumal
 * @Updated By  : --
 * @Update Info : -- 
 * @Description	: This class will insert the flight itinerary details.
 * ************************************************************************ */
fileRequire('plugins/airDomestic/personal/harinim/classes/class.flightItinerary.php');

 class insertFlightItinerary{

    
    public function __construct(){
        
        $this->_OFlightItinerary  = new personal\flightItinerary();
        $this->_AfinalResponse    = array('status' => '1' , 'message' => '');        
        $this->_Sonwardflightreason = '';
        $this->_Sreturnflightreason = '';
        $this->_OfareDetails = new \fareDetails();
    }
    
    /*
    * 
    * @description     :   default module method
    * @param
    * @return
    */
    public function _getDisplayInfo(){
        $this->_AfinalResponse = $this->_insertIntineraryDetails();        
        $this->_templateAssign();
    }
    
    
    public function _insertIntineraryDetails($itineraryInsertArray = '',$viaGSTAmount = 0,$agencyFeeDetails = '',$discountFeeDetails = '',$increment){
        

        if(isset($itineraryInsertArray) && !empty($itineraryInsertArray)){

            $this->_IinputData = $itineraryInsertArray;
            $this->_IinputData['agencyFeeDetails'] = $agencyFeeDetails;
            $this->_IinputData['discountFeeDetails'] = $discountFeeDetails;
            $this->_IinputData['viaGSTAmount'] = $viaGSTAmount; 
            if($itineraryInsertArray['tripType'] == 2){
                $this->_IinputData['frequentFlyer'] =  $itineraryInsertArray['frequentFlyer'];  
            }
            
            $this->_OFlightItinerary->multi=1;
        }

        //set travel mode id and class id
        $this->_IinputData['travelModeId']       = isset($this->_IinputData['travel_mode_id']) ? $this->_IinputData['travel_mode_id'] :$this->_IinputData['employeeInfo']['travel_mode_id'];
        $this->_IinputData['travelClassId']      = isset($this->_IinputData['class_id']) ? $this->_IinputData['class_id'] : $this->_IinputData['employeeInfo']['class_id'];
                
        //set gst amount based on via details
        $this->_OFlightItinerary->_IviaGSTAmount = $this->_IinputData['viaGSTAmount'];        
        
        if(isset($this->_IinputData['fareSplitUp']) && !empty($this->_IinputData['fareSplitUp'])){
            $fareArray = $this->_IinputData['fareSplitUp'];
        }
        else{
            $fareArray['systemUsageFee'] = $this->_IinputData['systemUsageFee'];
            $fareArray['transactionFee'] = $this->_IinputData['transactionFee'];
            $fareArray['discountAmount'] = $this->_IinputData['discountAmount'];
        }
        
        //set required values for insert flight itinerary functionality
        $this->_OFlightItinerary->_corporateId    = $this->_IinputData['employeeInfo']['r_corporate_id'];
        $this->_OFlightItinerary->_orderId        = $this->_IinputData['employeeInfo']['r_order_id'];
        $this->_OFlightItinerary->_flightTypeId   = $this->_IinputData['travelType'];
        $this->_OFlightItinerary->_IemployeeId    = $this->_IinputData['employeeInfo']['r_employee_id'];
        $this->_OFlightItinerary->_ITravelModeId  = $this->_IinputData['travelModeId'];
        $this->_OFlightItinerary->_ITravelClassId = $this->_IinputData['travelClassId'];
        $this->_OFlightItinerary->_ItravelTripType  = $this->_IinputData['displayTripType'];
        $this->_OFlightItinerary->_SclassCode  = $this->_IinputData['travelClassId'];

        /*** start logic for inserting itinerary details ****/
        //set initial low fare onward & return status
        $this->_SonwardLowFareStatus = 'Y';
        $this->_SreturnLowFareStatus = 'Y';
        
        //assigning flight search array to variables
        $selectedOnwardFlight = $this->_IinputData['selectedOnwardFlight'];
        $selectedReturnFlight = $this->_IinputData['selectedReturnFlight'];
        $lowestOnwardFlight   = $this->_IinputData['onwardLowestFlight'];
        $lowestReturnFlight   = $this->_IinputData['returnLowestFlight'];
        $_commonInsertFlightItinerary = common::_checkClassExistsInNameSpace('commonInsertFlightItinerary','airDomestic');


        //to insert gst based mapping values for trip types and order corporate mapping tables
        $_commonInsertFlightItinerary->_IinputData = $this->_IinputData;
        $_commonInsertFlightItinerary->_insertGSTCorporateMapping($selectedOnwardFlight, $selectedReturnFlight);
               
        //insert details into air_booking_details table
        $this->_OFlightItinerary->_insertAirBookingDetails($this->_OFlightItinerary->_orderId, $this->_IinputData['employeeInfo']['r_employee_id']);
        
        //insert onward selected fare details
        if(isset($selectedOnwardFlight) && !empty($selectedOnwardFlight)){
            
            $this->_SselectedFlight  = 'Y'; 
            
            //check flag status as N if onwardlowest flight is available
            if(isset($lowestOnwardFlight) && !empty($lowestOnwardFlight)){
                $this->_SonwardLowFareStatus = 'N';
            }
            $this->_tripType = 0;            
            $responseValue = $this->_OFlightItinerary->_insertFlightItinerary($selectedOnwardFlight, $this->_SonwardLowFareStatus, $this->_tripType, $this->_SselectedFlight,$fareArray,$this->_IinputData['frequentFlyer']);
        }
        
        //insert onward low fare details
        if(isset($lowestOnwardFlight) && !empty($lowestOnwardFlight)){            
            $this->_SselectedFlight      = 'N';             
            $this->_Sonwardflightreason = $this->_IinputData['onwardflightreason'];            
            $this->_tripType = 0;
            foreach ($lowestOnwardFlight as $key => $value) {
                $responseValue = $this->_OFlightItinerary->_insertFlightItinerary($value, $this->_SonwardLowFareStatus, $this->_tripType, $this->_SselectedFlight,$fareArray,$this->_IinputData['frequentFlyer']);
            }
        }
        
        //insert return selected fare details
        if(isset($selectedReturnFlight) && !empty($selectedReturnFlight)){
            
            $this->_SselectedFlight  = 'Y';
            
            //check flag status as N if returnlowest flight is available
            if(isset($lowestReturnFlight) && !empty($lowestReturnFlight)){
                $this->_SreturnLowFareStatus = 'N';
            }            
            $this->_tripType = 1;
            $responseValue = $this->_OFlightItinerary->_insertFlightItinerary($selectedReturnFlight, $this->_SreturnLowFareStatus, $this->_tripType, $this->_SselectedFlight,$fareArray,$this->_IinputData['frequentFlyer']);
        }
        
        //insert return loware details
        if(isset($lowestReturnFlight) && !empty($lowestReturnFlight)){            
            $this->_SselectedFlight      = 'N';            
            $this->_Sreturnflightreason = $this->_IinputData['returnflightreason'];            
            $this->_tripType = 1;
            foreach ($lowestReturnFlight as $key => $value) {
               $responseValue = $this->_OFlightItinerary->_insertFlightItinerary($value, $this->_SreturnLowFareStatus, $this->_tripType, $this->_SselectedFlight,$fareArray,$this->_IinputData['frequentFlyer']);
            }
        }

        $agentFeeDetailsArray = $this->_IinputData['agencyFeeDetails'];
        $discountFeeDetails = $this->_IinputData['discountFeeDetails'];

        //insert into booking fee_mapping
        if(isset($discountFeeDetails['responseData']['feeDetails']) && !empty($discountFeeDetails['responseData']['feeDetails'])){
            ($increment == '') ? $increment = 0 : ''; 
            $insertValues['responseData']['feeDetails'][] = $agentFeeDetailsArray['responseData']['feeDetails'][0];
            $insertValues['responseData']['feeDetails'][] = $discountFeeDetails['responseData']['feeDetails'][$increment];
            $insertValues['responseData']['gstAmount'] = $agentFeeDetailsArray['responseData']['gstAmount'];
            $totalAmount = $this->_getFeeDetailsForBooking($insertValues['responseData'],$discountFeeDetails);
        }
        else{
            $insertValues['responseData'][0]['feeDetails'][] = $agentFeeDetailsArray['responseData']['feeDetails'][0];
            $insertValues['responseData'][0]['gstAmount'] = $agentFeeDetailsArray['responseData']['gstAmount'];
            $totalAmount = $this->_getFeeDetailsForBooking($insertValues['responseData'][0],$discountFeeDetails);
        }        

        //insert into deal code order mapping.
        $this->_OfareDetails->_insertOrderDealCodeMapping($discountFeeDetails,$this->_IinputData['employeeInfo']['r_order_id']);
        
        //update total amount to order details table
        $this->_OFlightItinerary->_updateOrderDetails($totalAmount);
                
        //insert reason into reason master table
        if((isset($this->_Sonwardflightreason) && !empty($this->_Sonwardflightreason)) || (isset($this->_Sreturnflightreason)) && !empty($this->_Sreturnflightreason)){
            $reasonMasterId = $this->_OFlightItinerary->_saveLowFareReason($this->_Sonwardflightreason, $this->_Sreturnflightreason);
        }
        
        if($responseValue){
            $responseArray['status']   = 0;
            $responseArray['message']  = 'Itineray inserted successfully'; 
            $responseArray['listdata'] = $this->_getViewRequestData();
        } 
        else{
            $responseArray['status']   = 1;
            $responseArray['message']  = 'Itineray insertion failed'; 
        }        
        $this->_IinputData['order_id'] = $this->_IinputData['employeeInfo']['r_order_id'];        
        return $responseArray; 
    }
    
    /*
    * @description : get the json data for display in view request page after itinerary insert
    * @param
    * @return json|$responseJSON
    */
    private function _getViewRequestData(){
        
        //create response array
        $responseArray = array();
        
        //fetch data from fact_air_itinerary for order_id
        $orderBookingArray     = $this->_OFlightItinerary->_getOrderBookingDetails($this->_IinputData['r_order_id']);
        
        $itineraryDetailsArray = $this->_OFlightItinerary->_getItineraryDetails($this->_IinputData['r_order_id']);
        
        $responseArray['package_id']   = $orderBookingArray['r_package_id'];   //package_id
        $responseArray['booking_date'] = $orderBookingArray['created_date'];   //booking_date
        $responseArray['total_amount'] = $orderBookingArray['total_amount'];   //total_amount
        
        $responseJSON = json_encode($responseArray);
        
        return $responseJSON;
    }
    
    private function _templateAssign(){        
        $this->_AtwigOutputArray['action'] = $this->_action;
        $this->_AtwigOutputArray['moduleName'] = $this->_SmoduleName;
    }
    
    /*
    * @description : function used to calculation of the processing  fee
    * @param
    * @return json|$responseJSON
    */
    public function _getFeeDetailsForBooking($agentFeeDetailsArray){

        $this->_OcommonDBO = new \commonDBO();

        $_AfeeValues = array();
        $_AfeeTotal = 0;        

        //booking fee mapping insertion and updation.
        $_AfeeTotal = $this->_OfareDetails->_bookingFeeMappingInsertion($agentFeeDetailsArray,$this->_IinputData['employeeInfo']['r_order_id']);

        //totalFare+transaction fee+systemusage fee+gstamount+discount fee
        $totalAmount = intval($this->_OFlightItinerary->_IorderTotalFare) + $_AfeeTotal; 
        return $totalAmount;
    }
}
?>