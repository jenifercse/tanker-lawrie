<?php
/* * **************************************************************************
 * @Class           modifyBookingListTpl
 * @Description     This class has the cancel request itinerary and passenger info
 * @Author          Karthika
 * @Created Date    25/08/2016
 * @update Date
 * @update By
 * *************************************************************************** */
pluginFileRequire('default/', 'classes/class.commonDBO.php');

class modifyBookingListTpl {

    public $getBookList = '';
    public $airportList = '';
    public $result = array();

    public function __construct(){
        $this->_OAirRequest = new airRequest();
        $this->_OAirLine = new airline();
        $this->_OAirPort = new airport();
        $this->_OAplplicationSettings = new applicationSettings();
        $this->_OPassenger = new passenger();
        $this->_OgetBookList = new cancellation();
        $this->_Ocurrency  = new location();
        $this->_OcommonDBO = new commonDBO();
        $this->_Oinvoice = new invoice();

    }

    public function _getDisplayInfo(){
        
        $_OcommonQuery = new commonQuery();
        
        global $CFG;
        
        $displayResults = array();
        
        //get booking list.
        $results = $this->result = $this->_OgetBookList->_getBookingListPersonal($this->_IinputData);        
       
        //get flight details
        $airlineDetails = $this->_getFlightDetailsInfo($results);
        
        //To get origin airport name
        foreach($results as $key => $value){
            
            //get booking reference info
            $bookingRef  = $_OcommonQuery->_getBookingReferencePrefixStingBasedOnOrder($results[$key]['orderid']);
            
            //set bookinf reference
            $displayResults[$key]['bookingReference'] = $bookingRef;
           
            //set data
            $res = array('order_id'=> $results[$key]['orderid'],'trip_type'=> $results[$key]['Travel_type']);
            
            //get booking date and time
            $displayResults[$key]['dateTime'] = $this->_OgetBookList->_getDateTime($res);
            
            //get origin airport name
            $airportOrigin = $this->_OAirPort->_getAirportName($results[$key]['r_origin_airport_id']);
            $results[$key]['r_origin_airport_id'] = $airportOrigin[0]['airport_code'];
            
            //get destination airport name
            $airportDestination = $this->_OAirPort->_getAirportName($results[$key]['r_destination_airport_id']);
            $results[$key]['r_destination_airport_id'] = $airportDestination[0]['airport_code'];
            
            //set sector
            $results[$key]['sector'] .= $results[$key]['r_origin_airport_id'] . " - " . $results[$key]['r_destination_airport_id'];
            $airportCode = $this->_OAirLine->_getAirlineDetails($results[$key]['r_airline_id']);
            
            //set airline code and flight number
            $results[$key]['r_airline_id'] = $airportCode[0]['airline_code'];
            $results[$key]['Flight_info'] = $results[$key]['r_airline_id'] . " - " . $results[$key]['flight_no'];
           
            $displayResults[$key]['alias_orderid'] = $bookingRef.$results[$key]['orderid'];
            $displayResults[$key]['orderid']       = $results[$key]['orderid'];
            $displayResults[$key]['sync_order_id'] = $bookingRef.$results[$key]['sync_order_id'];
            $displayResults[$key]['booking_date']  = $results[$key]['booking_date'];
            $displayResults[$key]['Name']          = $results[$key]['Name'];
            $displayResults[$key]['sector']        = $results[$key]['sector'];
            $displayResults[$key]['Travel_date']   = $results[$key]['Travel_date'];
            $displayResults[$key]['Flight_info']   = $resulbookingIconStatusts[$key]['Flight_info'];
            $displayResults[$key]['Flight_name']   = $airportCode[0]['airline_name'];
            $displayResults[$key]['Travel_type']   = $results[$key]['Travel_type'];
            
            /*** to display the e-ticket  icon **/
            if(in_array($results[$key]['Cancel_status'],$CFG['bookingIconStatus'])){
                $displayResults[$key]['Cancel_status'] = 'Y';
            }
            
            $displayResults[$key]['status_value']    = $results[$key]['status_value'];
            $displayResults[$key]['icon_class_name'] = $results[$key]['icon_class_name'];
            $displayResults[$key]['Approver_name']   = '-';
            $displayResults[$key]['Amount']          = $results[$key]['Amount'];
            $displayResults[$key]['Return_date']     = $results[$key]['Return_date'];
            $displayResults[$key]['num_passenger']   = $results[$key]['num_passenger'];  
            $displayResults[$key]['paxList']         = $this->_OgetBookList->_getPassengerName($results[$key]['orderid']);
            
            //get currency type.
            $currencyType = $this->_Ocurrency->_getCurrencyType($results[$key]['Currency_type'],'currency_symbol');
            $displayResults[$key]['Currency_type']    = $currencyType[0]['currency_symbol'];
            $displayResults[$key]['reschedule_status']= $results[$key]['reschedule_status'];
            $displayResults[$key]['package_type']     = $results[$key]['package_type'];
            $displayResults[$key]['travel_mode']      = $results[$key]['r_travel_mode_id'];
            $displayResults[$key]['package_id']       = $results[$key]['package_id'];
            $displayResults[$key]['payment_date']     = $results[$key]['payment_date'];
            $displayResults[$key]['airline_code']     = $results[$key]['r_airline_id'];
            $displayResults[$key]['pnr']              = $airlineDetails[$key]['pnr'];
            $displayResults[$key]['payment_type_description'] = $results[$key]['payment_type_description'];
            $displayResults[$key]['airlineDetails']   = $airlineDetails[$key]['airlineInfo'];
            $displayResults[$key]['airline_code']     = $airlineDetails[$key]['airline_code'];
            $displayResults[$key]['booking_mode']     = $results[$key]['booking_mode'];
            $displayResults[$key]['payment_type_code']     = $results[$key]['payment_type_code'];
        }
        //set the flag for diplay the power suite display icon.
        $displayResults = $this->_Oinvoice->_getShowInvoiceDisplayFlag($displayResults);
        // check booking has credit note details
        $displayResults = (is_array($displayResults) && count($displayResults) > 0) ?  $this->_Oinvoice->_checkBookingCreditNoteExist($displayResults) : '';
        $this->_AserviceResponse['viewListData'] = $displayResults;

        //function to call and get airline code for the process
        $this->_AserviceResponse['airlineCode'] = $this->_OcommonDBO->_select('dm_airline','*', 'status','Y','','airline_name');
        $this->_AtwigOutputArray['userTypeId'] = $_SESSION['userTypeId'];
        //function to call and get corporate name for the process
        if($_SESSION['userTypeId'] == 6){
            $this->_AtwigOutputArray['corporateList'] = $this->_OcommonDBO->_select('dm_corporate','*', 'personal_booking_enable','Y','','corporate_name');
        }
        $this->_templateAssign($displayResults,$this->paxList);        
    }

    /**
    * @param           :   $data array
    * @description     :   get airline info
    * @return          :   $data
    */
    public function _getFlightDetailsInfo($data){
        
        $_OflightItinerary = new flightItinerary();
        
        foreach($data as $key => $value){
            
            $airline = array();
            
            //get airline code info
            $data[$key]['airlineInfo']= $this->_OAirLine->_getAllAirline($value['orderid']);

            //get onward and return airline
            $airlineCodeInfo = $this->_OAirLine->_getAirlineCodeDetails($value['orderid']);
            foreach($airlineCodeInfo as $k => $val){
                $airline[$val['trip_type']][] = $val['airline_code'];
            }  
            
            //set airline code based on the trip type
            $data[$key]['airline_code'] = (isset($airline[1])) ? $airline[0][0].'/'.$airline[1][0] : $airline[0][0];

            //get PNR with respect to the order id.
            $data[$key]['pnr'] = $_OflightItinerary->_getOrderPNRdetails($value['orderid']);
        }
        return $data;
    }
    
    private function _templateAssign($results,$paxList){ 
    
        global $CFG;
                       
        $this->bookingList = $results;
        
        /*
        * To add the action for whether cancel or reschedule for the change modification.                
        *  To store onward date after reducing 2 hours on onward and return date.
        */
        if(isset($this->bookingList) && !empty($this->bookingList)){
            
            //set total data count
            $totalDataCount = count($this->bookingList);
            
            for($dataCount = 0; $dataCount < $totalDataCount; $dataCount++){
                
                $dateTime = $this->bookingList[$dataCount]['dateTime'][0];

                $date = strtotime($dateTime['dateTime'])-60*60*2;

                /* To store system date in config.common.php defined variable*/
                $sysdate = strtotime($CFG['todaydate']);

                /* condition to check passenger  onward or return date with system date with reduced 2 hours*/
                if($sysdate <= $date){
                    $this->bookingList[$dataCount]['action']="show";
                }
                else{
                    $this->bookingList[$dataCount]['action'] = "hide";
                }
            }
        }
        $this->_AtwigOutputArray['action'] = $this->_action;
        $this->_AtwigOutputArray['moduleName'] = $this->_SmoduleName;
        $this->_AtwigOutputArray['bookingListInfo'] = $this->bookingList;
        $this->_AtwigOutputArray['paxInfo'] = $paxList;
    }   
}
?>