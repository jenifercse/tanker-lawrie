<?php
/* * **************************************************************************
 * @File             : class.tpl.getFlightSearchXml.php
 * @Description      : This file is used to generate the flight search xml to get the data from service
 * @Tables Affected  : approval_tracking
 * @Author           : Jk Thirumal
 * @Created Date     : 05/07/2016
 * @Modified Date    : 
 * ****************************************************************************/
pluginFileRequire('default/', 'lib/common/commonFunctions.php');
fileRequire('lib/common/commonMethods.php');
pluginFileRequire('default/', 'classes/class.corporateSettings.php');
pluginFileRequire('default/', 'classes/class.applicationSettings.php');
pluginFileRequire('airDomestic/personal/harinim/', "config/config.inc.php");
fileRequire('plugins/misc/personal/harinim/classes/class.commonQuery.php');
class getFlightSearchXml{

    //Private Access Variables
	private $db;
	private $status;
	private $_Ssegmenttype='ONWAY';
	private $_SsystemParameters='SERVICE_TAX';
	private $_AgoAirSpecialFares='N';
	private $_IcorporateId=0;
	private $_Sorigin='';
    private $_CrefundableSearch='N';
	private $_Sdestination='';
	private $_DonwardDate='';
	private $_InumOfPassenger=1;
	private $_SonwardFromTime='00:00';
	private $_SonwardEndTime='24:00';
    private $_SreturnFromTime='00:00';
	private $_SreturnEndTime='24:00';
	private $_ScorpFareAirlines = "'9W','AI','UK'";
	private $_XindigoPromoFares='EMPTY';
	private $_XpromoGDSfares='EMPTY';
	private $_XpromoFares='EMPTY';
	private $_XcorporateFare='EMPTY';
    private $_SsystemParamCode = 'DOMESTIC_SERVICE_TAX';
	private $_Ssearchtype;
	private $_CsearchFareDisplay;
	private $_ScabinClass;
    private $_StravelModeCode='D';
	private $_AfareBreakUpDisplay;
    private $_DtodayDate = '';
    private $_CsearchFlag='Y';
    private $_IadultCount=0;
    private $_IchildCount=0;
    private $_IinfatnCount=0;
    private $_SrescheduleSearchType = 'FALSE';
    private $_SresponseType='json';

    //Public Access Variables
    public $_SairlineCode='';
    public $_SfareType='RF';
	public $_CsearchTripType='O';
        
    public function __construct(){        
        $this->_DtodayDate = date('Y-m-d');
        $this->_OapplicationSettings=new applicationSettings();
        $this->_OcommonDBO=new commonDBO();
        $this->_commonMethods = new commonMethods();
        $this->_Oairline = new airline();
        $this->_Oitinerary = new flightItinerary();
    }
   
    /**
    * Method Name        : _getDisplayInfo
    * Desc  	      : To check the corporate is having markup fee or not
    * @access public
    * @param corporateid : Unique id of a corporate, default value is 0
    * @param cabinClass  : input parameters are ( 'E','B','F' ) E - Economy class , B - Business class , F - First class and default value is 'E'
    * @param emailId     : email id of the registered user
    * @param travelType  : input parameters are ( 'D','IN' ) D - Domestic , IN - Internatinal and default value is 'D'
    * @input param       : param={"mod":"flightSearch","method":"getFlightsList","parameter":{"corporateId":"3","cabinClass":"E","emailId":"balamurugan@atyourprice.in","origin":"MAA","destination":"DEL","onwardDate":"2015-08-25","tripType":"1","numOfPass":"1","returnDate":"2015-08-28"}}}
    * @return array
    */
	public function _getDisplayInfo(){

        fileWrite(print_r($this->_IinputData,1), 'airRequest_PER','a+');

        //Check for the session
        if(isset($_SESSION['corporateId'])&&!empty($_SESSION['corporateId'])){
            
            if(count($this->_IinputData)>0){

                //set fare profile settings
                $this->_getPersonalFlightSearchConfigurations();
                
                //Set the flight input data to class variables
                $this->_getFlightRequestData($this->_IinputData);
                
                //Generat the flight search Url
                $this->_getSearchXml();                 
                $this->_getFlightTemplateUrl();               
            }
            else{
                fileWrite('No input data found : '.__CLASS__.', Method: '.__FUNCTION__.', Line: '.__LINE__, 'moduleError','a+');
            }            
        }
        else{            
            fileWrite('Session not found : '.__CLASS__.', Method: '.__FUNCTION__.', Line: '.__LINE__, 'moduleError','a+');
        }
        $this->_AserviceResponse['NONREFUNDABLEFARE'] = $_SESSION['userApplicationSettings']['NONREFUNDABLEFARE'];
        $this->_AserviceResponse['showDetails'] = $this->_IinputData['showRequestDetails'];
        $this->_AserviceResponse['requestLevelInsetedData'] = $this->_IinputData;
        fileWrite(print_r($this->_AserviceResponse,1),"serviceResponmse");
	}

    /** 
    * Desc: To fetch the requested flight details
    * @param null
    */
    private function _getFlightRequestData($inputData){ 

        $_OcommonQuery = new commonQuery();
             
        //Get corporate id from session
        $this->_IcorporateId = isset($_SESSION['corporateId'])?$_SESSION['corporateId']:2;	 

        $sysParamValue='';
        $this->_getMasterInputData($inputData['masterInfo']);
            
        //Fetching Sector Informations
        $this->_Sorigin = isset($inputData['airRequestDetails'][0]['originCode'])?$inputData['airRequestDetails'][0]['originCode']:'';
        $this->_Sdestination = isset($inputData['airRequestDetails'][0]['destinationCode'])?$inputData['airRequestDetails'][0]['destinationCode']:'';
        $this->_DonwardDate = isset($inputData['airRequestDetails'][0]['requestTableData']['onward_date'])?$inputData['airRequestDetails'][0]['requestTableData']['onward_date']:date('Y-m-d');            
           
        //Sector informations for flight search
        $this->_AserviceResponse['origin'] = $this->_Sorigin;
        $this->_AserviceResponse['destination'] = $this->_Sdestination;
        $this->_AserviceResponse['onwardDate'] = $this->_DonwardDate;
        $this->_AserviceResponse['returnDate'] =$this->_DreturnDate;
        $this->_AserviceResponse['onwardFromTime'] = $this->_SonwardFromTime;
        $this->_AserviceResponse['onwardToTime'] =$this->_SonwardEndTime;
        $this->_AserviceResponse['returnFromTime'] = $this->_SreturnFromTime;
        $this->_AserviceResponse['returnToTime'] =$this->_SreturnEndTime;
        $this->_AserviceResponse['class_id'] = $this->_ItravelClassId;
        $this->_AserviceResponse['travel_mode_id'] = $this->_StravelModeId;
            
        //Tax code from config 
        $this->_AserviceResponse['configTaxCode'] = $GLOBALS['custom']['AIRLINETAXTOBASEFARE'];
         
        $sysParamValue =  $this->_Oitinerary->_getTaxValues($this->_SsystemParameters,0);
        if($sysParamValue!=''){
            $this->_AserviceResponse['serviceTaxPercent'] =$sysParamValue;
        } 
           
        //Generate Multicity array for flight search
        if (isset($inputData['masterInfo']['requestTableData']['trip_type']) && $inputData['masterInfo']['requestTableData']['trip_type'] == 2){
            foreach ($inputData['airRequestDetails'] as $key => $value) {
                
                $this->_AserviceResponse['multiCity'][$key]['origin'] = $inputData['airRequestDetails'][$key]['originCode'];
                $this->_AserviceResponse['multiCity'][$key]['destination'] = $inputData['airRequestDetails'][$key]['destinationCode'];
                $this->_AserviceResponse['multiCity'][$key]['onwardDate'] = $inputData['airRequestDetails'][$key]['requestTableData']['onward_date'];
                $this->_AserviceResponse['multiCity'][$key]['requestCount'] = $key+1;                    
            }                
        }

        // mew
        $this->_AtwigOutputArray['bookFlightRequest'] = $inputData['bookFlightRequest'] ? $inputData['bookFlightRequest'] : '';
        if(isset($inputData['updatePassenger']) && $inputData['updatePassenger']['onward']!=''){
            $this->_requestData['date']['onward'] = $inputData['airRequestDetails'][0]['requestTableData']['onward_date']; // 2017-03-06
            $this->_requestData['date']['return'] = $inputData['masterInfo']['requestTableData']['return_date'];
            $this->_requestData['passengers'] = array(
                                                    'adult'=>isset($inputData['masterInfo']['requestTableData']['adult_count'])?$inputData['masterInfo']['requestTableData']['adult_count']:1,
                                                    'child'=>isset($inputData['masterInfo']['requestTableData']['child_count'])?$inputData['masterInfo']['requestTableData']['child_count']:0,
                                                    'infant'=>isset($inputData['masterInfo']['requestTableData']['infant_count'])?$inputData['masterInfo']['requestTableData']['infant_count']:0
                                                ); // 1 0 0
        }
        else{
        $this->_requestData['date']['onward'] = $inputData['airRequestDetails'][0]['requestTableData']['onward_date']; // 2017-03-06
        $this->_requestData['passengers'] = array(
                                                'adult'=>isset($inputData['masterInfo']['requestTableData']['adult_count'])?$inputData['masterInfo']['requestTableData']['adult_count']:1,
                                                'child'=>isset($inputData['masterInfo']['requestTableData']['child_count'])?$inputData['masterInfo']['requestTableData']['child_count']:0,
                                                'infant'=>isset($inputData['masterInfo']['requestTableData']['infant_count'])?$inputData['masterInfo']['requestTableData']['infant_count']:0
                                            ); // 1 0 0
        }

        $this->_requestData['date']['return'] = $inputData['masterInfo']['requestTableData']['return_date'];

        //Request data
        $this->_requestData['cabinclass'] = $inputData['masterInfo']['cabinClass'][1]; // E
        $this->_requestData['refundableFare'] = 'N'; // N
        $this->_requestData['agentId'] = SERVICE_AGENCY_ID; // 101
        $this->_requestData['currency_type'] = 'INR'; // INR

        if(isset($inputData['masterInfo']['requestTableData']['trip_type']) && ($inputData['masterInfo']['requestTableData']['trip_type'] == 0 || $inputData['masterInfo']['requestTableData']['trip_type'] == 1)){
            $this->_requestData['sector']['origin'] = $inputData['airRequestDetails'][0]['originCode']; // MAA
            $this->_requestData['sector']['destination'] = $inputData['airRequestDetails'][0]['destinationCode']; // DEL
        }

        $this->_requestData['types']['requestedAirline'] = $inputData['requestedAirline'] ? $inputData['requestedAirline'] : $GLOBALS['custom']['SBAirlines'];
        $this->_requestData['types']['blockedAirlines'] = $GLOBALS['custom']['CTBlockedAirlines'];

        // promocode data
        $requestedData['cabinClass'] = $inputData['masterInfo']['cabinClass'][1];
        $requestedData['travelMode'] = $inputData['masterInfo']['r_travel_mode_id'];

        $this->_requestData['promoCode']['airline'] = $_OcommonQuery->_discountFareFlightsPromoCode($this->_requestData['date']['onward'],'',$_SESSION['corporateId'],$requestedData,'',0,'P');
           
        //LTC flight search
        $this->_AserviceResponse['LTCflightsEnable'] = 'N';
        if($inputData['LTCFlights']){
            $this->_requestData['LTCEnable'] = 'Y';
            $this->_AserviceResponse['LTCflightsEnable'] = 'Y';
        }

        //Go Air defense fare 
        $this->_AserviceResponse['goAirDefenseFare'] = 'N';
        if($inputData['goAirDefenseFare']){
             $this->_requestData['defenseFare'] = 'Y';
             $this->_AserviceResponse['goAirDefenseFare'] = 'Y';
        }

        $this->_AserviceResponse['flightRequestData'] = $this->_requestData;
            
        // for mark up and mark low fare array formation           
        $this->_AserviceResponse['requestXML'] =  $this->_markUp;

        //Tax code from config 
        $this->_AserviceResponse['configTaxCode']=$GLOBALS['custom']['AIRLINETAXTOBASEFARE'];
        (empty($this->_AserviceResponse['configTaxCode'])) ? $this->_AserviceResponse['configTaxCode'] = array('SG'=>array('WO'=>'','YQ'=>'','CMF'=>''),'6E'=>array('PHF'=>'','YQ'=>'','TTF'=>''),'G8'=>array('PHF'=>'','YQ'=>''),'9W'=>array('YR'=>'','YQ'=>''),'AI'=>array('YR'=>'','YQ'=>''),'UK'=>array('YR'=>'','YQ'=>'')) : FALSE;

        $sysParamValue =  $this->_Oitinerary->_getTaxValues($this->_SsystemParameters,0);
        if($sysParamValue!=''){
            $this->_AserviceResponse['serviceTaxPercent'] = $sysParamValue;
        } 
        $this->_AserviceResponse['quickSearchFlag'] = false; 

        //Generate Multicity array for flight search
        if (isset($inputData['masterInfo']['requestTableData']['trip_type']) && $inputData['masterInfo']['requestTableData']['trip_type'] == 2){ 
            foreach ($inputData['airRequestDetails'] as $key => $value) {
                $this->_AserviceResponse['multiCity'][$key]['origin'] = $inputData['airRequestDetails'][$key]['originCode'];
                $this->_AserviceResponse['multiCity'][$key]['destination'] = $inputData['airRequestDetails'][$key]['destinationCode'];
                $this->_AserviceResponse['multiCity'][$key]['onwardDate'] = $inputData['airRequestDetails'][$key]['requestTableData']['onward_date'];
                $this->_AserviceResponse['multiCity'][$key]['requestCount'] = $key+1;
            }            
        }          

        $this->_AserviceResponse['TRAVELPORT_API'] = array_values($_SESSION['userApplicationSettings']['TRAVELPORT_API']);
        fileWrite(print_r($this->_AserviceResponse['flightRequestData'],1),'promocodecheck_PER','a+');
    }
        

    private function _getMasterInputData($masterData){
        //Fetching Master Information
        $this->_ScabinClass = isset($masterData['cabinClass'])?$masterData['cabinClass'][1]:'E';
        $this->_InumOfPassenger = isset($masterData['requestTableData']['num_passenger'])?$masterData['requestTableData']['num_passenger']:1;
        $this->_CsearchTripType =  isset($masterData['requestTableData']['trip_type'])?$masterData['requestTableData']['trip_type']:0;
        $this->_IadultCount = isset($masterData['requestTableData']['adult_count'])?$masterData['requestTableData']['adult_count']:1;
        $this->_IchildCount = isset($masterData['requestTableData']['child_count'])?$masterData['requestTableData']['child_count']:0;
        $this->_IinfatnCount = isset($masterData['requestTableData']['infant_count'])?$masterData['requestTableData']['infant_count']:0;
        $this->_StravelModeCode = isset($masterData['requestTableData']['travel_type'])?$masterData['requestTableData']['travel_type']:$this->_StravelModeCode;
        $this->_DreturnDate = isset($masterData['requestTableData']['return_date'])?$masterData['requestTableData']['return_date']:'';    
        $this->_ItravelClassId = isset($masterData['requestTableData']['r_travel_class_id'])?$masterData['requestTableData']['r_travel_class_id']:'1';	
        $this->_StravelModeId=$masterData['r_travel_mode_id'];
        
        $this->_SonwardFromTime=isset($masterData['onwardTimeStart'])?$masterData['onwardTimeStart']:$this->_SonwardFromTime;
        $this->_SonwardEndTime=isset($masterData['onwardTimeEnd'])?$masterData['onwardTimeEnd']:$this->_SonwardFromTime;

        //If onward date falls by today, then fromTime will be current time
        $this->_SreturnFromTime=isset($masterData['returnTimeStart'])?$masterData['returnTimeStart']:$this->_SreturnFromTime;
        $this->_SreturnEndTime=isset($masterData['returnTimeEnd'])?$masterData['returnTimeEnd']:$this->_SreturnEndTime;

        //Reschedule changes for single airline
        $this->_SrescheduleSearchType = $masterData['returnTimeEnd']['searchType'];
    }

    /**
    * @description to get the airline id from code.
    * @param type $airLineCode airline code
    * @return boolean
    */
    private function _getAirlineId($airLineCode){
        $result = $this->_Oairline->_getAirlineCodeInfo($airLineCode);
        if(!empty($result) && count($result) > 0){         
            return $result[0]['airline_id'];
        }
        else{         
            return false;
        }
    }

	private function _getSearchXml(){                
            
        //xml variables declared
        $markUpXml = 'EMPTY';
        $fareBreakUpXml = 'EMPTY';
        $promoFaresXml = 'EMPTY';
        $fareBreakUp = array();
        $searchUrl = '';
        $tripType = 'O';

        //To generate markup fare xml
        //$markUpXml = $this->_getMarkUpFareDetails($this->_ItravelClassId,$this->_StravelModeId);

        //displayFareBreakUps method's input array generation
        $fareBreakUp['travelClassId']=$this->_ItravelClassId;
        $fareBreakUp['travelModeId']=$this->_StravelModeId;
        $fareBreakUp['parameterName']='*';
        $fareBreakUp['sysParamCode']= $this->_SsystemParamCode;
        $fareBreakUp['segmentType']='ONWAY';
        $fareBreakUp['noOfPass']=$this->_InumOfPassenger;
        $fareBreakUp['displayStatus']='Y';
        $fareBreakUp['corporateId']=$this->_IcorporateId;
                
        //Trip type value is changed for query execution
        $fareBreakUp['tripType']= $this->_CsearchTripType; 
                
        //To generate fare break up xml
        $fareBreakUpXml = $this->_displayFareBreakUps($fareBreakUp);
                 
        //Get Corporatefare XML
        $this->_XcorporateFare =  $this->_getCorporateAllFlightSearch();
        $this->_CrefundableSearch = 'N';        
        $this->_AgoAirSpecialFares = $this->_getSpecialFares(); 
        
        if(isset($this->_IinputData['factBookingDetails']['r_package_id'])){            
            $this->_AserviceResponse['packageId'] =$this->_IinputData['factBookingDetails']['r_package_id'];            
        }
        
        $this->_AserviceResponse['tripType']=$this->_CsearchTripType;
        $this->_AserviceResponse['travelInfo']['adult'] =$this->_IadultCount;
        $this->_AserviceResponse['travelInfo']['child'] =$this->_IchildCount;
        $this->_AserviceResponse['travelInfo']['infant'] =$this->_IinfatnCount;
        $this->_AserviceResponse['airLineCode'] = isset($airlineCode) ? $airlineCode : $GLOBALS['custom']['searchAirlineCodes'];
        $this->_AserviceResponse['flightCounter']=$GLOBALS['custom']['flightSearchCount'];
                
        //To generate discout fare flights pbm       
        if(in_array('SG',$GLOBALS['custom']['searchAirlineCodes']))
            $this->_XpromoFares=$this->_discountFareFlights('SG');
        if(in_array('6E',$GLOBALS['custom']['searchAirlineCodes']))
            $this->_XindigoPromoFares=$this->_discountFareFlights('6E');
        if(in_array('9W',$GLOBALS['custom']['searchAirlineCodes']))
            $this->_XpromoGDSfares=$this->_discountFareFlights('9W');
                
        //Change the trip type only for roundtrip by default 'O' -> oneway
        if($this->_CsearchTripType==1)
            $tripType='R';
                
        //Search response decrypt flag
        if(SEARCH_DECRYPT_FLAG){
            $this->_SresponseType = 'encode';
        }

        //Check for dummy flight data or Service Data 0 - local data, 1 - live data
        if(SEARCH_TYPE){ 
            
            //Generate Servic URL
            $searchUrl.='&adult='.$this->_IadultCount.'&child='.$this->_IchildCount.'&infant='.$this->_IinfatnCount.'&cabinclass='.$this->_ScabinClass.'&tripType='.$tripType.'&refundableFare='.$this->_CrefundableSearch.'&markupfares='.$markUpXml;

            $searchUrl.='&userkey=AYPR&fareBreakUps='.$fareBreakUpXml.'&promofares='.$this->_XpromoFares.'&corporateid='.$this->_IcorporateId.'&goSpecial='.$this->_AgoAirSpecialFares.'&corporateFaresXML='.$this->_XcorporateFare.'&indigoPromoFares='.$this->_XindigoPromoFares.'&promoGDSfares='.$this->_XpromoGDSfares.'&responseType='. $this->_SresponseType.'&combinedType=NO';

            /** reschedule flight search changes **/
            if(isset($this->_SrescheduleSearchType) && $this->_SrescheduleSearchType == 'TRUE'){
                $searchUrl.= '&searchType=reschedule';
            }
            $this->_AserviceResponse['fareUrl'] = $searchUrl;
            $this->_AserviceResponse['serviceUrl'] = SERVICE_URL;
            $this->_AserviceResponse['searchDecryptKey'] = SEARCH_DATA_DECRYPTION_KEY;
            $this->_AserviceResponse['decryptFlag'] = SEARCH_DECRYPT_FLAG;            
        }
        else{            
            $this->_AserviceResponse['serviceUrl'] = './dummyData/index.php?';
            $this->_AserviceResponse['fareUrl']=$searchUrl;
        }       
	}
	 
	/**
	 * Method Name        : _getCorporateAllFlightSearch
	 * Desc  	      	  : To get specialFareCheck status for goair airline
	 * @access public
	 * @param corporateid : Unique id of a corporate, default value is 0
	 * @return type		  : string
	 */
	function _getCorporateAllFlightSearch(){

        $corpAllXml='EMPTY';
        $_AcorporateAllAirline=array();

        $sqlquery="SELECT
                        dmpcd.operating_airline_code as marketingAirline,
                        dmpcd.booking_class as class,
                        dmpcd.fixed_fare as fare,
                        dmpcd.flight_number as flightNumber,
                        dmpcd.promo_code_value as promocode,
                        dmpcd.fare_basis_code as farebasis,
                        dmpcd.fare_check as farecheck
                    FROM
                        dm_promo_code dmpcd,
                        promo_code_mapping pcm
                    WHERE
                        dmpcd.promo_code_id=pcm.r_promo_code_id
                        AND if(dmpcd.fare_check='Y',dmpcd.fixed_fare=0,dmpcd.fixed_fare > 0)
                        AND LOCATE(dayofweek('".$this->_DonwardDate."'),applicable_days)
                        AND pcm.r_corporate_id=".$this->_IcorporateId."
                        AND if(dmpcd.fare_check='Y',dmpcd.origin='*',dmpcd.origin='".$this->_Sorigin."')
                        AND if(dmpcd.fare_check='Y',dmpcd.destination='*',dmpcd.destination='".$this->_Sdestination."')
                        AND dmpcd.marketing_airline_code in (".$this->_ScorpFareAirlines.")
                        AND date_format('".$this->_DonwardDate."','%Y-%m-%d') between dmpcd.start_date and dmpcd.end_date order by dmpcd.fixed_fare asc";
        $corpAllXml='<corporateFares><corporateId>'.$this->_IcorporateId.'</corporateId><origin>'.$this->_Sorigin.'</origin><destination>'.$this->_Sdestination.'</destination><airline>'.$corpFareAirlinesService.'</airline><departureDate>'.$this->_DonwardDate.'</departureDate>';
        $corpAllXml.='<numberOfPassenger>'.$this->_InumOfPassenger.'</numberOfPassenger><fromtime>'.$this->_SonwardFromTime.'</fromtime><totime>'.$this->_SonwardEndTime.'</totime><offeredClass>';

        $result =  $this->_OcommonDBO->_getResult($sqlquery);

        if(is_array($result) && count($result)>0){
            foreach($result as $key => $value){
                $corpAllXml .='<fareClass>'.generateXmlWithValue($value).'</fareClass>';
            }
            $corpAllXml.='</offeredClass></corporateFares>'; 
        }
        else{

            fileWrite($sqlquery,"SqlError","a+");
        }
        return $corpAllXml;
	}

    /**
    * Method Name        : getSpecialFares
    * Desc  	      : To get specialFareCheck status for goair airline
    * @access public
    * @param corporateid : Unique id of a corporate, default value is 0
    * @return type       : char
    */
	public function _getSpecialFares(){

		$this->specialFareCheck = 'N';
		 
        $sqlGoAir="SELECT
                        pcd.marketing_airline_code as airlineCode,
                        pcd.booking_class as bookingClass,  
                        pcm.r_corporate_id as corporateid,
                        pcd.fare_basis_code as fareBasisCode,
                        pcd.promo_code_value as promoCode
                    FROM
                        dm_promo_code pcd 
                        INNER JOIN promo_code_mapping pcm ON pcd.promo_code_id = pcm.r_promo_code_id
                    WHERE
                        pcm.r_corporate_id=".$this->_IcorporateId."
                       AND pcd.marketing_airline_code = 'G8'
                       AND pcm.status='Y'
                       AND pcd.fixed_fare=0
                       AND LOCATE(dayofweek('".$this->_DtodayDate."'),applicable_days)
                       AND if(pcd.fare_check='Y',pcd.origin='*',pcd.origin='*')
                       AND if(pcd.fare_check='Y',pcd.destination='*',pcd.destination='*')
                       AND date_format('".$this->_DtodayDate."','%Y-%m-%d') between pcd.start_date and pcd.end_date order by pcd.fixed_fare asc";
  
        $result =  $this->_OcommonDBO->_getResult($sqlGoAir);
        if (is_array($result) && count($result)>0) {
            $this->specialFareCheck = 'Y';
        }
        return $this->specialFareCheck;
	}

    /**
    * Method Name        : getMarkUpFareDetails
    * Desc  	      : To check markup fare is enabled for the corporate or not
    * @access private
    * @param cabin       : input parameters are ( 'E','B','F' ) E - Economy class , B - Business class , F - First class and default value is 'E'
    * @param travelmode  : input parameters are ( 'D','IN' ) D - Domestic , IN - Internatinal and default value is 'D'
    * @return type		  : xml
    */
	private function _getMarkUpFareDetails($travelClassId=0,$travelModeId=0){
            
        $markxml='EMPTY';
        $sqlMarkup="SELECT 
                            dmair.airline_code as code,
                            dmf.fare_type as faretype,
                            dmf.value as charges, 
                            dmf.markup_fee_type as markupfeetype, 
                            dmf.calculation_based_on as markupfeeassign
                    FROM 
                            dm_markupfare dmf,markupfare_mapping mfm,dm_airline dmair
                    WHERE 
                            dmf.markupfare_id = mfm.r_markupfare_id
                            AND dmf.r_travel_class_id = ".$travelClassId."
                            AND dmf.r_travel_mode_id = ".$travelModeId."
                            AND dmf.status = 'Y'
                            AND dmair.airline_id=dmf.r_airline_id
                            AND mfm.status = 'Y'
                            AND mfm.r_corporate_id =".$this->_IcorporateId;
        $result =  $this->_OcommonDBO->_getResult($sqlMarkup);
        if(!$result){                    
            fileWrite('Error in query:'.$sqlMarkup, 'SqlError', 'a+');            
        }
        if(is_array($result) && $this->_IcorporateId != 0){            
            $markxml = '<markupFares><corporateid>'.$this->_IcorporateId.'</corporateid>';            
            foreach($result as $key => $value){
                $markxml .='<airline>';
                $markxml .=generateXmlWithValue($value);
                $markxml .='</airline>';
            } 
            $markxml .= '</markupFares>';
        }         
		return $markxml;
	}
	
	/**
	 * Method Name        : displayFareBreakUps
	 * Desc  	      	  : To display the fare breakups based corporate id, travelmode and cabin class.
	 * @access public
	 * @param corporateId : Unique id of a corporate, default value is 0
	 * @param travelMode  : input parameters are ( 'D','IN' ) D - Domestic , IN - Internatinal and default value is 'D'
	 * @param cabinClass  : input parameters are ( 'E','B','F' ) E - Economy class , B - Business class , F - First class and default value is 'E'
	 * @input param       : param={"mod":"flightSearch","method":"displayFareBreakUps","parameter":{"corporateId":"3","cabinClass":"E","emailId":"balamurugan@atyourprice.in","origin":"MAA","destination":"DEL","onwardDate":"2015-05-25","tripType":"1","numOfPass":"1"}}} 
	 * @return type		  : xml
	 */
	public function _displayFareBreakUps($fareArray){
		
        //Get the fare breakups based on  the corporateid
        $fareXml='';
        $sqlServiceTax="SELECT  
                            daf.agent_fee_name,
                            afm.fee_type,
                            afm.calc_based_on,
                            afm.fee_value,
                            dtc.class_code,
                            dtm.travel_mode_code
                        FROM 
                            agent_fee_mapping afm 
                            LEFT JOIN dm_agent_fee daf ON daf.agent_fee_id = afm.r_agent_fee_id 
                            LEFT JOIN dm_travel_class dtc ON dtc.travel_class_id = afm.r_travel_class_id 
                            LEFT JOIN dm_travel_mode dtm ON dtm.travel_mode_id = afm.r_travel_mode_id
                        WHERE
                            afm.r_corporate_id=".$this->_IcorporateId." AND 
                            afm.r_travel_class_id=".$fareArray['travelClassId']." AND
                            afm.r_travel_mode_id=".$fareArray['travelModeId'];

        $result =  $this->_OcommonDBO->_getResult($sqlServiceTax);              
        if(!$result){
            $fareXml = 'EMPTY';             
            fileWrite('Error in query:'.$sqlServiceTax, 'SqlError', 'a+');
        } 
        else{
                    
            $fareXml='<fareBreakUps><txnFareBreakUp>';

            if(is_array($result)){

                $fareXml.='<corporateId>'.$this->_IcorporateId.'</corporateId>';
                foreach($result as $key => $value){                    
                    $fareXml.='<'.$value['agent_fee_name'].'>'.$value['fee_value'].'</'.$value['agent_fee_name'].'>';
                    $fareXml.='<'.$value['agent_fee_name'].'Type>'.$value['fee_type'].'</'.$value['agent_fee_name'].'Type>';
                    $fareXml.='<'.$value['agent_fee_name'].'Assign>'.$value['calc_based_on'].'</'.$value['agent_fee_name'].'Assign>';
                } 
               
                $fareXml.='</txnFareBreakUp>';
                $fareXml.=$this->_serviceTaxSplitUp();
                $fareXml.='<tripType>'.$fareArray['tripType'].'</tripType><segmentType>'.$fareArray['segmentType'].'</segmentType><numPassenger>'.$fareArray['noOfPass'].'</numPassenger><fareDisplay>'.$fareArray['displayStatus'].'</fareDisplay>';
                $fareXml.='</fareBreakUps>';
                 
                return $fareXml;
            } 
            else{
                 $fareXml='<txnFareBreakUp><transactionFee>0</transactionFee><transactionFeeType></transactionFeeType><transactionFeeAssign></transactionFeeAssign><discountAmount>0</discountAmount><discountAmountType></discountAmountType><discountAmountAssign></discountAmountAssign><systemUsageFee>0</systemUsageFee><systemUsageType></systemUsageType><corporateId>'.$this->_IcorporateId.'</corporateId></txnFareBreakUp>';
                $fareXml.='<tripType>'.$fareArray['tripType'].'</tripType><segmentType>'.$fareArray['segmentType'].'</segmentType><numPassenger>'.$fareArray['noOfPass'].'</numPassenger><fareDisplay>'.$fareArray['displayStatus'].'</fareDisplay>';
                $fareXml.='</fareBreakUps>';
                        
            }
        }            
        return $fareXml;
	}

    public function _serviceTaxSplitUp(){

        $servicXml='';
        $airlineId=$this->_getAirlineId('G8');
        $serviceSplitUp = "SELECT 
                                tmv.percentage,
                                td.tax_details_name,
                                tmv.valid_from,
                                tmv.valid_to
                            FROM
                                dm_tax dmt,
                                tax_mapping_value tmv,
                                tax_details_ids td
                            WHERE
                                dmt.tax_master_id = tmv.r_tax_master_id and
                                td.tax_details_id = tmv.r_tax_details_id and
                                dmt.tax_name='".$this->_SsystemParameters."' and
                                tmv.r_airline_id = ".$airlineId." and '".date('Y-m-d')."' BETWEEN valid_from and valid_to";
             
        $result =  $this->_OcommonDBO->_getResult($serviceSplitUp);                            
        if(!$result){                                
            fileWrite('Error in query:'.$serviceSplitUp, 'SqlError', 'a+');
        }
        else{                                
            if(is_array($result)){                
               $servicXml .=generateXmlWithValue(array_column($result,'percentage','tax_details_name'));
               $servicXml .='<startDate>'.$result[0]['valid_from'].'</startDate><endDate>'.$result[0]['valid_to'].'</endDate>';
               return $servicXml;                
            }            
        }                            
        return $servicXml;                                
    }

    /**
    * Method Name        : discountFareFlights
    * Desc  	      	  : To check the corporate is having discount promo codes
    * @access public
    * @param corporateId : Unique id of a corporate
    * @airlineCode		  : Unique code for a Airline eg:('SG','6E','9W'....)
    * @travelDate		  : Travel date of the requested sector
    * @return type		  : xml
    */
	public function _discountFareFlights($airCode){
            
        $promoFares = 'EMPTY';
         
        $sqlPromocode = "SELECT
                            pcd.marketing_airline_code as airlineCode,
                            pcd.booking_class as bookingClass,  
                            pcm.r_corporate_id as corporateid,
                            pcd.fare_basis_code as fareBasisCode,
                            pcd.promo_code_value as promoCode
                        FROM
                            dm_promo_code pcd 
                        INNER JOIN promo_code_mapping pcm ON pcd.promo_code_id = pcm.r_promo_code_id
                        WHERE
                            pcm.r_promo_code_id=pcd.promo_code_id
                            AND pcm.r_corporate_id=".$this->_IcorporateId."
                            AND pcd.marketing_airline_code ='".$airCode."'
                            AND pcm.status='Y'
                            AND  '".$this->_DonwardDate."' between pcd.start_date and pcd.end_date order by pcd.booking_class asc";
        $result =  $this->_OcommonDBO->_getResult($sqlPromocode);

        if(!$result){
            fileWrite('Error in query:'.$sqlPromocode, 'SqlError', 'a+');
        }
        else{
            if(is_array($result)){
                $promoFares = '<promofares><corporateid>'.$this->_IcorporateId.'</corporateid>';
                foreach($result as $key => $value){
                    $promoFares .='<airline>';
                    $promoFares .=generateXmlWithValue($result[$key]);
                    $promoFares .='</airline>';
                }
                $promoFares .= '</promofares>';
                 
                array_push($this->_AserviceResponse['airLineCode'][$airCode],'CF');
                $this->_AserviceResponse['flightCounter']++;
                 
            }
        } 
        return $promoFares;
    }
    
    public function _getPersonalFlightSearchConfigurations(){
            
       $this->_OcommonQuery = new commonQuery();

       //set the inputs for getting the fare profile settings info
       $fareProfileSettingsInput = array('travelMode' => $this->_IinputData['travelModeType'], 'tripType' => $this->_IinputData['masterInfo']['requestTableData']['trip_type'],'configuration' => 'Flight_Search_Configurations');

       //calling function for getting the fare profile settings info with respect to the employee, travel mode and trip type.
       $this->_AserviceResponse['fareProfileSettings'] = $this->_OcommonQuery->_getFareProfileSettingsInfo($fareProfileSettingsInput);
       return true;
    }

      /**
     * common function used to form a template URL 
     * @param array $value
     * @param array $requestDetails
     * @param int $key
     * @return array
     * @author Baskar.V.P
     */
    public function _getFlightTemplateUrl(){
        global $CFG;
        $url=array();
        $templateFolderPath ='view/personal/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch';
        //common url's
        $this->_IinputData['travel_mode'] = $this->_IinputData['travel_mode'] ? $this->_IinputData['travel_mode'] : $this->_IinputData['masterInfo']['requestTableData']['travel_type'];
        switch(true){
            case ($this->_IinputData['travel_mode'] =='I' && ($this->_IinputData['masterInfo']['requestTableData']['trip_type']=='0' || $this->_IinputData['masterInfo']['requestTableData']['trip_type']=='1') || ($this->_IinputData['travel_mode'] =='D' && $this->_IinputData['masterInfo']['requestTableData']['trip_type']=='0')):
                // onward international url's
                $url['ONWARDFLIGHTSEARCHURL'] = 'view/personal/harinim/html/flightSearch/onward/search.html';
                $url['ONWARDFLIGHTLIST'] = file_exists($CFG['path']['basePath'].'view/personal/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/onward/onwardFlightList.html') ? 'view/personal/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/onward/onwardFlightList.html' : 'view/personal/harinim/html/flightSearch/onward/onwardFlightList.html';
                $url['ONWARDCHOOSENFLIGHT'] = file_exists($CFG['path']['basePath'].'view/personal/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/onward/selectedFlight.html') ? 'view/personal/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/onward/selectedFlight.html' : 'view/personal/harinim/html/flightSearch/onward/selectedFlight.html';
                $this->_AtwigOutputArray['flightSearchUrl'] = $url['ONWARDFLIGHTSEARCHURL'];
                break;
            case ($this->_IinputData['masterInfo']['requestTableData']['trip_type'] == 1 && $this->_IinputData['travel_mode'] == 'D'):
               // $url['RETURNFLIGHTSEARCHURL'] = 'view/personal/harinim/html/flightSearch/return/search.html';
                $url['RETURNCHOOSENFLIGHT'] = file_exists($CFG['path']['basePath'].'view/personal/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/return/selectedFlight.html') ? 'view/personal/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/return/selectedFlight.html' : 'view/personal/harinim/html/flightSearch/return/selectedFlight.html';
                $url['RETURNFLIGHTSEARCHURL'] = file_exists($CFG['path']['basePath'].'view/personal/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/return/returnSearch.html') ? 'view/personal/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/return/returnSearch.html' : 'view/personal/harinim/html/flightSearch/return/returnSearch.html';
                break;
            case ($this->_IinputData['masterInfo']['requestTableData']['trip_type'] == 2 && $this->_IinputData['travel_mode'] == 'D'):
                //Multicity url's
                $url['MULTISEARCHFLIGHTSEARCHURL'] = 'view/personal/harinim/html/flightSearch/multiCity/search.html';
                $url['MULTISEARCHCHOOSENFLIGHT'] = file_exists($CFG['path']['basePath'].'view/personal/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/multiCity/selectedFlight.html') ? 'view/personal/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/multiCity/selectedFlight.html' : 'view/personal/harinim/html/flightSearch/multiCity/selectedFlight.html';
                $url['MULTISEARCHFLIGHTRESPONSEURL'] = file_exists($CFG['path']['basePath'].'view/personal/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/multiCity/response.html') ? 'view/personal/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/multiCity/response.html' : 'view/personal/harinim/html/flightSearch/multiCity/response.html';
                break;
        }
        $this->_AserviceResponse['url'] = $url;
    }
}
?>