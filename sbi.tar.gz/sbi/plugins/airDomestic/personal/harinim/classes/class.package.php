<?php

/* * **************************************************************************
 * @File             : class.package.php
 * @Description      : This file is used to insert,update,delete and get dm_package and order_details
 * @dimensionTables  : dm_package ,order_details 
 * @Author           : Lakshmi.S
 * @Created Date     : 01/07/2016
 * @Modified Date     : 
 * *************************************************************************** */
namespace personal;

pluginFileRequireByTravelMode('airDomestic/corporate/harinim/classes/class.package.php', true);

class package extends  \package{

    private $_OcommonDBO;

    public function __construct() {
        
        $this->_OcommonDBO = new \commonDBO();
        $this->_Ocurrency = new \location();
        $this->_OapplicationSettings = new applicationSettings();
        $this->_OpassengerDetails = new passenger();
	$this->_OfareDetails=new \fareDetails();
        
        parent::__construct();
    }

    /**
     * @Description :This function is used to insert the package details 
     * @param :array   | $packageDetails - holds array of package details
     * @return integer |$resultPackageId - inserted package id
     */
    
    
    public function _insertPackage($packageDetails) {
        if(isset($_SESSION['bookingMode']) && !empty($_SESSION['bookingMode']) && $_SESSION['bookingMode']==3){
           $packageDetails['booking_mode']=$_SESSION['bookingMode'];
        }
        $tableName       = 'dm_package';
        $resultPackageId = $this->_OcommonDBO->_insert($tableName, $packageDetails);
        if(ERROR_DEBUG_REPORT)
        {
            if(!$resultPackageId > 0)
            {
                $this->_OapplicationSettings->pushInsertDetailsOfDmPackage($packageDetails,$tableName,$resultPackageId,$this->_OcommonDBO->_AbugTracking);
            }
            else 
            {
                $this->_OapplicationSettings->pushInsertDetailsOfDmPackage($packageDetails,$tableName,$resultPackageId);
            }
        }
        // for inserting hotel and air combo for hotel insertion on facrbookingdetails
        $_SESSION['lastInsertedPackageId'] = $resultPackageId;
        return $resultPackageId;
    }

    public function _getTravelType($orderId) {
     
        $sqlTravelType = "SELECT 
                r_travel_mode_id
            FROM
                order_details od
            WHERE 
                od.order_id = ".$orderId;
        $result = $this->_OcommonDBO->_getResult($sqlTravelType);
        return $result;
    }

    /**
    * @Description :This function is used to get the package details 
    * @param :array   | $fieldsArray - holds array of fields get from package details
    * @param :integer   | $packageId - holds the packageid
    * @return array |$resultPackage - holds the array of package details
    */
    public function _getPackage($packageId = 0, $fieldsArray = '') {
        $tableName = 'dm_package';
        $wherekey = 'package_id';
        $wherevalue = $packageId;

        if (!empty($fieldsArray) && count($fieldsArray) > 0) {
            $resultPackage = $this->_OcommonDBO->_select($tableName, $fieldsArray, $wherekey, $wherevalue);
        }
        return $resultPackage;
    }

    /**
     * @Description :This function is used to update the package details 
     * @param :array   | $packageDetails - holds the package details
     * @param :integer   | $packageId - holds the packageid
     * @return boolean |$result - return true or false
     */
    public function _updatePackage($packageDetails, $packageId) {
        $result = $this->_OcommonDBO->_update('dm_package', $packageDetails, 'package_id', $packageId);

        return $result;
    }

    /**
     * @Description :This function is used to delete the package details 
     * @param :integer   | $packageId - holds the packageid
     * @return boolean |$result - return true or false
     */
    public function _deletePackage($packageId) {
        $result = $this->_OcommonDBO->_delete('dm_package', 'package_id', $packageId);

        return $result;
    }

    /**
     * @Description :This function is used to insert the order details 
     * @param :array   | $orderDetails - holds array of order details
     * @return integer |$resultOrderId - inserted order id
     */
    public function _insertOrderDetails($orderDetails) {
        $tableName = 'order_details';
        $resultOrderId = $this->_OcommonDBO->_insert($tableName, $orderDetails);
        
        if(ERROR_DEBUG_REPORT)
        {
            session_start();
            $_SESSION['orderInsertedId'] = $resultOrderId;
            if(!$resultOrderId > 0)
            {
                $this->_OapplicationSettings->pushInsertDetails($orderDetails,$tableName,$resultOrderId,$this->_OcommonDBO->_AbugTracking,'insert');
            }
            else 
            {
                $this->_OapplicationSettings->pushInsertDetails($orderDetails,$tableName,$resultOrderId,'','insert');
            }
        }
        return $resultOrderId;
    }

    /**
     * @Description :This function is used to get the order details 
     * @param :array   | $fieldsArray - holds array of fields get from order details
     * @param :integer   | $orderId - holds the order id
     * @return array |$resultOrder - holds the array of order details
     */
    public function _getOrderDetails($orderId = 0, $fieldsArray = '') {
        $tableName = 'order_details';
        $wherekey = 'order_id';
        $wherevalue = $orderId;
        if (!empty($fieldsArray) && count($fieldsArray) > 0) {
            $resultOrder = $this->_OcommonDBO->_select($tableName, $fieldsArray, $wherekey, $wherevalue);
        }
        return $resultOrder;
    }

    /**
     * @Description :This function is used to get the order details 
     * @param :array   | $fieldsArray - holds array of fields get from order details
     * @param :integer   | $orderId - holds the order id
     * @return array |$resultOrder - holds the array of order details
     */
    public function _getOrderDetailsForGivenInput($fieldsArray = '', $wherekey = 'sync_order_id', $wherevalue) {
        $tableName = 'order_details';

        if (!empty($fieldsArray) && count($fieldsArray) > 0) {
            $resultOrder = $this->_OcommonDBO->_select($tableName, $fieldsArray, $wherekey, $wherevalue);
        }
        return $resultOrder;
    }

    /**
     * @Description :This function is used to update the order details 
     * @param :array   | $orderDetails - holds the order details
     * @param :integer   | $orderId - holds the order id
     * @return boolean |$result - return true or false
     */
    public function _updateOrderDetails($orderDetails, $orderId) {
        
        $result = $this->_OcommonDBO->_update('order_details', $orderDetails, 'order_id', $orderId);      
        if(ERROR_DEBUG_REPORT)
        {
            if(!$result > 0)
            {
                $this->_OapplicationSettings->pushInsertDetails($orderDetails,'order_details',$orderId,$this->_OcommonDBO->_AbugTracking);
            }
            else 
            {
                $this->_OapplicationSettings->pushInsertDetails($orderDetails,'order_details',$orderId);
            }
        }
        return $result;
    }

    /**
     * @Description :This function is used to delete the order details 
     * @param :integer   | $orderId - holds the order id
     * @return boolean |$result - return true or false
     */
    public function _deleteOrderDetails($orderId) {
        $result = $this->_OcommonDBO->_delete('order_details', 'order_id', $orderId);

        return $result;
    }

    /**
     * @Description :This function is used to insert the package details 
     * @param :array   | $packageDetails - holds array of package details
     * @return integer |$resultPackageId - inserted package id
     */
    public function _insertFactBookingDetails($factBookingDetails) {
        $tableName = 'fact_booking_details';
        $resultFactId = $this->_OcommonDBO->_insert($tableName, $factBookingDetails);
        if(ERROR_DEBUG_REPORT)
        {
            if(!$resultFactId > 0)
            {
                $this->_OapplicationSettings->pushInsertDetails($factBookingDetails,$tableName,$resultFactId,$this->_OcommonDBO->_AbugTracking);
            }
            else 
            {
                $this->_OapplicationSettings->pushInsertDetails($factBookingDetails,$tableName,$resultFactId);
            }
        }
        return $resultFactId;
    }

    /**
     * @Description :This function is used to update the fact booking details
     * @param :array   | $factBookingDetails - holds array of booking details
     * @return integer |$affectedCount - affected rows count
     */
   public function _updateFactBookingDetails($factBookingDetails, $factBookingId) {
       $tableName        = 'fact_booking_details';
       $affectedCount  = $this->_OcommonDBO->_update($tableName, $factBookingDetails, 'fact_booking_details_id', $factBookingId);
        
       return $affectedCount ;
   }
   
   /**
     * @Description :This function is used to update the fact booking details
     * @param :array   | $factBookingDetails - holds array of booking details
     * @return integer |$affectedCount - affected rows count
     */
   public function _updateFactBookingWithOrderId($factBookingDetails, $orderId) {
       $tableName        = 'fact_booking_details';
       $affectedCount  = $this->_OcommonDBO->_update($tableName, $factBookingDetails, 'r_order_id', $orderId);
        
       return $affectedCount ;
   }
   
   /*
     * @Description  this function get the basic info of the AYPRC
     * @param int|$orderId
     * @return 
     */

    public function _getOrderDetailsInfo($orderId) {
        
        GLOBAL $CFG;
        $sqlOrd = "SELECT DISTINCT
					od.order_id,
                                        od.travel_purpose,
					od.total_amount,
					od.r_currency_type_id,
					dp.requested_by,
                                        dp.package_id,
                                        DATE_FORMAT(dp.created_date,'" . $CFG['date_format']['date_day'] . "') as created_date,
					de.email_id,
                                        fbd.r_request_id,
                                        dp.package_type,
                                        od.r_travel_mode_id as travelMode,
                                        od.sync_order_id
				FROM
					order_details od,
					dm_package dp,
					fact_booking_details fbd,
					dm_employee de
				WHERE
                                        od.order_id = fbd.r_order_id 
					AND fbd.r_package_id = dp.package_id
					AND fbd.r_employee_id = de.employee_id
					AND od.order_id =" . $orderId;
        $resultOrd = $this->_OcommonDBO->_getResult($sqlOrd);
        
        if ($resultOrd != '') {
            return $resultOrd;
        }
    }

    /*
     * @Description  this function is to get the order info from the array
     * @param array |$resultOrd
     * @return array |$resultOrd
     */

    public function _getOrderInfo($resultOrd) {
        /*         * ** to get the currency type  * */
        if ($resultOrd[0]['r_currency_type_id'] != '') {
            $currency = $this->_Ocurrency->_getCurrencyType($resultOrd[0]['r_currency_type_id'], '');
            $resultOrd[0]['currency'] = $currency[0]['currency_symbol'];
        }
        return $resultOrd;
    }

    /*
     * @Description  this function is used to get booking person details
     * @param int | $packageId 
     * @return array |$result
     */
    public function _getBookingPersonInfo($orderId,$packageId=0){
        $sql= "SELECT 
                dme.employee_id,
                dme.email_id,
                fbd.r_corporate_id,
                fbd.r_package_id
            FROM
                dm_employee dme,
                fact_booking_details fbd
            WHERE 
                dme.employee_id=fbd.r_employee_id 
                AND fbd.r_order_id=".$orderId;
        
        if($packageId!=0){
            $sql=$sql." fbd.r_package_id=".$packageId;
        }
        $result = $this->_OcommonDBO->_getResult($sql);
        return $result;
    }

    /*
     * @Description  this function is used to get order id belongs to the package
     * @param int | $packageId 
     * @return array |$result
     */

    public function _getPaidPackageDetails($packageId = 0) {
        $sqlPackage = "SELECT 
                r_order_id,package_type,od.r_travel_mode_id,fbd.r_request_id,od.total_amount,od.sync_order_id,fbd.r_corporate_id
            FROM
                dm_package dmp,
                fact_booking_details fbd,
                order_details od
            WHERE 
                fbd.r_package_id = dmp.package_id
                AND od.order_id = fbd.r_order_id
                AND dmp.package_id=$packageId"
                . " ORDER BY r_order_id";
        
        $result = $this->_OcommonDBO->_getResult($sqlPackage);
        return $result;
    }
    
    public function _getPaidPackageDetailsParent($packageId = 0) {
       $response =  parent:: _getPaidPackageDetails($packageId);
       return $response;
    }

    /*
     * @Description  this function is used to get order id belongs to the package
     * @param int | $packageId 
     * @return array |$result
     */

    public function _getPaymentCompletedPackageDetails($packageId = 0,$travelModeId=0,$orderId = 0) {
        
        $sqlPackage = "SELECT 
                dmp.package_id,
                fbd.r_order_id,
                od.r_travel_mode_id,
                od.total_amount,
                dmp.package_type
            FROM
                dm_package dmp,
                fact_booking_details fbd,
                order_details od
            WHERE 
                fbd.r_package_id = dmp.package_id
                AND od.order_id = fbd.r_order_id
                AND r_payment_status_id = " . PAYMENT_DONE." 
                AND dmp.package_id=".$packageId;
        
        if($travelModeId!=0){
            $sqlPackage.=" AND od.r_travel_mode_id=".$travelModeId;
        }
         if($orderId!=0){
            $sqlPackage.=" AND od.order_id=".$orderId;
        }
        $sqlPackage.=" ORDER BY r_order_id";
        
        $result = $this->_OcommonDBO->_getResult($sqlPackage);
        
        if($result!=''){ 
            foreach($result as $key=>$orderData){ 
                $agentFeeDetails=array();
                $agentFeeDetails=$this->_OfareDetails->_getAgentFeeDetailsByOrderId($orderData['r_order_id']);
                $result[$key]['agentFeeDetails']=$agentFeeDetails;
            }            
        }
        return $result;
    }
     /**
     * @Description :This function is used to get the package details when payment faliure occure
     * @param  :packageId
     * @return :array 
     * @author :Rajesh
     **/
    public function _getPaymentFailedDetails($packageId = 0,$travelModeId=0,$orderId = 0,$paymentType='') {
        
        $sqlPackage = "SELECT 
                dmp.package_id,
                fbd.r_order_id,
                od.r_travel_mode_id,
                od.total_amount,
                dmp.booking_type,
                dmp.package_type,
                dmp.created_date
                
            FROM
                dm_package dmp,
                fact_booking_details fbd,
                order_details od
            WHERE 
                fbd.r_package_id = dmp.package_id
                AND od.order_id = fbd.r_order_id 
                AND r_payment_status_id = 15 ";

        if($packageId !=0) {
            $sqlPackage.= " AND dmp.package_id=".$packageId;
        }
        
        if($travelModeId!=0){
            $sqlPackage.=" AND od.r_travel_mode_id=".$travelModeId;
        }
         if($orderId!=0){
            $sqlPackage.=" AND od.order_id=".$orderId;
        }
        $sqlPackage.=" ORDER BY r_order_id";
        
        $result = $this->_OcommonDBO->_getResult($sqlPackage);
        
        if($result!=''){ 
            foreach($result as $key=>$orderData){ 
                $agentFeeDetails=array();
                // calling function to get the agent fee details for the order
                $agentFeeDetails=$this->_OfareDetails->_getAgentFeeDetailsByOrderId($orderData['r_order_id']);
                $result[$key]['agentFeeDetails']=$agentFeeDetails;
            }            
        }
        return $result;
    }
    
     /**
     * @Description :This function is used to get the package details while passing package type as parameter.
     * @param :array   | $fieldsArray - holds array of fields get from package details
     * @param :integer   | package_type - holds the packagetype
     * @return array |$resultPackage - holds the array of package details
     */
    public function _getPackageInfo($packageType, $fieldsArray = '') {
     
        $tableName = 'dm_package';
        $wherekey = 'package_type';
        $wherevalue = $packageType;

        if (!empty($fieldsArray) && count($fieldsArray) > 0) {
            $resultPackage = $this->_OcommonDBO->_select($tableName, $fieldsArray, $wherekey, $wherevalue);
        }        
        return $resultPackage;
    }
    
    /**
     * @Description :This function is used to get the package details while passing package type as parameter.
     * @param :array   | $fieldsArray - holds array of fields get from package details
     * @param :integer   | package_type - holds the packagetype
     * @return array |$resultPackage - holds the array of package details
     */
    
    public function _getOrderInfoBypackage($packageType)
    {
        $permission = $_SESSION['permissions'];
         
        $getInfo = "SELECT
                        dm.package_id,
                        dm.package_type,
                        fbd.r_order_id as orderId, 	
                        sum(od.total_amount) as Amount, 
                        od.r_ticket_status_id as Cancel_status,
                        od.r_currency_type_id,
                        GROUP_CONCAT(od.sync_order_id) as comboOrderId,
                        od.sync_order_id,
                        od.created_date
                    FROM 
                        fact_booking_details fbd
                        INNER JOIN dm_package dm ON dm.package_id = fbd.r_package_id
                        INNER JOIN order_details od ON fbd.r_order_id = od.order_id
                    WHERE 
                        dm.package_type = '".$packageType."' 
                        AND od.r_payment_status_id = '".PAYMENT_DONE."' AND dm.booking_type = '0' ";
        
        
         //Condition for Data  Permission for permission type self
        if ($permission['permissionName'] == 'Self') {
            $this->condition .="AND fbd.r_employee_id='" . $permission['r_employee_id'] . "'";
        }

        //Condition for Data  Permission for permission type other corporate
        elseif ($permission['permissionName'] == 'Other Corporate') {
            $inCondition = '';
            $this->condition .="AND fbd.r_corporate_id IN (" . implode(',', $permission['r_corporate_id']) . ")";
        }

        //Condition for Data  Permission for permission type other employee
        elseif ($permission['permissionName'] == 'Other Employee') {
            $this->condition .="AND fbd.r_employee_id IN (" . implode(',', $permission['r_employee_id']) . ")";
        }

        //Condition for Data  Permission for permission type Self Corporate
        elseif ($permission['permissionName'] == 'Self Corporate') {
            $this->condition .="AND fbd.r_corporate_id IN (" . $permission['r_corporate_id'] . ")";
        }
        
        
        $this->condition .= " GROUP BY fbd.r_package_id " ;
        
        $getInfo = $getInfo.$this->condition." ORDER BY fbd.r_package_id DESC LIMIT 50";
        
        $result = $this->_OcommonDBO->_getResult($getInfo); 
        
        if($result != "")
        {
            foreach ($result as $data)
            {
                /*** to get currency symbol **/
                if($data['r_currency_type_id'] != "")
                {
                    $currencyType = $this->_Ocurrency->_getCurrencyType($data['r_currency_type_id'],'currency_symbol');
                    $data['currency_type'] = $currencyType[0]['currency_symbol'];
                }  
                /*** to get the status value **/
                if($data['Cancel_status'] != '')
                {
                    $_status = $this->_OapplicationSettings->_getTicketStatus($data['Cancel_status']); 
                    $data['status_value'] = $_status[0]['status_value'];
                    $data['icon_class_name'] = $_status[0]['icon_class_name'];
                }
                 /*** to get the passenger info of booking **/
                if($data['orderId'])
                {
                    $_ApaxDetails = $this->_OpassengerDetails->_getPassengerDetails($data['orderId']);
                    $data['Name'] = $_ApaxDetails[0]['paxName'];
                }
                
                $row[] = $data;
            }
        }
        return $row;
    }
}
?>