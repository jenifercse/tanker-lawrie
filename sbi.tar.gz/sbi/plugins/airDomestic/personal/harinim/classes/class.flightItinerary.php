<?php

/* * *********************************************************************************************
 * @Class Name	: insertFlightItinerary
 * @Created on	: 2016-07-20
 * @Created By	: Taslim
 * @Updated By  : --
 * @Update Info : -- 
 * @Description	: This class will handle all the flight itinerary related CURD and business logic
 * ********************************************************************************************** */

namespace personal;

pluginFileRequireByTravelMode('airDomestic/corporate/harinim/classes/class.flightItinerary.php', true);
fileRequire('plugins/airDomestic/personal/harinim/classes/class.flightItinerary.php');
fileRequire('plugins/airDomestic/personal/harinim/classes/class.passenger.php');
fileRequire('plugins/airDomestic/personal/harinim/classes/class.applicationSettings.php');
fileRequire('plugins/airDomestic/personal/harinim/classes/class.airline.php');
fileRequire('plugins/airDomestic/personal/harinim/classes/class.airRequest.php');
fileRequire('plugins/airDomestic/personal/harinim/classes/class.feeCalculation.php');

class flightItinerary extends \flightItinerary {

    public function __construct() {

        $this->db = new \commonDBO();
        $this->_OAppSettings = new applicationSettings();
        $this->_OEmployee = new \employee();

        $this->_Opackage = new \package();
        $this->_AapplicationError = array();
        $this->_OcommonDBO = new \commonDBO();
        $this->_OairportDetails = new \airport();
        $this->_OairlineDetails = new airline();
        $this->_ObandDetails = new passenger();
        $this->_OfareDetails = new \fareDetails();
        $this->_OfeeCalculation = new feeCalculation();
        $this->_OcommonMethods = new \commonMethods();
        $this->_OairRequest = new airRequest();
        $this->_Ocurrency = new \location();
        $this->_ApassengerType = array('0' => 'Adult', '1' => 'Child', '2' => 'Infant');
        $this->_STimeStamp = date('Y-m-d H:i:s');

        //get service tax value for all airlines
        $this->_IAllAirlineserviceTaxValue = $this->_getTaxValues('SERVICE_TAX', '*');

        $this->_IorderTotalFare = 0;
        $this->_IorderTotalServiceTax = 0;
        $this->_IorderCalTransBaseFare = 0;
        $this->_IorderCalSystemBaseFare = 0;
        $this->_IorderDiscountBaseFare = 0;

        $this->_ItransactionFee = 0;
        $this->_ICommissionData = 0;
        $this->_IsystemUsageFee = 0;
        $this->_IdiscountFee = 0;
        //for usage ins transaction fee calucation ...
        $this->_AviaAirlineId = array();
        $this->_AviaFlightNo = array();
        $this->_AviaAirlineIdGST = array();
    }

    /*
     * @Description function handles common flight details insert for lowfare onward/return flight, selected onward/return flight, 
     * @param array|$flightArraytwo times
     * @return
     */

    public function _insertFlightItinerary($flightArray, $lowFareStatus, $tripType = 1, $selectedFlight, $fareArray,$frequentFlyer) {

        //define return response value
        $returnValue = false;
        $this->_AviaFlightIdArray = array();
        $this->_AviaFareFlightId = array();
        $this->_viaFareSplitUp = array();
        $this->_AviaAirlineId = array();
        $this->_SfareTypeCode = $flightArray['fareType'];
        $this->_AflightServiceAgent = isset($flightArray['serviceAgent']['reservationCode'])? $flightArray['serviceAgent']['reservationCode'] : '';
       
        //check and insert via flight details
        $viaFlightCount = count($flightArray['via_flights']);

        if ($viaFlightCount > 0){
            $this->_setViaFlightDetails($flightArray['via_flights'], $lowFareStatus, $tripType, $selectedFlight,$this->_orderId);
        }
       
        //check and insert passenger fare details
        $passengerFareCount = count($flightArray['passenger_fare']);       

        if($passengerFareCount > 0){
            
            //set passenger fare info
            $_ApassengerFare = $flightArray['passenger_fare'];
          
            foreach ($_ApassengerFare as $passengerKey => $passengerValue){
               
                //prepare calculate fare details function arguments
                $calculateArgs = array('num_passenger' => $passengerValue['no_of_passenger'],
                    'pass_calc' => $flightArray['num_passenger'],
                    'tripType' => $tripType,
                    'newBaseFare' => isset($flightArray['new_baseFare']) ? $flightArray['new_baseFare'] : '',
                    'baseFare' => $passengerValue['base_fare'],
                    'calculateAmount' => isset($flightArray['calculate_Amount']) && !empty($flightArray['calculate_Amount']) ? $flightArray['calculate_Amount'] : '',
                    'tax' => $passengerValue['tax'],
                    'new_total_fare' => isset($_ApassengerFare['new_totalFare']) ? $_ApassengerFare['new_totalFare'] : '',
                    'total_fare' => $passengerValue['total_fare'],
                    'transaction_fee' => $fareArray['transactionFee'],
                    'discount_fee' => $fareArray['discountAmount'],
                    'system_usage_fee' => $fareArray['systemUsageFee']);
                //insert into via_fare_details table
                $this->_setPassengerFare($passengerValue, $this->_AviaFlightIdArray, $this->_AfareBasisCodeArray, $calculateArgs, $selectedFlight, $this->_ItravelTripType);
            }
        }

        //insert values into fact_air_itinerary table
        if (count($this->_AviaFlightIdArray) > 0 && count($this->_AfareBasisCodeArray) > 0){
            $this->_saveFactAirItineraryValues($selectedFlight);
        }

        //check and insert taxBreakUP details
        $taxBreakUpCount = count($flightArray['passenger_fare'][0]['taxBreakUpDetails']);

        if ($taxBreakUpCount > 0) {

            /* insert tax breakup details for the first via flight alone since for all other via flights amount will be entered as zero
              as total amount of all vial flights are returned in the first via flight itself */

            $firstViaFareId = current($this->_AviaFareIdArray);

            $this->_setTaxBreakupDetails($firstViaFareId, $this->_viaFareSplitUp);
        }

        if (count($this->_AviaFlightIdArray) > 0){
            $passengerIdArray = $this->_getPassengerId($this->_orderId);
            /* check and insert into passenger_via_details table
              $passengerIdArray = array(0 => array('passenger_id' => 1), 1 => array('passenger_id' => 2), 2 => array('passenger_id' => 3)); */
            $this->_insertPassengerViaDetails($passengerIdArray,$frequentFlyer,$flightArray['cancellation_fee']);
        }

        /* check values are availbel in 
        1. vialflight(Table: via_flight_details) array
        2. via fare array(Table:via_fare_details)
        3. factairitinerary array (table: fact_air_itinerary)
        4. passenger_via_array passenger_via_details */
        if (count($this->_AviaFlightIdArray) > 0 && count($this->_AviaFareIdArray) > 0 && count($this->_IfactAirItinerary) > 0 && count($this->_passengerViaArray) > 0) {
            $returnValue = true;
        }        
        return $returnValue;
    }

    /**
     * @Description insert passenger via details to passenger_via_details table
     * @param
     * @return 
     */

    private function _insertPassengerViaDetails($passengerIdArray,$frequentFlyer,$cancellationFee){

        if(count($passengerIdArray) > 0){
            $iteration = 0;
            foreach($this->_AviaFlightIdArray as $key => $viaFlightId){
                
                $insertPassArray = array();

                //get airline code id
                $airlineCodeId = $this->_AairlineCodeIdArray[$key];

                //assigning airline code to R 
                if($this->viaFlightIndex['code'] != 'CF'){
                    $this->viaFlightIndex['code'] = 'R';
                }

                $resultCharges = $this->_penaltyChargesUpdation($airlineCodeId, $this->viaFlightIndex['code']);
                foreach($resultCharges as $key => $value) {
                    $amountCharges[$value['passenger_type']]['cancellation_amount'] = $value['cancellation_amount'];
                    $amountCharges[$value['passenger_type']]['reschedule_amount'] = $value['reschedule_amount'];
                }

                foreach($passengerIdArray as $key => $value){
                    $airline_code = $this->_OairlineDetails->_getAirlineCode($viaFlightId);
                    $insertPassArray['r_order_id'] = $this->_orderId;
                    $insertPassArray['r_via_flight_id'] = $viaFlightId;
                    $insertPassArray['r_passenger_id'] = $value['passenger_id'];
                    $insertPassArray['r_booking_status_id'] = NOTHING_REQUESTED; //booking requested
                    $insertPassArray['frequent_flyer_no'] = $frequentFlyer[$key][$airline_code];
                    $insertPassArray['fullfilment_status'] = FULLFILMENT_NOT_DONE;
                    $insertPassArray['created_date'] = $this->_STimeStamp;

                    //inserting passenger via details cancel and reschedule amount
                    if($this->viaFlightIndex['id'] == $viaFlightId && $iteration == 0 ) {
                        $passengerType = $value['passenger_type'];
                        if($passengerType == 'CNN' || $passengerType == 'CHD'){
                            $passengerType = 'CHD';
                        }
                        $insertPassArray['cancellation_penalty'] = $cancellationFee[$passengerType];
                        $insertPassArray['reschedule_penalty'] = $amountCharges[$passengerType]['reschedule_amount'];
                    }
                    $this->_passengerViaArray[] = $this->_insertTableValues('passenger_via_details', $insertPassArray);
                }
                $iteration++;
            }
        } 
        else{
            return false;
        }
    }

    /* @Description : To get the inserted passenger id 
     * @param       : 
     * @return      : passenger_id | Integer
     */

    public function _getPassengerId($orderId) {

        $toGetPassengerId = "SELECT 
                                       pd.passenger_id,pd.passenger_type
                             FROM          
                                       passenger_details pd 
                             WHERE
                                       pd.r_order_id = '" . $orderId . "'";

        $retrivedPassengerId = $this->db->_getResult($toGetPassengerId);

        return $retrivedPassengerId;
    }

    public function _insertAirBookingDetails($orderId, $employeeId = '') {

        if (empty($employeeId)) {
            $employeeId = $_SESSION['employeeId'];
        }

        $insertAirBookingArray = array();

        $insertAirBookingArray['r_order_id'] = $orderId;
        $insertAirBookingArray['r_booking_employee_id'] = $employeeId;
        $insertAirBookingArray['booking_date'] = $this->_STimeStamp;
        $insertAirBookingArray['reschedule_status'] = 'Y';

        $this->_AairBookingDetailsId = $this->_insertTableValues('air_booking_details', $insertAirBookingArray);
    }

    /*
     * @Description insert passenger fare details 
     * @param array|$_ApassengerFare
     * @return
     */

    private function _setPassengerFare($_ApassengerFare, $viaFlightIdArray, $fareBasisCodeArray, $calculateArgs, $selectedFlight, $tripType) {
        
        $this->_IviabaseFare = 0;
        $this->_IviaTax = 0;
        $this->_IserviceTax = 0;
        $this->_Icommission = 0;
        $this->_serviceTaxComm = 0;
        $this->_serviceTaxFee = 0;
        $this->_IviatotalFare = 0;
        
        fileWrite("viaFlightIdArray: ".print_r($viaFlightIdArray,1),"viaFlightIdArray","a+");
        fileWrite("Passenger Fare: ".print_r($_ApassengerFare,1),"pasFare1","a+");
        
        if(count($_ApassengerFare) > 0 && $viaFlightIdArray > 0){

            $this->_AviaFareIdArray = array();

            foreach ($viaFlightIdArray as $key => $viaFlightId) {

                $insertPassengerArray = array();
                
                //get the basefare, amount, tax, service tax from passed array
                if($key == 0){
                    
                    $this->_IviaAirlineId = $this->_AviaAirlineIdGST[$calculateArgs['tripType']][$key];

                    $this->_AviaTaxBreakUp = array_column($_ApassengerFare['taxBreakUpDetails'], "taxAmount", "taxCode");
                    $this->_AviaTaxBreakUp['original_base_fare'] = $_ApassengerFare['original_base_fare'];
                    $this->_IviaJnTax = 0;
                    $this->_InewViaTotalFare = false;

                    $this->_calcuateFareDetails($calculateArgs, $selectedFlight, $key, $tripType);

                    if ($this->_IviaJnTax != 0) {
                        // find jn tax is present in the passenger fare array
                        $jnKey = array_search("JN", array_column($_ApassengerFare['taxBreakUpDetails'], 'taxCode'));
                        // if jn tax is present then assign the jn to new fare arry of CALCULATED_JN_TAX
                        if ($jnKey) {
                            array_push($_ApassengerFare['taxBreakUpDetails'], array(
                                "taxCode" => "CALCULATED_JN_TAX",
                                "taxAmount" => $this->_IviaJnTax,
                                "taxDescription" => "Calculated JN Tax"
                            ));
                        }
                        if ($this->_InewViaTotalFare) {
                            $_ApassengerFare['tax'] += $this->_IviaJnTax;
                            $_ApassengerFare['total_fare'] += $this->_IviaJnTax;
                        }
                    }
                    $this->_IviaAirlineId = 0;
                    $this->_AviaTaxBreakUp = array();
                }
                
                
                $insertPassengerArray['r_via_flight_id'] = $viaFlightId;
                

                switch ($_ApassengerFare['passenger_type']) {

                    case "ADT":
                        $insertPassengerArray['passenger_type']  = '0';
                        $insertPassengerArray['fare_basis_code'] = $fareBasisCodeArray[$key]['adult'];
                        break;

                    case "CNN":
                    case "CHD":
                        $insertPassengerArray['passenger_type']  = '1';
                        $insertPassengerArray['fare_basis_code'] = $fareBasisCodeArray[$key]['child'];
                        break;

                    case "INF":
                    case "INFT":
                        $insertPassengerArray['passenger_type']  = '2';
                        $insertPassengerArray['fare_basis_code'] = $fareBasisCodeArray[$key]['infant'];
                        break;

                    default:
                        return false;
                        break;
                }
                if ($key == 0){ // assign via fare details for first via flight (total fare of all via flights)
                    $insertPassengerArray['base_fare'] = $this->_IviabaseFare;
                    $insertPassengerArray['tax'] = $this->_IviaTax;
                    $insertPassengerArray['service_tax'] = $this->_IviaGSTAmount;
                    $insertPassengerArray['commission'] = $this->_Icommission;
                    $insertPassengerArray['commission_tax'] = $this->_serviceTaxComm;
                    $insertPassengerArray['fee_tax'] = $this->_serviceTaxFee;
                    $insertPassengerArray['total_fare'] = $this->_IviatotalFare+$this->_IviaGSTAmount;
                    $insertPassengerArray['created_date'] = $this->_STimeStamp;
                }else{ // assign empty values for all via flights since total fare is avilable for the first via flight itself
                    $insertPassengerArray['base_fare'] = 0;
                    $insertPassengerArray['tax'] = 0;
                    $insertPassengerArray['service_tax'] = 0;
                    $insertPassengerArray['commission'] = 0;
                    $insertPassengerArray['commission_tax'] = 0;
                    $insertPassengerArray['fee_tax'] = 0;
                    $insertPassengerArray['total_fare'] = 0;
                    $insertPassengerArray['created_date'] = $this->_STimeStamp;
                }

                //set service provider id
                $insertPassengerArray['service_provider_id'] = $this->_AflightServiceAgent;

                //insert into the via fare details.
                $insertedViaFareId = $this->_insertTableValues('via_fare_details', $insertPassengerArray);

                //push the inserted via fare id
                $this->_AviaFareIdArray[] = $insertedViaFareId;
                if ($insertPassengerArray['total_fare'] != 0){
                    $_ApassengerFare['insertedId'] = $insertedViaFareId;
                    $_ApassengerFare['fare_base_code'] = $fareBasisCodeArray[$key];  
                    $this->_viaFareSplitUp[] = $_ApassengerFare;
                }
                else{
                    //set base fare and tax as zero if the total fare is zero for the via flights or international round trip.
                    $_ApassengerFareInfo['original_base_fare'] = 0;
                    $_ApassengerFareInfo['original_tax'] = 0;
                    $_ApassengerFareInfo['insertedId'] = $insertedViaFareId;
                    $this->_viaFareSplitUp[] = $_ApassengerFareInfo;
                }                
                $this->_AviaFareFlightId[$insertedViaFareId] = $viaFlightId;
            }
        }
    }

    /*
    * @Description fetch tax details according to argument passed
    * @param array|$calculateArgs
    * @return
    */
    public function _calcuateFareDetails($calculateArgs, $selectedFlight, $key, $tripType) {
        
        $jnTaxArray = $this->_getTaxValues('JN_TAX', $this->_IviaAirlineId, 'ARRAY');
        foreach ($jnTaxArray as $jnValue){
            $this->_IviaJnTax += intval((intval($this->_AviaTaxBreakUp[$jnValue['tax_details_name']]) * $jnValue['percentage']) / 100);
            if ($jnValue['tax_details_name'] == 'original_base_fare') {
                $this->_InewViaTotalFare = true;
            }
        }       

        //calculate individual fare details
        if (isset($calculateArgs['newBaseFare']) && $calculateArgs['newBaseFare'] != '') {
            //calucate the individual fare
            $this->_IviabaseFare = (intval($calculateArgs['baseFare']));
            $this->_IviaTax = (intval($calculateArgs['tax']));
            $this->_IviatotalFare = (intval($calculateArgs['total_fare']));

            $this->_IbaseFare = ($this->_IviabaseFare * intval($calculateArgs['num_passenger']));
            $this->_ITax = ($this->_IviaTax * intval($calculateArgs['num_passenger']));
            $this->_ItotalFare = ($this->_IviatotalFare * intval($calculateArgs['num_passenger']));
            $feeArray ['transaction_fee'] = $calculateArgs['transaction_fee'];
            $feeArray ['discount_fee'] = $calculateArgs['discount_fee'];
            $feeArray ['system_usage_fee'] = $calculateArgs['system_usage_fee'];
            $this->_IserviceTax = $this->_getGSTTotalAmount($feeArray, $calculateArgs['pass_calc'], $tripType, $this->_AviaTaxBreakUp, $this->_IviabaseFare);
            $this->_ItotalServiceTax = $this->_IserviceTax * $calculateArgs['num_passenger'];

            // GST ENDS
            //calcuate the total fare for the entire order to update in order_details table
            if ($selectedFlight == 'Y') {
                $this->_IorderTotalFare += $this->_ItotalFare;
                $this->_IorderTotalServiceTax += $this->_ItotalServiceTax;
            }
        } 
        else if (isset($calculateArgs['baseFare']) && !empty($calculateArgs['baseFare'])) {

            //calucate the individual fare
            $this->_IviabaseFare = (intval($calculateArgs['baseFare']));
            $this->_IviaTax = (intval($calculateArgs['tax']));
            $this->_IviatotalFare = (intval($calculateArgs['total_fare']));

            $this->_IbaseFare = ($this->_IviabaseFare * intval($calculateArgs['num_passenger']));
            $this->_ITax = ($this->_IviaTax * intval($calculateArgs['num_passenger']));
            $this->_ItotalFare = (($this->_IviatotalFare) * intval($calculateArgs['num_passenger']));
            $feeArray['transaction_fee'] = $calculateArgs['transaction_fee'];
            $feeArray['discount_fee'] = $calculateArgs['discount_fee'];
            $feeArray['system_usage_fee'] = $calculateArgs['system_usage_fee'];

            $this->_IserviceTax = $this->_getGSTTotalAmount($feeArray, $calculateArgs['pass_calc'], $tripType, $this->_AviaTaxBreakUp, $this->_IviabaseFare);
            $this->_ItotalServiceTax = $this->_IserviceTax * $calculateArgs['num_passenger'];
            //calcuate the total fare for the entire order to update in order_details table
            if ($selectedFlight == 'Y') {

                $this->_IorderTotalFare += $this->_ItotalFare;
                $this->_IorderTotalServiceTax += $this->_ItotalServiceTax;
            }
        } 
        else {
            fileWrite('Itinerary Insert Error: function:' . __FUNCTION__ . 'empty via base fare received:', 'applicationError');
        }
    }

    /*
     * @Description insert via flight details from array passed
     * @param array|$viaFlightArray
     * @return array|$viaFlightIdArray
     */

    private function _setViaFlightDetails($viaFlightArray, $lowFareStatus, $tripType, $selectedFlight,$orderId) {

        $viaNew = $viaFlightArray;

        $viaFlightArray = array();
        $viaFlightArray = $viaNew['O'] ? $viaNew['O'] : '';

        foreach ($viaNew['R'] as $value) {
            $viaFlightArray[] = $value;
        }
        
        
        if (count($viaFlightArray) > 0) {
            $this->_AviaFlightIdArray = $this->_AfareBasisCodeArray = array();

            $segment = 1;
            fileWrite('insertViaFlight;' . print_r($viaFlightArray, 1), 'viaFlightDetails');
            foreach ($viaFlightArray as $key => $viaFlight) {

                $insertViaFlight = array();

                $insertViaFlight['r_origin_airport_id'] = $this->_fetchTableId('dm_airport', 'airport_code', array('airport_id'), $viaFlight['origin_airport_code']);
                $insertViaFlight['r_destination_airport_id'] = $this->_fetchTableId('dm_airport', 'airport_code', array('airport_id'), $viaFlight['dest_airport_code']);
                $insertViaFlight['segment_order'] = $segment;
                $insertViaFlight['time_arrival'] = $viaFlight['time_arrival'];
                $insertViaFlight['time_departure'] = $viaFlight['time_departure'];
                $insertViaFlight['r_airline_id'] = $this->_fetchTableId('dm_airline', 'airline_code', array('airline_id'), $viaFlight['airline_code']);
                $insertViaFlight['flight_no'] = $viaFlight['flight_number'];
                $insertViaFlight['arrival_date'] = $viaFlight['arrival_date'];
                $insertViaFlight['departure_date'] = $viaFlight['departure_date'];
                $insertViaFlight['arrival_terminal'] = $viaFlight['arrival_terminal'];
                $insertViaFlight['departure_terminal'] = $viaFlight['departure_terminal'];
                $insertViaFlight['miles'] = '';
                $insertViaFlight['low_fare_status'] = $selectedFlight; // Y-selected flight, N - low fare flight               
                $insertViaFlight['r_fare_type_id'] = $this->_checkFareTypeExists($viaFlight['faretype_code'], $viaFlight['faretypename'], $this->_ITravelModeId);
                $insertViaFlight['equipment_code_id'] = 0;
                $insertViaFlight['flight_type'] = 'FL'; //possible values FL / AY
                if($this->_ITravelModeId == 9) {
                    $insertViaFlight['trip_type'] = ($viaFlight['trip_type'] == 'R') ? 1 : 0;
                } 
                else {
                    $insertViaFlight['trip_type'] = $tripType;
                }
                $insertViaFlight['booking_class'] = substr($viaFlight['fare_basic_code'], 0, 1);
                $insertViaFlight['travel_time'] = $viaFlight['travel_time'];
                $insertViaFlight['gds_pnr'] = '';
                $insertViaFlight['time_limit'] = 0;
                $insertViaFlight['total_time'] = $viaFlight['total_time'];
                $insertViaFlight['layover_time'] = $viaFlight['layover_time'];
                $insertViaFlight['checkin_baggage'] = '';
                $insertViaFlight['hand_baggage'] = '';
                $insertViaFlight['created_date'] = $this->_STimeStamp;

                $this->_AairlineCodeIdArray[] = $this->_getAirlineCodeId($viaFlight['airline_code']);

                if($selectedFlight == 'Y') {
                    $this->_AviaAirlineIdGST[$tripType][] = $insertViaFlight['r_airline_id'];
                    $updateCabinCall = $this->_updateCabinClass($tripType,$viaFlight['cabin_class'],$orderId);
                }
                $this->_AviaAirlineId[] = $insertViaFlight['r_airline_id'];
                $this->_AviaFlightNo[] = $insertViaFlight['flight_no'];

                //set operating airline code
                $insertViaFlight['operating_airline_code'] = !empty($viaFlight['operating_airline_code']) ? $viaFlight['operating_airline_code'] : NULL;
                
                //insert into via flight details.
                $this->_AviaFlightIdArray[] = $this->_insertTableValues('via_flight_details', $insertViaFlight);

                if ($key == 0) {
                    $this->viaFlightIndex = array('id' => $this->_AviaFlightIdArray[0], 'code' => $viaFlight['faretype_code'], 'airline' => $viaFlight['airline_code']);
                }
                $this->_AfareBasisCodeArray[$key] = $viaFlight['fare_basic_code'];

                $segment++;
            }
        } else {
            fileWrite('Itinerary Insert Error: function:' . __FUNCTION__ . 'empty via flight array:', 'applicationError');
        }
    }

    /*
     * @Description insert break up tax details into airline_fare_splitup_details table
     * @param int|$viaFareId
     * @param array|$passengerFareArray
     * @return
     */

    private function _setTaxBreakupDetails($viaFareId, $passengerFareArray) {

        //insert original base_fare and original tax amount into airline_fare_splitup_details table

        $taxBaseFareId = $this->_OAppSettings->_checkTaxBreakUpAvailable('original_base_fare');
        $taxFareId     = $this->_OAppSettings->_checkTaxBreakUpAvailable('original_tax');

        if (count($passengerFareArray) > 0) {

            foreach ($passengerFareArray as $val) {
                $viaFareId = $val['insertedId'];
                //insert values for passenger_type based base_fare and tax 
                $insertBaseArray = $insertTaxArray = array();

                $insertTaxArray[] = "('" . $taxBaseFareId . "','" . $viaFareId . "','" . $val['original_base_fare'] . "')";

                $insertTaxArray[] = "('" . $taxFareId . "','" . $viaFareId . "','" . $val['original_tax'] . "')";

                $sqlquery   = "INSERT INTO airline_fare_splitup_details (r_airline_fare_splitup_id,r_via_fare_id,splitup_fare_amount) VALUES ";
                $sqlconject = '';

                foreach ($val['taxBreakUpDetails'] as $taxval) {

                    //check tax code already exists if not created and return tax code id
                    $taxCodeId = $this->_OAppSettings->_checkTaxBreakUpAvailable($taxval['taxCode']);

                    $insertTaxArray[] = "('" . $taxCodeId . "','" . $viaFareId . "','" . $taxval['taxAmount'] . "')";
                }
                $sqlconject = implode(',', $insertTaxArray);
                $sqlquery = $sqlquery . $sqlconject . ';';

                $this->db->_executeQuery($sqlquery);
            }
        }
    }

    /*
     * @Description fetch table key from the value specified
     * @param string|$tablename
     * @param int|$pkId
     * @param string|$field
     * @return mixed|$insertValue
     */

    private function _fetchTableId($tablename, $pkId, $field, $value) {
        $returnValue = false;

        $result = $this->db->_select($tablename, $field, $pkId, $value);

        if ($result) {
            $result = $this->db->_select($tablename, $field, $pkId, $value);
            $returnValue = $result[0][current($field)];
        }
        return $returnValue;
    }

    /*
     * @Description check value exist in table if not insert into db
     * @param string|$tablename
     * @param int|$pkId
     * @param string|$field
     * @param string|$value
     * @return mixed|$insertValue
     */

    private function _checkAndInsert($tablename, $pkId, $field, $value) {

        $returnValue = false;

        $fieldArray = array($field);

        $returnValue = $this->_fetchTableId($tablename, $pkId, $fieldArray, $value);

        if (!$returnValue || $returnValue = '') {
            $insertArray[$field] = $value;
            $returnValue = $this->db->_insert($tablename, $insertArray);
        }

        return $returnValue;
    }

    private function _checkFareTypeExists($fareTypeCode, $fareTypeDesc, $travelModeId) {
        $fareTypeCode = trim($fareTypeCode);
        //$travelModeId = $travelModeId != '' ? $travelModeId : 1; //travel mode domestic air
        //$travelModeId = $travelModeId != '' ? $travelModeId : 9; 
        if ($fareTypeCode != '' && $travelModeId != '') {
            $sql_exists = "SELECT fare_type_id FROM dm_fare_type WHERE fare_type_code = '" . $fareTypeCode . "' AND travel_type = " . $travelModeId . "";
            $result_exists = $this->db->_getResult($sql_exists);

            if (isset($result_exists[0]['fare_type_id']) && $result_exists[0]['fare_type_id'] != '') {
                $returnValue = $result_exists[0]['fare_type_id'];
            } else {
                $insertArray[$field] = $fareTypeCode;
                $insertArray['faretype'] = $fareTypeDesc;
                $insertArray['fare_type_code'] = $fareTypeCode;
                $insertArray['travel_type'] = $travelModeId;

                $returnValue = $this->db->_insert('dm_fare_type', $insertArray);
            }
        } else {
            $sql_exists = "SELECT fare_type_id FROM dm_fare_type WHERE fare_type_code = 'NR' AND travel_type = " . $travelModeId . "";
            $result_exists = $this->db->_getResult($sql_exists);
            $returnValue = $result_exists[0]['fare_type_id'];
        }
        return $returnValue;
    }

    /*
     * @Description get travel class id from dm_travel_class table
     * @param string|$value
     * @param int|$travelModeId
     * @return 
     */

    public function _getTravelClassId($value = '', $travelModeId = 1, $classCode = '') {
        $returnValue = 0;

        $sql = "SELECT travel_class_id FROM dm_travel_class WHERE r_travel_mode_id = " . $travelModeId;
        if ($value != '') {
            $sql = $sql . " AND class_name = '" . $value . "'";
            $result = $this->db->_getResult($sql);
        }
        if ($classCode != '') {
            $sql = $sql . " AND class_code = '" . $classCode . "'";
            $result = $this->db->_getResult($sql);
        }

        if ($result) {
            $returnValue = $result[0]['travel_class_id'];
        }
        return $returnValue;
    }

    /*
     * @Description get tax values from tax_mapping_value table for the name passed
     * @param array|$calculateArgs
     * @param string|$airlinecode
     * @return int|$returnValue
     */

    public function _getTaxValues($name='', $airlineCode = '0', $returnType='') {
        /* $returnValue = false;
          if (isset($name) && !empty($name)) {
          $result = $this->db->_select('dm_tax', array('tax_master_id'), 'tax_name', $name);
          $taxMasterId = $result[0]['tax_master_id'];

          $sql = "SELECT percentage FROM tax_mapping_value WHERE r_airline_id = '" . $airlineCode . "' AND r_tax_master_id = " . $taxMasterId . "";
          $result = $this->db->_getResult($sql);

          if ($result && isset($result[0]['percentage'])) {
          $returnValue = $result[0]['percentage'];
          } else {
          $returnValue = $this->_IAllAirlineserviceTaxValue;
          }
          }
          return $returnValue; */
        //removed function and added in class.applicaitonSettings for usage in all the travel modes
        $returnValue = $this->_OAppSettings->_getTaxValues($name, $airlineCode, $returnType);
        if ($returnValue != '') {
            return $returnValue;
        } else {
            return false;
        }
    }

    /*
     * @Description get airline code from dm_airline table
     * @param
     * @return 
     */

    public function _getAirlineCodeId($airlineCode) {

        $returnValue = false;

        if ($airlineCode != '') {

            $result = $this->db->_select('dm_airline', array('airline_id'), 'airline_code', $airlineCode);
            $returnValue = $result[0]['airline_id'];
        }

        return $returnValue;
    }

    /*
     * @Description set air itinerary values 
     * @param
     * @return 
     */

    public function _saveFactAirItineraryValues($selectedFlight) {



        //$this->_AviaFareFlightId[$insertedViaFareId] = $viaFlightId

        $itinearyStatus = (($selectedFlight == 'Y') ? ITINERARY_STATUS_SELECTED : ITINERARY_STATUS_LOWFARE);

        foreach ($this->_AviaFareFlightId as $key => $viaFlightId) {

            $insertAirItenerary = array();

            //$insertAirItenerary['r_order_id']        = $this->_orderId;
            $insertAirItenerary['r_air_booking_details_id'] = $this->_AairBookingDetailsId;
            $insertAirItenerary['r_via_flight_id'] = $viaFlightId;
            $insertAirItenerary['r_via_fare_id'] = $key;
            $insertAirItenerary['itinerary_status'] = $itinearyStatus;

            $this->_IfactAirItinerary[] = $this->_insertTableValues('fact_air_itinerary', $insertAirItenerary);
        }
    }

    /* $returnLowFareReason$returnLowFareReason
     * @Description get frequent flyer number by passing airline code id
     * @param int|$airlineCodeId
     * @return array|$returnValue
     */

    private function _getFrequentFlyerNo($airlineCodeId) {
        $returnValue = $this->_OEmployee->_getEmployeePreferences($this->_IemployeeId, $airlineCodeId);
        return $returnValue[0]['frequent_flyer_no'];
    }

    /*
    * @Description update order details
    * @param int|$travelModeId
    * @param int|$travelClassId
    * @return array|$returnValue
    */
    public function _updateOrderDetails($totalAmount){
        $updateOrderArray = array();
        $updateOrderArray['total_amount'] = $totalAmount;
        $updateOrderArray['r_ticket_status_id'] = NOT_PAID;
        $_SESSION['air_total_amount'] += $updateOrderArray['total_amount'];
        $orderUpdateResult = $this->_Opackage->_updateOrderDetails($updateOrderArray, $this->_orderId);
        return $orderUpdateResult;
    }

    /*
     * @Description insert low fare reason to reason_master table
     * @param string|$onwardLowFareReason
     * @param string|$returnLowFareReason
     * @return mixed|$reasonMasterId
     */

    public function _saveLowFareReason($onwardLowFareReason, $returnLowFareReason = '') {
        $insertLowFare = array();
        $insertLowFare['order_id'] = $this->_orderId;
        $insertLowFare['onward_fare_reason'] = $onwardLowFareReason;
        $insertLowFare['return_fare_reason'] = $returnLowFareReason;
        $reasonMasterId = $this->_insertTableValues('reason_master', $insertLowFare);
        return $reasonMasterId;
    }

    public function _calculateSegmentAgentFee($agentFeeDetailsArray, $segmentAirLineCount, $segmentFlightNoCount, $transDetails) {
        fileWrite(print_r($_SESSION['userApplicationSettings']['AGENT_FEE_CALCUATION'], 1), 'FEECALC', 'a+');
        //Check for airline based or via flight based calculation
        if (isset($_SESSION['userApplicationSettings']['AGENT_FEE_CALCUATION']['airline'])) {
            if ($_SESSION['userApplicationSettings']['AGENT_FEE_CALCUATION']['airline'] == 'YES') {
                $segmentCount = count($segmentAirLineCount);
            }
        }
        if (isset($_SESSION['userApplicationSettings']['AGENT_FEE_CALCUATION']['segment'])) {
            if ($_SESSION['userApplicationSettings']['AGENT_FEE_CALCUATION']['segment'] == 'NO') {
                $segmentCount = count($segmentFlightNoCount);
            }
        }
        fileWrite('count-->' . $segmentCount, 'FEECALC', 'a+');
        //Flush data before calculating
        $this->_OfeeCalculation->_flushFareData();
        //Do fee calculation          
        $this->_OfeeCalculation->_doAirFeeCalc($agentFeeDetailsArray, $segmentCount, $transDetails);
        $this->_ItransactionFee = $this->_OfeeCalculation->_ItransactionFee;
        $this->_IsystemUsageFee = $this->_OfeeCalculation->_IsysUsageFee;
        $this->_IdiscountFee = $this->_OfeeCalculation->_IdiscountFee;
    }

    /*
     * @Description get itinerary details for the given order id
     * @param int|$orderId
     * @param int|$itinearyStatus
     * @return
     */

    public function _getItineraryDetails($orderId, $itinearyStatus = ITINERARY_STATUS_SELECTED) {
        $returnValue = false;

        if ($orderId != '') {
            $sql = 'SELECT fact_air_itinerary_id,r_via_flight_id FROM air_booking_details abd LEFT JOIN fact_air_itinerary fat ON abd.air_booking_details_id=fat.r_air_booking_details_id WHERE itinerary_status=27 AND abd.r_order_id="' . $orderId . '"';
            $result = $this->db->_getResult($sql);

            $returnValue = $result;
        }
        return $returnValue;
    }

    /*
     * @Description insert array values to corresponding table
     * @param string|$tableName
     * @param array|$insertArray
     * @return mixed|$insertValue
     */

    public function _insertTableValues($tableName, $insertArray) {
        if (!empty($tableName) && count($insertArray) > 0) {
            $insertValue = $this->db->_insert($tableName, $insertArray);
        } else {
            fileWrite('Itinerary Insert Error: tablename' . $tableName . 'insertArray:' . print_r($insertArray, 1), 'applicationError');
            $insertValue = false;
        }
        if (ERROR_DEBUG_REPORT) {
            if (!$insertValue > 0) {
                $this->_OAppSettings->pushInsertDetails($insertArray, $tableName, $insertValue, $this->_OcommonDBO->_AbugTracking);
            } else {
                $this->_OAppSettings->pushInsertDetails($insertArray, $tableName, $insertValue);
            }
        }
        return $insertValue;
    }

    /*
     * @Description get booking details from fact_booking_details table
     * @param int|$orderId
     * @return mixed|$returnArray
     */

    public function _getOrderBookingDetails($orderId) {
        $returnArray = false;

        if ($orderId != '') {
            $sql = "SELECT fbd.r_order_id,od.travel_purpose, fbd.r_package_id, fbd.r_corporate_id, fbd.r_request_id, fbd.r_employee_id, od.total_amount, od.created_date 
                    FROM fact_booking_details fbd INNER JOIN order_details od ON fbd.r_order_id = od.order_id
                    WHERE od.order_id = " . $orderId . "";
            $result = $this->db->_getResult($sql);

            $returnArray = $result[0];
        }


        return $returnArray;
    }

    /*
     * @FunctionName    :   _getViaFlightDetails($ordeId)
     * @Description     :   This function is used to get the flight details by the 
     * @Author          :   Jagan.M
     * @Created Date    :   20/08/2016
     * @Modified Date   : 
     * @Return Type     :   Array
     */

    public function _getViaFlightDetails($flightId) {
        $returnArray = false;

        if ($flightId != '') {
            $sql = 'SELECT  
                            via_flight_id,
                            r_origin_airport_id,
                            r_destination_airport_id,
                            flight_no,
                            segment_order,time_arrival,
                            time_departure,
                            r_airline_id,
                            layover_time,
                            r_travel_class_id,
                            trip_type,
                            total_time
                      FROM 
                            via_flight_details
                      WHERE 
                            via_flight_id="' . $flightId . '" ';

            $result = $this->db->_getResult($sql);
            $returnArray = $result;
        }
        return $returnArray;
    }

    /*
     * @FunctionName    :   _getFlightListByOrdeId()
     * @Description     :   This function is used to retreive the booking level detail of air request raised by user
     * @Author          :   Jagan.M
     * @Created Date    :   20/08/2016
     * @Modified Date   : 
     * @Return Type     :   Array
     */

    public function _getFlightListByOrdeId($orderId) {
        $returnArray = false;

        if ($orderId != '') {
            $sql = 'SELECT fact_air_itinerary_id,r_via_flight_id,fat.itinerary_status,abd.r_order_id FROM air_booking_details abd LEFT JOIN fact_air_itinerary fat ON abd.air_booking_details_id=fat.r_air_booking_details_id 
 GROUP BY fat.r_via_flight_id HAVING fat.itinerary_status=27 AND abd.r_order_id="' . $orderId . '"';
            $result = $this->db->_getResult($sql);
            $returnArray = $result;
        }
        return $returnArray;
    }

    /*
     * @Description  this function get the basic info of the itinerary
     * @param int|$orderId,$packageId
     * @return 
     */

    public function _getFlightDetails($orderId = 0, $packageId = 0) {
        $sqlItinerary = "SELECT 
							vfd.via_flight_id,
							vfd.r_origin_airport_id,
							vfd.r_destination_airport_id,
							vfd.time_arrival,
							vfd.time_departure,
							vfd.r_airline_id,
							vfd.flight_no,
							vfd.arrival_date,
							vfd.departure_date,
							vfd.r_fare_type_id,
							vfd.flight_type,
							vfd.trip_type,
							vfd.booking_class,
							vfd.travel_time,
							vfd.gds_pnr,
							vfd.time_limit,
							vfd.total_time,
							vfd.layover_time,
							vfd.created_date,
							fd.via_fare_id,
							fd.fare_basis_code,
							fd.passenger_type,
							fd.base_fare,
							fd.tax,
							fd.service_tax,
							fd.total_fare,
							od.order_id,
                                                        od.travel_purpose
					FROM
							via_fare_details fd,
							via_flight_details vfd,
							fact_air_itinerary fai,
							order_details od,
							air_booking_details abd
					WHERE 
							vfd.via_flight_id = fai.r_via_flight_id
							AND fd.via_fare_id = fai.r_via_fare_id
							AND fd.r_via_flight_id = vfd.via_flight_id
							AND abd.r_order_id = od.order_id
							AND abd.air_booking_details_id = fai.r_air_booking_details_id
							AND od.order_id =" . $orderId . "
							GROUP BY vfd.via_flight_id ORDER BY vfd.trip_type";

        $resultItinerary = $this->db->_getResult($sqlItinerary);
        if ($resultItinerary != '') {
            $index = 0;
            $onindex = 0;
            $retindex = 0;
            foreach ($resultItinerary as $via) {

                /*                 * * to get the agent fee details * */
                $feeInfo = $this->_OfareDetails->_getAgentFeeDetailsByOrderId($orderId);
                if ($feeInfo[0]['agent_fee_name'] == 'transactionFee') {
                    $row[0]['transaction_fee'] = $feeInfo[0]['fee_value'];
                }
                if ($feeInfo[0]['agent_fee_name'] == 'discountAmount') {
                    $row[0]['discount_amount'] = $feeInfo[0]['fee_value'];
                }
                if ($feeInfo[0]['agent_fee_name'] == 'systemUsageFee') {
                    $row[0]['system_usage_fee'] = $feeInfo[0]['fee_value'];
                }
                /*                 * * end of agent fee * */
                /*                 * * to get the airport code and airport name * */
                if ($via['r_origin_airport_id'] != '') {
                    $airportInfo = $this->_OairportDetails->_getAirportName($via['r_origin_airport_id']);
                    $via['origin'] = $airportInfo[0]['airport_code'];
                    $via['mainOrigin'] = $airportInfo[0]['city_name'];
                }
                if ($via['r_destination_airport_id'] != '') {
                    $airportInfo = $this->_OairportDetails->_getAirportName($via['r_destination_airport_id']);
                    $via['destination'] = $airportInfo[0]['airport_code'];
                    $via['mainDestination'] = $airportInfo[0]['city_name'];
                }
                /*                 * * end of airport details ** */

                /*                 * * to get the airline details * */
                if ($via['r_airline_id'] != '') {
                    $airlineInfo = $this->_OairlineDetails->_getAirlineDetails($via['r_airline_id']);
                    $via['airlineCode'] = $airlineInfo[0]['airline_code'];
                    $via['airlineName'] = $airlineInfo[0]['airline_name'];
                }
                /*                 * * end of airline details * */

                /*                 * *** to get the fare type ** */
                $fareInfo = $this->_OfareDetails->_getFareTypeByFareTypeId($via['r_fare_type_id']);
                $via['fare_type'] = $fareInfo[0]['faretype'];
                /** end of fare type * */
                /*                 * * trip_type 
                 *   onward - 0
                 *   return - 1
                 * * */
                if ($via['trip_type'] == 0) {
                    if ($index > 0) {
                        $index --;
                    } else {
                        $row[$index] = $via;
                        $row[$index]['mainOrigin'] = $via['mainOrigin'];

                        $row[$index]['mainDepartureTime'] = $via['time_departure'];
                    }
                    $row[$index]['mainDestination'] = $via['mainDestination'];
                    $row[$index]['mainDestinationCode'] = $via['destination'];
                    $row[$index]['mainArrivalTime'] = $via['time_arrival'];
                    $row[$index]['totalBaseFare'] = $row[$index]['totalBaseFare'] + $via['base_fare'];
                    $row[$index]['totalTax'] = $row[$index]['totalTax'] + $via['tax'];
                    $row[$index]['totalServiceTax'] = $row[$index]['totalServiceTax'] + $via['service_tax'];
                    $row[$index]['tripCount'] = $onindex;
                    $row[$index]['viaInfo'][$onindex]['via_flight_id'] = $via['via_flight_id'];
                    $row[$index]['viaInfo'][$onindex]['origin'] = $via['origin'];
                    $row[$index]['viaInfo'][$onindex]['destination'] = $via['destination'];
                    $row[$index]['viaInfo'][$onindex]['airlineName'] = $via['airlineName'];
                    $row[$index]['viaInfo'][$onindex]['airlineCode'] = $via['airlineCode'];
                    $row[$index]['viaInfo'][$onindex]['time_arrival'] = $via['time_arrival'];
                    $row[$index]['viaInfo'][$onindex]['time_departure'] = $via['time_departure'];
                    $row[$index]['viaInfo'][$onindex]['trip_type'] = $via['trip_type'];
                    $row[$index]['viaInfo'][$onindex]['total_time'] = $via['total_time'];
                    $row[$index]['viaInfo'][$onindex]['layover_time'] = $via['layover_time'];
                    $row[$index]['viaInfo'][$onindex]['flight_no'] = $via['flight_no'];
                    $row[$index]['viaInfo'][$onindex]['fare_type'] = $via['fare_type'];
                    $row[$index]['viaInfo'][$onindex]['departure_date'] = $via['departure_date'];
                    $row[$index]['viaInfo'][$onindex]['arrival_date'] = $via['arrival_date'];
                    $row[$index]['viaInfo'][$onindex]['booking_class'] = $via['booking_class'];
                    $row[$index]['viaInfo'][$onindex]['flight_type'] = $via['flight_type'];
                    $row[$index]['viaInfo'][$onindex]['fare_basis_code'] = $via['fare_basis_code'];
                    $onindex ++;
                } else {
                    if ($index > 1) {
                        $index --;
                    } else {
                        $row[$index] = $via;
                        $row[$index]['mainOrigin'] = $via['mainOrigin'];
                        $row[$index]['mainDepartureTime'] = $via['time_departure'];
                    }
                    $row[$index]['mainDestination'] = $via['mainDestination'];
                    $row[$index]['mainDestinationCode'] = $via['destination'];
                    $row[$index]['mainArrivalTime'] = $via['time_arrival'];
                    $row[$index]['totalBaseFare'] = $row[$index]['totalBaseFare'] + $via['base_fare'];
                    $row[$index]['totalTax'] = $row[$index]['totalTax'] + $via['tax'];
                    $row[$index]['totalServiceTax'] = $row[$index]['totalServiceTax'] + $via['service_tax'];
                    $row[$index]['tripCount'] = $retindex;
                    $row[$index]['viaInfo'][$retindex]['via_flight_id'] = $via['via_flight_id'];
                    $row[$index]['viaInfo'][$retindex]['origin'] = $via['origin'];
                    $row[$index]['viaInfo'][$retindex]['destination'] = $via['destination'];
                    $row[$index]['viaInfo'][$retindex]['airlineName'] = $via['airlineName'];
                    $row[$index]['viaInfo'][$retindex]['airlineCode'] = $via['airlineCode'];
                    $row[$index]['viaInfo'][$retindex]['time_arrival'] = $via['time_arrival'];
                    $row[$index]['viaInfo'][$retindex]['time_departure'] = $via['time_departure'];
                    $row[$index]['viaInfo'][$retindex]['trip_type'] = $via['trip_type'];
                    $row[$index]['viaInfo'][$retindex]['total_time'] = $via['total_time'];
                    $row[$index]['viaInfo'][$retindex]['layover_time'] = $via['layover_time'];
                    $row[$index]['viaInfo'][$retindex]['flight_no'] = $via['flight_no'];
                    $row[$index]['viaInfo'][$retindex]['fare_type'] = $via['fare_type'];
                    $row[$index]['viaInfo'][$retindex]['departure_date'] = $via['departure_date'];
                    $row[$index]['viaInfo'][$retindex]['arrival_date'] = $via['arrival_date'];
                    $row[$index]['viaInfo'][$retindex]['booking_class'] = $via['booking_class'];
                    $row[$index]['viaInfo'][$retindex]['flight_type'] = $via['flight_type'];
                    $row[$index]['viaInfo'][$retindex]['fare_basis_code'] = $via['fare_basis_code'];
                    $retindex ++;
                }
                $row[0]['airlineBaseFare'] = $row[0]['airlineBaseFare'] + $row[$index]['totalBaseFare'];
                $row[0]['airlineTaxFare'] = $row[0]['airlineTaxFare'] + $row[$index]['totalTax'];
                $row[0]['airlineServiceTax'] = $row[0]['airlineServiceTax'] + $row[$index]['totalServiceTax'];
                $row[0]['travel_purpose'] = $via['travel_purpose'];
                $index ++;
            }
        }
        return $row;
    }

    /*
     * @Description  this function get the basic info of the itinerary
     * @param int|$packageId
     * @return 
     */

    public function _getPackageFlightDetails($packageId = 0) {
        $sqlItinerary = "SELECT 
							vfd.via_flight_id,
							vfd.r_origin_airport_id,
							vfd.r_destination_airport_id,
							vfd.time_arrival,
							vfd.time_departure,
							vfd.r_airline_id,
							vfd.flight_no,
							vfd.arrival_date,
							vfd.departure_date,
							vfd.r_fare_type_id,
							vfd.flight_type,
							vfd.trip_type,
							vfd.booking_class,
							vfd.travel_time,
							vfd.gds_pnr,
							vfd.time_limit,
							vfd.total_time,
							vfd.layover_time,
							vfd.created_date,
							fd.via_fare_id,
							fd.fare_basis_code,
							fd.passenger_type,
							fd.base_fare,
							fd.tax,
							fd.service_tax,
							fd.total_fare,
							od.order_id,
                                                        od.travel_purpose,
                                                        abd.reschedule_status
					FROM
							via_fare_details fd,
							via_flight_details vfd,
							fact_air_itinerary fai,
							order_details od,
							air_booking_details abd,
                                                        fact_booking_details fbd
					WHERE 
							vfd.via_flight_id = fai.r_via_flight_id
							AND fd.via_fare_id = fai.r_via_fare_id
							AND fd.r_via_flight_id = vfd.via_flight_id
							AND abd.r_order_id = od.order_id
							AND abd.air_booking_details_id = fai.r_air_booking_details_id
							AND od.order_id =fbd.r_order_id
                                                        AND fbd.r_package_id = $packageId
                                                        AND fai.itinerary_status=" . ITINERARY_STATUS_SELECTED .
                " GROUP BY vfd.via_flight_id ORDER BY fbd.r_order_id,vfd.trip_type,vfd.via_flight_id,vfd.segment_order";
        $resultItinerary = $this->db->_getResult($sqlItinerary);
        if ($resultItinerary != '') {
            $index = 0;
            $onindex = 0;
            $retindex = 0;
            $orderId = 0;
            foreach ($resultItinerary as $via) {
                if ($orderId != $via['order_id']) {

                    $orderId = $via['order_id'];
                    $index = 0;
                    $onindex = 0;
                    $retindex = 0;
                }
                /*                 * * to get the agent fee details * */
                $feeInfo = $this->_OfareDetails->_getAgentFeeDetailsByOrderId($via['order_id']);
                if ($feeInfo[0]['agent_fee_name'] == 'transactionFee') {
                    $row[$orderId][0]['transaction_fee'] = $feeInfo[0]['fee_value'];
                }
                if ($feeInfo[0]['agent_fee_name'] == 'discountAmount') {
                    $row[$orderId][0]['discount_amount'] = $feeInfo[0]['fee_value'];
                }
                if ($feeInfo[0]['agent_fee_name'] == 'systemUsageFee') {
                    $row[$orderId][0]['system_usage_fee'] = $feeInfo[0]['fee_value'];
                }
                /*                 * * end of agent fee * */
                /*                 * * to get the airport code and airport name * */
                if ($via['r_origin_airport_id'] != '') {
                    $airportInfo = $this->_OairportDetails->_getAirportName($via['r_origin_airport_id']);
                    $via['origin'] = $airportInfo[0]['airport_code'];
                    $via['mainOrigin'] = $airportInfo[0]['city_name'];
                }
                if ($via['r_destination_airport_id'] != '') {
                    $airportInfo = $this->_OairportDetails->_getAirportName($via['r_destination_airport_id']);
                    $via['destination'] = $airportInfo[0]['airport_code'];
                    $via['mainDestination'] = $airportInfo[0]['city_name'];
                }
                /*                 * * end of airport details ** */

                /*                 * * to get the airline details * */
                if ($via['r_airline_id'] != '') {
                    $airlineInfo = $this->_OairlineDetails->_getAirlineDetails($via['r_airline_id']);
                    $via['airlineCode'] = $airlineInfo[0]['airline_code'];
                    $via['airlineName'] = $airlineInfo[0]['airline_name'];
                }
                /*                 * * end of airline details * */

                /*                 * *** to get the fare type ** */
                $fareInfo = $this->_OfareDetails->_getFareTypeByFareTypeId($via['r_fare_type_id']);
                $via['fare_type'] = $fareInfo[0]['fare_type_code'];
                /** end of fare type * */
                /*                 * * trip_type 
                 *   onward - 0
                 *   return - 1
                 * * */
                if ($via['trip_type'] == 0) {
                    if ($index > 0) {
                        $index --;
                    } else {
                        $row[$orderId][$index] = $via;
                        $row[$orderId][$index]['mainOrigin'] = $via['mainOrigin'];

                        $row[$orderId][$index]['mainDepartureTime'] = $via['time_departure'];
                    }

                    $row[$orderId][$index]['mainDestination'] = $via['mainDestination'];
                    $row[$orderId][$index]['mainDestinationCode'] = $via['destination'];
                    $row[$orderId][$index]['mainArrivalTime'] = $via['time_arrival'];
                    $row[$orderId][$index]['totalBaseFare'] = $row[$orderId][$index]['totalBaseFare'] + $via['base_fare'];
                    $row[$orderId][$index]['totalTax'] = $row[$orderId][$index]['totalTax'] + $via['tax'];
                    $row[$orderId][$index]['totalServiceTax'] = $row[$orderId][$index]['totalServiceTax'] + $via['service_tax'];
                    $row[$orderId][$index]['tripCount'] = $onindex;
                    $row[$orderId][$index]['viaInfo'][$onindex]['via_flight_id'] = $via['via_flight_id'];
                    $row[$orderId][$index]['viaInfo'][$onindex]['origin'] = $via['origin'];
                    $row[$orderId][$index]['viaInfo'][$onindex]['destination'] = $via['destination'];
                    $row[$orderId][$index]['viaInfo'][$onindex]['airlineName'] = $via['airlineName'];
                    $row[$orderId][$index]['viaInfo'][$onindex]['airlineCode'] = $via['airlineCode'];
                    $row[$orderId][$index]['viaInfo'][$onindex]['time_arrival'] = $via['time_arrival'];
                    $row[$orderId][$index]['viaInfo'][$onindex]['time_departure'] = $via['time_departure'];
                    $row[$orderId][$index]['viaInfo'][$onindex]['trip_type'] = $via['trip_type'];
                    $row[$orderId][$index]['viaInfo'][$onindex]['total_time'] = $via['total_time'];
                    $row[$orderId][$index]['viaInfo'][$onindex]['layover_time'] = $via['layover_time'];
                    $row[$orderId][$index]['viaInfo'][$onindex]['flight_no'] = $via['flight_no'];
                    $row[$orderId][$index]['viaInfo'][$onindex]['fare_type'] = $via['fare_type'];
                    $row[$orderId][$index]['viaInfo'][$onindex]['departure_date'] = $via['departure_date'];
                    $row[$orderId][$index]['viaInfo'][$onindex]['arrival_date'] = $via['arrival_date'];
                    $row[$orderId][$index]['viaInfo'][$onindex]['booking_class'] = $via['booking_class'];
                    $row[$orderId][$index]['viaInfo'][$onindex]['flight_type'] = $via['flight_type'];
                    $row[$orderId][$index]['viaInfo'][$onindex]['fare_basis_code'] = $via['fare_basis_code'];
                    $onindex ++;
                } else {
                    if ($index > 1) {
                        $index --;
                    } else {
                        $row[$orderId][$index] = $via;
                        $row[$orderId][$index]['mainOrigin'] = $via['mainOrigin'];
                        $row[$orderId][$index]['mainDepartureTime'] = $via['time_departure'];
                    }
                    $row[$orderId][$index]['mainDestination'] = $via['mainDestination'];
                    $row[$orderId][$index]['mainDestinationCode'] = $via['destination'];
                    $row[$orderId][$index]['mainArrivalTime'] = $via['time_arrival'];
                    $row[$orderId][$index]['totalBaseFare'] = $row[$orderId][$index]['totalBaseFare'] + $via['base_fare'];
                    $row[$orderId][$index]['totalTax'] = $row[$orderId][$index]['totalTax'] + $via['tax'];
                    $row[$orderId][$index]['totalServiceTax'] = $row[$orderId][$index]['totalServiceTax'] + $via['service_tax'];
                    $row[$orderId][$index]['tripCount'] = $retindex;
                    $row[$orderId][$index]['viaInfo'][$retindex]['via_flight_id'] = $via['via_flight_id'];
                    $row[$orderId][$index]['viaInfo'][$retindex]['origin'] = $via['origin'];
                    $row[$orderId][$index]['viaInfo'][$retindex]['destination'] = $via['destination'];
                    $row[$orderId][$index]['viaInfo'][$retindex]['airlineName'] = $via['airlineName'];
                    $row[$orderId][$index]['viaInfo'][$retindex]['airlineCode'] = $via['airlineCode'];
                    $row[$orderId][$index]['viaInfo'][$retindex]['time_arrival'] = $via['time_arrival'];
                    $row[$orderId][$index]['viaInfo'][$retindex]['time_departure'] = $via['time_departure'];
                    $row[$orderId][$index]['viaInfo'][$retindex]['trip_type'] = $via['trip_type'];
                    $row[$orderId][$index]['viaInfo'][$retindex]['total_time'] = $via['total_time'];
                    $row[$orderId][$index]['viaInfo'][$retindex]['layover_time'] = $via['layover_time'];
                    $row[$orderId][$index]['viaInfo'][$retindex]['flight_no'] = $via['flight_no'];
                    $row[$orderId][$index]['viaInfo'][$retindex]['fare_type'] = $via['fare_type'];
                    $row[$orderId][$index]['viaInfo'][$retindex]['departure_date'] = $via['departure_date'];
                    $row[$orderId][$index]['viaInfo'][$retindex]['arrival_date'] = $via['arrival_date'];
                    $row[$orderId][$index]['viaInfo'][$retindex]['booking_class'] = $via['booking_class'];
                    $row[$orderId][$index]['viaInfo'][$retindex]['flight_type'] = $via['flight_type'];
                    $row[$orderId][$index]['viaInfo'][$retindex]['fare_basis_code'] = $via['fare_basis_code'];
                    $retindex ++;
                }
                if (!isset($row[$orderId][$index]['clientId'])) {
                    $row[$orderId][$index]['clientId'] = $via['order_id'] . $via['via_flight_id'];
                }
                $row[$orderId][0]['airlineBaseFare'] = $row[$orderId][0]['airlineBaseFare'] + $row[$orderId][$index]['totalBaseFare'];
                $row[$orderId][0]['airlineTaxFare'] = $row[$orderId][0]['airlineTaxFare'] + $row[$orderId][$index]['totalTax'];
                $row[$orderId][0]['airlineServiceTax'] = $row[$orderId][0]['airlineServiceTax'] + $row[$orderId][$index]['totalServiceTax'];
                $row[$orderId][0]['travel_purpose'] = $via['travel_purpose'];
                $index ++;
            }
        }
        return $row;
    }

    /*     * **************************************************************************
     * @Function Name    :  _getPassengerCountByOrderId
     * @Description      : This function is used to get fare break up details according to the number of passengers for the particular order
     * @Author           : Jagan.M
     * @Created Date     : 24/08/2016
     * @Modified Date     : 
     * *************************************************************************** */

    public function _getPassengerCountByOrderId($orderId) {
        $sql = "SELECT "
                . "adult_count,"
                . "child_count,"
                . "infant_count,"
                . "r_travel_class_id,"
                . "trip_type"
                . " FROM "
                . "air_request_details ard"
                . " LEFT JOIN "
                . " fact_booking_details fbd"
                . " ON fbd.r_request_id=ard.air_request_id"
                . " WHERE "
                . "r_order_id='" . $orderId . "'";
        $count = $this->db->_getResult($sql);
        return $count;

        return $row;
    }

    /*     * **************************************************************************
     * @Function Name    :  _getFareBreakUp($orderId)
     * @Description      : This function is used to get fare break up details according to the number of passengers for the particular order
     * @Author           : Jagan.M
     * @Created Date     : 24/08/2016
     * @Modified Date     : 
     * *************************************************************************** */

    public function _getFareBreakUp($orderId) {

        $onwardFare = array("total_fare" => 0, "base_fare" => 0, "tax" => 0, "service_tax" => 0);
        $returnFare = array("total_fare" => 0, "base_fare" => 0, "tax" => 0, "service_tax" => 0);
        $adultonward = array("total_fare" => 0, "base_fare" => 0, "tax" => 0, "service_tax" => 0);
        $childonward = array("total_fare" => 0, "base_fare" => 0, "tax" => 0, "service_tax" => 0);
        $infantonward = array("total_fare" => 0, "base_fare" => 0, "tax" => 0, "service_tax" => 0);
        $adultreturn = array("total_fare" => 0, "base_fare" => 0, "tax" => 0, "service_tax" => 0);
        $childreturn = array("total_fare" => 0, "base_fare" => 0, "tax" => 0, "service_tax" => 0);
        $infantreturn = array("total_fare" => 0, "base_fare" => 0, "tax" => 0, "service_tax" => 0);

        $count = $this->_getPassengerCountByOrderId($orderId);
        $adult = $count[0]['adult_count'];
        $child = $count[0]['child_count'];
        $infant = $count[0]['infant_count'];


        $fsql = "SELECT 
                        total_fare,
                        service_tax,
                        tax,
                        base_fare,
                        trip_type,
                        passenger_type
                  FROM 
                        air_booking_details abd 
                  LEFT JOIN 
                        fact_air_itinerary fai ON abd.air_booking_details_id=fai.r_air_booking_details_id  
                  LEFT JOIN
                        via_fare_details vfd ON fai.r_via_fare_id=vfd.via_fare_id 
                  LEFT JOIN 
                        via_flight_details vf ON fai.r_via_flight_id=vf.via_flight_id 
                  WHERE 
                        r_order_id='" . $orderId . "' AND fai.itinerary_status=" . ITINERARY_STATUS_SELECTED;
        $fare = $this->db->_getResult($fsql);

        foreach ($fare as $key => $value) {
            if ($value[trip_type] == 0) {

                if ($value[passenger_type] == 0) {
                    $onwardFare = $this->fareRecallFunction($onwardFare, $value, $adult);
                    $adultonward = $this->fareRecallFunction($adultonward, $value, $adult);
                }

                if ($value[passenger_type] == 1) {
                    $onwardFare = $this->fareRecallFunction($onwardFare, $value, $child);
                    $childonward = $this->fareRecallFunction($childonward, $value, $child);
                }
                if ($value[passenger_type] == 2) {
                    $onwardFare = $this->fareRecallFunction($onwardFare, $value, $infant);
                    $infantonward = $this->fareRecallFunction($infantonward, $value, $infant);
                }
            } elseif ($value[trip_type] == 1) {
                if ($value[passenger_type] == 0) {
                    $returnFare = $this->fareRecallFunction($returnFare, $value, $adult);
                    $adultreturn = $this->fareRecallFunction($adultreturn, $value, $adult);
                }

                if ($value[passenger_type] == 1) {
                    $returnFare = $this->fareRecallFunction($returnFare, $value, $child);
                    $childreturn = $this->fareRecallFunction($childreturn, $value, $child);
                }
                if ($value[passenger_type] == 2) {
                    $returnFare = $this->fareRecallFunction($returnFare, $value, $infant);
                    $infantreturn = $this->fareRecallFunction($infantreturn, $value, $infant);
                }
            }
        }
        $onwardFare['adult'] = $adultonward;
        $onwardFare['child'] = $childonward;
        $onwardFare['infant'] = $infantonward;
        $returnFare['adult'] = $adultreturn;
        $returnFare['child'] = $childreturn;
        $returnFare['infant'] = $infantreturn;
        $returnResult = ["onward" => $onwardFare,
            "return" => $returnFare, 'adult' => $adult, 'child' => $child, 'infant' => $infant];

        return $returnResult;
    }

    /*     * **************************************************************************
     * @Function Name    :  fareRecursiveFunction($mainArray,$fareArray,$count)
     * @Description      : This function is used  for the getfarebreakup function for reusability purpose
     * @Author           : Jagan.M
     * @Created Date     : 24/08/2016
     * @Modified Date     : 
     * *************************************************************************** */

    public function fareRecallFunction($mainArray, $fareArray, $count) {

        $mainArray['total_fare'] = $mainArray['total_fare'] + ($count * $fareArray['total_fare']);
        $mainArray['service_tax'] = $mainArray['service_tax'] + ($count * $fareArray['service_tax']);
        $mainArray['tax'] = $mainArray['tax'] + ($count * $fareArray['tax']);
        $mainArray['base_fare'] = $mainArray['base_fare'] + ($count * $fareArray['base_fare']);

        return $mainArray;
    }

    /**
     * @Description :This function is used to insert the passenger via details 
     * @param :array   | $passengerViaDetails - holds array of via flight and passenger details
     * @return integer |$resultPassengerViaId - inserted passenger via id
     */
    public function _insertPassengerViaDetailsDirect($passengerViaDetails) {
        $tableName = 'passenger_via_details';
        $resultPassengerViaId = $this->db->_insert($tableName, $passengerViaDetails);

        return $resultPassengerViaId;
    }

    public function _getSyncFareDetails($orderId, $noOfAdults) {
        $sqlFare = "SELECT base_fare,tax,service_tax,total_fare,vfd.via_flight_id,trip_type,passenger_type
                            FROM 
                                via_fare_details vfared,
                                via_flight_details vfd,
                                fact_air_itinerary fai,
                                air_booking_details abd
                            WHERE
                                abd.air_booking_details_id = fai.r_air_booking_details_id
                                AND fai.r_via_flight_id= vfd.via_flight_id
                                AND fai.r_via_fare_id= vfared.via_fare_id
                                AND abd.r_order_id=" . $orderId;

        $resultFare = $this->db->_getResult($sqlFare);

        if ($resultFare != '') {
            $index = 0;
            $onindex = 0;
            $retindex = 0;
            foreach ($resultFare as $viafareArray) {
                if (!isset($fareArray[$viafareArray['trip_type']]['baseFare'])) {
                    $fareArray[$viafareArray['trip_type']]['baseFare'] = 0;
                }
                if (!isset($fareArray[$viafareArray['trip_type']]['tax'])) {
                    $fareArray[$viafareArray['trip_type']]['tax'] = 0;
                }
                if (!isset($fareArray[$viafareArray['trip_type']]['childFare'])) {
                    $fareArray[$viafareArray['trip_type']]['childFare'] = 0;
                }
                //if($viafareArray['trip_type']==0){
                if ($viafareArray['passenger_type'] == '0' || $viafareArray['passenger_type'] == '1') {
                    $fareArray[$viafareArray['trip_type']]['baseFare'] = $fareArray[$viafareArray['trip_type']]['baseFare'] + $viafareArray['base_fare'];
                    $fareArray[$viafareArray['trip_type']]['tax'] = $fareArray[$viafareArray['trip_type']]['tax'] + $viafareArray['tax'];
                } elseif ($viafareArray['passenger_type'] == '2') {
                    $fareArray[$viafareArray['trip_type']]['childFare'] = $fareArray[$viafareArray['trip_type']]['childFare'] + ($viafareArray['base_fare'] + $viafareArray['tax']);
                }
                // }
            }
            foreach ($fareArray as $key => $fare) {
                if (isset($fare['childFare'])) {
                    $fareArray[$key]['tax']+=($fare['childFare'] / $noOfAdults);
                }
            }
        }
        return $fareArray;
    }

    public function _getPackageSyncFareDetails($packageId, $noOfAdults, $noOfInfant) {
        $sqlFare = "SELECT fbd.r_order_id,base_fare,tax,service_tax,commission,commission_tax,fee_tax,total_fare,vfd.via_flight_id,trip_type,passenger_type
                            FROM 
                                via_fare_details vfared,
                                via_flight_details vfd,
                                fact_air_itinerary fai,
                                air_booking_details abd,
                                fact_booking_details fbd
                            WHERE
                                abd.air_booking_details_id = fai.r_air_booking_details_id
                                AND fai.r_via_flight_id= vfd.via_flight_id
                                AND fai.r_via_fare_id= vfared.via_fare_id
				AND vfared.base_fare !=0
                                AND abd.r_order_id=fbd.r_order_id
                                AND fai.itinerary_status=" . ITINERARY_STATUS_SELECTED . " 
                                AND fbd.r_package_id=" . $packageId .
                " ORDER BY fbd.r_order_id,vfd.trip_type,fai.r_via_flight_id,fai.r_via_fare_id";
        $resultFare = $this->db->_getResult($sqlFare);
        if ($resultFare != '') {
            $index = 0;
            $onindex = 0;
            $retindex = 0;
            foreach ($resultFare as $viafareArray) {
                $orderId = $viafareArray['r_order_id'];
                $fareArray[$orderId][$viafareArray['trip_type']]['commission'] = $viafareArray['commission'];
                $fareArray[$orderId][$viafareArray['trip_type']]['commission_tax'] = $viafareArray['commission_tax'];
                $fareArray[$orderId][$viafareArray['trip_type']]['fee_tax'] = $viafareArray['fee_tax'];
                if (!isset($fareArray[$orderId][$viafareArray['trip_type']]['baseFare'])) {
                    $fareArray[$orderId][$viafareArray['trip_type']]['baseFare'] = 0;
                }
                if (!isset($fareArray[$orderId][$viafareArray['trip_type']]['tax'])) {
                    $fareArray[$orderId][$viafareArray['trip_type']]['tax'] = 0;
                }
                if (!isset($fareArray[$orderId][$viafareArray['trip_type']]['infantBaseFare'])) {
                    $fareArray[$orderId][$viafareArray['trip_type']]['infantBaseFare'] = 0;
                }
                if (!isset($fareArray[$orderId][$viafareArray['trip_type']]['infantTax'])) {
                    $fareArray[$orderId][$viafareArray['trip_type']]['infantTax'] = 0;
                }
                if (!isset($fareArray[$orderId][$viafareArray['trip_type']]['infantServiceTax'])) {
                    $fareArray[$orderId][$viafareArray['trip_type']]['infantServiceTax'] = 0;
                }
                if (!isset($fareArray[$orderId][$viafareArray['trip_type']]['infantTotalFare'])) {
                    $fareArray[$orderId][$viafareArray['trip_type']]['infantTotalFare'] = 0;
                }
                if ($viafareArray['passenger_type'] == '0') {
                    $fareArray[$orderId][$viafareArray['trip_type']]['baseFare'] = $fareArray[$orderId][$viafareArray['trip_type']]['baseFare'] + $viafareArray['base_fare'];
                    $fareArray[$orderId][$viafareArray['trip_type']]['tax'] = $fareArray[$orderId][$viafareArray['trip_type']]['tax'] + $viafareArray['tax'];
                } elseif ($viafareArray['passenger_type'] == '2') {
                    $fareArray[$orderId][$viafareArray['trip_type']]['infantTotalFare'] = $fareArray[$orderId][$viafareArray['trip_type']]['infantTotalFare'] + ($viafareArray['base_fare'] + $viafareArray['tax'] + $viafareArray['service_tax']);
                    $fareArray[$orderId][$viafareArray['trip_type']]['infantBaseFare'] = $fareArray[$orderId][$viafareArray['trip_type']]['infantBaseFare'] + ($viafareArray['base_fare'] * $noOfInfant);
                    $fareArray[$orderId][$viafareArray['trip_type']]['infantTax'] = $fareArray[$orderId][$viafareArray['trip_type']]['infantTax'] + ($viafareArray['tax'] * $noOfInfant);
                    $fareArray[$orderId][$viafareArray['trip_type']]['infantServiceTax'] = $fareArray[$orderId][$viafareArray['trip_type']]['infantServiceTax'] + ($viafareArray['service_tax'] * $noOfInfant);
                }

                // }
            }
            foreach ($fareArray as $orderkey => $fareOrderArray) {
                foreach ($fareOrderArray as $key => $fare) {
                    if (isset($fare['infantTotalFare']) && $fare['infantTotalFare'] != 0) {
                        $fareArray[$orderkey][$key]['tax']+=(($fare['infantTotalFare'] * $noOfInfant) / $noOfAdults);
                    }
                }
            }
        }
        return $fareArray;
    }

    public function _updateViaFlightSync($syncViaFlightDetails) {
        foreach ($syncViaFlightDetails as $key => $value) {
            $viaFlightDetails['sync_via_flight_id'] = $value['backEndViaFlightId'];
            $viaFlightId = $value['frontEndViaFlightId'][0];
            $result = $this->db->_update('via_flight_details', $viaFlightDetails, 'via_flight_id', $viaFlightId);
//        if(!$result > 0)
//        {
//            $this->_OAppSettings->pushInsertDetails($viaFlightDetails,'via_flight_details',$viaFlightId,$this->_OcommonDBO->_AbugTracking);
//        }
//        else 
//        {
//            $this->_OAppSettings->pushInsertDetails($viaFlightDetails,'via_flight_details',$viaFlightId);
//        }
        }
        return true;
    }

    /**
     * @Description :This function is used to insert the via flight details 
     * @param :array   | $viaFlightDetails - holds array of flight details
     * @return integer |$resultViaFlightId - inserted passenger id
     */
    public function _insertViaFlightDetails($viaFlightDetails) {
        $tableName = 'via_flight_details';
        $resultViaFlightId = $this->db->_insert($tableName, $viaFlightDetails);

        return $resultViaFlightId;
    }

    /**
     * @Description :This function is used to insert the passenger other details 
     * @param :array   | $viaFareDetails - holds array of via flight id and fare details
     * @return integer |$resultViaFareId - inserted passenger id
     */
    public function _insertViaFareDetails($viaFareDetails) {
        $tableName = 'via_fare_details';
        $resultViaFareId = $this->db->_insert($tableName, $viaFareDetails);

        return $resultViaFareId;
    }

    /**
     * @Description: This function is used to insert the passenger other details 
     * @param :array   | $viaFareDetails - holds array of via flight id and fare details
     * @return integer |$resultViaFareId - inserted passenger id
     */
    public function _getsegmentAgentFee($corporateId = '', $travelClassId = '', $travelModeId = ''){
        
        $result = false;

        if($corporateId != '' && $travelClassId != '' && $travelModeId != ''){

            $sql = "SELECT da.agent_fee_id, da.agent_fee_name, am.fee_type, am.calc_based_on, am.fee_value 
                    FROM dm_agent_fee da INNER JOIN agent_fee_mapping am ON da.agent_fee_id = am.r_agent_fee_id
                    WHERE am.r_corporate_id = " . $corporateId . " AND (am.r_travel_class_id = " . $travelClassId . " OR am.r_travel_class_id = 0 )
                    AND am.r_travel_mode_id = " . $travelModeId . "";
            $result = $this->db->_getResult($sql);
        }
        return $result;
    }

    public function _passengerViaFlightStatus($_status, $condition) {

        $sqlUpdate = "UPDATE passenger_via_details SET r_booking_status_id=" . $_status . " WHERE r_via_flight_id=" . $condition[0] . " AND r_passenger_id=" . $condition[1] . "";
        $status = $this->_OcommonDBO->_getResult($sqlUpdate);
    }

    public function _passengerViaDetailsUpdate($passengerViaDetails, $paxKey, $viaKey, $orderId) {
        $sqlPassengerViaUpdate = "UPDATE passenger_via_details pvd,via_flight_details vfd,passenger_details pd SET "
                . " pnr='" . $passengerViaDetails['pnr'] . "',
                 ticket_number='" . $passengerViaDetails['ticket_number'] . "',
                 airline_basefare='" . $passengerViaDetails['airline_basefare'] . "', 
                 airline_taxfare='" . $passengerViaDetails['airline_taxfare'] . "',
                 booked_through='" . $passengerViaDetails['booked_through'] . "',
                 reschedule_penalty='" . $passengerViaDetails['reschedule_amount'] . "',
                 cancellation_penalty='" . $passengerViaDetails['cancellation_amount'] . "',
                 agent_id='" . $passengerViaDetails['agent_id'] . "',
                 fullfilment_status=" . FULFILMENT_DONE .
                " WHERE pvd.r_via_flight_id=vfd.via_flight_id "
                . " AND pd.passenger_id=pvd.r_passenger_id "
                . " AND vfd.sync_via_flight_id=" . $viaKey
                . " AND pd.sync_passenger_id=" . $paxKey
                . " AND pvd.r_order_id =" . $orderId;
        $resultUpdate = $this->_OcommonDBO->_getResult($sqlPassengerViaUpdate);

        $sqlGetInfantId = "SELECT pim.r_infant_id FROM passenger_details pd,passenger_infant_mapping pim WHERE 
                                pd.passenger_id=pim.r_passenger_id AND pd.sync_passenger_id= " . $paxKey;

        $resultGetInfantId = $this->_OcommonDBO->_getResult($sqlGetInfantId);
        if (isset($resultGetInfantId[0]['r_infant_id']) && $resultGetInfantId[0]['r_infant_id'] != 0) {
            $infantId = $resultGetInfantId[0]['r_infant_id'];

            $sqlPaxViaInfantDetailsUpdate = "UPDATE passenger_via_details pvd,via_flight_details vfd,passenger_details pd SET "
                    . " pnr='" . $passengerViaDetails['pnr'] . "',
                     ticket_number='" . $passengerViaDetails['ticket_number'] . "',
                     booked_through='" . $passengerViaDetails['booked_through'] . "',
                     agent_id='" . $passengerViaDetails['agent_id'] . "',
                     fullfilment_status=" . FULFILMENT_DONE .
                    " WHERE pvd.r_via_flight_id=vfd.via_flight_id "
                    . " AND pd.passenger_id=pvd.r_passenger_id "
                    . " AND vfd.sync_via_flight_id=" . $viaKey
                    . " AND pd.passenger_id=" . $infantId
                    . " AND pvd.r_order_id =" . $orderId;

            $resultPaxViaInfantDetailsUpdate = $this->_OcommonDBO->_getResult($sqlPaxViaInfantDetailsUpdate);
            return $resultPaxViaInfantDetailsUpdate;
        }
        return $resultUpdate;
    }

    /*
     * @Description  this function get the basic info of the itinerary
     * @param int|$orderId
     * @return 
     */

    public function _getFlightItineraryDetails($orderId) {
        GLOBAL $CFG;

        $sqlItinerary = "SELECT 
							vfd.via_flight_id,
							vfd.r_origin_airport_id,
							vfd.r_destination_airport_id,
							vfd.time_arrival,
							vfd.time_departure,
							vfd.r_airline_id,
							vfd.flight_no,
                            fd.service_provider_id,vfd.operating_airline_code, 
                                                        DATE_FORMAT(vfd.arrival_date,'" . $CFG['date_format']['date_day'] . "') as arrival_date,
							DATE_FORMAT(vfd.departure_date,'" . $CFG['date_format']['date_day'] . "') as departure_date,
							vfd.r_travel_class_id,
							vfd.r_fare_type_id,
							vfd.flight_type,
							vfd.trip_type,
							vfd.booking_class,
							vfd.travel_time,
							vfd.gds_pnr,
							vfd.time_limit,
							vfd.total_time,
							vfd.layover_time,
							vfd.created_date,
							fd.via_fare_id,
							fd.fare_basis_code,
							fd.passenger_type,
							fd.base_fare,
							fd.tax,
							fd.service_tax,
							fd.total_fare,
							od.order_id,
							od.r_currency_type_id,
                                                        abd.booking_date,
                                                        vfd.meal_code_id,
                                                        vfd.checkin_baggage,
                                                        vfd.arrival_terminal,
                                                        vfd.departure_terminal
					FROM
							via_fare_details fd,
							via_flight_details vfd,
							fact_air_itinerary fai,
							order_details od,
							air_booking_details abd
					WHERE 
							vfd.via_flight_id = fai.r_via_flight_id
							AND fd.via_fare_id = fai.r_via_fare_id
							AND fd.r_via_flight_id = vfd.via_flight_id
							AND abd.r_order_id = od.order_id
							AND abd.air_booking_details_id = fai.r_air_booking_details_id
							AND fai.itinerary_status = " . SELECTED_ITINERARY . "
							AND od.order_id =" . $orderId . "
							GROUP BY vfd.via_flight_id,fd.passenger_type ORDER BY vfd.trip_type,fd.r_via_flight_id,fd.passenger_type";

        $resultItinerary = $this->_OcommonDBO->_getResult($sqlItinerary);
        if ($resultItinerary != '') {
            return $resultItinerary;
        }
    }

    /*
     * @Description  this function  get the itinerary info from the array
     * @param array |$resultItinerary
     * @return array |$resultrow
     */

    public function _getItineraryInfo($resultItinerary) {

        global $CFG;
        
        if ($resultItinerary != '') {
            $index = 0;
            $onindex = -1;
            $retindex = -1;
            $viaFlight = '';

            foreach ($resultItinerary as $via) {
                $_paxCount = '';

                /*                 * ** to get the currency type  * */
                if ($via['r_currency_type_id'] != '') {
                    $currency = $this->_Ocurrency->_getCurrencyType($via['r_currency_type_id'], '');
                    $via['currency'] = $currency[0]['currency_symbol'];
                }
                /*                 * * end of currency type * */

                /*                 * * to get the airport code and airport name * */
                if ($via['r_origin_airport_id'] != '') {
                    $airportInfo = $this->_OairportDetails->_getAirportName($via['r_origin_airport_id']);
                    $via['origin'] = $airportInfo[0]['airport_code'];
                    $via['mainOrigin'] = $airportInfo[0]['city_name'];
                    $via['airport_origin_desc'] = $airportInfo[0]['airport_desc'];
                    $via['origin_airport_name'] = $airportInfo[0]['airport_name'];
                }
                if ($via['r_destination_airport_id'] != '') {
                    $airportInfo = $this->_OairportDetails->_getAirportName($via['r_destination_airport_id']);
                    $via['destination'] = $airportInfo[0]['airport_code'];
                    $via['mainDestination'] = $airportInfo[0]['city_name'];
                    $via['airport_dest_desc'] = $airportInfo[0]['airport_desc'];
                    $via['dest_airport_name'] = $airportInfo[0]['airport_name'];
                }
                /*                 * * end of airport details ** */
                if ($via['meal_code_id'] != '') {
                    $mealType = $this->_OairportDetails->_getMealType($via['meal_code_id']);
                    $via['mealType'] = $mealType[0]['meal_description'];
                }
                /*                 * * to get the airline details * */
                if ($via['r_airline_id'] != '') {
                    $airlineInfo = $this->_OairlineDetails->_getAirlineDetails($via['r_airline_id']);
                    $via['airlineCode'] = $airlineInfo[0]['airline_code'];
                    $via['airlineName'] = $airlineInfo[0]['airline_name'];
                }
                /*                 * * end of airline details * */

                /*                 * *** to get the fare type ** */
                $fareInfo = $this->_OfareDetails->_getFareTypeByFareTypeId($via['r_fare_type_id']);
                $via['fare_type'] = $fareInfo[0]['faretype'];
                $via['rtfare_status'] = 'N';
                if (in_array($via['r_fare_type_id'], $CFG['RTFARE'])) {
                    $via['rtfare_status'] = 'Y';
                }

                // Check departure date is expire or not 

                $flightcancelTime = strtotime($via['departure_date']) - 60 * 60 * 2;

                $todayDateTime = strtotime(date("d-M-Y H:i:s"));

                if ($todayDateTime <= $flightcancelTime) {
                    $via['flightaction'] = "show";
                } else {
                    $via['flightaction'] = "hide";
                }

                /** end of fare type * */
                /*                 * * trip_type 
                 *   onward - 0
                 *   return - 1
                 * * */
                if ($via['trip_type'] == 0) {
                    if ($index > 0) {
                        $index --;
                    } else {
                        $viaindex = $onindex;
                        $row[$index] = $via;
                        $row[$index]['mainOrigin'] = $via['mainOrigin'];
                        $row[$index]['mainDepartureTime'] = date('H:i', strtotime($via['time_departure']));
                        /*                         * * to get the pax count * */
                        $paxTypeCount = $this->_OairRequest->_getAirRequestDetails($via['order_id']);
                        $row[$index]['mainTripType'] = $paxTypeCount[0]['trip_type'];
                        /*                         * * to get the agent fee * */
                        $feeInfo = $this->_OfareDetails->_getAgentFeeDetailsByOrderId($via['order_id']);
                    }
                } else {
                    if ($index > 1) {
                        $index --;
                    } else {
                        $viaindex = $retindex;
                        $row[$index] = $via;
                        $row[$index]['mainOrigin'] = $via['mainOrigin'];
                        $row[$index]['mainDepartureTime'] = date('H:i', strtotime($via['time_departure']));
                    }
                }
                /*                 * ** multiple passenger type same via_flight * */
                if ($viaFlight != $via['via_flight_id']) {
                    $viaFlight = $via['via_flight_id'];
                    $viaindex ++;
                }
                $row[$index]['mainDestination'] = $via['mainDestination'];
                $row[$index]['mainDestinationCode'] = $via['destination'];
                $row[$index]['mainArrivalTime'] = date('H:i', strtotime($via['time_arrival']));
                $row[$index]['total_time'] = $via['total_time'];
                $row[$index]['tripCount'] = $viaindex;
                $row[$index]['viaInfo'][$viaindex]['origin'] = $via['origin'];
                $row[$index]['viaInfo'][$viaindex]['destination'] = $via['destination'];
                $row[$index]['viaInfo'][$viaindex]['dest_airport_name'] = $via['dest_airport_name'];
                $row[$index]['viaInfo'][$viaindex]['airport_dest_desc'] = $via['airport_dest_desc'];
                $row[$index]['viaInfo'][$viaindex]['origin_airport_name'] = $via['origin_airport_name'];
                $row[$index]['viaInfo'][$viaindex]['airport_origin_desc'] = $via['airport_origin_desc'];
                $row[$index]['viaInfo'][$viaindex]['arrival_terminal'] = $via['arrival_terminal'];
                $row[$index]['viaInfo'][$viaindex]['arrival_date'] = $via['arrival_date'];
                $row[$index]['viaInfo'][$viaindex]['departure_date'] = $via['departure_date'];
                $row[$index]['viaInfo'][$viaindex]['base_fare'] = $via['base_fare'];
                $row[$index]['viaInfo'][$viaindex]['departure_terminal'] = $via['departure_terminal'];
                $row[$index]['viaInfo'][$viaindex]['mealType'] = $via['mealType'];
                $row[$index]['viaInfo'][$viaindex]['checkin_baggage'] = $via['checkin_baggage'];
                $row[$index]['viaInfo'][$viaindex]['airlineName'] = $via['airlineName'];
                $row[$index]['viaInfo'][$viaindex]['airlineCode'] = $via['airlineCode'];
                $row[$index]['viaInfo'][$viaindex]['time_arrival'] = date('H:i', strtotime($via['time_arrival']));
                $row[$index]['viaInfo'][$viaindex]['time_departure'] = date('H:i', strtotime($via['time_departure']));
                $row[$index]['viaInfo'][$viaindex]['trip_type'] = $via['trip_type'];
                $row[$index]['viaInfo'][$viaindex]['total_time'] = $via['travel_time'];
                $row[$index]['viaInfo'][$viaindex]['layover_time'] = $via['layover_time'];
                $row[$index]['viaInfo'][$viaindex]['flight_no'] = $via['flight_no'];
                $row[$index]['viaInfo'][$viaindex]['fare_type'] = $via['fare_type'];
                $row[$index]['viaInfo'][$viaindex]['via_flight_id'] = $via['via_flight_id'];

                /*                 * * to get the fare break up info * */
                if (array_key_exists($via['passenger_type'], $this->_ApassengerType)) {
                    $passengerCaption = $this->_ApassengerType[$via['passenger_type']];
                }
                foreach ($paxTypeCount as $arr) {
                    $arr['0'] = $arr['ADT'];
                    $arr['1'] = $arr['CH'];
                    $arr['2'] = $arr['INF'];
                    $paxTypeCount[0] = $arr;
                }
                /*                 * * to get the pax count info for pax type * */
                if (array_key_exists($via['passenger_type'], $paxTypeCount[0])) {
                    $paxCount = $paxTypeCount[0][$via['passenger_type']];
                }
                /*                 * * to get the total farebreak up info * */
                if ($paxCount > 1) {
                    $_paxCount = ' x ' . $paxCount;
                }


                $request_date = $this->_OcommonDBO->_select('booking_history', 'DATE(request_date)', 'order_id', $via['order_id'])[0]['DATE(request_date)'];
                $passenger_type = $passengerCaption;

                $row[$index]['fareBreakUp'][$passenger_type]['paxCount'] = $paxCount;
                $row[$index]['fareBreakUp'][$passenger_type]['paxTypeName'] = $passengerCaption;
                $row[$index]['fareBreakUp'][$passenger_type]['baseFare_caption'] = 'Airline Fare';
                $row[$index]['fareBreakUp'][$passenger_type]['baseFare'] += $via['base_fare'];
                $row[$index]['fareBreakUp'][$passenger_type]['tax_caption'] = 'Tax';
                $row[$index]['fareBreakUp'][$passenger_type]['tax'] += $via['tax'];
                $row[$index]['fareBreakUp'][$passenger_type]['serviceTax_caption'] = strtotime($request_date) >= strtotime(GST_DISPLAY_DATE) ? 'GST' : 'Service Tax';
                ;
                $row[$index]['fareBreakUp'][$passenger_type]['serviceTax'] += $via['service_tax'];
                $row[$index]['fareBreakUp'][$passenger_type]['paxAmount'] = ($via['base_fare'] + $via['tax'] + $via['service_tax']);
                $total = ($via['base_fare'] + $via['tax'] + $via['service_tax']) * ($paxCount);
                $row[$index]['fareBreakUp'][$passenger_type]['amount'] += $total;
                $row[$index]['total_amount'] += $total;

                //calculate GST (agency and airline)
                //get the via fare info with respect to the via flight id,
                $viaFareInfo = $this->_getViaFareInfoViaFlightId($viaFlightIds)[0];
                /** * end of fare break up info * */

                /* * * to get the agent fee details * */
                if ($feeInfo[0]['agent_fee_name'] == 'transactionFee') {
                    $row[0]['transaction_fee'] = $feeInfo[0]['fee_value'];
                }
                if ($feeInfo[1]['agent_fee_name'] == 'discountAmount') {
                    $row[0]['discount_amount'] = $feeInfo[1]['fee_value'];
                }
                if ($feeInfo[2]['agent_fee_name'] == 'systemUsageFee') {
                    $row[0]['system_usage_fee'] = $feeInfo[2]['fee_value'];
                }
                if ($feeInfo[1]['agent_fee_name'] == 'feeGST') {
                    $row[0]['fee_GST'] = $feeInfo[1]['fee_value'];
                }
                /*                 * * end of agent fee * */
                $_baseFare = $via['base_fare'] * ($paxCount);
                $_tax = $via['tax'] * ($paxCount);
                $_serviceTax = $via['service_tax'] * ($paxCount);
                $row[0]['airlineBaseFare'] += $_baseFare;
                $row[0]['airlineTaxFare'] += $_tax;
                $row[0]['airlineServiceTax'] += $_serviceTax;
                $row[$index]['airlineBaseFareEticket'] += $_baseFare;
                $row[$index]['airlineTaxFareEticket'] += $_tax;
                $row[$index]['airlineServiceTaxEticket'] += $_serviceTax;
                $index ++;
            }
        }
        return $row;
    }

    /*
     * @Description  this function get the via flight id 
     * @param $orderId,$tripType
     * @return viaFlightId
     */

    public function _getViaFlightId($orderId, $tripType) {
        $sqlViaFlight = "SELECT 
            
                            vfd.via_flight_id 

                         FROM 
                         
                            via_flight_details vfd,
                            passenger_via_details pvd,
                            fact_air_itinerary fai

                        WHERE
                        
                            pvd.r_order_id =" . $orderId . " 
                            AND vfd.trip_type in (" . $tripType . ") 
                            AND pvd.r_via_flight_id = vfd.via_flight_id 
                            AND fai.r_via_flight_id = vfd.via_flight_id 
                            AND fai.itinerary_status = " . SELECTED_ITINERARY . "
                            GROUP BY vfd.via_flight_id";

        $resultViaFlight = $this->_OcommonDBO->_getResult($sqlViaFlight);
        if ($resultViaFlight != '') {
            return $resultViaFlight;
        }
    }

    /*
     * @Description  this function update the passenger via details status
     * @param $_status - status to be update
     * @param $condition- passenger via id
     * @param $oldorderid- old order id
     */

    public function _updateRescheduleViaFLight($_status, $condition, $oldOrderId) {

        $sqlUpdate = "UPDATE passenger_via_details SET r_booking_status_id=" . $_status . " WHERE r_order_id=" . $oldOrderId . " AND passenger_via_id in (" . $condition . ") ";
        $status = $this->_OcommonDBO->_getResult($sqlUpdate);
    }

    /*
     * @Description  this function update the passenger via details status
     * @param $value - booking detail id
     * @param $condition- fact air itinerary id
     */

    public function _updateFactItineraryDetails($value, $condition) {
        $sqlUpdate = "UPDATE fact_air_itinerary SET r_air_booking_details_id=" . $value . " WHERE fact_air_itinerary_id in (" . $condition . ") ";
        $status = $this->_OcommonDBO->_getResult($sqlUpdate);
    }

    /*
     * @Description get sector details for package or order id passed
     * @param int|$packageId
     * @param int|$orderId
     * @return array|$sectorDetailsArray
     */

    public function _getSectorDetails($packageId, $orderId) {

        $sql = "SELECT ar.r_origin_airport_id, ar.r_destination_airport_id, od.total_amount FROM air_request_details ar
                  INNER JOIN fact_booking_details fb ON ar.air_request_id = fb.r_request_id
                  INNER JOIN order_details od ON fb.r_order_id = od.order_id
                  WHERE fb.r_package_id = " . $packageId . "";

        if (isset($orderId) && !empty($orderId)) {
            $sql .= " AND od.order_id = " . $orderId . "";
        }

        $result = $this->_OcommonDBO->_getResult($sql);

        $sectorDetailsArray = array();

        foreach ($result as $res) {

            $orginAirportArray = $this->_OairportDetails->_getAirportName($res['r_origin_airport_id']);
            $destAirportArray = $this->_OairportDetails->_getAirportName($res['r_destination_airport_id']);

            $sectorDetailsArray['origin_airport'] = $orginAirportArray[0];
            $sectorDetailsArray['destination_airport'] = $destAirportArray[0];
            $sectorDetailsArray['total_amount'] = $res['total_amount'];
        }

        return $sectorDetailsArray;
    }

    /*
     * @Description update via_fare_details and via_flight_details table with new fare
     * @param array|$orderArray
     * @return 
     */

    public function _updateViaFareDetails($_IorderId, $_Aorder, $otherDetailsArray) {

        ### $airlineCodeId = $this->_getAirlineCodeId($airLineCode);
        ### get passenger type and key type for passenger type array
        $passengerTypeArray = array('ADT' => 0, 'CNN' => 1, 'CHD' => 1, 'INF' => 2);
        fileWrite('otherDetailsArray--->' . print_r($otherDetailsArray, 1), 'AYPR' . $this->_orderId, 'a+');
        $tripTypeIdsPresent = array();
        $serviceTaxValue = $this->_getTaxValues('SERVICE_TAX', '0');

        $segmentAirLineCount = array();
        $segmentFlightNoCount = array();
        $transDetails = array();
        $updateOrderArray = $updateRessCanUpdateArray = array();
        $orderTotalServiceTax = 0;
        $transDetails['passCount'] = $otherDetailsArray['passCount'];
        $transDetails['tripType'] = $otherDetailsArray['tripType'];
        $transDetails['travelType'] = 'DO';
        $agentFeeDetailsArray = $this->_getSegmentAgentFee($_SESSION['corporateId'], $otherDetailsArray['travelClassId'], $otherDetailsArray['travelModeId']);

        foreach ($_Aorder as $key => $tripFare) {

            foreach ($tripFare['response']['segment'] as $segmentKey => $passFare) {
                
                if (isset($passFare['passengerFare']) && count($passFare['passengerFare']) > 0) {

                    ### patch added for re-arranging array based on passenger type start for 
                    ### if passenger key does not match with passenger type

                    $passengerNewFareArray = array();

                    foreach ($passFare['passengerFare'] as $res) {
                        $passengerNewFareArray[$passengerTypeArray[$res['passengerType']]] = $res;
                    }

                    $passFare['passengerFare'] = $passengerNewFareArray;

                    ### patch added for re-arranging array based on passenger type end 

                    $tripTypeIdsPresent[] = $key;
                    //intitlaize order base fare variables
                    ### intitlaize order base fare variables
                    $orderTotalBaseFare = $orderTotalTotalTax = 0;

                    $passFare['passengerFare'] = $this->_JNTaxCalculation($passFare['passengerFare']);
                    $passFare['passengerFare'] = $this->_serviceTaxCalculation($passFare['passengerFare']);

                    $_ApassengerFare = $passFare['passengerFare'];
                    
                    if ($passFare['tripType'] == 'onward') {
                        
                        $itineraryTripType = 'ONEWAY';
                        $tripType = 0;
                        $tripTypeIdsPresent[] = $tripType;
                    } else {
                        $itineraryTripType = 'RETURN';
                        $tripType = 1;
                        $tripTypeIdsPresent[] = $tripType;
                    }
                    
                    $_AviaFare = $this->_getViaFareIdForOrder($_IorderId, $key);
                    $this->_orderId = $_IorderId;
                    fileWrite('via fare from order details--->' . print_r($_AviaFare, 1), 'AYPR' . $this->_orderId, 'a+');

                    foreach ($_AviaFare as $res) {

                        $feeCalcBaseFare = 0;
                        $feeCalcTax = 0;
                        $updateRessCanUpdateArray[$key][$res['passenger_type']]['cancellation_penalty'] = $_ApassengerFare[$res['passenger_type']]['cancellationAmount'];
                        $updateRessCanUpdateArray[$key][$res['passenger_type']]['reschedule_penalty']   = $_ApassengerFare[$res['passenger_type']]['rescheduleAmount'];

                        $viaFareIdsArray = explode(",", $res['via_fare_id']);

                        $fareBasisArray = array_combine($_ApassengerFare[$res['passenger_type']]['flightNumber'], $_ApassengerFare[$res['passenger_type']]['farebasis']);

                        //update via_flight_details tab
                        $_AupdateViaFlightArray = array();

                        //update via_fare_details table
                        $_AupdateViaFareArray = array();


                        $this->_viaFareBreakUp[$viaFareIdsArray[$res['passenger_type']]]['viaFareId'] = $viaFareIdsArray[$res['passenger_type']];
                        $this->_viaFareBreakUp[$viaFareIdsArray[$res['passenger_type']]]['tax'] = $_ApassengerFare[$res['passenger_type']]['tax'];
                        $this->_viaFareBreakUp[$viaFareIdsArray[$res['passenger_type']]]['tax']['original_base_fare'] = $_ApassengerFare[$res['passenger_type']]['original_base_fare'];
                        $this->_viaFareBreakUp[$viaFareIdsArray[$res['passenger_type']]]['tax']['original_tax'] = $_ApassengerFare[$res['passenger_type']]['original_tax'];



                        //will get all values in first result row itself
                        $segmentAirLineCount = array_unique(explode(",", $res['airlineids']));
                        $segmentFlightNoCount = array_unique(explode(",", $res['flightnos']));

                        $this->_calculateSegmentAgentFee($agentFeeDetailsArray, $segmentAirLineCount, $segmentFlightNoCount, $transDetails);

                        // GST STARTS
                        $feeArray['transaction_fee'] = $this->_ItransactionFee;
                        $feeArray['system_usage_fee'] = $this->_IsystemUsageFee;
                        $feeArray['discount_fee'] = $this->_IdiscountFee;
                        $this->_IviaAirlineId = $this->db->_select('dm_airline', array('airline_id'), 'airline_code', $_ApassengerFare[0]['airline_code'])[0]['airline_id'];
                        $this->_SfareTypeCode = $this->_getFareTypeID($res['r_fare_type_id'])[0]['fare_type_code'];
                        $this->_SclassCode = $otherDetailsArray['travelClassId'];
                        $basFareWitPass = $basefare / $transDetails['passCount'];
                        $calculatedTax = $this->_getGSTTotalAmount($feeArray, $otherDetailsArray['passCount'], $otherDetailsArray['tripType'], $this->_viaFareBreakUp[$viaFareIdsArray[$res['passenger_type']]]['tax'], $_ApassengerFare[$res['passenger_type']]['baseFare']);
                        $_IserviceTax = $calculatedTax;

                        // GST ENDS
                        $_AupdateViaFareArray['fare_basis_code'] = $fareBasisArray[$res['flight_no']];
                        $_AupdateViaFareArray['passenger_type'] = $res['passenger_type'];
                        $_AupdateViaFareArray['base_fare'] = $_ApassengerFare[$res['passenger_type']]['baseFare'];
                        $_AupdateViaFareArray['tax'] = $_ApassengerFare[$res['passenger_type']]['totalTax'];
                        $_AupdateViaFareArray['service_tax'] = $_IserviceTax;
                        $_AupdateViaFareArray['total_fare'] = $_ApassengerFare[$res['passenger_type']]['baseFare'] + $_ApassengerFare[$res['passenger_type']]['totalTax'];
                        //$affectedCount = $this->_OcommonDBO->_update('via_fare_details', $_AupdateViaFareArray, 'via_fare_id', $res['r_via_fare_id']);
                        $sql = "UPDATE via_fare_details SET fare_basis_code = '" . $_AupdateViaFareArray['fare_basis_code'] . "',
                                                    passenger_type  = '" . $_AupdateViaFareArray['passenger_type'] . "',
                                                    base_fare       = '" . $_AupdateViaFareArray['base_fare'] . "',
                                                    tax             = '" . $_AupdateViaFareArray['tax'] . "',
                                                    service_tax     = '" . $_IserviceTax . "',
                                                    commission     = '" . $this->_Icommission . "',
                                                    commission_tax     = '" . $this->_serviceTaxComm . "',
                                                    fee_tax     = '" . $this->_serviceTaxFee . "',
                                                    total_fare      = '" . $_AupdateViaFareArray['total_fare'] . "'
                        WHERE via_fare_id = '" . $viaFareIdsArray[$res['passenger_type']] . "' AND passenger_type = '" . $_AupdateViaFareArray['passenger_type'] . "'";

                        $this->_OcommonDBO->_executeQuery($sql);

                        $this->_viaFareBreakUp[$viaFareIdsArray[$res['passenger_type']]]['viaFareId'] = $viaFareIdsArray[$res['passenger_type']];
                        $this->_viaFareBreakUp[$viaFareIdsArray[$res['passenger_type']]]['tax'] = $_ApassengerFare[$res['passenger_type']]['tax'];
                        $this->_viaFareBreakUp[$viaFareIdsArray[$res['passenger_type']]]['tax']['original_base_fare'] = $_ApassengerFare[$res['passenger_type']]['original_base_fare'];
                        $this->_viaFareBreakUp[$viaFareIdsArray[$res['passenger_type']]]['tax']['original_tax'] = $_ApassengerFare[$res['passenger_type']]['original_tax'];


                        //Get Basefare and tax for each trip
                        $feeCalcBaseFare = intval($_ApassengerFare[$res['passenger_type']]['baseFare'] * $otherDetailsArray[$res['passenger_type']]);
                        $feeCalcTax = intval($_ApassengerFare[$res['passenger_type']]['totalTax'] * $otherDetailsArray[$res['passenger_type']]);

                        //get order total base fare , total tax 
                        $orderTotalBaseFare += $feeCalcBaseFare;
                        $orderTotalTotalTax += $feeCalcTax;
                        fileWrite('serviceTaxPer before->' . $orderTotalServiceTax, 'AYPR' . $this->_orderId, 'a+');
                        fileWrite('orderTotalServiceTax-->' . $_IserviceTax . '-->' . $otherDetailsArray[$res['passenger_type']], 'AYPR' . $this->_orderId, 'a+');
                        $orderTotalServiceTax += intval($_IserviceTax * $otherDetailsArray[$res['passenger_type']]);
                        fileWrite('serviceTaxPer after->' . $orderTotalServiceTax, 'AYPR' . $this->_orderId, 'a+');

                        //Get transDetails array to calculate fee types based on the trip
                        if ($_ApassengerFare[$res['passenger_type']]['tripBasedTripType'] == 0) {
                            fileWrite('ONARD-->' . $feeCalcBaseFare . '-->' . $feeCalcTax, 'AYPR' . $this->_orderId, 'a+');
                            $transDetails['onwBaseFare'] = $feeCalcBaseFare;
                            $transDetails['onwTaxFare'] = $feeCalcTax;
                        } else {
                            fileWrite('RETURN-->' . $feeCalcBaseFare . '-->' . $feeCalcTax, 'AYPR' . $this->_orderId, 'a+');
                            $transDetails['retBaseFare'] = $feeCalcBaseFare;
                            $transDetails['retTaxFare'] = $feeCalcTax;
                        }
                    }
                    //calculate total amount to update in order_details table
                    $orderTotalAirlineAmount += $orderTotalBaseFare + $orderTotalTotalTax;
                    fileWrite('Order check amount 1-->' . $orderTotalBaseFare . '-->' . $orderTotalTotalTax, 'AYPR' . $this->_orderId, 'a+');
                    fileWrite('Order details amount-->' . $orderTotalAirlineAmount, 'AYPR' . $this->_orderId, 'a+');
                    //update cancellation * rescheudle amount in passenger_via_details table
                    //$updateRsCanUpdateArray[]
                    //calculate segment fees
                    //delete previous agent_fee_mapping values from table
                    $this->_OcommonDBO->_delete('booking_fee_mapping', 'r_order_id', $_IorderId);
                    //For fee type calculation 
                }
            }
        }
        //Case were the fare increase array not found in round trip, may be array onward empty or return array empty empty.
        //If so calculate we have to get the total amount from the via_flight_details 
        if ($otherDetailsArray['tripType'] == 1 && count($tripTypeIdsPresent) == 1) {
            fileWrite('Order details amount -->' . $orderTotalAirlineAmount, 'AYPR' . $this->_orderId, 'a+');
            $tripTypeArray = array(0, 1);

            $tripTypeIdNotReturned = array_diff($tripTypeArray, $tripTypeIdsPresent);

            //calculate the fare details for the array which is not present
            $viaFareResult = $this->_getViaFareIdForOrder($_IorderId, current($tripTypeIdNotReturned));

            $orderTotalBaseFare = $orderTotalTotalTax = $orderTotalServiceTax = 0;

            foreach ($viaFareResult as $res) {
                $orderTotalBaseFare += intval($res['base_fare'] * $otherDetailsArray[$res['passenger_type']]);
                $orderTotalTotalTax += intval($res['tax'] * $otherDetailsArray[$res['passenger_type']]);
                $orderTotalServiceTax += intval($res['service_tax'] * $otherDetailsArray[$res['passenger_type']]);
            }

            $orderTotalAirlineAmount = $orderTotalBaseFare + $orderTotalTotalTax;
            fileWrite('Order check amount 2-->' . $orderTotalBaseFare . '-->' . $orderTotalTotalTax, 'AYPR' . $this->_orderId, 'a+');
            fileWrite('Order details amount -->' . $orderTotalAirlineAmount, 'AYPR' . $this->_orderId, 'a+');
        }

        fileWrite('$updateRessCanUpdateArray--' . print_r($updateRessCanUpdateArray, 1), 'updateFareIncreaseArray', 'a+');


        $ordderTotalAmount = intval($orderTotalAirlineAmount + $orderTotalServiceTax + $this->_ItransactionFee + (intval($this->_IsystemUsageFee) - intval($this->_IdiscountFee)));
        fileWrite('Sum order total amount TB-->' . $orderTotalAirlineAmount . '-TT->' . $orderTotalServiceTax . '--TF->' . $this->_ItransactionFee . '--SUF->' . $this->_IsystemUsageFee . '--DF->' . $this->_IdiscountFee, 'AYPR' . $this->_orderId, 'a+');
        $updateOrderArray['total_amount'] += $ordderTotalAmount;
        fileWrite('Final order update -->' . print_r($agentFeeDetailsArray, 1), 'AYPR' . $this->_orderId, 'a+');

        if (is_array($agentFeeDetailsArray) && count($agentFeeDetailsArray) > 0) {

            foreach ($agentFeeDetailsArray as $value) {

                $insertArray = array();
                switch ($value['agent_fee_name']) {
                    case 'transactionFee':
                        $insertArray['fee_value'] = $this->_ItransactionFee;
                        break;
                    case 'systemUsageFee':
                        $insertArray['fee_value'] = $this->_IsystemUsageFee;
                        break;
                    case 'discountAmount';
                        $insertArray['fee_value'] = $this->_IdiscountFee;
                        break;
                    default:
                        break;
                }
                $insertArray['r_order_id'] = $this->_orderId;
                $insertArray['r_agent_fee_id'] = $value['agent_fee_id'];
                $this->_insertTableValues('booking_fee_mapping', $insertArray);
            }
        }

        //update reschedule and cancellation amount to passenger_via_details table
        $this->_updateRescheduleCancellationFees($_IorderId, $updateRessCanUpdateArray, $otherDetailsArray['tripType']);
        fileWrite('Final order update -->' . print_r($updateOrderArray, 1), 'AYPR' . $this->_orderId, 'a+');
        $affectedCount = $this->_OcommonDBO->_update('order_details', $updateOrderArray, 'order_id', $_IorderId);

        if ($affectedCount >= 0) { //condition added in case same old amount is updated in order_detail after fare increase with onward/return fare increase alone
            $response = array('status' => 0, 'message' => 'updated successfully');
        } else {
            $response = array('status' => 1, 'message' => 'updated failed - payment cannot be done');
        }
        return $response;
    }

    /*
     * @Description get via fare details for order id
     * @param int|$orderId
     * @return array|$result
     */

    public function _getViaFareIdForOrder($orderId, $tripType) {

        $result = false;

        if ($orderId != '') {

            $sql = "SELECT fare.base_fare, fare.tax, fare.service_tax, fa.r_via_flight_id, GROUP_CONCAT(fa.r_via_fare_id order by fa.r_via_fare_id) as via_fare_id, vfd.flight_no, fare.passenger_type , GROUP_CONCAT(vfd.r_airline_id) as airlineids, GROUP_CONCAT(vfd.flight_no) as flightnos,r_fare_type_id 
                    FROM air_booking_details ab 
                    INNER JOIN fact_air_itinerary fa ON ab.air_booking_details_id = fa.r_air_booking_details_id
                    INNER JOIN via_flight_details vfd ON fa.r_via_flight_id = vfd.via_flight_id
                    INNER JOIN via_fare_details fare ON vfd.via_flight_id = fare.r_via_flight_id
                    WHERE ab.r_order_id = " . $orderId . " AND vfd.trip_type = " . $tripType . " GROUP BY fare.passenger_type";

            $result = $this->_OcommonDBO->_getResult($sql);
        }

        return $result;
    }

    /*
     * @Description  this function get the basic info of the itinerary for fare check process
     * @param int|$orderId
     * @return array | $resultItinerary
     */

    public function _getFareCheckFlightItineraryDetails($orderId) {
        GLOBAL $CFG;

        $sqlItinerary = "SELECT
                                            vfd.via_flight_id,
                                            vfd.r_origin_airport_id,
                                            vfd.r_destination_airport_id,
                                            vfd.time_arrival,
                                            vfd.time_departure,
                                            vfd.r_airline_id,
                                            vfd.flight_no,
                                            vfd.arrival_date as arrivalDate,
                                            vfd.departure_date as departureDate,
                                            vfd.r_fare_type_id,
                                            vfd.flight_type,
                                            vfd.trip_type,
                                            vfd.booking_class,
                                            vfd.travel_time,
                                            vfd.gds_pnr,
                                            vfd.time_limit,
                                            vfd.total_time,
                                            vfd.layover_time,
                                            vfd.created_date,
                                            fd.via_fare_id,
                                            fd.fare_basis_code,
                                            fd.passenger_type,
                                            SUM(fd.base_fare) as base_fare,
                                            SUM(fd.tax) as tax,
                                            SUM(fd.base_fare)+SUM(fd.tax) as totalFare,
                                            fd.service_tax,
                                            fd.total_fare,
                                            od.order_id,
                                            od.r_currency_type_id
                            FROM
                                            via_fare_details fd,
                                            via_flight_details vfd,
                                            fact_air_itinerary fai,
                                            order_details od,
                                            air_booking_details abd
                            WHERE
                                            vfd.via_flight_id = fai.r_via_flight_id
                                            AND fd.via_fare_id = fai.r_via_fare_id
                                            AND fd.r_via_flight_id = vfd.via_flight_id
                                            AND abd.r_order_id = od.order_id
                                            AND abd.air_booking_details_id = fai.r_air_booking_details_id
                                            AND fai.itinerary_status = " . SELECTED_ITINERARY . "
                                            AND od.order_id =" . $orderId . "
                                            GROUP BY fd.r_via_flight_id ORDER BY vfd.trip_type,vfd.via_flight_id,fd.passenger_type";

        $resultItinerary = $this->_OcommonDBO->_getResult($sqlItinerary);
        if ($resultItinerary != '') {
            return $resultItinerary;
        }
    }

    public function _getFareCheckFareDetails($orderId, $noOfAdults, $noOfChild, $noOfInfant) {
        $sqlFare = "SELECT fbd.r_order_id,base_fare,tax,service_tax,total_fare,vfd.via_flight_id,trip_type,passenger_type
                            FROM 
                                via_fare_details vfared,
                                via_flight_details vfd,
                                fact_air_itinerary fai,
                                air_booking_details abd,
                                fact_booking_details fbd
                            WHERE
                                abd.air_booking_details_id = fai.r_air_booking_details_id
                                AND fai.r_via_flight_id= vfd.via_flight_id
                                AND fai.r_via_fare_id= vfared.via_fare_id
				AND vfared.base_fare !=0
                                AND abd.r_order_id=fbd.r_order_id
                                AND fai.itinerary_status=" . ITINERARY_STATUS_SELECTED . "
                                AND fbd.r_order_id=" . $orderId .
                " ORDER BY fbd.r_order_id,vfd.trip_type,fai.r_via_flight_id,fai.r_via_fare_id";

        $resultFare = $this->db->_getResult($sqlFare);

        if ($resultFare != '') {
            $index = 0;
            $onindex = 0;
            $retindex = 0;
            foreach ($resultFare as $viafareArray) {
                $orderId = $viafareArray['r_order_id'];
                if (!isset($fareArray[$viafareArray['trip_type']]['totalFare'])) {
                    $fareArray[$viafareArray['trip_type']]['totalFare'] = 0;
                }
                if (!isset($fareArray[$viafareArray['trip_type']]['totalBaseFare'])) {
                    $fareArray[$viafareArray['trip_type']]['totalBaseFare'] = 0;
                }
                if (!isset($fareArray[$viafareArray['trip_type']]['totalTax'])) {
                    $fareArray[$viafareArray['trip_type']]['totalTax'] = 0;
                }
                if (!isset($fareArray[$viafareArray['trip_type']]['baseFare'])) {
                    $fareArray[$viafareArray['trip_type']]['baseFare'] = 0;
                }
                if (!isset($fareArray[$viafareArray['trip_type']]['tax'])) {
                    $fareArray[$viafareArray['trip_type']]['tax'] = 0;
                }
                if (!isset($fareArray[$viafareArray['trip_type']]['infantBaseFare'])) {
                    $fareArray[$viafareArray['trip_type']]['infantBaseFare'] = 0;
                }
                if (!isset($fareArray[$viafareArray['trip_type']]['infantTax'])) {
                    $fareArray[$viafareArray['trip_type']]['infantTax'] = 0;
                }
                if (!isset($fareArray[$viafareArray['trip_type']]['childBaseFare'])) {
                    $fareArray[$viafareArray['trip_type']]['childBaseFare'] = 0;
                }
                if (!isset($fareArray[$viafareArray['trip_type']]['childTax'])) {
                    $fareArray[$viafareArray['trip_type']]['childTax'] = 0;
                }
                $fareArray[$viafareArray['trip_type']]['tripType'] = $viafareArray['trip_type'];
                //if($viafareArray['trip_type']==0){
                if ($viafareArray['passenger_type'] == '0') {
                    $fareArray[$viafareArray['trip_type']]['baseFare'] = $fareArray[$viafareArray['trip_type']]['baseFare'] + $viafareArray['base_fare'];
                    $fareArray[$viafareArray['trip_type']]['tax'] = $fareArray[$viafareArray['trip_type']]['tax'] + $viafareArray['tax'];
                } elseif ($viafareArray['passenger_type'] == '1') {
                    $fareArray[$viafareArray['trip_type']]['childBaseFare'] = $fareArray[$viafareArray['trip_type']]['childBaseFare'] + ($viafareArray['base_fare']);
                    $fareArray[$viafareArray['trip_type']]['childTax'] = $fareArray[$viafareArray['trip_type']]['childTax'] + ($viafareArray['tax']);
                } elseif ($viafareArray['passenger_type'] == '2') {
                    $fareArray[$viafareArray['trip_type']]['infantBaseFare'] = $fareArray[$viafareArray['trip_type']]['infantBaseFare'] + ($viafareArray['base_fare']);
                    $fareArray[$viafareArray['trip_type']]['infantTax'] = $fareArray[$viafareArray['trip_type']]['infantTax'] + ($viafareArray['tax']);
                }
                // }
            }
            foreach ($fareArray as $key => $fare) {
                if (isset($fare['infantBaseFare']) && isset($fare['childBaseFare']) && isset($fare['infantBaseFare'])) {
                    $fareArray[$key]['totalBaseFare'] = $fareArray[$key]['totalBaseFare'] + (($fare['baseFare'] * $noOfAdults) + ($fare['childBaseFare'] * $noOfChild) + ($fare['infantBaseFare'] * $noOfInfant));
                    $fareArray[$key]['totalTax'] = $fareArray[$key]['totalTax'] + (($fare['tax'] * $noOfAdults) + ($fare['childTax'] * $noOfChild) + ($fare['infantTax'] * $noOfInfant));
                    $fareArray[$key]['totalFare'] = $fareArray[$key]['totalFare'] + ((($fare['baseFare'] + $fare['tax']) * $noOfAdults) + (($fare['childBaseFare'] + $fare['childTax']) * $noOfChild) + (($fare['infantBaseFare'] + $fare['infantTax']) * $noOfInfant));
                }
            }
        }
        return $fareArray;
    }

    /*
     * @Function name:_getPnrAndTicketNumber
     * @param: int(passengerId)|int(tripType)
     * @Description: This function is to get pnr and ticket number for particular passenger id based on triptype (onward,return)
     * @return: Array
     * @Author: SELVAKUMAR.S
     */

    public function _getPnrAndTicketNumber($passengerId, $tripType) {
        $sql = "SELECT
                DISTINCT
                    pvd.pnr,
                    pvd.ticket_number
                FROM
                    passenger_via_details pvd,
                    fact_air_itinerary fai,
                    via_flight_details vfd
                WHERE
                    fai.r_via_flight_id = pvd.r_via_flight_id
                AND
                    vfd.via_flight_id = fai.r_via_flight_id
                AND
                    fai.itinerary_status = '" . SELECTED_ITINERARY . "'
                And
                    pvd.r_passenger_id = $passengerId
                AND 
                    vfd.trip_type = $tripType";
        $result = $this->_OcommonDBO->_getResult($sql);
        if ($result != '') {
            return $result;
        }
    }

    /*
     * @Function name:_getTicketStatus
     * @param: int(orderId)
     * @Description: This function is to get ticket Status
     * @return: Array
     * @Author: SELVAKUMAR.S
     */

    public function _getTicketStatus($orderId) {
        $sql = "SELECT ds.status_value
                FROM 
                    order_details od,
                    dm_status ds
                WHERE   
                    od.r_ticket_status_id = ds.status_id
                AND
                    od.order_id = $orderId";
        $result = $this->_OcommonDBO->_getResult($sql);
        if ($result != '') {
            return $result;
        }
    }

    public function _getPackageFareBreakupDetails($packageId, $travelModeId) {
        $sqlFareBreakup = "SELECT fbd.r_order_id,splitup_fare_amount ,splitup_fare_name,vfd.via_flight_id,trip_type,passenger_type
                            FROM 
                                dm_airline_fare_splitup dafs,
                                airline_fare_splitup_details afsd,
                                via_fare_details vfared,
                                via_flight_details vfd,
                                fact_air_itinerary fai,
                                air_booking_details abd,
                                fact_booking_details fbd
                            WHERE
                                abd.air_booking_details_id = fai.r_air_booking_details_id
                                AND fai.r_via_flight_id= vfd.via_flight_id
                                AND fai.r_via_fare_id= vfared.via_fare_id
                                AND vfared.via_fare_id =afsd.r_via_fare_id
                                AND afsd.r_airline_fare_splitup_id = dafs.airline_fare_splitup_id
                                AND vfared.passenger_type = 0
				AND vfared.base_fare !=0
                                AND abd.r_order_id=fbd.r_order_id
                                AND fai.itinerary_status=" . ITINERARY_STATUS_SELECTED . "
                                AND fbd.r_package_id=" . $packageId . " 
                                AND dafs.r_dm_travel_mode_id=" . $travelModeId . " 
                                ORDER BY fbd.r_order_id,vfd.trip_type,fai.r_via_flight_id,fai.r_via_fare_id,afsd.r_airline_fare_splitup_id";

        $resultFareBreakup = $this->db->_getResult($sqlFareBreakup);

        if ($resultFareBreakup != '') {
            $fareArray = array();
            foreach ($resultFareBreakup as $fareSplitupArray) {
                $orderId = $fareSplitupArray['r_order_id'];
                if (!isset($fareArray[$orderId][$fareSplitupArray['trip_type']]['taxBreakUP'])) {
                    $fareArray[$orderId][$fareSplitupArray['trip_type']]['taxBreakUP'] = array();
                }
                if ($fareSplitupArray['splitup_fare_name'] != 'original_base_fare' && $fareSplitupArray['splitup_fare_name'] != 'original_tax') {
                    $fareArray[$orderId][$fareSplitupArray['trip_type']]['taxBreakUP']['taxCode'][] = $fareSplitupArray['splitup_fare_name'];
                    $fareArray[$orderId][$fareSplitupArray['trip_type']]['taxBreakUP']['taxAmount'][] = $fareSplitupArray['splitup_fare_amount'];
                } else {
                    $fareArray[$orderId][$fareSplitupArray['trip_type']][$fareSplitupArray['splitup_fare_name']] = $fareSplitupArray['splitup_fare_amount'];
                }
            }
        }
        return $fareArray;
    }

    /*
     * @Description  this function is to update the fare splitup amount in airline_splitup_details after the change in amount is detected by the farecheck module
     * @return array | $returnResult
     */

    public function _updateFareBreakSplitUp() {

        $passengerFareArray = $this->_viaFareBreakUp;

        foreach ($passengerFareArray as $viafareId => $value) {
            //insert values for passenger_type based base_fare and tax 
            $insertBaseArray = $insertTaxArray = array();
            //Check for airline fare splitp details for the viafareid

            $sqlViaFare = "SELECT r_via_fare_id FROM airline_fare_splitup_details WHERE r_via_fare_id = " . $value['viaFareId'];
            $result = $this->_OcommonDBO->_getResult($sqlViaFare);
            if ($result != '' && is_array($result) && isset($result[0]['r_via_fare_id'])) {
                $resultFareBreakupDelete = $this->_OcommonDBO->_delete('airline_fare_splitup_details', 'r_via_fare_id', $value['viaFareId']);
                if ($resultFareBreakupDelete != '') {
                    $sqlquery = "INSERT INTO airline_fare_splitup_details (r_airline_fare_splitup_id,r_via_fare_id,splitup_fare_amount) VALUES ";
                    $sqlconject = '';

                    foreach ($value['tax'] as $fareSplitCode => $fareamount) {
                        //check tax code already exists if not created and return tax code id
                        $taxCodeId = $this->_OAppSettings->_checkTaxBreakUpAvailable($fareSplitCode);
                        $insertTaxArray[] = "('" . $taxCodeId . "','" . $value['viaFareId'] . "','" . $fareamount . "')";
                    }
                    $sqlconject = implode(',', $insertTaxArray);
                    $sqlquery = $sqlquery . $sqlconject . ';';
                    $returnResult = $this->_OcommonDBO->_getResult($sqlquery);
                }
            }
        }
        return $returnResult;
    }

    /*

     * function    :serviceTaxCalculation()
     * Description :To calculate service tax amount in case of fare increase
     * Parameter   :
     *      */

    public function _serviceTaxCalculation($passArray) {
        //To get service Tax value           
        //$serviceTaxValue = $this->_getTaxValues('SERVICE_TAX', $this->_AairlineCodeIdArray[$key]);
        //To get Airline code from adult passenger fare

        $serviceAirCode = $passArray[0]['airline_code'];
        foreach ($passArray as $key => $value) {

            //for saving original value
            $passArray[$key]['original_base_fare'] = $value['baseFare'];
            $passArray[$key]['original_tax'] = $value['totalTax'];
            //Get the airline splitup code from config            
            $configAirCode = $GLOBALS['custom']['AIRLINETAXTOBASEFARE'][$serviceAirCode];

            //Initialising            
            $taxamount = 0;

            //To get the aditional service amount from Airline splitup 
            foreach ($configAirCode as $aircode => $taxvalue) {
                $taxamount+=$value['tax'][$aircode];
            }
            //Adding new service amount to fare
            $passArray[$key]['baseFare'] = $value['baseFare'] + $taxamount;
            $passArray[$key]['totalTax'] = $value['totalTax'] - $taxamount;
//            //new service tax based on new basefare
//           $passArray[$key]['search_service_tax'] = round(($value['baseFare'] * $serviceTaxValue) / 100);
//           fileWrite('amountbefore='.($value['baseFare'] * $serviceTaxValue), 'aftercalc','a+');
//           fileWrite('totaltax='.$passArray[$key]['search_service_tax'], 'aftercalc','a+');
        }
        return $passArray;
    }

    /*

     * function    :serviceTaxCalculation()
     * Description :To calculate service tax amount in case of fare increase
     * Parameter   :
     *      */

    public function _JNTaxCalculation($passArray) {

        fileWrite('fare update : ', 'JN_TAX' . $this->_orderId, 'a+');
        fileWrite('input pax array : ' . print_r($passArray, 1), 'JN_TAX' . $this->_orderId, 'a+');
        $_IairlineId = $this->_fetchTableId('dm_airline', 'airline_code', array('airline_id'), $passArray[0]['airline_code']);
        foreach ($passArray as $key => $value) {

            //for saving original value
            $passArray[$key]['original_base_fare'] = $value['baseFare'];
            $passArray[$key]['original_tax'] = $value['totalTax'];

            $jnTaxArray = $this->_getTaxValues('JN_TAX', $_IairlineId, 'ARRAY');
            fileWrite('jn tax settings : ' . print_r($jnTaxArray, 1), 'JN_TAX' . $this->_orderId, 'a+');

            $_AviaTaxBreakUp = $passArray[$key]['tax'];
            $_AviaTaxBreakUp['original_base_fare'] = $passArray[$key]['original_base_fare'];

            $_IviaJnTax = 0;
            foreach ($jnTaxArray as $jnValue) {
                $_IviaJnTax += intval(((intval($_AviaTaxBreakUp[$jnValue['tax_details_name']]) * $jnValue['percentage']) / 100));
                if ($jnValue['tax_details_name'] == "original_base_fare")
                    $passArray[$key]['totalTax'] = $value['totalTax'] + $_IviaJnTax;
            }

            if ($_IviaJnTax != 0) {
                unset($passArray[$key]['tax']['JN']);
                $passArray[$key]['tax']['JN'] = $_IviaJnTax;
            }
        }
        return $passArray;
    }

    /*
     * @function    : _updateRescheduleCancellationFees()
     * @Description : To calcuate update rescheudle cancellation and reschedule fees
     * @param       : int|$orderId
     * @param       : array|$updateArray
     * @param       : int|$tripType
     * @return      : 
     *      */

    public function _updateRescheduleCancellationFees($orderId, $updateArray, $tripType = 0) {

        fileWrite(print_r($updateArray, 1), 'updaterescanarry', 'a+');

        if ($orderId != '' && is_array($updateArray)) {

            $passTypeConvArray = array('ADT' => 0, 'CNN' => 1, 'INF' => 2);

            if ($tripType == 0) {
                $where = " AND  vf.trip_type = 0 ";
            } else {
                $where = " AND (vf.trip_type = 0 OR vf.trip_type = 1) ";
            }

            $sql = "SELECT vf.trip_type, pv.passenger_via_id, pv.r_order_id, pd.passenger_type, pv.r_via_flight_id, pv.reschedule_penalty, pv.cancellation_penalty 
                       FROM passenger_via_details pv INNER JOIN passenger_details pd ON pv.r_passenger_id = pd.passenger_id
                       INNER JOIN via_flight_details vf ON vf.via_flight_id = pv.r_via_flight_id
                       WHERE pv.r_order_id = " . $orderId . " " . $where . " GROUP BY pd.passenger_type, vf.trip_type ORDER BY pv.r_via_flight_id";
            $result = $this->_OcommonDBO->_getResult($sql);

            foreach ($result as $res) {

                $passengerType = $passTypeConvArray[$res['passenger_type']];
                $updatePassViaArray = $updateArray[$res['trip_type']];
                $passengerViaId = $res['passenger_via_id'];

                if (isset($updatePassViaArray[$passengerType])) {
                    $affectedRows = $this->_OcommonDBO->_update('passenger_via_details', $updatePassViaArray[$passengerType], 'passenger_via_id', $passengerViaId);
                }
            }
        }
        return;
    }

    /* function    :penaltyChargesUpdation()
     * Description :To get passenger cancellation charges and reschedule charges from dm_penaltycharges database
     * Parameter   :
     *      */

    public function _penaltyChargesUpdation($airlineId, $fareType) {

        $sql = "SELECT cancellation_amount, passenger_type, reschedule_amount
                    FROM dm_penaltycharges
                    WHERE r_airline_id =" . $airlineId . "
                    AND faretype = '" . $fareType . "'";
        $result = $this->_OcommonDBO->_getResult($sql);
        return $result;
    }

    /* function    :getPackagePaxViaDetails()
     * Description :To get passenger via details information from passenger_via_details database
     * Parameter   : $packageId | package id for the booking
     *      */

    public function _getPackagePaxViaDetails($packageId) {
        $sqlPaxViaDetails = "SELECT fbd.r_order_id,pvd.r_passenger_id,pvd.r_via_flight_id,reschedule_penalty,cancellation_penalty 
                                FROM passenger_via_details pvd,fact_booking_details fbd,passenger_details pd
                                WHERE pvd.r_order_id = fbd.r_order_id 
                                AND pd.passenger_id = pvd.r_passenger_id
                                AND pd.passenger_type != 'INF'
                                AND fbd.r_package_id = " . $packageId . " 
                                ORDER BY fbd.r_order_id,pvd.r_passenger_id,pvd.r_via_flight_id";

        $resultPaxViaDetails = $this->db->_getResult($sqlPaxViaDetails);

        if ($resultPaxViaDetails != '') {
            $paxViaArray = array();
            foreach ($resultPaxViaDetails as $paxViaResultArray) {
                $orderId = $paxViaResultArray['r_order_id'];
                $paxViaArray[$orderId][$paxViaResultArray['r_passenger_id']][$paxViaResultArray['r_via_flight_id']] = $paxViaResultArray;
            }
        }
        return $paxViaArray;
    }

    /**
     * Get's GST total amount calculated from Fees
     * @param array $calculateArgs Calculating values
     * @return type
     */
    public function _getGSTTotalAmount($feeArray, $numPass, $tripType, $taxBreakup, $viaBaseFare) {
        if ($tripType == '') {
            $tripType = 0;
        }
        fileWrite("ORDERTSTARTS" . print_r($this->_orderId, 1), 'inpGST', 'a+');
        fileWrite(print_r($numPass, 1), 'inpGST', 'a+');
        fileWrite(print_r($tripType, 1), 'inpGST', 'a+');
        fileWrite(print_r($taxBreakup, 1), 'inpGST', 'a+');
        $tripType +=1;
        //removed function and added in class.applicaitonSettings for usage in all the travel modes
        $serviceTaxValue = $this->_OAppSettings->_getTaxValues('SERVICE_TAX', 0, 'ARRAY', 0)[0];
        //Gst calculation starts
        if ($serviceTaxValue['calculation_from'] != 'BASE_FARE') {
            fileWrite("INSIDE FIF", 'inpGST', 'a+');
            //Agency calculation
            $this->_Icommission = $this->_calculateCommission($taxBreakup, $this->_IviaAirlineId, $this->_SfareTypeCode, $this->_SclassCode);
            fileWrite($this->_Icommission, 'inpGST', 'a+');

            $this->_serviceTaxComm = round(($this->_Icommission * $serviceTaxValue['percentage']) / 100, 3);
            fileWrite($this->_serviceTaxComm, 'inpGST', 'a+');
            //Total fee

            $totalFee = $feeArray['transaction_fee'] + $feeArray['system_usage_fee'] - $feeArray['discount_fee'];
            fileWrite($totalFee, 'inpGST', 'a+');

            $this->_serviceTaxFee = round((($totalFee / ($numPass * $tripType)) * $serviceTaxValue['percentage']) / 100, 3);

            fileWrite($this->_serviceTaxFee, 'inpGST', 'a+');

            $totalServiceTax = round($this->_serviceTaxComm + $this->_serviceTaxFee);
        } else {
            $taxableAmt = $viaBaseFare;
            $totalServiceTax = round(($taxableAmt * $serviceTaxValue['percentage']) / 100);
        }
        fileWrite($taxableAmt, 'inpGST', 'a+');
        fileWrite($totalServiceTax, 'inpGST', 'a+');
        fileWrite("ORDERENDS", 'inpGST', 'a+');
        return $totalServiceTax;
    }

    /**
     * Calculates commission from the via flight details in flight search
     * @param array $_AviaTaxBreakUp Via flight tax breakup
     * @param int $_IviaAirlineId Via airline id
     * @param string $fareTypeCode Fare type code
     * @param string $classCode Class code
     * @param int $travelMode Travel mode
     * @return int
     * @author Vijaykeerthi R
     */
    public function _calculateCommission($_AviaTaxBreakUp, $_IviaAirlineId, $fareTypeCode, $classCode = '', $travelMode = 1) {
        fileWrite($classCode, 'Commission', 'a+');
        $sql = "SELECT 
                    td.tax_details_name,
                    acm.percentage, 
                    acm.priority 
                FROM 
                    agency_commission_mapping acm INNER JOIN tax_details td ON acm.r_tax_details_id = td.tax_details_id 
                WHERE r_agency_id = '" . $_SESSION['agencyId'] . "'
                    AND r_travel_mode_id='$travelMode' 
                    AND r_airline_id= '$_IviaAirlineId'
                    AND (DATE(NOW()) BETWEEN start_date AND end_date) ";

        //$sqlA = " AND r_fare_type_id = (SELECT fare_type_id FROM dm_fare_type WHERE fare_type_code ='$fareTypeCode' AND travel_type=$travelMode)";
        $sqlA = " AND r_travel_class_id = '$classCode' ";

        $orderBy = " ORDER BY priority ASC";

        $sql1 = $sql . $sqlA . $orderBy;
fileWrite('query'.$sql1, 'Commission', 'a+');
        $result1 = $this->db->_getResult($sql1);

        $finalArray = $result1;
fileWrite('finalArray'.print_r($finalArray,1),'Commission', 'a+');
        //For fare type with no class code
        if ($result1 == FALSE) {
            fileWrite('insideIF', 'Commission','a+');
            $sql2 = $sql . " AND r_travel_class_id = 0  " . $orderBy;

            $result2 = $this->db->_getResult($sql2);

            $finalArray = $result2;
        }

        $commission = 0;
        fileWrite('result1'.print_r($result1, 1) .'result2'. print_r($result2, 1), 'Commission', 'a+');
        foreach ($finalArray as $key => $value) {
            if (isset($_AviaTaxBreakUp[$value['tax_details_name']])) {
                $commission += ($_AviaTaxBreakUp[$value['tax_details_name']] * $value['percentage']) / 100;
            }
        }
        fileWrite($commission, 'Commission', 'a+');
        return $commission;
    }

    public function _getFareTypeID($fareTypeId) {

        if ($fareTypeId != '') {

            $sql = "SELECT 
                        fare_type_code
                    FROM 
                        dm_fare_type 
                    WHERE 
                       fare_type_id='" . $fareTypeId . "'";
            $result = $this->_OcommonDBO->_getResult($sql);

            return $result;
        }
    }

    /**
     * Get's via fare id from via fare details table
     * @param int|$viaFlightId
     * @return array|$result
     */
    public function _getViaFareIdByViaFlightId($viaFlightId) {

        $response = false;

        if ($viaFlightId != '') {
            $sql = "SELECT via_fare_id FROM via_fare_details WHERE r_via_flight_id = " . $viaFlightId . "";
            $result = $this->_OcommonDBO->_getResult($sql);

            $response = $result;
        }

        return $response;
    }
    
    public function _getViaDetails($orderId) {
        $sqlViaDetails = "SELECT 
                            vfd.flight_no,
                            vfd.r_fare_type_id,
                            vfd.trip_type as tripType, 
                            vfd.r_airline_id
                         FROM                          
                            via_flight_details vfd,
                            fact_air_itinerary fai,
                            air_booking_details abd
                        WHERE                        
                            abd.r_order_id =" . $orderId . "  
                            AND fai.r_air_booking_details_id = abd.air_booking_details_id
                            AND fai.r_via_flight_id = vfd.via_flight_id 
                            AND fai.itinerary_status = " . SELECTED_ITINERARY . "
                            ORDER BY vfd.trip_type,vfd.via_flight_id";
        fileWrite("sqlViaFlight" . $sqlViaDetails, "FARECHECK", "a+");
        $resultViaDetails = $this->_OcommonDBO->_getResult($sqlViaDetails);
        if ($resultViaDetails != '') {
            if (is_array($resultViaDetails) && count($resultViaDetails) > 0) {
                foreach ($resultViaDetails as $value) {
                    /*                     * * end of airport details ** */
                    $airlineInfo = $this->_OairlineDetails->_getAirlineDetails($value['r_airline_id']);
                    $value['airlineCode'] = $airlineInfo[0]['airline_code'];
                    $fareInfo = $this->_OfareDetails->_getFareTypeByFareTypeId($value['r_fare_type_id']);
                    $value['viaCabinFareType'] = $fareInfo[0]['fare_type_code'];
                    $value['trip_type'] = ($value['trip_type'] = 0) ? 'O' : 'R';
                    $itineraryViaFlightArray[] = $value;
                }
            }fileWrite("sqlViaFlight" . print_r($itineraryViaFlightArray, true), "FARECHECK", "a+");
            return $itineraryViaFlightArray;
        }
    }
     public function _getViaItineraryDetails($orderId) {
        $sqlViaFlight = "SELECT 
                            vfd.via_flight_id,
                            vfd.r_fare_type_id,
                            fd.fare_basis_code,
                            vfd.trip_type as tripType,
                            vfd.r_origin_airport_id,
                            vfd.r_destination_airport_id, 
                            vfd.r_airline_id,
                            vfd.flight_no as flightNumber,
                            vfd.departure_date as departureDate,
                            vfd.arrival_date as arrivalDate,
                            vfd.time_departure as departureTime,
                            vfd.time_arrival as arrivalTime,
                            vfd.booking_class as cabinclass,
                            GROUP_CONCAT(fd.fare_basis_code) as fare_basis_code,
                            GROUP_CONCAT(fd.passenger_type) as passenger_type,
                            SUM(fd.base_fare) as base_fare,
                            SUM(fd.tax) as tax,
                            fd.service_provider_id,vfd.operating_airline_code, 
                         FROM                          
                            via_flight_details vfd,
                            fact_air_itinerary fai,
                            air_booking_details abd,
                            via_fare_details fd
                        WHERE                        
                            abd.r_order_id =" . $orderId . "  
                            AND fai.r_air_booking_details_id = abd.air_booking_details_id
                            AND fai.r_via_flight_id = vfd.via_flight_id 
                            AND fai.itinerary_status = " . SELECTED_ITINERARY . "
                            AND fd.r_via_flight_id = vfd.via_flight_id
                            AND fai.r_via_fare_id = fd.via_fare_id
                            GROUP BY fd.r_via_flight_id ORDER BY vfd.trip_type,vfd.via_flight_id,fd.passenger_type";
        fileWrite("sqlViaFlight" . $sqlViaFlight, "FARECHECK", "a+");
        $resultViaFlight = $this->_OcommonDBO->_getResult($sqlViaFlight);
        if ($resultViaFlight != '') {
            if (is_array($resultViaFlight) && count($resultViaFlight) > 0) {
                foreach ($resultViaFlight as $value) {
                    /*                     * * to get the airport code and airport name * */
                    if ($value['r_origin_airport_id'] != '') {
                        $airportInfo = $this->_OairportDetails->_getAirportName($value['r_origin_airport_id']);
                        $value['origin'] = $airportInfo[0]['airport_code'];
                        unset($value['r_origin_airport_id']);
                    }
                    if ($value['r_destination_airport_id'] != '') {
                        $airportInfo = $this->_OairportDetails->_getAirportName($value['r_destination_airport_id']);
                        $value['destination'] = $airportInfo[0]['airport_code'];
                        unset($value['r_destination_airport_id']);
                    }
                    /*                     * * end of airport details ** */
                    $airlineInfo = $this->_OairlineDetails->_getAirlineDetails($value['r_airline_id']);
                    $value['airlineCode'] = $airlineInfo[0]['airline_code'];
                    unset($value['r_airline_id']);
                    $fareInfo = $this->_OfareDetails->_getFareTypeByFareTypeId($value['r_fare_type_id']);
                    $value['viaCabinFareType'] = $fareInfo[0]['fare_type_code'];
                    unset($value['r_fare_type_id']);
                    $value['passenger_type'] = explode(",", $value['passenger_type']);
                    $value['fare_basis_code'] = explode(",", $value['fare_basis_code']);
                    $value['tripTypeCaption'] = $value['tripType'];
                    $value['tripType'] = ($value['tripType'] == 0) ? 'onward' : 'return';
                    $itineraryViaFlightArray[$value['tripTypeCaption']][$value['airlineCode']][] = $value;
                }
            }fileWrite("sqlViaFlight" . print_r($itineraryViaFlightArray, true), "FARECHECK", "a+");
            return $itineraryViaFlightArray;
        }
    }

      /**
     * used to get the details of gst split up for orderid
     * @param type $orderId
     * @param type $tripType
     * return array
     */
    public function _getOrderGstSplitUpAmount($orderId,$tripType,$gstType=0){
        $sql = "SELECT gsom.gst_tax_splitup_amount, gsm.gst_tax_splitup_name
                FROM gst_splitup_order_mapping gsom
                INNER JOIN gst_order_mapping gom ON gsom.gst_order_mapping_id = gom.gst_order_mapping_id
                INNER JOIN gst_tax_splitup_master gsm ON gsm.gst_tax_splitup_id = gsom.gst_tax_splitup_id
                WHERE gom.order_id = $orderId AND gom.trip_type = $tripType AND gsom.gst_type=$gstType";
        
        return $this->_OcommonDBO->_getResult($sql);
    }

     /**
     * @Description  Function used to get the gst splitup info
     * @param int|$orderId,$tripType
     * @return array|$gstSplitupInfo
     * @date|10.11.2017
     * @author|Karthika.M
     */  
    public function _getGSTsplitupByType($orderId,$tripType,$gstType){
        $gstSplitup = $this->_getGSTsplitup($orderId,$tripType,$gstType);
        if(count($gstSplitup) > 0){
            foreach($gstSplitup as $key => $value){                
                $gstSplitupInfo[$value['gst_tax_splitup_name']] = $value['gst_tax_splitup_amount'];
            }
            
            return $gstSplitupInfo;
        }       
    }

    public function _updateCabinClass($tripType,$cabinclass,$orderId){
        $travelClassId = $this->_OcommonDBO->_select('dm_travel_class','travel_class_id','class_code',$cabinclass)[0]['travel_class_id'];
        $sql = "UPDATE
                    air_request_details ard 
                INNER JOIN fact_booking_details fbd ON ard.air_request_id = fbd.r_request_id 
                SET ";
        if($tripType == 0){
            $sql.=" ard.r_travel_class_id = " .$travelClassId;
        }
        else{
            $sql.=" ard.r_travel_class_id_return = " .$travelClassId;   
        }

            $sql.=" WHERE fbd.r_order_id = " .$orderId;

        $this->_OcommonDBO->_getResult($sql);  

    }

}

?>
