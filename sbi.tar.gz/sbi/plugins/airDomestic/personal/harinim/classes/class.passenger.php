<?php
/* * **************************************************************************
 * @File             : class.passenger.php
 * @Description      : This file is used to insert,update,delete and get dm_passenger ,passenger_other_details
 * @dimensionTables  : dm_passenger ,passenger_other_details
 * @Author           : Lakshmi.S
 * @Created Date     : 01/07/2016
 * @Modified Date     : 
 * ****************************************************************************/
 namespace personal;

pluginFileRequireByTravelMode('airDomestic/corporate/harinim/classes/class.passenger.php', true);
pluginFileRequire('default/', 'classes/class.commonDBO.php');
fileRequire('plugins/airDomestic/personal/harinim/classes/class.applicationSettings.php');
class passenger extends \passenger{
    
   private $_OcommonDBO;
    
   public function __construct() {
       
       $this->_OcommonDBO=new \commonDBO();
       $this->_OapplicationSettings = new applicationSettings();
       
       parent::__construct();
   }
   
   /**
     * @Description :This function is used to insert the dm_passenger 
     * @param :array   | $passengerDetails - holds array of passenger details
     * @return integer |$resultPassengerId - inserted passenger id
     */
   public function _insertPassengerMainDetails($passengerDetails=array(),$passengerPassportDetails=array()){       
        $tableName        = 'passenger_details';
        $resultPassengerId  = $this->_OcommonDBO->_insert($tableName, $passengerDetails);
        if(ERROR_DEBUG_REPORT)
        {
            if(!$resultPassengerId > 0)
            {
                $this->_OapplicationSettings->pushInsertDetails($passengerDetails,$tableName,$resultPassengerId,$this->_OcommonDBO->_AbugTracking);
            }
            else 
            {
                $this->_OapplicationSettings->pushInsertDetails($passengerDetails,$tableName,$resultPassengerId);
            }
        }
        return $resultPassengerId ;
   }
   
    /**
     * @Description :This function is used to get the passenger details from dm_passenger
     * @param :array   | $fieldsArray - holds array of fields get from dm_passenger
     * @param :integer   | $passengerId - holds the passenger id
     * @return array |$resultPassenger - holds the array of passenger details
     */
   public function _getPassengerMainDetails($passengerId=0,$fieldsArray=''){
        $tableName = 'dm_passenger';
        $wherekey ='passenger_id';
        $wherevalue=$passengerId;
        
        if(!empty($fieldsArray) && count($fieldsArray)>0 ){
            $resultPassenger  = $this->_OcommonDBO->_select($tableName, $fieldsArray, $wherekey, $wherevalue);
        }
        return $resultPassenger ;
   }
   
   /**
     * @Description :This function is used to update the passenger details 
     * @param :array   | $passengerDetails - holds the passenger details
     * @param :integer   | $passengerId - holds the passenger id
     * @return boolean |$result - return true or false
     */
   public function _updatePassengerMainDetails($passengerDetails,$passengerId){
        $result = $this->_OcommonDBO->_update('passenger_details',$passengerDetails,'passenger_id',$passengerId);
        if(ERROR_DEBUG_REPORT)
        {
            if(!$result > 0)
            {
                $this->_OapplicationSettings->pushInsertDetails($passengerDetails,'passenger_details',$passengerId,$this->_OcommonDBO->_AbugTracking);
            }
            else 
            {
                $this->_OapplicationSettings->pushInsertDetails($passengerDetails,'passenger_details',$passengerId);
            }
        }
        return $result;
   }
   
   /**
     * @Description :This function is used to delete the passenger details 
     * @param :integer   | $passengerId - holds the passenger id
     * @return boolean |$result - return true or false
     */
   public function _deletePassengerMainDetails($passengerId){
        $result = $this->_OcommonDBO->_delete('dm_passenger','passenger_id', $passengerId);
            
        return $result;
   }
   
   /**
     * @Description :This function is used to insert the passenger other details 
     * @param :array   | $passengerOtherDetails - holds array of passenger_other_details
     * @return integer |$resultPassengerId - inserted passenger id
     */
   public function _insertPassengerOtherDetails($passengerOtherDetails){
        $tableName        = 'passenger_other_details';
        $resultPassengerId  = $this->_OcommonDBO->_insert($tableName, $passengerOtherDetails);
       
        return $resultPassengerId ;
   }
   
    /**
     * @Description :This function is used to get the passenger other details from passenger_other_details
     * @param :array   | $fieldsArray - holds array of fields get from passenger_other_details
     * @param :integer   | $passengerId - holds the passenger id
     * @return array |$resultPassenger - holds the array of passenger details
     */
   public function _getPassengerOtherDetails($passengerId=0,$fieldsArray=''){
        $tableName = 'passenger_other_details';
        $wherekey ='r_passenger_id';
        $wherevalue=$passengerId;
        
        if(!empty($fieldsArray) && count($fieldsArray)>0 ){
            $resultPassenger  = $this->_OcommonDBO->_select($tableName, $fieldsArray, $wherekey, $wherevalue);
        }
        return $resultPassenger ;
   }
   
   /**
     * @Description :This function is used to update the passenger_other_details
     * @param :array   | $passengerDetails - holds the passenger details
     * @param :integer   | $passengerId - holds the passenger id
     * @return boolean |$result - return true or false
     */
   public function _updatePassengerOtherDetails($passengerDetails,$passengerId){
        $result = $this->_OcommonDBO->_update('passenger_other_details',$passengerDetails,'r_passenger_id',$passengerId);
            
        return $result;
   }
   
   /**
     * @Description :This function is used to delete the passenger_other_details
     * @param :integer   | $passengerId - holds the passenger id
     * @return boolean |$result - return true or false
     */
   public function _deletePassengerOtherDetails($passengerId){
        $result = $this->_OcommonDBO->_delete('passenger_other_details','r_passenger_id', $passengerId);
            
        return $result;
   }/**
     * @Description :This function is used to insert the passenger and infant details in passenger_infant_mapping table
     * @param :array   | $requestDetails - holds the passenger-infant details
     * @return integer |$passengerInfantMappingId - inserted passenger mapping id
     */
   
   public function _insertPassengerInfant($requestDetails) {
       $tableName        = 'passenger_infant_mapping';
       $passengerInfantMappingId  = $this->_OcommonDBO->_insert($tableName, $requestDetails);
       if(ERROR_DEBUG_REPORT)
       {
        if(!$passengerInfantMappingId > 0)
         {
             $this->_OapplicationSettings->pushInsertDetails($requestDetails,$tableName,$passengerInfantMappingId,$this->_OcommonDBO->_AbugTracking);
         }
         else 
         {
             $this->_OapplicationSettings->pushInsertDetails($requestDetails,$tableName,$passengerInfantMappingId);
         }
       }
       return  $passengerInfantMappingId ;
   
   }
   
   /**
     * @Description :This function is used get the passenger_name
     * @param :integer   | $passengerId - holds the passenger id
     * @return boolean |$result - return true or false
     */
   public function _getPassengerName($order_id){
       $sql = "SELECT 
                     title,
                     first_name,
                     last_name
                   FROM passenger_details 
                   WHERE r_order_id=" . $order_id; 
       
       $result = $this->_OcommonDBO->_getResult($sql);
            
        return $result;
   }
   

/*
 * @FunctionName    :   _getAllPassengerDetailsByOrderId()
 * @Description     :   This function is used to get all the passenger details for the particular order
 * @Author          :   Jagan.M
 * @Created Date    :   20/08/2016
 * @Modified Date   : 
 * @Return Type     :   Array
 */
   public function _getAllPassengerDetailsByOrderId($order_id) {
        $passengerDetailQuery='SELECT  '
                                    . 'concat(pd.title,".",pd.first_name," ",pd.last_name) name,'
                                    . 'pod.age,'
                                    . 'pd.mobile_no,'
                                    . 'pod.meal_type,'
                                    . 'pd.email_id,'
                                    . 'pod.seat_preference,'
                                    . 'pd.passenger_type, '
                                    . 'pd.employee_code ,'
                                    . 'pd.passenger_id, pd.r_employee_id, pd.r_order_id '
                                . 'FROM '
                                    . 'passenger_details pd '
                                . 'LEFT JOIN '
                                    . 'passenger_other_details pod '
                                . 'ON '
                                    . 'pd.passenger_id=pod.r_passenger_id '
                                . 'WHERE '
                                   . 'pd.r_order_id="'.$order_id.'"';
        $result = $this->_OcommonDBO->_getResult($passengerDetailQuery);
        return $result;
    }
/**
     * @Description :This function is used to get the band details from band details
     * @param :array   | $fieldsArray - holds array of fields get from band_details
     * @param :integer   | $bandId - holds the band id
     * @return array |$resultBand - holds the array of band details
     */
   public function _getBandDetails($bandId=0,$fieldsArray=''){
        $tableName = 'band_details';
        $wherekey ='band_id';
        $wherevalue=$bandId;

        if(!empty($fieldsArray) && count($fieldsArray)>0 ){
            $resultBand  = $this->_OcommonDBO->_select($tableName, $fieldsArray, $wherekey, $wherevalue);
        }
        return $resultBand ;
   }
   
   /*
     * @Description  this function get the passenger details of the particular AYPRC 
     * @param int|$orderId
     * @return 
     */
	public function _getPassengerDetails($orderId)
    {

		$sqlPax = "SELECT
						pd.passenger_id,
						pd.r_employee_id,
                                                pd.title,
                                                pd.first_name,
                                                pd.last_name,
						concat(pd.title,'. ',pd.first_name,' ',pd.last_name) as paxName,	
						pd.passenger_type,
						pd.employee_code,
						pd.mobile_no,
						pd.r_order_id,
						pd.email_id
				FROM 
					   passenger_details pd
				WHERE
					   r_order_id = ".$orderId."
				ORDER BY pd.passenger_type ";  
                $resultPax = $this->_OcommonDBO->_getResult($sqlPax);
                if($resultPax != '')
                {
                        return $resultPax;
                }	
	}
        
        /*
     * @Description  this function get the passenger details of the particular AYPRC 
     * @param int|$orderId
     * @return 
     */
	public function _getPackagePassengerDetails($packageId,$travelModeId=0)
    {
		$sqlPax = "SELECT
                                        pd.passenger_id,
                                        pd.r_employee_id,
                                        pd.title,
                                        pd.first_name,
                                        pd.last_name,
                                        concat(pd.title,' ',pd.first_name,' ',pd.last_name) as paxName,	
                                        pd.passenger_type,
                                        pd.employee_code,
                                        pd.mobile_no,
                                        pd.r_order_id,
                                        pd.email_id,
					pd.DOB,
                                        fbd.travel_mode
				FROM 
                                        passenger_details pd,
                                        fact_booking_details fbd
				WHERE
                                        pd.r_order_id = fbd.r_order_id 
                                        AND fbd.r_package_id=".$packageId;
                if($travelModeId!=0){
                    $sqlPax.=" AND fbd.travel_mode=".$travelModeId;
                }
                $sqlPax.=" ORDER BY fbd.r_order_id,pd.passenger_id ";
                $resultPax = $this->_OcommonDBO->_getResult($sqlPax);
                if($resultPax != '')
                {
                        $paxDetails=array();
                        foreach($resultPax as $orderPax){
                                $paxDetails[$orderPax['r_order_id']][]=$orderPax;
                        }
                        return $paxDetails;
                }	
	}
        
	/**
     * @Description :This function is used to get respoansible passenger id for the infant
     * @param :array   | $fieldsArray - holds array of fields get from passenger_infant_mapping
     * @param :integer   | $paxId - holds the passenger id
     * @return array |$resultInfant - holds the array of passenger Id of infant
     */
    public function _getPassengerInfantMapping($paxId=0,$fieldsArray='',$wherekey='r_passenger_id'){
        $tableName = 'passenger_infant_mapping';
        $wherevalue=$paxId;
        $fieldsArray = ' * ';
        if(!empty($fieldsArray) && count($fieldsArray)>0 ){
             $result  = $this->_OcommonDBO->_select($tableName, $fieldsArray, $wherekey, $wherevalue);
        }
        return $result ;
   }
  
    public function _updatePassengerSync($syncPassengerDetails){
        foreach($syncPassengerDetails as $key=>$value){
            $passengerDetails['sync_passenger_id']=$value['backEndPassengerId'];
            if(is_array($value['frontEndPassengerId'])){ 
                $passengerId=$value['frontEndPassengerId'][0];
            }
            else{
                $passengerId=$value['frontEndPassengerId'];
            }
             
            $result=$this->_updatePassengerMainDetails($passengerDetails,$passengerId);            
        }
        return true;
    }
    
    	/*
     * @Description  this function get the passenger details of the particular AYPRC 
     * @param int|$orderId
     * @return 
     */
	public function _getCorporatePassengerDetails($orderId)
    	{

		$sqlPax = "SELECT               pd.passenger_id,
                                                pd.passenger_id as passengerId,
		                                pd.title,
		                                pd.first_name as firstname,
		                                pd.last_name as lastname,
						pd.passenger_type as passengertype,
						pd.mobile_no as phonenumber,
						pd.email_id as paxemail,
                                                pd.DOB as dob,
                                                IF(pd.title='Mr' or pd.title='Mstr' or pd.title='Dr','Male','Female') as gender
				FROM 
					   passenger_details pd
				WHERE
					   r_order_id = ".$orderId."
				ORDER BY pd.passenger_type ";  
		$resultPax = $this->_OcommonDBO->_getResult($sqlPax);
		if($resultPax != '')
		{
		        return $resultPax;
		}	
	}
        //FOR THE INSERTION OF PASSPORT DETAILS IN PERSONAL BOOKING
    public function _insertPassengerPassportDetails($passportDetails , $passengerId, $familyDetailsId,$employeeId){
        $passDetails['r_passenger_id'] = $passengerId;
        $passDetails['r_employee_id'] = $employeeId;
        $passDetails['r_employee_family_details_id'] = $familyDetailsId;
        $sql = "SELECT 
                    r_employee_id,r_employee_family_details_id,r_passport_id
                FROM   
                    employee_passport_mapping
                WHERE  
                    r_employee_id =".$employeeId."
                     AND r_employee_family_details_id = ".$familyDetailsId;

        $result = $this->_OcommonDBO->_getResult($sql);        
        if(!empty($result)){
            // update that details
            $this->_OcommonDBO->_update('dm_passport', $passportDetails,'passport_id',$result[0]['r_passport_id']);
            $updateSql = "UPDATE employee_passport_mapping SET r_passenger_id = ".$passengerId." WHERE r_employee_id = ".$employeeId." AND r_employee_family_details_id = ".$familyDetailsId;
            $this->_OcommonDBO->_getResult($updateSql);
        } 
        else{
            $passportId = $this->_OcommonDBO->_insert('dm_passport', $passportDetails);
            if($passportId > 0){
               $insertValue = [];
               $insertValue['r_passport_id'] = $passportId;
               $insertValue['r_employee_id'] = $employeeId;
               $insertValue['r_employee_family_details_id'] = $familyDetailsId;
               $insertValue['r_passenger_id'] = $passengerId;
               return $this->_OcommonDBO->_insert('employee_passport_mapping', $insertValue);
            }
        }
            
    }

    public function _insertFrequentFlyerDetails($freqentFlyerDetails){
        $sql = "SELECT 
                    r_employee_id,r_employee_family_details_id
                FROM   
                    frequent_flyer_details
                WHERE  
                    r_employee_id =".$freqentFlyerDetails['r_employee_id']."
                     AND r_employee_family_details_id = ".$freqentFlyerDetails['r_employee_family_details_id']." AND r_airline_id = ".$freqentFlyerDetails['r_airline_id'];

        $result = $this->_OcommonDBO->_getResult($sql);
        if(!empty($result)){
                $updateSql = "UPDATE frequent_flyer_details SET frequent_flyer_no = '".$freqentFlyerDetails['frequent_flyer_no']."' WHERE r_employee_id = ".$freqentFlyerDetails['r_employee_id']." AND r_employee_family_details_id = ".$freqentFlyerDetails['r_employee_family_details_id']." AND r_airline_id = ".$freqentFlyerDetails['r_airline_id'];
                $this->_OcommonDBO->_getResult($updateSql); 
        }
        else{
            $this->_OcommonDBO->_insert('frequent_flyer_details', $freqentFlyerDetails);
        }
    }
}
?>
