<?php
/* * **********************************************************************
 * @Class Name	: applicationSettings
 * @Created on	: 2016-06-07
 * @Created By	: Thirumal
 * @Description	: This class holds the application settings plane related methods
 * ************************************************************************ */
  namespace personal;

pluginFileRequireByTravelMode('airDomestic/corporate/harinim/classes/class.applicationSettings.php', true);
fileRequire("lib/common/commonMethods.php");
class applicationSettings extends \applicationSettings{
                                   
    //constructor
    function __construct() {
        $this->_ODBC = new \commonDBO();

    }
    
    /**
    * @description function to get the cost center code details of a corporate
    * @param $corpId corporate's unique id
    * @return array
    */
    public function _getCostCenterCode($corpId=0, $category="", $costCenterCode="" ){
        $sql="SELECT 
                    cv.category_value,cv.category_value_id
                FROM 
                    fact_category fc 
                    inner join category_value cv on cv.category_value_id = fc.r_category_value_id 
                    inner join dm_corporate dm on dm.corporate_id=fc.r_corporate_id
                    inner join dm_category dc on dc.category_id = fc.r_category_id";
        $append = " WHERE ";
        
        if($corpId!=0){
            $sql.= $append.' r_corporate_id='.$corpId;
            $append = " and ";
        }
        
        if( isset($category) ) {
            $sql.= $append." dc.category_name = '".$category."'";
            $append = " and ";
        }
        
        if(isset($costCenterCode)) {
            $sql .= $append." cv.category_value = '".$costCenterCode."'";
        }

        return $this->_ODBC->_getResult($sql);
    }
    /**
     * @description function to get the seat preferences.
     * @return type array
     */
    public function _getSeatPreferences(){
        
        return explode(',', EMPLOYEE_PREFERENCE);
        
    }
    /**
     * @description method to get the airline types
     * @param type $airType L - lowcost carriers, T - international airlines
     * @param type $fieldArray - array holds the field names
     * @return type array
     */
    public function _getAirlineDetails($airType='',$fieldArray){
        
        $airLineTypes='';
        if($airType!=''){
            $airLineTypes=$this->_ODBC->_select('dm_airline',$fieldArray,'airline_type',$airType);
        }
        
        return $airLineTypes;
    }
    /**
     * @description function to all meal code details
     * @return type array
     */
    public function _getMealCodeDetails(){
        
       return $this->_ODBC->_select('dm_meal_code_details','*');
        
    }
    /**
     * @description function to get all the user types
     * @return type array
     */
    public function _getUserTypes(){
        
        $sql="SELECT * from dm_user_type where user_type !='PA'";
                    
        return $this->_ODBC->_getResult($sql);
        
    }

    /**
     * @description get country values as array
     * @return type array
     */
    public function _getCountryDetails() {
        
        $fieldArray = array('country_id', 'country_name');
        $returnValue = $this->_ODBC->_select('dm_country', $fieldArray,'status','Y');
        
        return $returnValue;
    }
    /**
     * @description function to get all the travel mode 
     * @return type array
     */
    public function _getTravelMode($fieldsArray, $whereKey='', $whereValue=''){
        if(empty($fieldsArray)) {
            $fieldsArray='*';
        }
       return $this->_ODBC->_select('dm_travel_mode', $fieldsArray,$whereKey,$whereValue);
        
    }
    
     /**
     * @description check tax code is already available in dm_airline_fare_splitup table
     * @param string|$taxCode
     * @param int|$travelModeId| default =1 (dm_travel_mode.dm_travel_mode_id value = doemstic air)
     * @return type array
     */
    public function _checkTaxBreakUpAvailable($taxCode = '', $travelModeId = 1)
    {
        $returnValue = false;
        
        if(isset($taxCode) && !empty($taxCode))
        {
            $sql    = "SELECT airline_fare_splitup_id FROM dm_airline_fare_splitup
                       WHERE splitup_fare_name = '".$taxCode."' AND r_dm_travel_mode_id = '".$travelModeId."'";
            $result = $this->_ODBC->_getResult($sql);
            
            if(isset($result[0]['airline_fare_splitup_id']) && !empty($result[0]['airline_fare_splitup_id'])) {
                //value already available in the table
                $returnValue = $result[0]['airline_fare_splitup_id'];
            } 
            else 
            {
                $returnValue = $this->_insertTaxFareBrakup($taxCode, $travelModeId);
            }
        }
        
        return $returnValue;
    }
    
     /**
     * @description add tax fare brakup code into dm_airline_fare_splitup table
     * @param string|$taxCode
     * @param int|$travelModeId| default =1 (dm_travel_mode.dm_travel_mode_id value = doemstic air)
     * @return int|$insertedId
     */
    public function _insertTaxFareBrakup($taxCode, $travelModeId)
    {
        $insertedId = 0;
        
        if(isset($taxCode) && !empty($taxCode))
        {
            $insertArray['splitup_fare_name']   = $taxCode;
            $insertArray['r_dm_travel_mode_id'] = $travelModeId;
            
            $insertedId = $this->_ODBC->_insert('dm_airline_fare_splitup', $insertArray);
            
            if($insertedId == 0)
            {
                fileWrite('Fare breakup Insert Error: tablename: dm_airline_fare_splitup - insertarray'. print_r($insertArray,1), 'applicationError');
            }
        }
        
        return $insertedId;
    }
    
     /**
     * @description insert tax fare breakup amount into airline_fare_splitup_details table
     * @param int|$splitUpId
     * @param int|$viaFareId
     * @param string|$splitUpAmount
     * @return int|$insertedId
     */
    public function _insertTaxFareBreakupAmount($splitUpId, $viaFareId, $splitUpAmount)
    {
        if($splitUpId > 0 && $viaFareId > 0 && $splitUpAmount !='')
        {
            $insertArray = array();
            
            $insertArray['r_airline_fare_splitup_id']   = $splitUpId;
            $insertArray['r_via_fare_id']               = $viaFareId;
            $insertArray['splitup_fare_amount']         = $splitUpAmount;
            
            $insertedId = $this->_ODBC->_insert('airline_fare_splitup_details', $insertArray);
            
            return $insertedId;
        }
    }
    
     /**
     * @description get agent fee details based on agent fee name passed
     * @param int|$corporateId
     * @param string|$agentFeeName
     * @param int|$travelModeId
     * @param int|$travelClassId
     * @return mixed|$returnValue
     */
    public function _getAgentFeeDetails($corporateId, $agentFeeName, $travelModeId = 1, $travelClassId = 1, $calcBasedOn = '' , $feeType = '')
    {
        $returnValue = false;
        
        $sql    = "select fee_value, calc_based_on, fee_type from dm_agent_fee da 
                   INNER JOIN agent_fee_mapping afm ON da.agent_fee_id = afm.r_agent_fee_id
                   WHERE afm.r_corporate_id = ".$corporateId." AND (afm.r_travel_class_id = ".$travelClassId." OR afm.r_travel_class_id = 0 )
                   AND afm.r_travel_mode_id = ".$travelModeId." AND da.agent_fee_name = '".$agentFeeName."'";
        
        if($calcBasedOn !='')
        {
            $sql .= " AND afm.calc_based_on = '".$calcBasedOn."' ";
        }
        
        if($feeType != '')
        {
            $sql .= " AND afm.fee_type = '".$feeType."' ";
        }
        
        $result = $this->_ODBC->_getResult($sql);
        
        if($result){
            $returnValue = $result[0];
        }
        
        return $returnValue;
    }
    
    /**
     * @description Select the status name for given status_id
     * @param int|$statusId
     * @return string|$return
     */
    
    public function _getTicketStatus($status_id){
        $sql = "SELECT 
                    status_value,
                    icon_class_name
                FROM dm_status 
                WHERE status_id=" . $status_id;
        
        $result = $this->_ODBC->_getResult($sql);
        
        return $result;
    }
    /**
     * @description Select the faretype from the faretype table using its id
     * @param int|$fareTypeId
     * @return string|$return
     */
    public function fareTypeName($fareTypeId){
        $sql="SELECT 
                   faretype 
                   FROM dm_fare_type 
                   WHERE fare_type_id=" . $fareTypeId;
        
        $result = $this->_ODBC->_getResult($sql);
        
        return $result;
    }
    
    public function _addBookingHistory($bookingArray) {
        
        if(count($bookingArray) > 0) {
            $this->_ODBC->_insert('booking_history', $bookingArray);
        }
        
    }
    
    /**
     * to mail booking not synced package id
     * @param type $packageId
     * @param type $subject
     */
    public function _mailBookingNotSynced($packageId, $subject, $corporateId) {
        
            $mailSync = explode(',', MAIL_BOOKING_SYNC);
            
            $serverProtocol = isset($_SERVER['HTTPS']) ? 'https://' : 'http://';                    
            
            $OcommonMethods = new \commonMethods();            
            
            foreach ($mailSync as $key => $value) {
                
                $this->_AtwigOutputArray['syncPackageUrl'] = $serverProtocol.$_SERVER['HTTP_HOST']."/kotak-personalbooking/bookingSyncFromMail.php?packageId=".base64_encode($packageId)."&mailId=".base64_encode($value)."&corporateId=".base64_encode($corporateId);                
                
                $str = $this->_Otwig->render('mailRequestInfo.tpl', $this->_AtwigOutputArray);        

                $OcommonMethods->_Email($value, MAIL_FROM_TEXT, $subject, $str, '');
            }        
    }
    
    public function pushInsertDetailsOfDmPackage($requestArray,$insertTableName,$resultRequestId,$bugTrackReport)
    {
        $sql = "select order_tracking_id from dm_order_tracking where table_name = '".$insertTableName."'";
        $result = $this->_ODBC->_getResult($sql);
        
            $this->_ArequestInsertDetailsOfDmPackage = array();
            
            $this->_ArequestInsertDetailsOfDmPackage[$insertTableName] = ['data'=>$requestArray,'errordescription'=>$bugTrackReport];        
            $this->_ArequestInsertDetailsOfDmPackage['primary_key_id'] = $resultRequestId;
            $this->_ArequestInsertDetailsOfDmPackage['r_order_tracking_id'] = $result[0]['order_tracking_id'];
            $this->_ArequestInsertDetailsOfDmPackage['input_data'] = json_encode($this->_ArequestInsertDetailsOfDmPackage[$insertTableName]['data']);
            $this->_ArequestInsertDetailsOfDmPackage['input_data'] = str_replace('"',"'",$this->_ArequestInsertDetailsOfDmPackage['input_data']);
            
        if($bugTrackReport == '')
        {
            $this->_ArequestInsertDetailsOfDmPackage['status'] = 'Y';
            $this->_ArequestInsertDetailsOfDmPackage['error_description'] = '';
        }
        else 
            {
                $this->_ArequestInsertDetailsOfDmPackage['status'] = 'N';
                $this->_ArequestInsertDetailsOfDmPackage['error_description'] = $this->_ArequestInsertDetailsOfDmPackage[$insertTableName]['errordescription']['Tablename'];
            }
    }
    public function pushInsertDetails($requestArray,$insertTableName,$resultRequestId,$bugTrackReport='',$action='')
    {
            $this->_ArequestInsertDetails = array();
            
        if($insertTableName === 'order_details' && $action === 'insert')
        {
            $this->_ArequestInsertDetailsOfDmPackage['r_order_id'] = $resultRequestId;
            $this->_ODBC->insertTrackingTable($this->_ArequestInsertDetailsOfDmPackage);
        }
        
        $sql = "select order_tracking_id from dm_order_tracking where table_name = '".$insertTableName."'";
        $result = $this->_ODBC->_getResult($sql);
            
            $this->_ArequestDetails[$insertTableName] = ['data'=>$requestArray,'errordescription'=>$bugTrackReport];
            $this->_ArequestInsertDetails['r_order_id'] = $_SESSION['orderInsertedId'];
            $this->_ArequestInsertDetails['primary_key_id'] = $resultRequestId;
            $this->_ArequestInsertDetails['r_order_tracking_id'] = $result[0]['order_tracking_id'];
            $this->_ArequestInsertDetails['input_data'] = json_encode($this->_ArequestDetails[$insertTableName]['data']);
            $this->_ArequestInsertDetails['input_data'] = str_replace('"',"'",$this->_ArequestInsertDetails['input_data']);
            
        if($bugTrackReport == '')
        {            
            $this->_ArequestInsertDetails['status'] = 'Y';
            $this->_ArequestInsertDetails['error_description'] = '';
            $this->_ODBC->insertTrackingTable($this->_ArequestInsertDetails);
        }
        else 
            {
                $this->_ArequestInsertDetails['status'] = 'N';
                $this->_ArequestInsertDetails['error_description'] = $this->_ArequestDetails[$insertTableName]['errordescription']['Tablename'];
                $this->_ODBC->insertTrackingTable($this->_ArequestInsertDetails);
            }
    }
    
    public function _getTaxValues($name, $airlineCode = '0',$returnType = "") {
        
        $returnValue = false;
        
        $name = trim($name);
        
        if (isset($name) && !empty($name)) {
            
            $result      = $this->_ODBC->_select('dm_tax', array('tax_master_id'), 'tax_name', $name);
            $taxMasterId = $result[0]['tax_master_id'];

            $sql = "SELECT tax_details_name,percentage FROM tax_mapping_value tmv LEFT JOIN tax_details td ON tmv.r_tax_details_id = td.tax_details_id WHERE r_airline_id = '" . $airlineCode . "' AND r_tax_master_id = " . $taxMasterId . " AND valid_from<=CURDATE() AND valid_to >=CURDATE()";
            $result = $this->_ODBC->_getResult($sql);
            
            if ($result && isset($result[0]['percentage'])) {
                if($returnType == "ARRAY")
                {
                    $returnValue = $result;
                }
                else
                {
                    $returnValue = $result[0]['percentage'];
                }
            }
        }
        return $returnValue;
    }
    
    public function _getApplicationSettings() {
        
        $sql    = "SELECT * FROM application_settings where status = 'Y' ORDER BY sorting DESC";
        
        $result =  $this->_ODBC->_getResult($sql);
        
        return $result;
    }
    
    public function _checkAndInsertApplicationSettingsValue($agencyId = '', $corporateId = '', $bookingType=0) {
        
        
        $result = $this->_getApplicationSettingsValues($agencyId, $corporateId, $bookingType);
        
        if(!$result) {
            //import existing corporate values to db
            $sql = "INSERT INTO application_settings_value 
                    SELECT NULL, r_setting_id, value, enabled, ".$corporateId.",".$agencyId.",'1' FROM application_settings_value 
                    WHERE  r_corporate_id = 0 AND r_agency_id =".$agencyId." AND booking_type = '".$bookingType."'";
            $result = $this->_ODBC->_executeQuery($sql);
        }
        
        $result = $this->_getApplicationSettingsValues($agencyId, $corporateId, $bookingType);
        
        return $result;
    }
    
    public function _getApplicationSettingsValues($agencyId = '', $corporateId = '', $bookingType = 0) {
        
        $where = " WHERE 1 ";
        
        if($agencyId !='') {
            $where .= " AND asv.r_agency_id = ".$agencyId." ";
        }
        
        if($corporateId !='') {
            $where .= " AND asv.r_corporate_id = ".$corporateId." ";
        }
        
        if($bookingType !='') {
             $where .= " AND asv.booking_type = '".$bookingType."' ";
        }
        
        $sql    = "SELECT asd.settings_details_id, asd.r_setting_id, asd.value, asv.enabled 
                   FROM application_settings_details asd 
                   INNER JOIN application_settings_value asv ON asd.settings_details_id = asv.value ".$where." ";
        $result =  $this->_ODBC->_getResult($sql);
        
        return $result;
    }
    
         /*
     * @Description get uploaded logo details for the corporate
     * @param int|$corporateId
     * @return boolean|$returnValue
     */
    public function _getUploadedLogoForCorporate($corporateId) 
    {
        
        $returnValue = false;
        
        if($corporateId > 0) {

            $sql    = "SELECT dm_corporate_logo_id, image_path FROM dm_corporate_logo WHERE r_corporate_id = ".$corporateId." AND `status` = 'Y'";
            $result = $this->_ODBC->_getResult($sql);
            
            $returnValue['corporateLogo']     = $result[0]['image_path'];
            $returnValue['corporateLogoId']   = $result[0]['dm_corporate_logo_id'];
            
        }

        return $returnValue;
    }
    
    public function _copyExistingApplicationSettings($newCorporateId, $existingCorporateId) {
        
        $existingFileName = APP_PATH_SYNC.'appSettings/corporate'.$existingCorporateId.'.json';
        $newFileName      = APP_PATH_SYNC.'appSettings/corporate'.$newCorporateId.'.json';
        
        if (!copy($existingFileName, $newFileName)) {
            $returnValue = array('status' => 0, 'message' => 'settings file not copied');
        } else {
            $returnValue = array('status' => 1, 'message' => 'settings file copied successfully');
        }
        
        return $returnValue;
    }
    
    public function _updateApplicationSettingsData($applicationData, $agencyId, $corporateId) {
        
        foreach ($applicationData as $key=>$val) {
            
            $userSettingArray = array();
            $userSettingArray = explode('_', $key);
            
            $settingType      = $userSettingArray[1];
            $settingId        = $userSettingArray[2];
            $settingDetailsId = $userSettingArray[3];
            
            switch($settingType) {
                
                case 'R': // RADIO-BUTTON
                    $returnValue = $this->_updateRadioButton($settingId, $settingDetailsId, $agencyId, $corporateId, $val);
                    break;
                
                case 'CB': // CHECK-BOX
                    $returnValue = $this->_updateCheckBox($settingId, $settingDetailsId, $agencyId, $corporateId, $val);
                    break;
                
                default: //NO VALUES SPECIFIED
                    $returnValue = 0;
                    break;
            }
        }
        
        return $returnValue;
    }

    
    public function _updateRadioButton($settingId, $settingDetailsId, $agencyId, $corporateId, $value) {
        
        //get settings details id possible values - update all the values to status enabled = 'N'
        
        $this->_disableToDefaulValue($settingId, $agencyId, $corporateId);
        
        if($agencyId !='') {
            $where .= " AND r_agency_id = ".$agencyId."";
        }
        
        if($corporateId !='') {
            $where .= " AND r_corporate_id = ".$corporateId."";
        }

        $sql = "UPDATE application_settings_value asv 
                JOIN application_settings_details asd ON (asv.value=asd.settings_details_id AND asv.r_setting_id =".$settingId." AND asd.value = '".$value."')
                SET asv.enabled='Y'";
        $affectedRows = $this->_ODBC->_executeQuery($sql);
        
        fileWrite($sql, 'userSettingArray', 'a+');
        
        return $affectedRows;
    }
    
    public function _updateCheckBox($settingId, $settingDetailsId, $agencyId, $corporateId, $value) {
        
        if($agencyId !='') {
            $where .= " AND r_agency_id = ".$agencyId."";
        }
        
        if($corporateId !='') {
            $where .= " AND r_corporate_id = ".$corporateId."";
        }
        
        $enabledValue = $value == 1 ? 'Y' : 'N';
        
        $sql          = "UPDATE application_settings_value SET enabled = '".$enabledValue."' WHERE r_setting_id = ".$settingId." AND value='".$settingDetailsId."' $where ";
        $affectedRows = $this->_ODBC->_executeQuery($sql);
        fileWrite($sql, 'userSettingArray', 'a+');
        return $affectedRows;
    }
    
    public function _disableToDefaulValue($settingId, $agencyId, $corporateId) {
        
        $where = '';
        
        if($agencyId !='') {
            $where .= " AND r_agency_id = ".$agencyId."";
        }
        
        if($corporateId !='') {
            $where .= " AND r_corporate_id = ".$corporateId."";
        }
        
        $sql          = "UPDATE application_settings_value asv  SET enabled = 'N' WHERE r_setting_id = ".$settingId." $where ";
        $affectedRows = $this->_ODBC->_executeQuery($sql);
        
    }
    
    // function is used to get the subfolder name and return the path of directory with subfolder name
    // param directory file path
    // return $queryFileSubFolder file path of subfolder in given directory
    
    public function _getSubFoldersDirectory($queryFilePath) {
        $queryFileSubFolder = '';
        if(!empty($queryFilePath))
        {
               foreach (glob($queryFilePath . "/*", GLOB_ONLYDIR) as $filename)
                    {
                        $queryFileSubFolder[] = $filename;   
                    }
        }
        return $queryFileSubFolder;
        
    }
    
     /*
     * @description : get file name inside the particular path.
     * @param : $filePath,$fileExtension
     * @return array|$filename
     */
    
    public function _getFileName($filePath,$fileExtension) 
    {
        foreach(glob($filePath."/*.".$fileExtension) as $file) 
        {
            //$fileName = str_replace(".".$fileExtension,"",basename($file));
            $result[] = $file;
	}
        return $result;        
    }  
    
    
    /*
     * @description : get template name inside the particular folder.
     * @param : $folderPath.
     * @return array|$templateFolderArray
     */
    
    public function _getAllSubFolderArray($folderPath)
    {
         // get template folder       
        $templateFolderInfoTemp = array($folderPath);
        $templateFolderInfo = $this->_getSubFoldersDirectory($folderPath);        
        if($templateFolderInfo != "")
        {
            foreach ($templateFolderInfo as $value) 
            {
               $templateFolder = $this->_getSubFoldersDirectory($value);
               if($templateFolder != "")
               {
                    $templateTempArray[] = $templateFolder;
               }
               else
               {
                   $templateTempArray[] = $value; 
               }              
            }             
            
            $templateFolderArray = array();
            foreach ($templateTempArray as $value) 
            {
               if(is_array($value))
               { 
                  $templateFolderArray = array_merge($templateFolderArray,$value);
               }
               else
               {
                   array_push($templateFolderArray,$value);
               }   
            }  
        }
        $templateFolderArray1 = array_merge($templateFolderInfoTemp ,$templateFolderArray);
        return $templateFolderArray1;  
    }  
}
?>
