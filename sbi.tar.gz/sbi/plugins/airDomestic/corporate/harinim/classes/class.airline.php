<?php
/** **********************************************************************
 * @Class Name	: class.airline.php
 * @Created on	: 2016-06-14
 * @Created By	: Lakshmi
 * @Description	: This file is used to insert,update and get airline details
 * ************************************************************************ */
fileRequire('classes/class.commonDBO.php');

class airline{
    private $_AfieldsArray=array();
    private $_Swherekey="";
    private $_Swherevalue="";
    private $_SoutputType="";
    private $_OcommonDBO;
    
    public function __construct(){
        $this->_OcommonDBO = new commonDBO();
    }
     
    /**
     * @Description :This function get airline details mapped for the corporate
     * @param :integer | $airlineId - holds airline id
     * @return array|$return - return array of records
     */
    public function _getAirlineDetails($airlineId=0,$fieldsArray=array()){
        
        if(!empty($fieldsArray)){
            if(is_array($fieldsArray) && count($fieldsArray) > 0){
                $fieldsCSV = implode(", ",$fieldsArray);
            }else{
                $fieldsCSV = $fieldsArray;
            }
            //Query to get the billto-address mapped for the corporate id
            $sqlAirline="SELECT ".$fieldsCSV." FROM dm_airline WHERE ";
        }else{
            //Query to get the billto-address mapped for the corporate id
            $sqlAirline="SELECT airline_id,airline_code,airline_name,status FROM dm_airline WHERE ";
        }
        if($airlineId!=0){
            $sqlAirline .=  " airline_id=".$airlineId." AND";
        }
        $sqlAirline .=  " status='Y' ";
        $sqlAirline .=  " order by airline_name  AND";
        $sqlAirline=substr($sqlAirline,0,-4);
         
        //Functiona call to get fetch the records 
        $result=$this->_OcommonDBO->_getResult($sqlAirline);
        
        return $result;
    }
    
    public function _getTravelClassInformation($travelModeId=1){
        $sql = "SELECT dtc.travel_class_id,dtc.class_name,dtc.class_code,dtm.travel_mode_id,dtm.travel_mode
                FROM dm_travel_mode dtm 
                INNER JOIN dm_travel_class dtc ON dtm.travel_mode_id = dtc.r_travel_mode_id ";
        $append = " WHERE ";
        if(isset($travelModeId)){
            $sql .= $append." dtm.travel_mode_id = ".$travelModeId;
            $append = " AND ";
        }
        if( isset($this->_ItravelClassId)){
            $sql .= $append." dtc.travel_class_id = ".$this->_ItravelClassId;
            $append = " AND ";
        }
        $sql .= $append." dtc.status = 'Y' order by dtc.travel_class_id desc";
        $result = $this->_OcommonDBO->_getResult($sql);
        foreach( $result as $value ){
            $response[$value['travel_mode_id']][] = $value;
        }
        
        return $response;
    }
    
    /**
     * @Description :This function is used get the travel Class name
     * @param :integer   | $traveClassId - holds the travelclass id
     * @return array |$result - contains classname 
     */
    public function _getTravelClassName($traveClassId){
        $sql="SELECT class_name,class_code 
              FROM dm_travel_class 
              WHERE travel_class_id=".$traveClassId;
        $result = $this->_OcommonDBO->_getResult($sql);
        
        return  $result;
     }
     
    /**
     * @description To get the airline details based on airline code
     * @param type $airLineCode
     */
    public function _getAirlineCodeInfo($airLineCode){
         
        if($airLineCode!=''){
            $sql="SELECT airline_id,airline_code,airline_name 
                  FROM dm_airline 
                  WHERE airline_code='".$airLineCode."'";
            $result = $this->_OcommonDBO->_getResult($sql);
           
            return  $result;
        }
    }
     
    // mark up calculation 
    public function _getMarkUpMarkDownFareFee($agencyId,$corporateId,$syncCorporateId,$travelModeId,$travelClass){
        $markfare['markUpMarkDown']['corporateId'] = $corporateId;
        $markfare['markUpMarkDown']['agencyId'] = $agencyId;
        $markfare['markUpMarkDown']['syncCorporateId'] = $syncCorporateId;
        $markfare['markUpMarkDown']['classType'] = $travelClass;
        $markfare['markUpMarkDown']['travelType'] = ($travelModeId == 0 || $travelModeId == 1) ? 'D' : '';
        $markfare['markUpMarkDown']['modeType'] = ($travelModeId == 0 || $travelModeId == 1) ? 'Air' : '';
            
        fileRequire('classes/class.sync.php');
        $sync = new sync(); 
            
        $result =$sync->_getMarkUpMarkdownFee($markfare);
        $this->_markUp= $result;
            if(isset($this->_markUp['responseData']['MarkupAmount']['airline']) && $this->_markUp['responseData']['MarkupAmount']['airline']!=''){
                foreach ($this->_markUp['responseData']['MarkupAmount']['airline'] as $key => &$value){
                    $value['markKey'] ='Up';
                }
            }
            if(isset($this->_markUp['responseData']['MarkDownAmount']['airline']) && $this->_markUp['responseData']['MarkDownAmount']['airline']!='' ){
                foreach ($this->_markUp['responseData']['MarkDownAmount']['airline'] as $key => &$value){
                    $value['markKey'] ='Down';
                }
            }
            // result array merged to one key with mark down and mark up data
            if(isset($this->_markUp['responseData']['MarkDownAmount']['airline']) && $this->_markUp['responseData']['MarkDownAmount']['airline']!='' && isset($this->_markUp['responseData']['MarkupAmount']['airline']) && $this->_markUp['responseData']['MarkupAmount']['airline']!=''){
                $resultValue = array_merge($this->_markUp['responseData']['MarkDownAmount']['airline'],$this->_markUp['responseData']['MarkupAmount']['airline']);
            }
            elseif(isset($this->_markUp['responseData']['MarkDownAmount']['airline']) && $this->_markUp['responseData']['MarkDownAmount']['airline']!='' ){
                $resultValue = $this->_markUp['responseData']['MarkDownAmount']['airline'];
            }
            else{
                $resultValue = $this->_markUp['responseData']['MarkupAmount']['airline'];
            }

        return $resultValue;
    }
    
    /**
     *  function used to get enabled  airlines in fare profile settings
     *   @param  |string (fareProfileSelectedAirline)
     *   @return | array (enables airlines)
     *   @author Puroskhan.M 
     */
    public function _getfareProfileEnabledAirLines($fareProfileSelectedAirline,$FSCairliesSelected,$fareprofileAirlineName) {
        $sql = "SELECT airline_id, 
                       airline_code, 
                       airline_name 
                FROM   dm_airline 
                WHERE  airline_code IN (".$fareProfileSelectedAirline.") AND status='Y'";
            $airlines = $this->_OcommonDBO->_getResult($sql);
           return $this->_formArrayForAirlineDetails($airlines,$FSCairliesSelected,$fareprofileAirlineName);
    }

    /**
    *  function used to get enabled  airlines in fare profile settings
    *   @param  |string (fareProfileSelectedAirline)
    *   @return | array (enables airlines)
    *   @author Puroskhan.M 
    */
    public function _formArrayForAirlineDetails($airlines,$FSCairliesSelected,$fareprofileAirlineName) {
         $allAirlines=array();
            foreach ($airlines as $key => $value) {
                 $code= $value['airline_code'];
                 $allAirlines[$key]["fareProfile_airline_name"]= $fareprofileAirlineName[$code];//this will send flight search
                 $allAirlines[$key]["airline_id"]= $value['airline_id'];
                 $allAirlines[$key]["airline_code"]= $value['airline_code'];
                 $allAirlines[$key]["airline_name"]= $value['airline_name'];
            }
             
              
              if(empty($allAirlines)){
                $allAirlines['checkValue'] = 'EMPTY';
              }
              $allAirlines['GDS']=$FSCairliesSelected;
              return $allAirlines;
    }
    
    /**
    *  function used to get airlines
    *   @param  |int ($orderId)
    *   @return | array 
    */
    public function _getAirlineCodeDetails($orderId,$tripType = ''){
        
        $sql = "SELECT 
                    air.airline_code,
                    vfd.trip_type 
                FROM 
                    dm_airline air 
                    INNER JOIN via_flight_details vfd ON air.airline_id = vfd.r_airline_id 
                    INNER JOIN fact_air_itinerary fai ON vfd.via_flight_id = fai.r_via_flight_id 
                    INNER JOIN air_booking_details abd ON fai.r_air_booking_details_id = abd.air_booking_details_id 
                WHERE fai.itinerary_status = ".SELECTED_ITINERARY." AND abd.r_order_id = ". $orderId;
        
        if($tripType != ''){
            $sql .= " AND vfd.trip_type IN (".$tripType.")";
        }
        
        $sql .= " ORDER BY vfd.trip_type";
        $result = $this->_OcommonDBO->_getResult($sql);
        return $result;
    }     
    
    /**
    *  function used to get all airlines
    *   @param  |int ($orderId)
    *   @return | array 
    */
    public function _getAllAirline($orderId,$tripType = ''){
        
        $airline = array();
        
        $airlineInfo = $this->_getAirlineCodeDetails($orderId,$tripType);
        foreach($airlineInfo as $key => $value){
            $airline[$value['trip_type']][] = $value['airline_code'];
        }        
        
        $onwardAirlineArray = array_values(array_unique($airline[0]));
        $returnAirlineArray = array_values(array_unique($airline[1]));
        
        $onwardAirline = implode("/",$onwardAirlineArray);
        $returnAirline = implode("/",$returnAirlineArray);
        
        //get onward airline
        if($onwardAirline != '' && $returnAirline != ''){
            $airlineInfo = $onwardAirline.','.$returnAirline;
        }        
        else if($onwardAirline != ''){
            $airlineInfo = $onwardAirline;
        }
        else if($returnAirline != ''){
            $airlineInfo = $returnAirline;
        }        
        return $airlineInfo;
    }

    /**
    *  function used to get airlines
    *   @param  |int ($viaFlightID)
    *   @return | array 
    */
    public function _getViaFlightsAirlineCode($viaFlightID){
        
        $sql = "SELECT 
                    air.airline_code
                FROM 
                    dm_airline air 
                    INNER JOIN via_flight_details vfd ON air.airline_id = vfd.r_airline_id                    
                WHERE vfd.via_flight_id IN ($viaFlightID)";
        return $this->_OcommonDBO->_getResult($sql);
    }    
}
?>