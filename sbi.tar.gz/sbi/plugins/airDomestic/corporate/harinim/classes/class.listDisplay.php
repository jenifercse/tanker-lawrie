<?php
/**
 * @File             : class.listDisplay.php
 * @Author           : Sivaprakash.M
 * @Created Date     : 02/01/2017
 * @Modified Date    : 13/11/2017
 */
class listDisplay{

    public function __construct(){
        $this->_OcommonDBO=new commonDBO();
        $this->_OAgency = new agency();
        $this->_Oairline = new airline();
        $this->_MobileStatus = 'N';

        // condition to check booking based on corporate and package related to air travel mode
        $this->_ccheckCondition = " WHERE ( dmp.package_type = '0' OR dmp.package_type = '".CORPORATE_BOOKING_AIR_PACKAGE_TYPE."' )  AND IF(fai.r_via_flight_id != '', fai.itinerary_status = " . SELECTED_ITINERARY . ","."( od.r_ticket_status_id = ".REQUESTED." or od.r_ticket_status_id = ".CANCEL_REQUEST .")".") ";
        // executed query to get result based on order id    
        $this->_OorderByOrderId = ' GROUP BY bh.order_id ORDER BY bh.order_id DESC ';
        // status conditio for booking in which status 
        $this->_SstatusCheckForPostApproval = " AND if(od.approval_status in (0) , od.r_ticket_status_id = ds.status_id,if(od.approval_status = 1 , ds.status_id =2,if(od.approval_status = 3 , ds.status_id = od.r_ticket_status_id,if(od.r_ticket_status_id = 8, ds.status_id = 8, ds.status_id = od.r_ticket_status_id)))) ";
        // reference value of corporate based to display ayprc id (back end sync id)    
        $this->_referenceValueOfCorporate = $_SESSION['syncAgencyReference'];
    }
    
    /**
     * used to get booking list based on lis type for view
     * @param string $bookingStatus
     * @param array $input
     * @param string $returnQuery
     * @return  array detailslist
     * @author baskar
     */
    public function _getBookingsList($bookingStatus,$input = '',$returnQuery = ''){
        $sql="  SELECT 
                concat(pd.title,' ',pd.first_name,' ',pd.last_name) as name,
		pd.title,
		pd.first_name,
		pd.last_name,
                pd.employee_code,
                pod.department,
                pod.branch,
                bh.sector_from,
                bh.sector_to,
                dma.airline_code,
                CASE  dmp.booking_mode WHEN '0' THEN 'Online' WHEN '1' THEN 'Offline' ELSE 'Mobile' END as bookingMode,
                CASE  bh.trip_type WHEN '0' THEN 'One Way' WHEN '1' THEN 'Round Trip' ELSE 'Multi City' END as journeytype,
                CASE  bh.travel_mode WHEN  'D' THEN 'Domestic' ELSE 'International' END AS travelmode,
                pvd.pnr,
                DATE_FORMAT(bh.onward_depature_date,'".COMMON_DATE_FORMAT."') as 'travel_date',
                DATE_FORMAT(bh.request_date,'".COMMON_DATE_FORMAT."') as 'booking_date',
                DATE_FORMAT(bh.payment_date,'".COMMON_DATE_FORMAT."') as 'payment_date',
                bh.onward_depature_date as 'travel_date_dp_format',
                bh.return_depature_date as 'travel_date_return_dp_format',
                bh.total_amount,
                dpt.payment_type_description,
                sap.sap_request_id,
                bh.package_id,
                od.r_ticket_status_id as booking_status,
                od.r_payment_status_id, 
                od.approval_status,
                od.order_id,
                od.sync_order_id,
                od.workflow_caption,
                bh.travel_mode,
                bh.trip_type, 
                dmp.booking_mode,
                od.approver_account_id,
                od.sync_order_id as corpoartePackagereference,
                ds.status_value,
                ds.icon_class_name as icon_class,
                vfd.flight_no,
                dmp.package_type
                FROM booking_history bh
                INNER JOIN dm_package dmp ON bh.package_id = dmp.package_id
                INNER JOIN order_details od ON od.order_id = bh.order_id
                INNER JOIN fact_booking_details fbd ON od.order_id = fbd.r_order_id
                INNER JOIN dm_employee dme ON fbd.r_employee_id = dme.employee_id
                INNER JOIN passenger_details pd ON od.order_id = pd.r_order_id 
                INNER JOIN passenger_other_details pod ON pod.r_passenger_id = pd.passenger_id
                LEFT JOIN passenger_via_details pvd ON pd.passenger_id = pvd.r_passenger_id
                LEFT JOIN via_flight_details vfd ON pvd.r_via_flight_id = vfd.via_flight_id
                LEFT JOIN fact_air_itinerary fai ON fai.r_via_flight_id = vfd.via_flight_id
                LEFT JOIN dm_airline dma ON vfd.r_airline_id = dma.airline_id 
                LEFT JOIN payment_details pds ON  bh.package_id = pds.r_package_id
                LEFT JOIN dm_payment_type dpt ON  pds.r_payment_type_id = dpt.payment_type_id 
                LEFT JOIN sap_request_details sap ON dmp.package_id  =  sap.r_package_id ";
        
        if($bookingStatus == 'APPROVEDBOOKINGS'){   
            
            $sql .= $this->_getApprovedBookingList($input);
            $sql  = $this->_checkConditionAndPostApprovalStatus($sql);
            $sql  = $this->_getDataBasedOnFilter($input, $sql);
            $sql .= ' GROUP BY order_id ORDER BY order_id DESC';
            return $this->_OcommonDBO->_getResult($sql);
        }
        if(($bookingStatus == 'PENDINGAPPROVECANCELBOOKINGS' || $bookingStatus == 'REQUESTAPPROVALBOOKINGS' || $bookingStatus == 'PENDINGAPPROVALBOOKINGS' || $bookingStatus == 'POSTAPPROVALBOOKINGS')){                  
            $sql .= $this->_getApprovalListBookings($input);
        }
        $sql  = $this->_checkConditionAndPostApprovalStatus($sql);
        $sql .= $this->_getListTypeBookings($bookingStatus);
        $sql .= $this->_getBookingsBasedOnPermission($bookingStatus);
        $sql  = $this->_getDataBasedOnFilter($input, $sql);
        $sql .= " AND dmp.booking_type = '1' ";
        if($this->_MobileStatus == 'N')
        {
            $sql .= $this->_OorderByOrderId;
        }
        // if flag returnquery is to return query return the query or return the query executed result
        return (!empty($returnQuery) && $returnQuery == 'returnQuery') ? $sql : $this->_OcommonDBO->_getResult($sql);
    }

    /**
     * used to apply sorting option for list view data
     * @param array $input
     * @return string
     * @author baskar
    */
    public function _getCorporateList($agencyId) {
        
        $sql = "    SELECT acm.agency_id, acm.corporate_id, acm.sync_corporate_id, dc.corporate_name 
                    FROM  agency_corporate_mapping acm 
                    INNER JOIN dm_corporate dc ON acm.corporate_id = dc.corporate_id and acm.sync_corporate_email_id != '' 
                    WHERE acm.deleteStatus='N' AND acm.status='Y' AND dc.status ='Y' 
                    AND agency_id IN (" . implode($_SESSION['permissions']['access']['agencyId'],',') . " 
                    ) AND dc.corporate_id IN (" . implode($_SESSION['permissions']['access']['corporateId'],',') . " 
                    ) GROUP BY dc.corporate_id ORDER BY  dc.corporate_name";
        return $this->_OcommonDBO->_getResult($sql);
    }

    /**
     * used to apply sorting option for list view data
     * @param array $input
     * @return string
     * @author baskar
     */
    
    public function _setPackageWise($data) {
        $packageId = 0;
        $keySet = preg_split("/,/", implode(',',array_unique(array_column($data, 'package_id'))));
        foreach ($keySet as $mainkey => $pacvalue) {
            foreach ($data as $key => $value) {
                ($pacvalue == $value['package_id']) ? $formingArray[$mainkey]['employee_code'] =$value['employee_code']  : '';
                ($pacvalue == $value['package_id']) ? $formingArray[$mainkey]['name'] = $value['name'] : '';
                ($pacvalue == $value['package_id']) ? $formingArray[$mainkey]['department'] = $value['department'] : '';
                ($pacvalue == $value['package_id']) ? $formingArray[$mainkey]['branch']  = $value['branch'] : ''; 
                ($pacvalue == $value['package_id']) ? $formingArray[$mainkey]['approverName']  = $value['approverName'] :'';
                ($pacvalue == $value['package_id']) ? $formingArray[$mainkey]['sub'][$value['order_id']] = $value : '';
            }            
        }
        return $formingArray;
    }

    /**
     * used to check the order id based on cancellation date
     * @param array $input
     * @return array
     * @author baskar
     */
    public function _setCancellationData($data) {
        $finalData = $data;
        foreach ($finalData as $key => $value) {
            if($value['booking_status'] > 8 && $value['r_payment_status_id'] == 16){
                // adding cancellation date for booking list
                $sql = "  SELECT DATE_FORMAT(cancel_date,'".COMMON_DATE_FORMAT."')   as cancel_date
                    FROM  trans_cancellation
                    WHERE r_order_id =".$value['order_id'];
                    $dataCancel =$this->_OcommonDBO->_getResult($sql)[0]['cancel_date'];
                    $finalData[$key]['cancellationDate'] = $dataCancel;
            }
        }
     return $finalData;
    }

    public function _getPassengerInfo($data){
        $_Opassenger = new \passenger();
        foreach($data as $key => $value) {
            $data[$key]['paxInfo'] = $_Opassenger->_getPassengerName($value['order_id']);
        }
        return $data;
    }

    public function _cancellationDisplayStatus($data){
    
        foreach($data as $key => $value) {
           $date = strtotime($value['travel_date_dp_format'])-60*60*2;
            $sysdate = strtotime(date("Y-m-d H:i:s"));
            $data[$key]['cancelIconViewStatusOnward'] =   ($sysdate <= $date) ? 'SHOW' : 'HIDE';//&& $value['r_employee_id'] == $_SESSION['employeeId'] 
            // for return 
            $data[$key]['cancelIconViewStatusReturn'] = 'HIDE';

            if($value['trip_type'] == 1){
                $dateReturn = strtotime($value['travel_date_return_dp_format'])-60*60*2;
                $data[$key]['cancelIconViewStatusReturn'] =   ($sysdate <= $dateReturn) ? 'SHOW' : 'HIDE'; //&& $value['r_employee_id'] == $_SESSION['employeeId']
            }
        }
        return $data;
    }

    /**
     * used to append filter data to sort the query
     * @param array $input
     * @param string $sql
     * @return string
     * @author sivaprakash
     */
    public function _getDataBasedOnFilter($input, &$sql, $avoidFilter = '') {
    
        $sql .= $input['process_type'] != 'NoShowApprover' ? $this->_getRequestByDateRange($input, $avoidFilter) : $this->_getNoShowRequestByDateRange($input, $avoidFilter) ;
        $sql .= $this->_getRequestByFilterSorting($input);
        // $sql .= $this->_OorderByOrderId;
        //(isset($input['recordLimit']) && !empty($input['recordLimit'])) ? $sql .= ' LIMIT '.$input['recordLimit'] : '';        
        
        return $sql;
    }
    
    /**
     * used to apply sorting option for list view data
     * @param array $input
     * @return string
     * @author sivaprakash
     */
    public function _getRequestByFilterSorting($input) {
        
        !empty($input['sortDataFilter']['travelDate']) ? $sql .= " AND DATE(bh.onward_depature_date) = '".$input['sortDataFilter']['travelDate']."' " : '';
        $input['sortDataFilter']['booking_type'] != ''?  $sql .= " AND dmp.booking_mode = '".$input['sortDataFilter']['booking_type']."' " :' ';
        $input['sortDataFilter']['request_type'] != ''  ? $sql .= " AND bh.travel_mode = '".$input['sortDataFilter']['request_type']."' " : ' ';
        $input['sortDataFilter']['airline_code'] != '' ? $sql .= " AND vfd.r_airline_id = '".$input['sortDataFilter']['airline_code']."' " : ' ';
        $input['sortDataFilter']['employee_code'] ? $sql .= " AND dme.employee_code =  '" . $input['sortDataFilter']['employee_code'] . "' " : '';
        $input['sortDataFilter']['employee_name'] ? $sql .= " AND CONCAT(pd.first_name,' ',pd.last_name) like '%".$input['sortDataFilter']['employee_name']."%' " : '';
        // !empty($input['sortDataFilter']['passengerName']) ? $sql .= " AND CONCAT(pd.first_name,' ',pd.last_name) like '%".$input['sortDataFilter']['employee_name']."%' " : '';
        
        $input['sortDataFilter']['status'] ? $sql .= " AND od.r_ticket_status_id = ".$input['sortDataFilter']['status'] : '';
        $input['sortDataFilter']['journey_type'] != '' ? $sql .= " AND bh.trip_type = '".$input['sortDataFilter']['journey_type']."' " : ' ';
        $input['sortDataFilter']['employee_pnr'] != '' ? $sql .= " AND pvd.pnr like '%".$input['sortDataFilter']['employee_pnr']."%' " : '';
        $input['sortDataFilter']['corporate_id'] != '' ? $sql .= " AND bh.r_corporate_id = '".$input['sortDataFilter']['corporate_id']."' " : ' ';
        $input['sortDataFilter']['request_id'] != '' ? $sql .= " AND bh.package_id = '".$input['sortDataFilter']['request_id']."' " : ' ';
        !empty($input['sortDataFilter']['approval_status']) ? $sql .= " AND od.r_ticket_status_id = '".$input['sortDataFilter']['approval_status']."' " : ' ';
        //$input['sortDataFilter']['sector'] ? $sql .= " AND (bh.sector_from = '".$input['sortDataFilter']['sector']."'  OR bh.sector_to = '".$input['sortDataFilter']['sector']."' )" : '';        
        return $sql;
    }
    
    /**
     * used to append the query with condition and approval post condition
     * @param string $sql
     * @return string
     * @author sivaprakash
     */
    public function _checkConditionAndPostApprovalStatus(&$sql) {
        
        $sql .=" ,dm_status ds";
        $sql .= $this->_ccheckCondition;
        $sql .= $this->_SstatusCheckForPostApproval;        
        
        return $sql;
    }
    /**
     * @functionName    :   _getApprovalListBookings()
     * @param           :   array $input
     * @param           :   string $approverBasedOn
     * @description     :   get approval list for bookings raised
     * @return          :   string $sql
     * @author sivaprakash
     */         
    public function _getApprovalListBookings($input = '',$approverBasedOn = 'orderId',$bookingStatus ='' ){
        $sql = $approverBasedOn == 'packageId' ? " INNER JOIN approval_tracking apt ON apt.r_package_id = dmp.package_id " : " INNER JOIN approval_tracking apt ON apt.r_order_id = od.order_id ";
        if($bookingStatus != 'PENDINGNOSHOWAPPROVALBOOKINGS'){
            $sql .=" AND apt.approval_level = od.approval_level ";
        } 
        $sql .=" AND apt.approval_view_status = 'N' AND apt.approval_type != 'IA' ";
        $sql .=  $input['r_employee_id'] ? " AND apt.approver_id =  '".$input['r_employee_id']."' " : '';
        $sql .=  $input['process_type'] ? " AND apt.process_type =  '".$input['process_type']."' " : '';
        return $sql;
    }
    
    /**
     * @functionName    :   _getBookingsBasedOnPermission()
     * @param           :   string $bookingStatus
     * @description     :   get approval list for bookings raised based on permissions
     * @return          :   string $sql
     * @author sivaprakash
     */         
    public function _getBookingsBasedOnPermission($bookingStatus){        
        if(!($bookingStatus == 'PENDINGAPPROVECANCELBOOKINGS' || $bookingStatus == 'PENDINGAPPROVALBOOKINGS' || $bookingStatus == 'POSTAPPROVALBOOKINGS' || $bookingStatus == 'REQUESTAPPROVALBOOKINGS' || $bookingStatus == 'PENDINGNOSHOWAPPROVALBOOKINGS' || $bookingStatus == 'APPROVEDNOSHOWAPPROVALBOOKINGS')){
            $permission = $_SESSION['permissions'];
            if($_SESSION['userTypeId'] == 8){
               // $sql =" AND (pd.r_employee_id IN (".$_SESSION['employeeId'].") or bh.r_booked_by IN (".$_SESSION['employeeId']."))";
                $sql =" AND bh.r_booked_by IN (".$_SESSION['employeeId'].")";
            }
            else{           
                //Condition for Data  Permission for permission type self
                $permission['permissionName'] == 'Self' ? $sql =" AND bh.r_booked_by = '" . $permission['r_employee_id'] . "' " : '';
                //Condition for Data  Permission for permission type other corporate
                $permission['permissionName'] == 'Other Corporate' ? $sql =" AND bh.r_corporate_id IN (" . $permission['fieldList']['corporateList'] . ") " : '';
                //Condition for Data  Permission for permission type other employee
                $permission['permissionName'] == 'Other Employee' ? $sql =" AND bh.r_booked_by IN (" . $permission['r_employee_id'] . ") " : '';
                //Condition for Data  Permission for permission type Self Corporate
                $permission['permissionName'] == 'Self Corporate' ? $sql =" AND bh.r_corporate_id IN (" . $permission['fieldList']['corporateList'] . ") " : '';
            }
        }       
        return $sql;
    }
        
    /**
     * @functionName    :   _getListTypeBookings()
     * @param           :   string $bookingStatus
     * @description     :   get list for bookings raised based on booking status
     * @return          :   string $sq
     * @author sivaprakash
     */           
    public function _getListTypeBookings($bookingStatus){

        switch ($bookingStatus){
            case 'MYBOOKINGS':
                $sql =$this->_setMyBookingList();
                break;
            case 'POSTMYBOOKINGS':
                $sql =$this->_setPostBookingList();
                break;
            case 'CREDITNOTE':
                $sql =" AND od.r_ticket_status_id IN (".CANCELLED.",".PARTIALLY_CANCELLED.") ";
                break;
            case 'MAKEPAYMENT':
                $sql =" AND od.workflow_caption != '".CMP_REQUEST_APPROVAL."' AND (od.r_ticket_status_id = ".APPROVED." OR od.r_ticket_status_id = ".NOT_PAID." )  AND od.r_payment_status_id = ".PAYMENT_NOT_DONE." ";
                break;
            case 'REQUESTMAKEPAYMENT':
                $sql =" AND od.workflow_caption = '".CMP_REQUEST_APPROVAL."' AND od.r_ticket_status_id = ".NOT_PAID."  AND od.r_payment_status_id = ".PAYMENT_NOT_DONE." ";
                break;
            case 'PENDINGAPPROVALBOOKINGS':
            case 'REQUESTAPPROVALBOOKINGS':    
                $sql =" AND od.r_ticket_status_id = ".SEND_FOR_APPROVAL."  AND od.r_payment_status_id = ".PAYMENT_NOT_DONE." ";
                break;
            case 'PENDINGNOSHOWAPPROVALBOOKINGS':
                $sql =" AND od.r_ticket_status_id = ".NO_SHOW_PENDING_APPROVAL." AND nsd.approval_status = ".NO_SHOW_PENDING_APPROVAL." ";
                break;
             case 'APPROVEDNOSHOWAPPROVALBOOKINGS':
                $sql =" AND od.r_ticket_status_id IN (".NO_SHOW_APPROVED." , ".NO_SHOW_REJECTED.") AND nsd.approval_status IN (".NO_SHOW_APPROVED." , ".NO_SHOW_REJECTED.") ";
                break;
            case 'POSTAPPROVALBOOKINGS':
                $sql =" AND  od.approval_status = ".POSTAPPROVAL_NOT_APPROVED_BOOKINGS." ";
                break;
            case 'VIEWREQUEST':
                // no condition added to query for listing all type of status bookings
                break;
            case 'CANCELBOOKINGS':
                $sql =" AND od.approval_status = 0 AND od.r_ticket_status_id IN ( ".PARTIAL_CANCEL_PROCESS.",".TICKETTED.",".PARTIALLY_CANCELLED.",".CANCELLED.",".CANCEL_PROCESS.",".CANCELLATION_FAILURE.") AND od.r_payment_status_id = ".PAYMENT_DONE." ";
                break;
            case 'PENDINGAPPROVECANCELBOOKINGS':
                $sql =" AND od.r_ticket_status_id = ".SEND_FOR_APPROVAL."  AND od.r_payment_status_id = ".PAYMENT_DONE." ";
                break;
            case 'POSTCANCELBOOKINGS':
                $sql = $this->_getPostCancelRequest();
                break;
            default:
                $sql =" AND pvd.fullfilment_status = ".FULFILMENT_DONE." AND od.r_ticket_status_id = ".TICKETTED." ";
        }
         
        return $sql;
    }
    /**
     * used to get status array for booking status and approval status
     * @param srting $statusType
     * @return array
     * @author sivaprakash
     */
    public function _getBookingAndApprovalStatusDisplay($statusType = "'Booking Status'",$statusValueArray,$statusExpect='') {
        $statusValue = implode(",", $statusValueArray);
        $statusExpect = implode(",", $statusExpect);

        $sql = " SELECT 
                        status_value, status_id
                 FROM
                        dm_status
                 WHERE  1 ";
        $sql.= $statusType != '' ? " AND  status_type IN (".$statusType.")" : "" ;
        $sql.= $statusValueArray !='' ? " AND  status_id IN($statusValue) " : "" ;
        $sql.= $statusExpect !='' ? " AND status_id NOT IN(".$statusExpect.") " : "" ;

    return array_column($this->_OcommonDBO->_getResult($sql), 'status_value', 'status_id');
        
    }
    /**
     * @functionName    :   _getRequestByDateRange()
     * @param           :   array $datePeriod
     * @description     :   get view request list for bookings raised based on filter
     * @return          :   string $sql
     * @author sivaprakash
     */         
    public function _getRequestByDateRange($datePeriod = '',$avoidFilter = ''){

        $range = $this->_setTimePeriodRange($datePeriod,$avoidFilter);
        if($avoidFilter != 'NODATERANGE'){
            $sql .= " AND DATE(bh.request_date) ";
        }
        if(!empty($datePeriod['active']) && $datePeriod['active'] == 'Reference'){
            $range = '';
        }
        switch ($range){
           case 1:
                $sql.=" = '" . date('Y-m-d') . "' ";
                break;
           case 2:
                $yesterday = date('Y-m-d', strtotime('-1 days'));
                $sql.=" = '" . $yesterday . "' ";
                break;
           case 3:
                $sql.="  BETWEEN DATE_SUB(CURDATE(), INTERVAL 14 DAY) AND DATE_SUB(CURDATE(), INTERVAL 8 DAY) ";
                break;
            case 4:
                $sql.=" BETWEEN DATE_SUB(CURDATE(), INTERVAL 1 WEEK) AND CURDATE() ";
                break;
            case 5:
                $sql.=" !=0 AND MONTH(bh.request_date) = MONTH(CURDATE()) AND YEAR(bh.request_date) = YEAR(CURDATE()) ";
                break;
            case 6:
                $sql.=" BETWEEN DATE_FORMAT(NOW() - INTERVAL 1 MONTH, '%Y-%m-01 00:00:00') AND DATE_FORMAT(LAST_DAY(NOW() - INTERVAL 1 MONTH), '%Y-%m-%d 23:59:59')";
                break;
            case 7:
                $sql.=" BETWEEN '" . $datePeriod['from'] ."' AND '" . $datePeriod['to'] ."' ";
                break;
            case 8:
                $sql.=" ";
                break;
            default:
                break;
       }
       
       return $sql;
    }

    /**
     * @functionName    :   _setTimePeriodRange()
     * @param           :   array $datePeriod
     * @description     :   in function used to set the time period range based on the corporate
     * @return          :   int $range
     * @author Rajesh U
     */ 

    public function _setTimePeriodRange($datePeriod,$avoidFilter){
        
        if($avoidFilter != 'NODATERANGE'){

            $range = $datePeriod['range'] ? $datePeriod['range'] : 1;
        }

        return $range;
    }   

    /**
     * @functionName    :   _getNoShowRequestByDateRange()
     * @param           :   array $datePeriod
     * @description     :   get view request list for bookings raised based on filter
     * @return          :   string $sql
     * @author sivaprakash
     */         
    public function _getNoShowRequestByDateRange($datePeriod = '',$avoidFilter = ''){

        if($avoidFilter != 'NODATERANGE'){
            $range = $datePeriod['range'] ? $datePeriod['range'] : 1;
            $sql .= " AND DATE(apt.approve_sent_date) ";
        }
        if(!empty($datePeriod['active']) && $datePeriod['active'] == 'Reference'){
            $range = '';
        }
        switch ($range){
           case 1:
                $sql.=" = '" . date('Y-m-d') . "' ";
                break;
           case 2:
                $yesterday = date('Y-m-d', strtotime('-1 days'));
                $sql.=" = '" . $yesterday . "' ";
                break;
           case 3:
                $sql.="  BETWEEN DATE_SUB(CURDATE(), INTERVAL 14 DAY) AND DATE_SUB(CURDATE(), INTERVAL 8 DAY) ";
                break;
            case 4:
                $sql.=" BETWEEN DATE_SUB(CURDATE(), INTERVAL 1 WEEK) AND CURDATE() ";
                break;
            case 5:
                $sql.=" !=0 AND MONTH(apt.approve_sent_date) = MONTH(CURDATE()) AND YEAR(apt.approve_sent_date) = YEAR(CURDATE()) ";
                break;
            case 6:
                $sql.=" BETWEEN DATE_FORMAT(NOW() - INTERVAL 1 MONTH, '%Y-%m-01 00:00:00') AND DATE_FORMAT(LAST_DAY(NOW() - INTERVAL 1 MONTH), '%Y-%m-%d 23:59:59')";
                break;
            case 7:
                $sql.=" BETWEEN '" . $datePeriod['from'] ."' AND '" . $datePeriod['to'] ."' ";
                break;
            case 8:
                $sql.=" ";
                break;
            default:
                break;
       }
       
       return $sql;
    }
    
    /**
     * @functionName    :   _getApprovedBookingList()
     * @param           :   array $input
     * @param           :   string $approverBasedOn
     * @description     :   get approved list for bookings raised
     * @return          :   string $sql
     * @author sivaprakash
     */         
    public function _getApprovedBookingList($input = '',$approverBasedOn = 'orderId'){
        $sql = $approverBasedOn == 'packageId' ? " INNER JOIN approval_tracking apt ON apt.r_package_id = dmp.package_id " : " INNER JOIN approval_tracking apt ON apt.r_order_id = od.order_id ";
        $sql .= " AND apt.approval_view_status = 'Y' ";
        $sql .=  $input['r_employee_id'] ? " AND apt.approver_id =  '".$input['r_employee_id']."' " : '';
        
        return $sql;
    }
    
    /**
     * @functionName    :   _getApproverNameLevelForRequestBookingList()
     * @param           :   array $input
     * @description     :   get the name and approver level for the bookings of orderid
     * @return          :   string $sql
     * @author sivaprakash
     */         
    public function _getApproverNameLevelForRequestBookingList($input = ''){
        $sql = " SELECT CONCAT(title, '.', first_name, last_name) as approverName FROM dm_employee WHERE employee_id = ".$input['approver_account_id'];
        
        return $this->_OcommonDBO->_getResult($sql)[0]['approverName'];
    }
    
    /**
     * @functionName    :   _getCombinedQueryResult()
     * @param           :   string $sqlOne, $sqlTwo
     * @description     :   get result of two combined query 
     * @return          :   array executed query result
     * @author sivaprakash
     */         
    public function _getCombinedQueryResult($sqlOne,$sqlTwo){
        $this->_CcommonArrayFunction = new commonArrayFunctions();
        $queryOne = $this->_CcommonArrayFunction->_strReplace($this->_OorderByOrderId, "", $sqlOne);
        $queryTwo = $this->_CcommonArrayFunction->_strReplace($this->_OorderByOrderId, "", $sqlTwo);
        $orderBy  = $this->_CcommonArrayFunction->_strReplace('bh', "combineTwoQuery", $this->_OorderByOrderId);
        $sql = " SELECT combineTwoQuery.* FROM (".$queryOne. ' UNION ALL' .$queryTwo. ") combineTwoQuery ".$orderBy;
        return $this->_OcommonDBO->_getResult($sql);
    }
    
    /**
     * @functionName    :   _getInvoiceListDetails()
     * @param           :   string $bookingStatus
     * @param           :   arrray $input
     * @description     :   get result of invoice details
     * @return          :   array executed query result
     * @author sivaprakash
     */         
    public function _getInvoiceListDetails($bookingStatus,$input){
        $sql =" SELECT bh.travel_mode,bh.trip_type,bh.sector_from,bh.sector_to,
                DATE_FORMAT(bh.onward_depature_date,'".COMMON_DATE_FORMAT."') as 'travel_date',
                od.r_ticket_status_id as booking_status,od.order_id,od.total_amount,od.sync_order_id,
                od.sync_order_id as corpoartePackagereference,bh.package_id,pd.title,
                pd.first_name,pd.last_name,ds.status_value,ds.icon_class_name as icon_class,
                DATE_FORMAT(inv.created_date,'".COMMON_DATE_FORMAT."') as invoiceDate,dmp.package_type
                FROM booking_history bh 
                INNER JOIN dm_package dmp ON bh.package_id = dmp.package_id
                INNER JOIN fact_booking_details fbd ON bh.order_id = fbd.r_order_id 
                INNER JOIN order_details od ON fbd.r_order_id = od.order_id
                INNER JOIN dm_invoice inv ON fbd.r_invoice_id = inv.invoice_id 
                INNER JOIN passenger_details pd ON od.order_id = pd.r_order_id                    
                INNER JOIN passenger_via_details pvd ON pd.passenger_id = pvd.r_passenger_id ";
        $sql .=" ,dm_status ds";
        $sql .= $this->_ccheckCondition;
        $sql .= $this->_SstatusCheckForPostApproval;
        $sql .= $this->_getListTypeBookings($bookingStatus);
        $sql .= $this->_getBookingsBasedOnPermission($bookingStatus);
        $sql .= $this->_getRequestByDateRange($input);
        $sql .= $this->_OorderByOrderId;
        
        return $this->_OcommonDBO->_getResult($sql);
    }
    
    /**
     * @functionName    :   _getCreditNoteListDetails()
     * @param           :   string $bookingStatus
     * @description     :   get result of credit note details
     * @return          :   array executed query result
     * @author sivaprakash
     */         
    public function _getCreditNoteListDetails($bookingStatus,$input){
        $sql =" SELECT bh.travel_mode,bh.trip_type,bh.sector_from,bh.sector_to,
                DATE_FORMAT(bh.onward_depature_date,'".COMMON_DATE_FORMAT."') as 'travel_date',
                od.r_ticket_status_id as booking_status,od.order_id,od.total_amount,od.sync_order_id,
                od.sync_order_id as corpoartePackagereference,bh.package_id,pd.title,pd.first_name,pd.last_name,
                DATE_FORMAT(crd.creditnote_date,'".COMMON_DATE_FORMAT."') as creditNoteDate,tc.cancellation_id,dmp.package_type
                FROM booking_history bh 
                INNER JOIN dm_package dmp ON bh.package_id = dmp.package_id
                INNER JOIN order_details od ON bh.order_id = od.order_id
                INNER JOIN trans_cancellation tc ON tc.r_order_id = od.order_id
                INNER JOIN creditnote_details crd ON crd.r_cancellation_id = tc.cancellation_id 
                INNER JOIN passenger_details pd ON pd.r_order_id = od.order_id
                INNER JOIN cancellation_details cd ON cd.r_passenger_id = pd.passenger_id ";
        $sql .= $this->_ccheckCondition;
        $sql .= $this->_getListTypeBookings($bookingStatus);
        $sql .= $this->_getBookingsBasedOnPermission($bookingStatus);
        $sql .= $this->_getRequestByDateRange($input);
        $sql .= " GROUP BY tc.cancellation_id ORDER BY tc.cancellation_id DESC ";
        
        return $this->_OcommonDBO->_getResult($sql);
    }

    /**
     * @functionName    :   _getApproverDataList()
     * @param           :   $viewRequestData array
     * @description     :   get the name and approver level for the bookings of orderid
     * @return          :   $viewRequestData array
     */
    public function _getApproverDataList($viewRequestData){
        foreach ($viewRequestData as $key => $value){

            $viewRequestData[$key]['approverName'] = $value['approver_account_id'] != 0 ? $this->_getApproverNameLevelForRequestBookingList($value) : '-';
        }
        return $viewRequestData;
    }    

    /**
     * @functionName    :   _setPostBookingList()
     * @param           :   $viewRequestData array
     * @description     :   set post booking param data
     * @return          :   $viewRequestData array
     */

    public function _setPostBookingList(){
        $queryValue =" AND od.approval_status IN ( ".POSTAPPROVAL_APPROVED_BOOKINGS.",".POSTAPPROVAL_REJECTED_BOOKINGS.") AND od.r_ticket_status_id IN (".CANCELLED.",".PARTIALLY_CANCELLED.",".TICKETTED.",".PAID.",".PARTIAL_CANCEL_PROCESS.",".CANCEL_PROCESS.",".CANCELLATION_FAILURE.")  AND od.r_payment_status_id = ".PAYMENT_DONE." ";
        return $queryValue;
    }

    /**
     * @functionName    :   _setMyBookingList()
     * @param           :   $viewRequestData array
     * @description     :   get booking list param data
     * @return          :   $viewRequestData array
     */
    public function _setMyBookingList(){
        $queryValue =" AND od.approval_status = 0 AND od.r_ticket_status_id IN (".CANCELLED.",".PARTIALLY_CANCELLED.",".TICKETTED.",".PAID.",".PARTIAL_CANCEL_PROCESS.",".CANCEL_PROCESS.",".CANCELLATION_FAILURE." )  AND od.r_payment_status_id = ".PAYMENT_DONE." ";
        return $queryValue;
    }
    
    public function _getPostCancelRequest() {
        $sql =" AND od.approval_status = ".POSTAPPROVAL_APPROVED_BOOKINGS." AND od.r_ticket_status_id IN ( ".PARTIAL_CANCEL_PROCESS.",".TICKETTED.",".PARTIALLY_CANCELLED.",".CANCELLED.",".CANCEL_PROCESS.",".CANCELLATION_FAILURE." ) AND od.r_payment_status_id = ".PAYMENT_DONE." ";
        return $sql;
    }
    
    
    /**
     * Report file download
     */
    public function _fileDownload($action, $data, $report, $fileTypeId = 1){
                
        global $CFG;
        $this->_Oreport = new report();
        // $res = array_slice(array_keys($data[0]),1,15);
        // foreach ($data as $key => $value) {
        //     foreach ($value as $ikey => $ivalue) {
        //         if(!in_array($ikey,$res)){
        //             unset($data[$key][$ikey]);
        //         }
        //     }
        // }
        //set file name.
        $fileName = REPORTS_DIR.$report.'_'.date('d-m-Y').'_'.time();        
        if($fileTypeId == 1){
            $fileName .= '.csv';
        } 
        else{
            $fileName .= '.xlsx';
        } 
        
        $headerValue = array_flip(array_change_key_case(array_flip(array_keys($data[0])),CASE_UPPER));
        $this->_Oreport->_AheaderData = $headerValue;
        fileWrite($fileName,'fileName','a+');

        $this->_Oreport->_createCsvFile($data, $fileName,$fileTypeId);
        
        //Download details - send relative path to browser for donwload
        return $this->_Oreport->_exportReports($fileName);
    }


    /**
     * @param           :   $data array
     * @description     :   get airline info
     * @return          :   $data
     */
    public function _getFlightDetailsInfo($data){

        $_OflightItinerary = new flightItinerary();
        
        foreach($data as $key => $value){
            
            $airline = array();
            
            //get airline code info
            $data[$key]['airlineInfo']= $this->_Oairline->_getAllAirline($value['order_id']);

            //get onward and return airline
            $airlineCodeInfo = $this->_Oairline->_getAirlineCodeDetails($value['order_id']);
            foreach($airlineCodeInfo as $k => $val){
                $airline[$val['trip_type']][] = $val['airline_code'];
            }  
            
            //set airline code based on the trip type
            $data[$key]['airline_code'] = (isset($airline[1])) ? $airline[0][0].','.$airline[1][0] : $airline[0][0];

            //get PNR with respect to the order id.
            $data[$key]['pnr'] = $_OflightItinerary->_getOrderPNRdetails($value['order_id']);
        }
        return $data;
    }

    /**
    * @functionName    :   _displayApproverNameBasedWorkFlow()
    * @param           :   $viewRequestData array
    * @description     :   get approver name
    * @return          :   $viewRequestData array
    * @author          :   Karthika.M
    */
    public function  _displayApproverNameBasedWorkFlow($viewRequestData){
        

        //object creation.
        $this->_OapprovalTracking = new approvalTracking();
        
        foreach($viewRequestData as $key => $value){      
            
            //set the flag based on the work flow.
            if($value['workflow_caption'] == CMP_TICKET_APPROVAL){            
                $flag = ($value['approval_status'] == POSTAPPROVAL_NOT_APPROVED_BOOKINGS) ? 'PENDING_APPROVAL' : 'APPROVED';
            }
            else{
                $flag = ($value['booking_status'] == SEND_FOR_APPROVAL) ? 'PENDING_APPROVAL' : 'APPROVED';
            }
            
            //get the approver name based on the flag.
            if ($value['trip_flow_type'] == 'G') {
                 $approverId  = $this->_OapprovalTracking->_getTripCurrentApproverName($value['trip_id'])[0]['approver_id'];
                 $viewRequestData[$key]['approverName'] = ($approverId) ? $this->_getApproverNameLevelForRequestBookingList(array('approver_account_id' => $approverId)) : '-';
            }
            elseif($flag == 'PENDING_APPROVAL'){
                $approverId  = $this->_OapprovalTracking->_getCurrentApproverName($value['order_id'])[0]['approver_id'];
                $viewRequestData[$key]['approverName'] = ($approverId) ? $this->_getApproverNameLevelForRequestBookingList(array('approver_account_id' => $approverId)) : '-';
            }
            else{
                if($value['workflow_caption'] == CMP_TICKET_APPROVAL && $value['approval_status'] == POSTAPPROVAL_REJECTED_BOOKINGS){
                    $approverId  = $this->_OapprovalTracking->_getCurrentApproverName($value['order_id'])[0]['approver_id'];
                    $value['approver_account_id'] = $approverId ? $approverId : 0;
                }  
                $viewRequestData[$key]['approverName'] = $value['approver_account_id'] != 0 ? $this->_getApproverNameLevelForRequestBookingList($value) : '-';
             
            }
            $viewRequestData[$key]['approverFlowStatus'] = $this->_OapprovalTracking->_getCurrentOrderApprovalStatus($value['order_id']);

        }
        return $viewRequestData;
    }

    /**
    * @functionName    :   _displayApproverNameBasedWorkFlow()
    * @param           :   $viewRequestData array
    * @description     :   get approver name
    * @return          :   $viewRequestData array
    * @author          :   Karthika.M
    */
    public function  _displayApproverNameTripBasedWorkFlow($viewRequestData){  

        $this->_OcommonDomesticAirItineraryDisplay = common::_checkClassExistsInNameSpace('commonDomesticAirItineraryDisplay');

        //object creation.
        $this->_OapprovalTracking = new approvalTracking();
        
        foreach($viewRequestData as $key => $value){     

            //get the approver name based on the flag.
            if($value['status'] == TRIP_SEND_FOR_APPROVAL){
                $approverId  = $this->_OapprovalTracking->_getTripCurrentApproverName($value['trip_id'])[0]['approver_id'];
                $viewRequestData[$key]['approverName'] = ($approverId) ? $this->_getApproverNameLevelForRequestBookingList(array('approver_account_id' => $approverId)) : '-';
            }
            elseif($value['status'] == TRIP_CANCELLED) {
                 $approverId  = $this->_OapprovalTracking->_getTripCurrentApproverName($value['trip_id'])[0]['approver_id'];
                $viewRequestData[$key]['approverName'] = ($approverId) ? $this->_getApproverNameLevelForRequestBookingList(array('approver_account_id' => $approverId)) : 'Self Approved';
            }
            else{
                $viewRequestData[$key]['approverName'] = $value['approver_account_id'] != 0 ? $this->_getApproverNameLevelForRequestBookingList($value) : 'Self Approved';
            }

            $approvalSendDate = $this->_OcommonDomesticAirItineraryDisplay->_validateProceedBookExpire('reference_id',$value['trip_id'],'TRIP_APPROVAL');
            $timeExpire = '';
            if($approvalSendDate && $value['status'] == TRIP_SEND_FOR_APPROVAL && $value['approval_type'] != 1){
                $timeExpire = $this->_getApprovalExpireTime($approvalSendDate['approve_sent_date']);
            }
            elseif (!$approvalSendDate) {
                $timeExpire = 'selfApproval';
            }
            elseif($value['status'] == TRIP_SEND_FOR_APPROVAL && $value['approval_type'] == 1){
                $timeExpire = 'NoLimit';   
            }

            $viewRequestData[$key]['approverExpireTime'] = $this->_setTripExpireValue($timeExpire,$value['status'],$approvalSendDate['approved_date'],$value['approval_type']);
            $viewRequestData[$key]['approverExpireStatus'] = $viewRequestData[$key]['approverExpireTime'] == 'Approval time expired' ? 'Y' : '';
        }
        return $viewRequestData;
    }
    //overwrite function for iocl
    public function _checkApprovalActionExpire($viewRequestData){

        return $viewRequestData; 
    }

    /* 
     * @Function Name           : _getApprovalExpireTime
     * @Description             : this function used to get the approval expire time 
     * @Author                  : Rajesh U
     * @Created Date            : 03/07/2019
     */

    public function _getApprovalExpireTime($approvalDate){

        $date1 = strtotime($approvalDate);  
        $date2 = strtotime(date("Y-m-d H:i:s"));
        $timeDiff = abs($date2 - $date1); 
        $minutes = round($timeDiff/60);
        if( $minutes < APPROVER_ACTION_EXPIRE_TIME ){
            $seconds = APPROVER_ACTION_EXPIRE_TIME * 60 - $timeDiff;
            $dt1 = new DateTime("@0");
            $dt2 = new DateTime("@$seconds");
            return $dt1->diff($dt2)->format( '%H:%I:%S ');
        }
        else{
            return false;
        }
    }

    /* 
     * @Function Name           : _setTripExpireValue
     * @Description             : this function used to set the approval expire value 
     * @Author                  : Rajesh U
     * @Created Date            : 03/07/2019
     */

    public function _setTripExpireValue($expireTime,$tripStatus,$approvedDate,$approvalType){

        if($tripStatus == TRIP_SEND_FOR_APPROVAL && !$expireTime){
            $timeExpire = 'Approval time expired'; 
        }
        elseif($tripStatus == TRIP_SEND_FOR_APPROVAL && $approvalType != 1) {
            $timeExpire = $expireTime;
        }
        elseif($expireTime == 'selfApproval') {
            $timeExpire = '-';
        }
        elseif($expireTime == 'NoLimit') {
            $timeExpire = 'No Limit';
        }
        elseif($tripStatus == TRIP_CANCELLED){
            $timeExpire = '-';
        }
        else{
            $date=date_create($approvedDate);
            $timeExpire = date_format($date,"d-M-Y | H:i:s");  
        }

        return $timeExpire;

    }

}
