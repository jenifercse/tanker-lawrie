<?php
/****************************************************************************
 * @File             : class.flightSearchDetails.php
 * @Description      : This file is used to generate the flight search xml to get the data from service
 * @Tables Affected  : approval_tracking
 * @Author           : Sathees
 * @Created Date     : 31/01/2017
 * @Modified Date    : 
 *****************************************************************************/
fileRequire("./plugins/common/interface/commonConstants.php");
pluginFileRequire('airDomestic/corporate/harinim/', "config/config.inc.php");

class commonFlightSearchDetails implements commonConstants{

    public function __construct(){
        $this->_OcommonDBO = new commonDBO();
        $this->_OcommonQuery = common::_checkClassExistsInNameSpace('commonQuery');
        $this->_OtripCreation = new tripCreation();
        $this->_OsendToApproval = common::_checkClassExistsInNameSpace('sendToApproval');    
        $this->commonInsertPrimaryBookingInfo = new commonInsertPrimaryBookingInfo();
    }
    
    /**
     * Method Name        : _getDisplayInfo
     * Desc               : To check the corporate is having markup fee or not
     * @access            : public
     * @param corporateid : Unique id of a corporate, default value is 0
     * @param cabinClass  : input parameters are ( 'E','B','F' ) E - Economy class , B - Business class , F - First class and default value is 'E'
     * @param emailId     : email id of the registered user
     * @param travelType  : input parameters are ( 'D','IN' ) D - Domestic , IN - Internatinal and default value is 'D'
     * @input param       : param={"mod":"flightSearch","method":"getFlightsList","parameter":{"corporateId":"3","cabinClass":"E","emailId":"balamurugan@atyourprice.in","origin":"MAA","destination":"DEL","onwardDate":"2015-08-25","tripType":"1","numOfPass":"1","returnDate":"2015-08-28"}}}
     * @return array
     */
    public function _getDisplayInfo(){            
        $workFlowCaption = $this->_OcommonQuery->_getWorkFlowForOrder($this->_IinputData['factBookingDetails']['r_order_id']);
        if($workFlowCaption == 'CMP_REQUEST_APPROVAL'){                                 
            $this->_IinputData['packageType'] = $this->_IinputData['packageDetails']['package_type'];
            $this->_IinputData['approvalSettingsCheckInfo'] = $this->_IinputData['requestApprovalSettingsInfo']['approvalSettingsCheckInfo'];
            //set inputs.
            $input = $this->_IinputData;
            if($this->_IinputData['approvalExist'] && $this->_IinputData['intimationApproverExist'] != 'Y'){
                $this->_OsendToApproval->_Otwig = $this->_Otwig; 
                $this->_OsendToApproval->_requestApprovalFlow($input);
                $this->_AserviceResponse = $this->_OsendToApproval->_AserviceResponse;
            }else{  
               //calling function for sending mail to intimation approver.
               if($input['intimationApproverExist'] == 'Y'){
                   $this->_OsendToApproval->_Otwig = $this->_Otwig;
                   $this->_OsendToApproval->_sendMailtoIntimationApprover($input);                        
               }   
               $this->_getFlightSearch($workFlowCaption);
            }
        }else{ 
            $this->_getFlightSearch($workFlowCaption);
        }
        // assigning fact employee id from based on value from request variable or server variable
        $this->_AtwigOutputArray['factEmployeeId'] = $_SESSION['factEmployeeId'] ? $_SESSION['factEmployeeId'] : $_REQUEST['factEmployeeId'];
        $this->_AserviceResponse['expWorkFlow'] = $workFlowCaption;
        $this->_AserviceResponse['showDetails'] = $this->_IinputData['showRequestDetails'];
        //setting data for flight Search from FLight search for content id to proceed flight search
        $this->_AserviceResponse['contentIDFlightSearch'] = $this->_IinputData['factBookingDetails']['r_package_id'].":".$this->_IinputData['factBookingDetails']['r_order_id'].":".$this->_IinputData['packageDetails']['package_type'].":".$this->_IinputData['masterInfo']['requestTableData']['travel_type'].":".$this->_IinputData['masterInfo']['requestTableData']['trip_type'];
        
        $resultResponse = $this->getCorporateSettings($this->_IinputData['factBookingDetails']['r_corporate_id']);


        if($this->_IinputData['masterInfo']['requestTableData']['travel_type'] == 'D' && $this->_IinputData['masterInfo']['requestTableData']['trip_type'] == 0){
            $resultResponse['settings']['CORPORATEFARE_250'] == 'YES' ? $this->_AserviceResponse['corporateFareScenario'] =  'YES' : $this->_AserviceResponse['corporateFareScenario'] = 'NO';
        }else{
            $this->_AserviceResponse['corporateFareScenario'] =  'NO';
        }
        $this->_AserviceResponse['discountCalculation'] = $resultResponse['settings']['DISCOUNT_FEE_CALCULATION'] == 'YES' ? 'YES' : 'NO';
        // based on settings assginig value for non refundable fare for yes or no
         $this->_AserviceResponse['validAdvancedSearchDetails']=$this->_IinputData['masterInfo']['validAdvancedSearchDetails'];
         if($this->_IinputData['quickSearchFlag'] == 'show'){
            $this->_AserviceResponse['requestLevelInsetedData']['masterInfo'] = $this->_IinputData['masterInfo'];
            $this->_AserviceResponse['requestLevelInsetedData']['travelModeType'] = 1;
        } 
        $this->_AserviceResponse['NONREFUNDABLEFARE'] =  $resultResponse['settings']['NONREFUNDABLEFARE'] == 'YES'  ? 'YES' : 'NO' ;
        $this->_AtwigOutputArray['booking_mode'] = $this->_OcommonDBO->_select('dm_package','booking_mode','package_id',$this->_IinputData['factBookingDetails']['r_package_id']);
    }
    /**
     * common function used to get flight search data 
     * @param array $value
     * @param array $requestDetails
     * @param int $key
     * @return array
     * @author Baskar.V.P
     */
    public function _getFlightSearch($workFlowCaption){
        //Check for the session
        if(isset($_SESSION['corporateId'])&&!empty($_SESSION['corporateId'])){
            if(count($this->_IinputData)>0){
                $this->_getCorporateFareProfileSettings();

                //Set the flight input data to class variables
                $this->_getFlightRequestData($this->_IinputData);
                //Get URL for including files in js during flight search
                $this->_getFlightTemplateUrl($workFlowCaption);
                //Generat the flight search xml
                $this->_getSearchXml();
            }
        }
        $this->_AserviceResponse['status'] = array(
                                            'status_code'    => 0, 
                                            'status_message' => 'success', 
                                            'error_alert'    => 'BOOK',
                                            'package_id' =>  $this->_IinputData['factBookingDetails']['r_package_id']
                                            );
    }
        
    /**
     * common function used to form a template URL 
     * @param array $value
     * @param array $requestDetails
     * @param int $key
     * @return array
     * @author Baskar.V.P
     */
    public function _getFlightTemplateUrl($workFlowCaption){
        global $CFG;
        $url=array();
        $plugin = OVERRIDE_PACKAGE_NAME == 'loreal' ? 'loreal' : 'harinim';
        $this->_AserviceResponse['showFare'] = OVERRIDE_PACKAGE_NAME == 'ongc' ? 'YES' : 'NO';
        $templateFolderPath ='view/corporate/'.$plugin.'/html/flightSearch';
        //common url's
        $url['PROGRESSBAR'] = $templateFolderPath.'/common/progressBar.html';
        $url['travelClassModify'] = $templateFolderPath.'/common/modifyTravelClass.html';
        $this->_CsearchTripType =$this->_IinputData['masterInfo']['requestTableData']['trip_type'];
        $this->_IinputData['travel_mode'] = $this->_IinputData['travel_mode'] ? $this->_IinputData['travel_mode'] : $this->_IinputData['masterInfo']['requestTableData']['travel_type'];
        switch(true){
            case ($this->_IinputData['travel_mode'] =='I' && ($this->_IinputData['masterInfo']['requestTableData']['trip_type']=='0' || $this->_IinputData['masterInfo']['requestTableData']['trip_type']=='1')):
                // onward international url's
                $url['ONWARDFLIGHTSEARCHURL'] = $templateFolderPath.'/onward/searchInt.html';
                //$url['ONWARDFLIGHTLIST'] = $templateFolderPath.'/onward/onwardFlightList.html';
                $url['ONWARDFLIGHTLIST'] = file_exists($CFG['path']['basePath'].'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/onward/onwardFlightList.html') ? 'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/onward/onwardFlightList.html' : 'view/corporate/harinim/html/flightSearch/onward/onwardFlightList.html';

                //$url['ONWARDCHOOSENFLIGHT'] = $templateFolderPath.'/onward/selectedFlight.html';
                $url['SUBMITFLIGHTURL'] =  file_exists($CFG['path']['basePath'].'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/onward/submitFlight.html') ? 'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/onward/submitFlight.html' : 'view/corporate/harinim/html/flightSearch/onward/submitFlight.html';
                $url['ONWARDCHOOSENFLIGHT'] = file_exists($CFG['path']['basePath'].'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/onward/selectedFlight.html') ? 'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/onward/selectedFlight.html' : 'view/corporate/harinim/html/flightSearch/onward/selectedFlight.html';
                $this->_AtwigOutputArray['flightSearchUrl'] = $url['ONWARDFLIGHTSEARCHURL'];
                break;
            case ($this->_IinputData['travel_mode'] =='D' && $this->_IinputData['masterInfo']['requestTableData']['trip_type']=='0'):
                // onward domestic url's
                $url['ONWARDFLIGHTSEARCHURL'] =$templateFolderPath.'/onward/searchDom.html';
                //$url['ONWARDFLIGHTLIST'] =$templateFolderPath.'/onward/onwardFlightList.html';
                $url['ONWARDFLIGHTLIST'] = file_exists($CFG['path']['basePath'].'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/onward/onwardFlightList.html') ? 'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/onward/onwardFlightList.html' : 'view/corporate/harinim/html/flightSearch/onward/onwardFlightList.html';

                $url['ONWARDCHOOSENFLIGHT'] = file_exists($CFG['path']['basePath'].'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/onward/selectedFlight.html') ? 'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/onward/selectedFlight.html' : 'view/corporate/harinim/html/flightSearch/onward/selectedFlight.html';
                //$url['ONWARDCHOOSENFLIGHT'] = $templateFolderPath.'/onward/selectedFlight.html';
                $url['SUBMITFLIGHTURL'] = file_exists($CFG['path']['basePath'].'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/onward/submitFlight.html') ? 'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/onward/submitFlight.html' : 'view/corporate/harinim/html/flightSearch/onward/submitFlight.html';
                $this->_AtwigOutputArray['flightSearchUrl'] = $url['ONWARDFLIGHTSEARCHURL'];
                break; 
            case ($this->_IinputData['masterInfo']['requestTableData']['trip_type'] == 1 && $this->_IinputData['travel_mode'] == 'D'):
                //$url['RETURNCHOOSENFLIGHT'] = $templateFolderPath.'/return/selectedFlight.html';
                $url['RETURNCHOOSENFLIGHT'] = file_exists($CFG['path']['basePath'].'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/return/selectedFlight.html') ? 'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/return/selectedFlight.html' : 'view/corporate/harinim/html/flightSearch/return/selectedFlight.html';
                //$url['RETURNFLIGHTSEARCHURL'] = $templateFolderPath.'/return/returnSearch.html';
                $url['RETURNFLIGHTSEARCHURL'] = file_exists($CFG['path']['basePath'].'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/return/returnSearch.html') ? 'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/return/returnSearch.html' : 'view/corporate/harinim/html/flightSearch/return/returnSearch.html';

                $url['SUBMITFLIGHTURL'] = file_exists($CFG['path']['basePath'].'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/return/submitFlight.html') ? 'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/return/submitFlight.html' : 'view/corporate/harinim/html/flightSearch/return/submitFlight.html';

                $this->_AtwigOutputArray['flightSearchUrl'] = $url['RETURNFLIGHTSEARCHURL'];
                break;
            case ($this->_IinputData['masterInfo']['requestTableData']['trip_type'] == 2 && $this->_IinputData['travel_mode'] == 'D'):
                //Multicity url's
                //$url['MULTISEARCHCHOOSENFLIGHT']  = $templateFolderPath.'/multiCity/selectedFlight.html';
                $url['MULTISEARCHCHOOSENFLIGHT'] = file_exists($CFG['path']['basePath'].'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/multiCity/selectedFlight.html') ? 'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/multiCity/selectedFlight.html' : 'view/corporate/harinim/html/flightSearch/multiCity/selectedFlight.html';

                $url['MULTISEARCHFLIGHTSEARCHURL'] = $templateFolderPath.'/multiCity/search.html';
                
                $url['MULTISEARCHFLIGHTRESPONSEURL'] = file_exists($CFG['path']['basePath'].'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/multiCity/response.html') ? 'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/multiCity/response.html' : 'view/corporate/harinim/html/flightSearch/multiCity/response.html';
                $url['SUBMITFLIGHTURL'] = file_exists($CFG['path']['basePath'].'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/multiCity/submitFlight.html') ? 'view/corporate/'.OVERRIDE_PACKAGE_NAME.'/html/flightSearch/multiCity/submitFlight.html' : 'view/corporate/harinim/html/flightSearch/multiCity/submitFlight.html';
                $this->_AtwigOutputArray['flightSearchUrl'] = $url['MULTISEARCHFLIGHTSEARCHURL'];  
                break;
        }
        $this->_AserviceResponse['flightSearchUrl']  = $this->_AtwigOutputArray['flightSearchUrl'];
        $this->_AserviceResponse['showSectorStrip'] = $this->_AtwigOutputArray['showSectorStrip'] = 'Y';
        $this->_SdisplayUrl = $url;
    }
    
    /**
     * common function used to get requested data for to call request data
     * @param array $value
     * @param array $requestDetails
     * @param int $key
     * @return array
     * @author Baskar.V.P
     */
    public function _getFlightRequestData($inputData){
        //Request data for flight search list
        $this->_OapplicationSettings = new applicationSettings();
        $this->_AtwigOutputArray['bookFlightRequest'] = $inputData['bookFlightRequest'] ? $inputData['bookFlightRequest'] : '';

        $this->_requestData['passengers'] = array(
                                    'adult'=> (isset($inputData['updatePassenger']) && $inputData['updatePassenger']['onward']!='') ? $inputData['masterInfo']['requestTableData']['adult_count'] : $inputData['adult_count'],
                                                'child'=>(isset($inputData['updatePassenger']) && $inputData['updatePassenger']['onward']!='') ? $inputData['masterInfo']['requestTableData']['child_count'] : $inputData['child_count'],
                                                'infant'=>(isset($inputData['updatePassenger']) && $inputData['updatePassenger']['onward']!='') ? $inputData['masterInfo']['requestTableData']['infant_count'] : $inputData['infant_count']
                                                ); // 1 0 0

        $this->_requestData['date']['onward'] = $inputData['airRequestDetails'][0]['requestTableData']['onward_date'];
        $this->_requestData['date']['return'] = $inputData['masterInfo']['requestTableData']['return_date'];
        
        //Request data
        $this->_requestData['cabinclassTrigger'] = $inputData['masterInfo']['cabinClass'][1];
        $this->_requestData['cabinclassTotal'] = $this->_OcommonQuery->_setCabinClass($inputData['masterInfo']['cabinClass'][1]);
        $this->_requestData['refundableFare'] = 'N'; 
        $this->_requestData['agentId'] = SERVICE_AGENCY_ID;
        $this->_requestData['currency_type'] = 'INR';

        if(isset($inputData['masterInfo']['requestTableData']['trip_type']) && ($inputData['masterInfo']['requestTableData']['trip_type'] == 0 || $inputData['masterInfo']['requestTableData']['trip_type'] == 1)){
            $this->_requestData['sector']['origin'] = $inputData['airRequestDetails'][0]['originCode'];
            $this->_requestData['sector']['destination'] = $inputData['airRequestDetails'][0]['destinationCode'];
        }

        $this->_requestData['types']['requestedAirline'] = $inputData['requestedAirline'] ? $inputData['requestedAirline'] : $GLOBALS['custom']['SBAirlines'];
        $this->_requestData['types']['blockedAirlines'] = $GLOBALS['custom']['CTBlockedAirlines'];

        foreach ($this->_AserviceResponse['fareProfileSettings']['Businsess_class_Settings'] as $key => $value) {
            $this->_requestData['bookingClassData'][$key] = explode(",",$value);
        }
        
        //promocode data
        $requestedData['cabinClass'] = $inputData['masterInfo']['cabinClass'][0];
        $requestedData['travelMode'] = $inputData['masterInfo']['r_travel_mode_id'];
        
        $this->_requestData['requestId'] = $inputData['factBookingDetails']['r_order_id'];
        $this->_requestData['versionCode'] = VERSION_CODE; 

        $this->_requestData['promoCode']['airline'] = $this->_OcommonQuery->_discountFareFlightsPromoCode($this->_requestData['date']['onward'],'',$inputData['factBookingDetails']['r_corporate_id'],$requestedData,'', $inputData['factBookingDetails']['r_order_id']);

        $this->_AserviceResponse['flightRequestData'] = $this->_requestData;

        // for mark up and mark low fare array formation
        $this->_AserviceResponse['requestXML'] =  $this->_markUp;
        
        //Tax code from config 
        $this->_AserviceResponse['configTaxCode'] = $GLOBALS['custom']['AIRLINETAXTOBASEFARE'];
        $sysParamValue =  $this->_OapplicationSettings->_getTaxValues($this->_SsystemParameters,0);
        if($sysParamValue != ''){
            $this->_AserviceResponse['serviceTaxPercent'] = $sysParamValue;
        } 
            $this->_AserviceResponse['quickSearchFlag'] = (isset($inputData['quickSearchFlag']) && $inputData['quickSearchFlag']!='') ? TRUE : FALSE;
        
        //Generate Multicity array for flight search
        if(isset($inputData['masterInfo']['requestTableData']['trip_type']) && $inputData['masterInfo']['requestTableData']['trip_type'] == 2){
           foreach ($inputData['airRequestDetails'] as $key => $value){
              $this->_AserviceResponse['multiCity'][$key]['origin'] = $inputData['airRequestDetails'][$key]['originCode'];
              $this->_AserviceResponse['multiCity'][$key]['destination'] = $inputData['airRequestDetails'][$key]['destinationCode'];
              $this->_AserviceResponse['multiCity'][$key]['onwardDate'] = $inputData['airRequestDetails'][$key]['requestTableData']['onward_date'];
              $this->_AserviceResponse['multiCity'][$key]['requestCount'] = $key+1;
              $orderIdM = $inputData['multiCityOrderDetails'][$key] ? $inputData['multiCityOrderDetails'][$key] : $inputData['orderId'][$key];
              $this->_AserviceResponse['multiCity'][$key]['contentId'] = 
              $inputData['factBookingDetails']['r_package_id'].":".$orderIdM.":1:".$inputData['masterInfo']['requestTableData']['travel_type'].":".$inputData['masterInfo']['requestTableData']['trip_type'];
              $this->_AserviceResponse['multiCity'][$key]['multiCitycabinClass'] =$this->getTravelClass($orderIdM);
              $this->_AserviceResponse['multiCity'][$key]['onwardTimeStart'] = $inputData['masterInfo'][
              'advancedsearch']['onwardTimeStart'][$key];
            }
        }

        $this->_AserviceResponse['TRAVELPORT_API'] = array_values($_SESSION['userApplicationSettings']['TRAVELPORT_API']);
        fileWrite(print_r($this->_AserviceResponse,1),'promocodecheck','a+'); 
        return true;
    }
    
    /**
     * function used to get fare profile settings based on corporate
     * @param 
     * @param array $requestDetails
     * @param int $key
     * @return array
     * @author Baskar.V.P
     */
    public function _getCorporateFareProfileSettings(){

       $this->_AserviceResponse['fareProfileSettings'] = $this->_OcommonQuery->_getSettingsDisplayData($this->_IinputData['factBookingDetails']['r_package_id'], 'Flight_Search_Configurations','','',$this->_IinputData['masterInfo']['advancedsearch']['guestFlowType']);

       $travelClassFareProile = $this->_OcommonQuery->_getSettingsDisplayData($this->_IinputData['factBookingDetails']['r_package_id'], 'Request_Form_Configurations');

       $airline = new airline();
       //Travel Mode 1 : Domestic Air | Travel Mode 2 : International
       $domesticClass = $airline->_getTravelClassInformation(1)[1];
       $this->_AserviceResponse['domesticClass'] = $domesticClass;
       foreach ($travelClassFareProile['Cabin'] as $key => $value){
           $keyValue = str_split($key, 1);
           if($value == 'Y' ){
               $travelClassCount[] = $value;
           }
           $travelClassFareProileData['Cabin'][$keyValue[0]] = $value;
       }
       // assigining value to service response fare profile settings travel class
       $this->_AserviceResponse['fareProfileSettingsTravelClass'] = $travelClassFareProileData;
       // assigining _getFareSettingsToDisplay
       $this->_AserviceResponse['displayFareProfileSettings'] = $this->_getFareSettingsToDisplay($this->_AserviceResponse['fareProfileSettings']);
       $this->_AserviceResponse['displayFareProfileSettings']['name'] = $this->_OcommonQuery->_settingNamePassing;
       
       return true;
    }
    
    /**
     * function used to get airline id for the specific airline value
     * @param array $airLineCode
     * @param int $key
     * @return array
     * @author Baskar.V.P
     */
    public function _getAirlineId($airLineCode){
        $result = $this->_Oairline->_getAirlineCodeInfo($airLineCode);
        if(!empty($result) && count($result)>0){
           return $result[0]['airline_id'];
        }else{
           return false;
        }
    }
    
    /**
     * function used to get airline id for the specific airline value
     * @param array 
     * @param int $key
     * @return array
     * @author Baskar.V.P
     */
    public function _getSearchXml(){
        //xml variables declared
        $this->_AserviceResponse['markUpXml']='EMPTY';
        //Get Corporatefare XML
        $this->_CrefundableSearch='N';
        if(isset($this->_IinputData['factBookingDetails']['r_package_id'])){
            $this->_IinputData['factBookingDetails']['r_package_id'] ? $this->_AserviceResponse['packageId'] = $this->_IinputData['factBookingDetails']['r_package_id'] : FALSE;
        }
        $this->_AserviceResponse['tripType']=$this->_CsearchTripType;
        $this->_AserviceResponse['travelInfo']['adult'] =$this->_IadultCount;
        $this->_AserviceResponse['travelInfo']['child'] =$this->_IchildCount;
        $this->_AserviceResponse['travelInfo']['infant'] =$this->_IinfatnCount;
        $this->_AserviceResponse['url'] = $this->_SdisplayUrl;
        return true;
    }
    
    /**
     * function used to get mark up and mark down charges based on corporate
     * @param array 
     * @param int $key
     * @return array
     * @author Baskar.V.P
     */        
    public function _getMarkUpMarkDownFareFee($corporateDetails = ''){

        $this->_Opackage = new package();

        if(!isset($corporateDetails['r_corporate_id']) || !isset($corporateDetails['sync_corporate_id'])) {
            $corporateDetails = $this->_Opackage->_getCorporateAdminDetails($this->_IinputData['factBookingDetails']['r_order_id'])[0];
        } 

        // array formation for mark up and mark down charges query formation..
        $markfare['markUpMarkDown']['corporateId']     = $corporateDetails['r_corporate_id'];
        $markfare['markUpMarkDown']['syncCorporateId'] = $corporateDetails['sync_corporate_id'];

        $markfare['markUpMarkDown']['agencyId'] = $_SESSION['agencyId'] ? $_SESSION['agencyId'] : $_REQUEST['agencyId'];
        $markfare['markUpMarkDown']['classType'] = $this->_OcommonDBO->_select('dm_travel_class', 'class_code', 'travel_class_id',$this->_IinputData['masterInfo']['cabinClass'][0])[0]['class_code'];
        
        //set travel type based on input value set
        $markfare['markUpMarkDown']['travelType'] = ($this->_IinputData['travelModeType'] == 0 || $this->_IinputData['travelModeType'] == 1) ? 'D' : '';
        
        //set modeType based on input value set
        $markfare['markUpMarkDown']['modeType'] = ($this->_IinputData['travelModeType'] == 0 || $this->_IinputData['travelModeType'] == 1) ? 'Air' : '';
        
        fileRequire('classes/class.sync.php');
        $sync = new sync(); 
        
        $this->_markUp = $sync->_getMarkUpMarkdownFee($markfare);

        if(isset($this->_markUp['responseData']['MarkupAmount']['airline']) && $this->_markUp['responseData']['MarkupAmount']['airline']!=''){
            foreach ($this->_markUp['responseData']['MarkupAmount']['airline'] as $key => &$value){
                $value['markKey'] ='Up';
            }
        }
        if(isset($this->_markUp['responseData']['MarkDownAmount']['airline']) && $this->_markUp['responseData']['MarkDownAmount']['airline']!='' ){
            foreach ($this->_markUp['responseData']['MarkDownAmount']['airline'] as $key => &$value){
                $value['markKey'] ='Down';
            }
        }
        // result array merged to one key with mark down and mark up data
        if(isset($this->_markUp['responseData']['MarkDownAmount']['airline']) && $this->_markUp['responseData']['MarkDownAmount']['airline']!='' && isset($this->_markUp['responseData']['MarkupAmount']['airline']) && $this->_markUp['responseData']['MarkupAmount']['airline']!='')
        {
            $resultValue = array_merge($this->_markUp['responseData']['MarkDownAmount']['airline'],$this->_markUp['responseData']['MarkupAmount']['airline']);
        }elseif(isset($this->_markUp['responseData']['MarkDownAmount']['airline']) && $this->_markUp['responseData']['MarkDownAmount']['airline']!='' ){
            $resultValue = $this->_markUp['responseData']['MarkDownAmount']['airline'];
        }else{
            $resultValue = $this->_markUp['responseData']['MarkupAmount']['airline'];
        }
        
        return $resultValue;
    }  
    
    /**
     * function  used to insert the request level data for the flighr search details through sso log in
     * @param array 
     * @param int $key
     * @return array
     * @author  
     */   
    public function _insertAirRequestDetails($ssoInputData){

        $this->_OcommonFlightSearchRequestInsert = common::_checkClassExistsInNameSpace('commonFlightSearchRequestInsert');
        
        $this->_Opackage = new package();

        $this->_OcommonQuery = new commonQuery();

        $packageInsertBookingMode = array('Online'=> '0', 'Offline'=> '1', 'Mobile'=> '2');
        
        $insertAirRequest = $insertPassenger = array();$i = 0;
        $orderInsertId = $airRequestInsertId = $passengerDetailsId = '';
        if(isset($ssoInputData['tripDetails']) && count($ssoInputData['tripDetails']) > 0){
            
            if($ssoInputData['tripFormDetails']['tripId']!=''){
                $tripID = $ssoInputData['tripFormDetails']['tripId'];
            }else{
                $tripID =  $this->_insertTripDetails($ssoInputData['tripDetails'])['tripId'];
            }
        }
        // insert dm_package details        
        $packageInsertId = $this->_OcommonDBO->_insert('dm_package' ,array('requested_by'=> $ssoInputData['loginEmail'], 'r_fact_employee_id'=> $ssoInputData['factEmployeeId'] ? $ssoInputData['factEmployeeId'] : $_SESSION['factEmployeeId'], 'package_type'=> $ssoInputData['packageType'], 'booking_type'=> $ssoInputData['bookingType'], 'booking_mode'=> $packageInsertBookingMode[$ssoInputData['requestBookingType']], 'created_date'=> date('Y-m-d H:i:s')));

        if(!$packageInsertId){
            throw new Exception("Package not created");
        }
        
        //insert into sap_request_details
        $meetingDetails = $ssoInputData['meetingDetails'];
        $approverDetails = $ssoInputData['approverDetails'];
        
        //Get employee cost center code
        $this->_Oemployee = new employee();
        $costCenterId = $this->_Oemployee->_insertCostcenterCodeDetails(array('cost_center_code' => $meetingDetails['cost_center_code']),$ssoInputData['corporate_id']);
        
        $sapRequestDetails = array(
            'sap_request_id'=> $meetingDetails['sapRequestId'] ? $meetingDetails['sapRequestId'] : 0,
            'r_package_id'=> $packageInsertId,
            'city' => $meetingDetails['city'],
            'country' => $meetingDetails['country'],
            'r_cost_center_code_id' => $costCenterId,
            'approver_employee_code' => $approverDetails['approverEmpCode'],
            'approver_name' => $approverDetails['approverName'],
            'approver_mobile_no' => $approverDetails['approverMobileNumber'],
            'approver_remarks' => $approverDetails['approverRemarks'],
            'meeting_details' => isset($ssoInputData['originalData']['MeetingDetails'])?json_encode($ssoInputData['originalData']['MeetingDetails']):NULL,
            'created_date' => date('Y-m-d H:i:s')
        );
        
        $sapRequestId = $this->_OcommonDBO->_insert('sap_request_details',$sapRequestDetails);
        if(!$sapRequestId){
            throw new Exception("SAP request not created");
        }
        
        for($i; $i <= $ssoInputData['count']; $i++){
            // prepare array based on the given sector count as from sso array data            
            $insertAirRequest['r_origin_airport_id'] = $this->_getCityCodeAirportId($ssoInputData['origin'.$i]['cityCode'],$ssoInputData['originDetails'.$i]);
            $insertAirRequest['r_destination_airport_id'] = $this->_getCityCodeAirportId($ssoInputData['destination'.$i]['cityCode'],$ssoInputData['destinationDetails'.$i]);
            $insertAirRequest['r_travel_class_id'] = explode(':',$ssoInputData['travelClass'])[0];
            
            $insertAirRequest['num_passenger'] = $ssoInputData['num_passenger'];
            $insertAirRequest['adult_count'] = $ssoInputData['adult'];
            $insertAirRequest['trip_type'] = $ssoInputData['triptype'] == 2 ? 0 : $ssoInputData['triptype'] ;
            
            $insertAirRequest['onward_date'] = $ssoInputData['onwardDate'.$i];
            $insertAirRequest['return_date'] = ($ssoInputData['triptype'] == 1) ? $ssoInputData['endDate'] : FALSE;
            $insertAirRequest['travel_type'] = $ssoInputData['travelMode'];
            $insertAirRequest['created_date'] = date('Y-m-d H:i:s');
            //insert departure window time
            $ssoInputData['onwardTimeStart'] = $ssoInputData['onwardTimeStart'];
            $ssoInputData['returnTimeStart'] = $ssoInputData['returnTimeStart'];
            $insertAirRequest['customize_fields'] = json_encode(array('onwardTimeStart' => $ssoInputData['onwardTimeStart'], 'returnTimeStart' => $ssoInputData['returnTimeStart']));
            
            // insert air request details            
            $airRequestInsertId = $this->_OcommonDBO->_insert('air_request_details' ,$insertAirRequest);
            if(!$airRequestInsertId){
                throw new Exception("Air request not created");
            }
            unset($insertAirRequest);

            $orderId = $this->_Opackage->_getPaidPackageDetails($packageInsertId);
            $updateInput = array_column($orderId, 'r_order_id');
            //update workflow in order_details, which is set in the session based on the corporate.
            $this->_workFlowCaption = $this->_OcommonQuery->_updateWorkFlowForOrder($updateInput);

            $sql = "SELECT workflow_id from dm_workflow WHERE workflow_name = '".SBI_ITINERARY_FLOW."'";
            
            $getWorkFlowId = $this->_OcommonDBO->_getResult($sql)[0]['workflow_id'];

            // insert order detail and air booking details
            $orderInsertIds[] = $orderInsertId = $this->_OcommonDBO->_insert('order_details' ,array('r_travel_mode_id'=> $ssoInputData['r_travel_mode_id'], 'r_payment_status_id'=> PAYMENT_NOT_DONE, 'r_ticket_status_id'=> REQUESTED, 'r_workflow_id' => $getWorkFlowId, 'r_currency_type_id' => DEFAULT_CURRENCY_ID, 'workflow_caption' => CMP_TICKET_APPROVAL, 'created_date'=> date('Y-m-d H:i:s')));                  
            

            $this->_OcommonFlightSearchRequestInsert->_factTripOrderInsert($tripID,$packageInsertId,$orderInsertId);
            
            // insert fact booking details
            $agencyId = $ssoInputData['agency_id'] ? $ssoInputData['agency_id']: $ssoInputData['agencyId'];
            $factBookingDetailsId = $this->_OcommonDBO->_insert('fact_booking_details' ,array('r_order_id'=> $orderInsertId, 'r_package_id'=> $packageInsertId, 'r_corporate_id'=> $ssoInputData['corporate_id'], 'r_agency_id' =>$agencyId, 'r_request_id'=> $airRequestInsertId, 'travel_mode'=> $ssoInputData['r_travel_mode_id'], 'r_employee_id'=> $ssoInputData['employeeId'] ? $ssoInputData['employeeId'] : $_SESSION['employeeId']));
            if(!$factBookingDetailsId){
                throw new Exception("Fact booking details not created");
            }
            
            //SAP Request segment id insertion for online booking
            if($packageInsertBookingMode[$ssoInputData['requestBookingType']] =='0' ){
                $segmentDetails = array(
                    'r_package_id'  => $packageInsertId,
                    'r_order_id'    => $orderInsertId,
                    'onward_sequence_no'    => $ssoInputData['seqNo'.$i],
                    'return_sequence_no'    => $ssoInputData['rSeqNo'.$i]
                );

                $sapSegmentId = $this->_OcommonDBO->_insert('sap_sequence_details',$segmentDetails);
                if(!$sapSegmentId){
                    throw new Exception("Segment id not created");
                }
            }
            
            foreach ($ssoInputData['passengerDetails'] as $key => $passenger){
                // array formation for passenger details             
                $insertPassenger['ADT'][$key] = array(
                    'r_employee_id'  => $passenger['employeeId'] ? $passenger['employeeId'] : $_SESSION['employeeId'],
                    'title'          => $passenger['title'],
                    'passenger_type' => $passenger['passenger_type'],
                    'first_name'     => $passenger['first_name'],
                    'last_name'      => $passenger['last_name'],
                    'employee_code'  => $passenger['employeeCode'],
                    'mobile_no'      => $passenger['mobile_number'],
                    'email_id'       => $passenger['emailId'],
                    'DOB'            => $passenger['DOB'],
                    'department_name'  => $passenger['department'],
                    'designation_name' => $passenger['position'],
                    'band'           => $passenger['band'],
                    'branch_name'    => $passenger['branch'],
                    'created_date'   => date('Y-m-d H:i:s'),
                    'cost_center'    => $meetingDetails['cost_center_code'],
                    'aadhar_number'  => '',
                    'city'           => $passenger['city'],
                    'country'        => $passenger['country'],
                    'pin_code'       => $passenger['zipCode'],
                    'contact_no'     => $passenger['contactNo'],
                    'alternate_email_id' => $passenger['alternate_email_id'],
                    'is_manager' => $passenger['is_manager']
                );
                
                // array preparation and calling function to insert passenger deytails
                $this->commonInsertPrimaryBookingInfo->_IinputData['order_id'] = $orderInsertId;
                $passengerIds = $this->commonInsertPrimaryBookingInfo->_insertpassenger($insertPassenger);
                if(empty($passengerIds)){
                    throw new Exception("Passengers not created");
                }
                unset($insertPassenger);
            }
        }

        $bookingHistoryIds = $this->_insertBookingHistory($orderInsertIds,$packageInsertId,$ssoInputData);
        if(empty($bookingHistoryIds)){
            throw new Exception("Booking history not created");
        }
        
        return $packageInsertId.':'.$orderInsertIds[0].':'.$ssoInputData['packageType'].':'.$ssoInputData['travelMode'].':'.$ssoInputData['triptype'];
    }
    
    /**
    * function used to insert data for booking history from sso login
    * @param array 
    * @param $orderArray,$packageId, $inputdata
    * @return array
    * @author  
    */   
    public function _insertBookingHistory($orderArray,$packageId,$inputdata){
        $bookingArray = $bokingId = array();
        // form array to insert booking history table        
        foreach ($orderArray as $key => $value){
            $bookingArray['r_booked_by'] = $_SESSION['factEmployeeId'] ? $_SESSION['factEmployeeId'] : $inputdata['factEmployeeId'];
            $bookingArray['r_corporate_id'] = $_SESSION['corporateId'] ? $_SESSION['corporateId'] : $inputdata['corporate_id'];
            $bookingArray['r_agency_id'] = $_SESSION['agencyId'] ? $_SESSION['agencyId'] : $inputdata['agency_id'];
            
            $bookingArray['package_id'] = $packageId;
            $bookingArray['order_id'] = $value;
            $bookingArray['travel_mode'] = $inputdata['travelMode'];
            
            $bookingArray['trip_type'] = $inputdata['triptype'];
            $bookingArray['sector_from'] = $inputdata['origin'.$key]['cityCode'];
            $bookingArray['sector_to'] = $inputdata['destination'.$key]['cityCode'];
            
            $bookingArray['onward_depature_date'] = $inputdata['onwardDate'.$key];
            ($inputdata['triptype'] == 1) ? $bookingArray['return_depature_date'] = $inputdata['endDate'] : FALSE;
            
            $bookingArray['no_of_passenger'] = $inputdata['num_passenger'];
            $bookingArray['adult'] = $inputdata['adult'];
            $bookingArray['request_date'] = $bookingArray['booking_date'] = date('Y-m-d H:i:s');
            $bookingArray['booking_type'] = $inputdata['bookingType'];
            // call functiontto insert booking histroy            
            $bokingId[] = $this->_OcommonDBO->_insert('booking_history', $bookingArray);
            unset($bookingArray);
        }
        
        return $bokingId;
    }
    
    /**
    * function  used to get the city code airport id
    * @param array 
    * @param $orderArray, $packageId, $inputdata
    * @return array
    * @author  
    */  
    public function _getCityCodeAirportId($cityCode,$dataArray){

        //check city code airport id exist 
        $dmAirporatId = $this->_OcommonDBO->_select('dm_airport', array('airport_id'), 'airport_code', $cityCode)[0]['airport_id'];
        
        //return existing airport id or return last inserted airport id
        if(!$dmAirporatId){
            $countryId = $this->_OcommonDBO->_select('dm_country', array('country_id'), 'country_code_ISO2', $dataArray['countryCode'])[0]['country_id'];
            $insertAirport = array(
                'airport_code'=> $dataArray['cityCode'], 
                'airport_desc'=> $dataArray['airport_desc'],
                'city_name'   => $dataArray['cityName'],
                'r_country_id'=> $countryId
            );
            $dmAirporatId = $this->_OcommonDBO->_insert('dm_airport', $insertAirport);
        }        
        return $dmAirporatId;
    }
   
    /**
    * fare settings to display in the header section 
    * @param type $settings
    * @return array
    * @Author:- Vishwa Raj
    */
    public function _getFareSettingsToDisplay($settings){

        $arrayLogic =array('Lowest_Fare_Display_Type','Source','Corporate_or_Retail_Fare_Comparison_amount','Low_fare_logic_amount');
        $finalArray = array();
        foreach ($settings as $key => $value){
            $finalArray[$key]= array();
            foreach ($value as $keySet => $valueSet){
                // check if the key is status or any other. If key == status then show YES/NO else show the key  
                if($valueSet!='N'){
                    if($keySet == 'status' && $valueSet == 'Y'){
                        $keySet = "YES";
                    }elseif ($keySet == 'status' && $valueSet == 'N'){
                        $keySet = "NO";
                    }elseif($keySet == 'textBoxValue'){
                        $keySet = 'Amount '.$valueSet;
                    }
                    array_push($finalArray[$key], $keySet);
                }
            }
        }
        $resultArray = array();
        foreach ($finalArray as $key => $value) {
          if(in_array($key,$arrayLogic)){
                if($key == 'Lowest_Fare_Display_Type'){
                  $resultArray['Flights Visible'][0] = $value[0] == 'Lowest_Fare' ? 'Lowest Low fare flights ('.$finalArray['Low_fare_logic_amount'][0].
                  ')' : 'Recommending lowfare flights with all flights';
                }
                if($key == 'Source'){
                  $resultArray['Source'][0] = implode(",",$value);
                }
                if($key == 'Airlines'){
                  $resultArray['Ailines from'][0] = implode(",",$value);
                }
                if($key == 'Corporate_or_Retail_Fare_Comparison_amount'){
                  $resultArray['Comaprison between fare'][0] = 'CP VS (Retail Fare + '.$finalArray['Corporate_or_Retail_Fare_Comparison_amount'][0].')';
                }
              }
            }
        $finalArray = $resultArray;
        return $finalArray;
    }
    
    /**
    * function to get travel class based on order id
    * @param type $orderId
    * @return array
    * @Author:- Baskar.V.P
    */
    public function getTravelClass($orderId){
        // query forming based on order
        $sql ="SELECT class_code
                FROM air_request_details ad  
                INNER JOIN fact_booking_details fbd ON ad.air_request_id = fbd.r_request_id  
                INNER JOIN order_details od ON od.order_id = fbd.r_order_id 
                INNER JOIN dm_travel_class dmc ON dmc.travel_class_id  = ad.r_travel_class_id
                WHERE fbd.r_order_id=".$orderId;
        $result =  $this->_OcommonDBO->_getResult($sql)[0]['class_code'];        
        return $result;
    }
    
    /**
    * function  used to get corporate product settings
    * @param array 
    * @param $corporateId
    * @return array
    * @author  Baskar.V.P
    */  
    public function getCorporateSettings($corporateId){
        $corporate = new corporateCustomization();
        $corporate->_IcorporateId = $corporateId;
        $_AsettingsArray = $corporate->_getCorporateSettingsFromJSON();
        return $_AsettingsArray;
    }
    /* 
    * @Function Name             : _insertTripDetails
    * @Description               : This function used to insert Trip Details in GDS Booking flow.  
    * @Tables                    : 
    * @Author                    : Muruganandham.M
    * @Created Date              : 28/03/2019
    * @Modified Date             : 
    */  
    public function _insertTripDetails($tripDetails){
        return true;
    }

}
?>