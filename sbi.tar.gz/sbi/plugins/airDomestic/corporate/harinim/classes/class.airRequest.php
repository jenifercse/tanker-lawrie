<?php
/** * **************************************************************************
 * @File             : class.airRequest.php
 * @Description      : This file is used to insert,update,delete and get air_request_details
 * @dimensionTables  : air_request_details
 * @Author           : Lakshmi.S
 * @Created Date     : 01/07/2016
 * @Modified Date     : 
 * *************************************************************************** */
fileRequire('classes/class.commonDBO.php');

class airRequest{

    private $_OcommonDBO;

    public function __construct(){
        $this->_OcommonDBO = new commonDBO();
        $this->_OapplicationSettings = new applicationSettings();
    }

    /**
     * @Description :This function is used to insert the air_request_details 
     * @param :array   | $requestDetails - holds array of request details
     * @return integer |$resultRequestId - inserted request id
     */
    public function _insertAirRequest($requestDetails){
        $tableName = 'air_request_details';
        $resultRequestId = $this->_OcommonDBO->_insert($tableName,$requestDetails);
        
        if(ERROR_DEBUG_REPORT){
            if(!$resultRequestId > 0){
                $this->_OapplicationSettings->pushInsertDetails($requestDetails,$tableName,$resultRequestId,$this->_OcommonDBO->_AbugTracking);
            }else{
                $this->_OapplicationSettings->pushInsertDetails($requestDetails,$tableName,$resultRequestId);
            }
        }
        
        return $resultRequestId;
    }

    /**
     * @Description :This function is used to get the air_request_details
     * @param :array   | $fieldsArray - holds array of fields get from air_request_details
     * @param :integer   | $requestId - holds the request id
     * @return array |$resultRequest - holds the array of request details
     */
    public function _getAirRequest($requestId = 0, $fieldsArray = ''){
        
        $tableName = 'air_request_details';
        $wherekey = 'air_request_id';
        $wherevalue = $requestId;

        if (!empty($fieldsArray) && count($fieldsArray) > 0){
            $resultRequest = $this->_OcommonDBO->_select($tableName, $fieldsArray, $wherekey, $wherevalue);
        }
        
        return $resultRequest;
    }

    /**
     * @Description :This function is used to update the request details 
     * @param :array   | $requestDetails - holds the request details
     * @param :integer   | $requestId - holds the request id
     * @return boolean |$result - return true or false
     */
    public function _updateAirRequest($requestDetails,$requestId){
        $result = $this->_OcommonDBO->_update('air_request_details',$requestDetails,'air_request_id',$requestId);
        return $result;
    }

    /**
     * @Description :This function is used to delete the request details 
     * @param :integer   | $requestId - holds the request id
     * @return boolean |$result - return true or false
     */
    public function _deleteAirRequest($requestId){
        $result = $this->_OcommonDBO->_delete('air_request_details', 'air_request_id', $requestId);
        
        return $result;
    }

    /**
     * @Description | This function is used check the payment status of the air request
     * @param :integer   | $requestId - holds the current airRequest request id
     * @return boolean | $paymentStatus return true or false
     */
   
    public function _checkPaymentStatus($packageId){
        
        $checkPayment = "SELECT od.order_id   
                         FROM order_details od
                         WHERE  od.order_id IN 
                         (SELECT fbd.r_order_id      
                         FROM dm_package dmp
                         INNER JOIN fact_booking_details fbd ON fbd.r_package_id = dmp.package_id
                         WHERE dmp.package_id = ".$packageId.")                            
                         AND od.r_payment_status_id = ".PAYMENT_STATUS_NOTPAID;

	$paymentStatus = $this->_OcommonDBO->_getResult($checkPayment);   
	
        return $paymentStatus;
    }
       
    /**
     * @Description :This function is used to list all the air request details 
     * @param :integer   | $requestId - holds the request id
     * @param :integer   | $ - 
     * @return array |$resultRequest - holds the array of request details
     */
    public function _listAirRequest($search){
        global $CFG;
        $permission = $_SESSION['permissions'];
        $where = '';
        $today = date('Y-m-d');
        $sql = "SELECT od.order_id,fbd.r_package_id,
                DATE_FORMAT(dpm.created_date,'".$CFG['date_format']['datetime']."') AS created_date,
                ard.r_origin_airport_id,ard.r_destination_airport_id,
                DATE_FORMAT(ard.onward_date,'".$CFG['date_format']['date_smarty']."')AS onward_date,
                ard.trip_type,ard.r_travel_class_id,od.r_ticket_status_id,od.r_payment_status_id
                FROM order_details  od   
                INNER JOIN fact_booking_details fbd ON od.order_id=fbd.r_order_id AND r_travel_mode_id IN(1,2)
                INNER JOIN air_request_details ard ON fbd.r_request_id=ard.air_request_id
                INNER JOIN dm_package dpm ON fbd.r_package_id=dpm.package_id 
                WHERE ";
        //Condition for reqested date today 
        if ($search['date'] == 'Today'){
            $sql.=" dpm.created_date like '" .$today."%'";
        }
        //Condition for  requested date Yesterday  
        elseif ($search['date'] == 'Yesterday'){
            $yesterday = date('Y-m-d', strtotime('-1 days'));
            $sql.="dpm.created_date like '" .$yesterday."%'";
        }
        //Condition for  requested date last week    
        elseif ($search['date'] == 'Last week'){
            $Lastweek = date('Y-m-d', strtotime('-7 days'));
            $sql.="dpm.created_date BETWEEN '" .$Lastweek."' AND '".$today."'";
        }
        //Condition for  requested date last Month    
        elseif ($search['date'] == 'Last Month'){
            $Lastmonth = date('Y-m-d', strtotime('-30 days'));
            $sql.="dpm.created_date BETWEEN '".$Lastmonth."'AND'".$today."'";
        }
        //Condition for  requested date between two date range  
         elseif ($search['startDate'] != ''){
            $sql.="dpm.created_date BETWEEN '" .$search['startDate']."'AND'".$search['endDate']."'";
        }
        //Condition for  search by order id
         elseif ($search['orderId'] != ''){
            $sql.="fbd.r_order_id='" .$search['orderId']."'";
        }
        //Condition for  search by request id
         elseif ($search['requestId'] != ''){
            $sql.="fbd.r_request_id='" .$search['requestId']. "'";
        }
        //Condition for Data  Permission for permission type self
        if ($permission['permissionName'] == 'Self'){
            $sql.="AND fbd.r_employee_id='".$permission['r_employee_id']."'";
        }
        //Condition for Data  Permission for permission type other corporate
        elseif ($permission['permissionName'] == 'Other Corporate'){
            $inCondition = '';
            $sql.="AND fbd.r_corporate_id IN (".implode(',',$permission['r_corporate_id']).")";
        }
        //Condition for Data  Permission for permission type other employee
        elseif ($permission['permissionName'] == 'Other Employee'){
            $sql.="AND fbd.r_employee_id IN (".implode(',',$permission['r_employee_id']).")";
        }

        //Condition for Data  Permission for permission type Self Corporate
        elseif ($permission['permissionName'] == 'Self Corporate'){
            $sql.="AND fbd.r_corporate_id IN (". $permission['r_corporate_id'].")";
        }
        $resultRequest = $this->_OcommonDBO->_getResult($sql);
        
        return $resultRequest;
    }

    /**
     * @Description :This function is used to insert the fact_air_itinerary
     * @param :array   | $factAirDetails - holds array of air via flight ,via fare id
     * @return integer |$resultFactAirId - inserted request id
     */
    public function _insertFactAirItinerary($factAirDetails){
        $tableName        = 'fact_air_itinerary';
        $resultFactAirId  = $this->_OcommonDBO->_insert($tableName, $factAirDetails);
        
        return $resultFactAirId ;
    }

    /**
     * @Description :This function is used to insert the air_booking_details
     * @param :array   | $requestDetails - holds array of order id, employeeid,reschedulestatus
     * @return integer |$resultRequestId - inserted request id
     */
    public function _insertAirBookingDetails($airBookingDetails){
        $tableName        = 'air_booking_details';
        $resultBookingId  = $this->_OcommonDBO->_insert($tableName, $airBookingDetails);
        
        return $resultBookingId ;
    }

   /**
     * @Description :This function is used to update the air booking details
     * @param :array   | $bookingDetails - holds the reshedule status
     * @param :integer   | $bookingId - holds the request id
     * @return boolean |$result - return true or false
     */
    public function _updateAirBookingDetails($bookingDetails,$bookingId){
        $result = $this->_OcommonDBO->_update('air_booking_details',$bookingDetails,'r_order_id',$bookingId);
        
        return $result;
    }
   
    /**
     * @Description :This function is used to get the air request details using the order_id
     * @param :integer   | $orderId - holds the order id
     * @return :array |$resultAirRequest - return the array value
     */
    public function _getAirRequestDetails($orderId){
        $airRequestSql = "SELECT fbd.r_order_id,fbd.r_corporate_id,fbd.r_package_id ,ard.air_request_id as airRequest,
                            ard.onward_date as onward,ard.return_date as returnDate,
                            ard.r_origin_airport_id as orgin,ard.r_destination_airport_id as dest,
                            fbd.r_employee_id as employeeId,ard.adult_count as ADT,
                            ard.child_count as CH,ard.infant_count as INF,
                            ard.num_passenger,ard.travel_type,ard.trip_type,ard.r_travel_class_id,ard.customize_fields,ard.r_travel_class_id_return,
                            (SELECT class_code FROM dm_travel_class WHERE travel_class_id = ard.r_travel_class_id_return) as returncabinClass,
                            (SELECT travel_mode_id FROM dm_travel_mode WHERE travel_mode_code = ard.travel_type) as travelModeId,
                            (SELECT class_code FROM dm_travel_class WHERE travel_class_id = ard.r_travel_class_id) as cabinClass,
                            (SELECT city_name FROM dm_airport WHERE airport_id = ard.r_origin_airport_id) as mainOrigin,
                            (SELECT airport_code FROM dm_airport WHERE airport_id = ard.r_origin_airport_id) as mainOriginCode,
                            (SELECT airport_code FROM dm_airport WHERE airport_id = ard.r_destination_airport_id) as mainDestinationCode,
                            (SELECT city_name FROM dm_airport WHERE airport_id = ard.r_destination_airport_id) as mainDestination,
                            (SELECT DATE_FORMAT(bh.onward_depature_date,'".COMMON_DATE_FORMAT."') FROM booking_history bh WHERE bh.order_id = fbd.r_order_id) as onwardDepatureDate
                          FROM air_request_details ard
                          INNER JOIN fact_booking_details fbd ON ard.air_request_id =fbd.r_request_id
                          WHERE fbd.r_order_id =".$orderId;
        return !empty($orderId) ? $this->_OcommonDBO->_getResult($airRequestSql): FALSE;
    }

    //get Booking History Data request Level
    public function _getAirRequestBookingDetails($orderId){
        $airBookingRequestSql ="SELECT sector_from as start ,sector_to as going,travel_purpose as purpose, expense_borne as bill 
                                FROM booking_history bh
                                INNER JOIN order_details od ON od.order_id = bh.order_id 
                                WHERE bh.order_id = ".$orderId;
        $resultAirBookingRequest = $this->_OcommonDBO->_getResult($airBookingRequestSql);     
        
        return $resultAirBookingRequest;
    }
   
    //get via fare amount for low fare search
    public function _getAirRequestBookingDetailsAmount($orderId,$tripType = ''){
        $sqlItinerary = "SELECT fd.passenger_type,fd.base_fare,fd.tax,fd.service_tax,vfd.time_departure,vfd.departure_date
                        FROM via_fare_details fd,via_flight_details vfd,fact_air_itinerary fai,order_details od,air_booking_details abd
                        WHERE vfd.via_flight_id = fai.r_via_flight_id
                        AND fd.via_fare_id = fai.r_via_fare_id
                        AND fd.r_via_flight_id = vfd.via_flight_id
                        AND abd.r_order_id = od.order_id
                        AND abd.air_booking_details_id = fai.r_air_booking_details_id
                        AND fai.itinerary_status = " .SELECTED_ITINERARY. "
                        AND od.order_id =".$orderId;
        if($tripType != ''){
           $sqlItinerary.= ' AND vfd.trip_type ='. $tripType;
        }
        $resultItinerary = $this->_OcommonDBO->_getResult($sqlItinerary);        
        return $resultItinerary;
    }

    public function _getSapRequestDetails($packageId){
        $sapRequestInfo=$this->_OcommonDBO->_select('sap_request_details','*','r_package_id',$packageId)[0];        
        return $sapRequestInfo;
    }

    /*
     * @function         : _validateAdvanceSearchDeatils
     * @Description      : validate advance search details and set flag values
     * @param            : array | $advanceSearchData
     * @return           : array | $allData
     * @Author           : puroskhan.M
     * @Created Date     : 29/12/2018
     * @Modified Date    : 
     */
    public function _validateAdvanceSearchDeatils($advanceSearchData){
        $timeForFilter = false;
        $airlineFilter = false;
        $preferAirline = array();
        $preferAirlineTime = array();
        $allData = array();
        foreach ($advanceSearchData as $key => $value){
         if($key == "preferredAirlines"){
            foreach ($value as $Preferkey => $Prefervalue) {
              if(!empty($Prefervalue) && isset($Prefervalue)) {
               $airlineFilter  = true;  //set flag
               $preferAirline[$Prefervalue] = 'Y'; 
              }
            }
        }
        else if($key == 'LTCEnable' || $key == 'defenseFare'){
            $allData[$key] = ($value == 'Y') ? $value : 'N';
        }
        else if(!empty($value) && isset($value) && $key !='preferredAirlines') {
             $timeForFilter = true; //set flag
             $preferAirlineTime[$key]=$value;
           }
        }
        //form the details with valid flag
        $allData['preferredAirlinesFlag'] = $airlineFilter;
        $allData['preferredAirlinesTimeFlag'] = $timeForFilter;
        $allData['preferredAirlinesTimes'] = $preferAirlineTime;
        $allData['preferredAirlines']  = $preferAirline;
        return $allData;   
    }

    /*
     * @function         : _getOrderAdvanceFilterData
     * @Modified Date    : 
     */
    public function _getOrderAdvanceFilterData($orderId){

        $sql = "SELECT ard.* 
                FROM
                    air_request_details ard
                    INNER JOIN fact_booking_details fbd ON fbd.r_request_id = ard.air_request_id
                WHERE
                    fbd.r_order_id = ".$orderId;

        $airRequestResult = $this->_OcommonDBO->_getResult($sql)[0];        
        if($airRequestResult && $airRequestResult['customize_fields'] != ''){

            //decode the customized field data
            $customizeData = json_decode($airRequestResult['customize_fields'],1);

            //get the filter data.
            return $this->_validateAdvanceSearchDeatils($customizeData);
        }
    }

    /*
     * @function         : checkLTCGOAirEnable
     * @Modified Date    : 
     */
    public function checkLTCGOAirEnable($orderId){

        $advanceSearchFlag['LTCFlights'] = 'N';
        $advanceSearchFlag['goAirDefenseFare'] = 'N';

        //get advance search data.
        $advanceSearchData = $this->_getOrderAdvanceFilterData($orderId);
        
        //set flag.
        if($advanceSearchData['LTCEnable'] &&  $advanceSearchData['LTCEnable'] != ''){
            $advanceSearchFlag['LTCFlights'] = $advanceSearchData['LTCEnable'];
        }
        if($advanceSearchData['defenseFare'] &&  $advanceSearchData['defenseFare'] != ''){
            $advanceSearchFlag['goAirDefenseFare'] = $advanceSearchData['defenseFare'];
        }
        return $advanceSearchFlag;
    }
}
?>