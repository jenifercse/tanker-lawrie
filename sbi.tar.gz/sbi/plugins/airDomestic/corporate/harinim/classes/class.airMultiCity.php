<?php
/** * **************************************************************************
 * @File             : class.airMultiCity.php
 * @Description      : This file is used to insert,update,delete and get multiple city air_request_details / book flight / Itineary display / payment insert
 * @dimensionTables  : order_details, air_request_details
 * @Author           : Taslim
 * @Created Date     : 25/08/2016
 * @Modified Date    : 
 * *************************************************************************** */
fileRequire('classes/class.commonDBO.php');

class airMultiCity extends airRequest{

    private $_OcommonDBO;

    public function __construct(){
        parent::__construct();
        
        $this->_OPackage         = new package();
        $this->_OPassenger       = new passenger();
        $this->_OFlightItinerary = new flightItinerary();
    }
    
    /**
     * @Description :This function is used to insert multiple order_details for multiple flight request
     * @param int | $flightCount - no of multiple flights
     * @param array | $orderDetailsArray  
     * @return array |$returnValue 
     */
    public function _insertMultipleRequestOrderDetails($orderDetailsArray){
        
        $returnValue = false;
        
        if(count($orderDetailsArray) > 0){
            foreach ($orderDetailsArray as $val){
                $orderIdArray[] = $this->_OPackage->_insertOrderDetails($val);
            }
            $returnValue = $orderIdArray;
        }
        return $returnValue;
    }
    
    /**
     * @Description :Function insert multiple air request by iteirating array for multiple air flight request
     * @param int | $flightCount - no of multiple flights
     * @param array | $orderDetailsArray  
     * @return array |$returnValue 
     */
    public function _insertMultipleRequestAir($requestDetailsArray){
        
        $returnValue = false;
        
        if(count($requestDetailsArray) > 0){
            foreach ($requestDetailsArray as $requestDetails){
                $airRequestIdArray[] = $this->_insertAirRequest($requestDetails);
            }
            $returnValue = $airRequestIdArray;
        }
        
        return $returnValue;
    }
    
    /**
     * @Description :Function insert multiple air request by iteirating array for multiple air flight request
     * @param int | $flightCount - no of multiple flights
     * @param array | $orderDetailsArray  
     * @return array |$returnValue 
     */
    public function _insertMultipleRequestAirPassengerDetails($passengerArray){
        
        $returnValue = false;
        
        if(count($passengerArray) > 0){
            foreach ($passengerArray as $passengerDetails){
                $airRequestIdArray[] = $this->_OPassenger->_insertPassengerMainDetails($passengerDetails);
            }
            $returnValue = $airRequestIdArray;
        }
        
        return $returnValue;
    }
    
    /**
     * @Description: Function to insert multiple entryfact booking details table
     * @param int | $flightCount - no of multiple flights
     * @param array | $orderDetailsArray  
     * @return array | $returnValue 
     */
    public function _insertMultipleRequestFactBookingDetails($factBookingDetailsArray){
        
        $returnValue = false;
        
        if(count($factBookingDetailsArray) > 0){
            foreach($factBookingDetailsArray as $factBookingDetails){ 
                $factBookingIdArray[] = $this->_OPackage->_insertFactBookingDetails($factBookingDetails);
            }
            $returnValue = $factBookingIdArray;
        }
        
        return $returnValue;
    }
    
    /**
     * @Description: Function to insert multiple air booking details calls clas.tpl.insertFlightitinerary for multiple city requestsetSector
     * @param array  | $flightBookingArray -booking insert array
     * @return array | $responseArray 
     */
    public function _insertMultipleBookingAirDetails($flightBookingArray){

        pluginFileRequire('common/', 'classesTpl/class.tpl.insertFlightItinerary.php');
        
        $returnValue = false;

        if(count($flightBookingArray) > 0){
            $this->_OItineraryInsert = new insertFlightItinerary();

            foreach ($flightBookingArray as $key=>$bookingArray){
                if($key!=0){
                    //re-initialize old existing values 
                    $this->_OItineraryInsert->_OFlightItinerary->_IorderTotalFare         = 0;
                    $this->_OItineraryInsert->_OFlightItinerary->_IorderTotalServiceTax   = 0;
                    $this->_OItineraryInsert->_OFlightItinerary->_IorderCalTransBaseFare  = 0;
                    $this->_OItineraryInsert->_OFlightItinerary->_IorderCalSystemBaseFare = 0;
                    $this->_OItineraryInsert->_OFlightItinerary->_IorderDiscountBaseFare  = 0;
                    
                    $responseArray[]['status'] = $this->_OItineraryInsert->_insertIntineraryDetails($bookingArray);
                }
            }
            $returnValue = $responseArray;
        }
        
        return $responseArray;
    }

}
?>