<?php

/** * **************************************************************************
 * @File             : class.insertPrimaryBookingDetails.php
 * @Description      : This file is used to insert primary booking request details
 * @Tables Affected  : package_details,order_details,passenger_details,fact_booking_details
 * *************************************************************************** */
class commonInsertPrimaryBookingInfo {

    public function __construct() {
        $this->_Oemployee = new employee();
        $this->_Olocation = new location();
        $this->_OapplicationSettings = new applicationSettings();
        $this->_Opackage = new package();
        $this->_Opassenger = new passenger();
        $this->_OpassengerPrefence = new passengerPreferences();
        $this->_OcommonDBO = new commonDBO();

        $this->_request = new airRequest();
        $this->_OdynamicInsertion = new dynamicFormElementManipulation();
        $this->_OcommonQuery = new commonQuery();
        $this->_OapprovalTracking = common::_checkClassExistsInNameSpace('approvalTracking');
        $this->_CheckInsertPassengerDynamicValue = '';
        $this->_AfinalResponse['error_alert'] = '';
        $this->_AfinalResponse['status'] = 0;
        $this->_OsetApproval = common::_checkClassExistsInNameSpace('setApprovalProcess');
        $this->_OcheckApprovalSettings = common::_checkClassExistsInNameSpace('checkApprovalSettings');
    }

    /**
     * @functionName    :   _getDisplayInfo()
     * @description     :   default module method
     */
    public function _getDisplayInfo() {

        if ($this->_IinputData['action'] == 'checkApprovalExist') {
            //Flow will come here when fares are selected
            // get workflow caption from order_details based on order_id
            $this->_workFlowCaption = $this->_OcommonQuery->_getWorkFlowForOrder($this->_IinputData['factBookingDetails']['r_order_id']);
            if($this->_workFlowCaption != "CMP_REQUEST_APPROVAL") {
                $this->_setApproval();
            }
        }
        else if($this->_IinputData['action'] != ''){
            //Flow will come here when request is modified
            $action = 'update';
        } 
        else{
            //Flow will come here when request is submitted
            $action = 'insert';
        }

        switch ($action) {
            case 'update':
                $this->_getResponseInModifyRequest();
                $this->_AserviceResponse['airRequestDetails'] = $this->_IinputData['airRequestDetails'];
                $this->_AserviceResponse['requestLevelInsetedData'] = $this->_IinputData;
                $this->_AserviceResponse['requestLevelInsetedData']['orderId'] = $this->_IinputData['action'];
                break;
            case 'insert':
                $this->_passengerInsertionFlow();
                $this->_AserviceResponse['airRequestDetails'] = $this->_IinputData['airRequestDetails'];
                break;
            default:
                break;
        }
    }

    /**
     * @functionName    :   _passengerInsertionFlow()
     * @description     :   insert the passenger details.
     */
    public function _passengerInsertionFlow() {

        //object creation.
        $this->_Itineray = new flightItinerary();

        /* To get order id based on package details */
        $package = $this->_IinputData['factBookingDetails']['r_package_id'];
        
        //form passenger details.
        $this->_IinputData['passengerDetails']['passenger'] = $this->_IinputData['passenger']['ADT'];
        foreach ($this->_IinputData['passenger']['CNN'] as $key => $value) {
            $this->_IinputData['passengerDetails']['passenger'][$key + count($this->_IinputData['passenger']['ADT'])] = $this->_IinputData['passenger']['CNN'][$key];
        }
        $this->_IinputData['passengerDetails']['infant'] = $this->_IinputData['passenger']['INF'];

        // get order Data based on paid id
        $orderId = $this->_Opackage->_getPaidPackageDetails($package);

        //get booking details.
        $itinerayDetails = $this->_Itineray->_getOrderBookingDetails($orderId[0]['r_order_id']);

        //get air request details.
        $fieldArray = array('trip_type', 'adult_count', 'child_count', 'infant_count', 'onward_date');
        $requestDetails = $this->_request->_getAirRequest($itinerayDetails['r_request_id'], $fieldArray);
        foreach ($requestDetails[0] as $key => $value) {
            $this->_IinputData[$key] = $requestDetails[0][$key];
        }

        foreach ($orderId as $key => $value) {
            $this->_IinputData['order_id'] = $value['r_order_id'];
            foreach ($this->_IinputData as $key => $value) {
                $this->_AtwigOutputArray[$key] = $this->_IinputData[$key];
            }
            $this->_AtwigOutputArray['email'] = $_SESSION['employeeEmailId'];
            $this->_passengerInsertForPersonalBooking();
        }
        //set booking type.
        $this->_setBookingType();

        //insert the booking details.
        $this->_insertBookingDetails();

        //get orderid
        $updateInput = array_column($orderId, 'r_order_id');

        //update workflow in order_details, which is set in the session based on the corporate.
        $this->_workFlowCaption = $this->_OcommonQuery->_updateWorkFlowForOrder($updateInput,'B',$this->_IinputData['travelModeType']);

        //check if policy is violated for the order is in request level.
        $violatedPolicyArray = $this->_OcommonQuery->_checkPolicyViolation($updateInput[0]);

        //get approver type.
        $approverType = $this->_setApprovalAfterPolicyViolated($violatedPolicyArray, $updateInput);

        $this->_AserviceResponse['requestLevelInsetedData'] = $this->_IinputData;
        
        //set policy checking flag
        $this->_AserviceResponse['POLICY_CHECK']['BOOKING_LEVEL'] = in_array("BOOKING_LEVEL",$_SESSION['userApplicationSettings']['POLICY_CHECK']) ? 'YES' : 'NO';

        //get time violation limit.
        $this->_AserviceResponse['timeViolationCount'] = $this->_OcommonQuery->_getTimeViolationCount($package);
        $this->_templateAssign();
    }

    /**
     * @Description :This function is used to insert the passenger details
     * @return integer |$factBookingId - inserted fact booking id
     */
    public function _passengerInsertForPersonalBooking(){
        
        //insert the dynamic field value of passenger with respect to the id.
        if (isset($this->_IinputData['passengerDynamic']) && count($this->_IinputData['passengerDynamic']) > 0) {
            $this->_CheckInsertPassengerDynamicValue = in_array(CUSTOM_FIELD_ID_OF_OPTIONAL_APPROVAL, array_column($this->_IinputData['passengerDynamic'], 'id')) ? TRUE : FALSE;
        }
        //set passenger info.
        $passenger = $this->_IinputData['passengerDetails'];
        $passengerDetails = isset($passenger['passenger']) ? array($passenger['passenger']) : '';
        $passengerOtherDetails = isset($passenger['passengerOtherDetails']) ? array($passenger['passengerOtherDetails']) : '';      
        //Insert Passenger details.
        $this->_paxIds = $this->_insertpassenger($passengerDetails);
        
        //insert the passenger dynamic field value.
        if (isset($this->_IinputData['passengerDynamic']) && count($this->_IinputData['passengerDynamic']) > 0 && $this->_CheckInsertPassengerDynamicValue) {
            $resultForDynamic = $this->_OdynamicInsertion->_insertDynamicFields($this->_IinputData['factBookingDetails']['r_order_id'], '3', $this->_IinputData['passengerDynamic']);
        }
        
        //Insert Infant Details.
        if(isset($passenger['infant']) && count($passenger['infant']) > 0){
            $infantDetails = isset($passenger['infant']) ? array($passenger['infant']) : '';
            $infantIds = $this->_insertInfant($infantDetails,$this->_paxIds);
        }
    }

    /**
     * @Description :This function is used to insert the infant details
     * @param :infant details and paxids to maps
     * @return boolean (true)
     */
    public function _insertInfant($infantDetails, $paxIds){
        //Infant Insertions.
        foreach ($infantDetails as $key => $infants) {
            foreach ($infants as $index => $infant) {             
                
                $infant['DOB'] = date("Y-m-d", strtotime($infant['DOB']));                
               
                // To remove the adultAssigned from the array.
                $assignedAdults = $paxIds[$infant['adultAssigned']];
                
                $infant['r_order_id'] = $this->_IinputData['order_id'];
                unset($infant['adultAssigned']);
                unset($infant['cost_center']);
                unset($infant['aadhar_number']);                
                $infantId = $this->_Opassenger->_insertPassengerMainDetails($infant);
                $this->_insertPassengerInfantDetails($assignedAdults, $infantId, $infant['DOB']);
            }
        }
        return true;
    }

    public function _setPassengerCostCenterCode($passengerDetails) {

        if($passengerDetails[0][0]['employee_code'] == 'GUEST' ||  $passengerDetails[0][0]['employee_code'] == 'FAMILY' ){
            $costCenterCode = $this->_getPassengerCostCenterCode($_SESSION['employeeEmailId']);
        }
        else{
            $costCenterCode = $passengerDetails[0][0]['cost_center'];
        }

        return $costCenterCode;
    }
    /**
     * @Description :function to get the cost_center_code
     * @param :email_id
     **/

    public function _getPassengerCostCenterCode($emailId) {

         $sql = "SELECT 
                    ccc.cost_center_code
                FROM dm_employee dme
                INNER JOIN employee_details emd ON dme.employee_id = emd.r_employee_id
                INNER JOIN dm_cost_center_code ccc ON emd.r_cost_center_code_id = ccc.cost_center_code_id 
                WHERE dme.email_id = '".$emailId."' ";

        $result = $this->_OcommonDBO->_getResult($sql);
        return $result[0]['cost_center_code'];
    }

    /**
     * @Description :This function is used to insert the passenger details
     * @param :passenger details
     * @return boolean (true)
     */
    public function _insertpassenger($passengerDetails, $passengerOtherDetails=''){
        
        // Passenger Insertions.
        $passengerIds = array();
        $cnt = 1;
        foreach ($passengerDetails as $key => $passenger) {
            foreach ($passenger as $index => $pas) {
                $employeeId = $pas['r_employee_id']  == 0 ? $_SESSION['employeeId'] : $pas['r_employee_id'];
                $empOtherData = $this->_Oemployee->_getEmployeeOtherDetails($employeeId);
                $empOtherData = $empOtherData[$employeeId][0];
                $passOther['project_code'] = $this->_setPassengerCostCenterCode($passengerDetails);
                $passOther['aadhar_number'] = $pas['aadhar_number'];
                $passOther['department'] = $pas['department_name'] ? $pas['department_name'] : $empOtherData['department_name'];
                $passOther['designation'] = $pas['designation_name'] ? $pas['designation_name'] : $empOtherData['designation_name'];
                $passOther['band'] = $pas['band'] ? $pas['band'] : $empOtherData['band_name'];
                $passOther['branch'] = $pas['branch_name'] ? $pas['branch_name'] : $empOtherData['branch_name'];
                $passOther['city'] = $pas['city'] ? $pas['city'] : $empOtherData['city'];
                $passOther['country'] = $pas['country'] ? $pas['country'] : $empOtherData['country'];
                $passOther['pin_code'] = $pas['pin_code'] ? $pas['pin_code'] : $empOtherData['pin_code'];
                $passOther['contact_no'] = $pas['contact_no'] ? $pas['contact_no'] : $empOtherData['contact_no'];
                unset($pas['cost_center']);
                unset($pas['aadhar_number']);
                unset($pas['department_name']);
                unset($pas['designation_name']);
                unset($pas['band']);
                unset($pas['branch_name']);
                unset($pas['city']);
                unset($pas['country']);
                unset($pas['pin_code']);
                unset($pas['contact_no']);
                $pas['first_name'] = addslashes($pas['first_name']);
                $pas['last_name'] = addslashes($pas['last_name']);
                // adding the DateofBirth field if the user is Adult, Just adding 30yrs for adult for webservice default parameter.
                if($pas['passenger_type'] == 'ADT'){
                    $getAdultDob = $this->_Oemployee->_getEmployeeDOB($employeeId);

                    if($getAdultDob){
                        $pas['DOB'] = $getAdultDob;
                    }
                    else{
                        $pas['DOB'] = date('Y-m-d', strtotime('-30 years'));
                    }
                }
                else{
                    if(array_key_exists('DOB', $passenger)){ // this will be handle for both adult and child .
                        $pas['DOB'] = date("Y-m-d", strtotime($pas['DOB']));
                    } 
                    else{
                        $pas['DOB'] = date("Y-m-d", strtotime(date('Y-m-d', strtotime($pas['DOB']))));
                    }
                }
                

                //set order id,
                $pas['r_order_id'] = $this->_IinputData['order_id'];

                //Insert the passenger_id.
                $passengerIds[$index] = $this->_Opassenger->_insertPassengerMainDetails($pas);

                ($pas['employee_code'] != 'GUEST' && !empty($pas['r_employee_id']) && !empty($this->_CheckInsertPassengerDynamicValue)) ? $this->_OdynamicInsertion->_insertPassengerDynamicFieldValue($passengerIds[$index], CUSTOM_FIELD_ID_OF_OPTIONAL_APPROVAL, $this->_IinputData['passengerDynamic'][$pas['r_employee_id']]) : FALSE;

                $passOther['r_passenger_id'] = $passengerIds[$index];
                $passOther['age'] = $this->_Oemployee->_getAge($pas['DOB']);
                if ($pas['r_employee_id'] != '') {
                    $mealType = $this->_OpassengerPrefence->_getEmployeeMealType($pas['r_employee_id']);
                    $seatType = $this->_OpassengerPrefence->_getEmployeeSeatType($pas['r_employee_id']);
                    $passOther['meal_type'] = $mealType[0]['meal'] ? $mealType[0]['meal'] : 'No Meal';
                    $passOther['seat_preference'] = $seatType[0]['seat'] ? $seatType[0]['seat'] : 'Any Seat';
                    
                }
                $passengerOtherDetails = $this->_Opassenger->_insertPassengerOtherDetails($passOther);
                if ($this->_IinputData['updateMasterPassenger'] == 1) {
                    $this->_employeeMasterUpdate($pas, $passOther);
                }
            }
        }
        return $passengerIds;
    }

    /**
     * @Description :This function is used to get guest details
     * @param : integer | $orderId - order id
     * @return array |$returnValue - Booked employee designation,department,branch details
     */
    private function _getGuestDetails($orderId) {
        $sqlEmployee = "SELECT ed.designation,ed.department,ed.branch
                        FROM employee_details ed,fact_booking_details fbd
                        WHERE fbd.r_order_id='" . $orderId . "' AND fbd.r_employee_id=ed.r_employee_id";
        $result = $this->_OcommonDBO->_getResult($sqlEmployee);
        return $result;
    }

    /**
    * @Description :This function is used to infant and adult details
    * @param : integer | $passengerId,$infantId array |$infantDetails
    */
    private function _insertPassengerInfantDetails($passengerId, $infantId, $infantDetails) {
        $requestDetails['r_passenger_id'] = $passengerId;
        $requestDetails['r_infant_id'] = $infantId;
        $requestDetails['DOB'] = date("Y-m-d", strtotime($infantDetails));
        //to insert into table
        $this->_Opassenger->_insertPassengerInfant($requestDetails);
    }

    /**
     * @Description :This function is used to infant and adult details
     * @param : integer | $passengerId,$infantId array |$infantDetails
     */
    private function _setBookingType() {
        //setting from session for harinim SSO
        $bookingType = array("N" => array("id" => 0, "value" => "Official"), "Y" => array("id" => 0, "value" => "Personal"));
        $this->_AtwigOutputArray['bookingType'] = $bookingType[$_SESSION['travellerInfo']['is_personal']];
    }

    //function used to set the approval for oneway roundtrip and multicity.
    public function _setApproval($approverType = "NA','IA','TA") {
        
        global $CFG;
        if (isset($this->_IinputData['orderId']) && count($this->_IinputData['orderId']) > 0) {
            $setApprovalOrderId = $this->_IinputData['orderId'];
        } else {
            $setApprovalOrderId[] = $this->_IinputData['factBookingDetails']['r_order_id'];
        }

        //looping the air request details
        foreach ($this->_IinputData['airRequestDetails'] as $key => $value) {
            $input['agencyId'] = $_SESSION['agencyId'] ? $_SESSION['agencyId'] : $this->_IagencyId;
            $input['corporateId'] = $_SESSION['corporateId'];
            $input['employeeId'] = $_SESSION['employeeId'];
            $input['travelModeId'] = $this->_IinputData['travelModeType'];

            // check condition for except request level approval for only multicity.
            if ($this->_workFlowCaption != "CMP_REQUEST_APPROVAL" && $this->_IinputData['travelTripType'] == 2) {
                if ($value['originCode'] == $this->_IinputData['selectedFlightInfo']['origin_airport_code']) {
                    $input['order_id'] = $setApprovalOrderId[$key];
                    $input['processType'] = $this->_IinputData['processType'];
                    $onwardDate = new DateTime($value['requestTableData']['onward_date']);
                    $today = new DateTime($CFG['dbTodayDate']);
                    $interval = $today->diff($onwardDate);
                    $daysToDeparture = $interval->format('%a');
                    $input['approvalValues'] = array("booking_class" => explode(":", $this->_IinputData['masterInfo']['oldCabinClass'])[0],
                        "booking_date" => $CFG['dbTodayDate'],
                        "onward_date" => $value['requestTableData']['onward_date'],
                        "return_date" => $this->_IinputData['masterInfo']['requestTableData']['return_date'],
                        "origin" => $value['requestTableData']['r_origin_airport_id'], "destination" => $value['requestTableData']['r_destination_airport_id'],
                        "num_passenger" => $this->_IinputData['masterInfo']['requestTableData']['num_passenger'],
                        "days_to_departure" => $daysToDeparture,
                        "booking_amount" => $this->_IinputData['selectedFlightInfo']['newTotalFare'],
                        "trip_type" => $this->_IinputData['travelTripType']);

                    //checking condition for setting booking_amount for checking criteria validation.
                    $input['approvalValues']['low_fare_selection'] = 'Y';
                    if (count($this->_IinputData['lowfareFlight']) > 0) {
                        $input['approvalValues']['low_fare_selection'] = 'N';
                    }
                    // calling funtion for set approval
                    $this->_OsetApproval->_getApprovalInfo($input, $approverType);
                    $resultApprovalInsert[] = $this->_OsetApproval->_approvalExist;
                    // assign the value as responseArray.
                    $responseArray['orderId'] = $setApprovalOrderId[$key];
                    $responseArray['approvalSettingsCheckInfo'] = $this->_OsetApproval->_approvalCheckInfo;
                    $responseArray['approvalTrackingInfo'] = $this->_OsetApproval->_approvalTrackingInfo;
                }
            } else {
                // condition for request level approval flow
                $input['order_id'] = $setApprovalOrderId[$key];
                $input['processType'] = $this->_IinputData['processType'];
                $onwardDate = new DateTime($value['requestTableData']['onward_date']);
                $today = new DateTime($CFG['dbTodayDate']);
                $interval = $today->diff($onwardDate);
                $daysToDeparture = $interval->format('%a');

                $input['approvalValues'] = array("booking_class" => explode(":", $this->_IinputData['masterInfo']['oldCabinClass'])[0],
                    "booking_date" => $CFG['dbTodayDate'],
                    "onward_date" => $value['requestTableData']['onward_date'],
                    "return_date" => $this->_IinputData['masterInfo']['requestTableData']['return_date'],
                    "origin" => $value['requestTableData']['r_origin_airport_id'],
                    "destination" => $value['requestTableData']['r_destination_airport_id'],
                    "num_passenger" => $this->_IinputData['masterInfo']['requestTableData']['num_passenger'],
                    "days_to_departure" => $daysToDeparture,
                    "trip_type" => $this->_IinputData['travelTripType']);

                //adding criteria for booking level.
                if (count($this->_IinputData['selectedFlightInfo']) > 0) {

                    //checking condition for setting booking_amount for checking criteria validation.
                    $input['approvalValues']['low_fare_selection'] = 'Y';

                    // checking condition for setting booking_amount for round trip.
                    if ($this->_IinputData['travelTripType'] == 1) {

                        $this->_IinputData['bookingTotalAmount'] != '' ? $input['approvalValues']['booking_amount'] = $this->_IinputData['bookingTotalAmount'] : '';
                        //check low fare status.
                        if (count($this->_IinputData['selectedFlightInfo']['onwardLowestFlight']) > 0 || count($this->_IinputData['selectedFlightInfo']['returnLowestFlight']) > 0) {
                            $input['approvalValues']['low_fare_selection'] = 'N';
                        }
                    } else {
                        $this->_IinputData['selectedFlightInfo']['newTotalFare'] != '' ? $input['approvalValues']['booking_amount'] = $this->_IinputData['selectedFlightInfo']['newTotalFare'] : '';
                        //check low fare status.
                        if (count($this->_IinputData['lowfareFlight']) > 0) {
                            $input['approvalValues']['low_fare_selection'] = 'N';
                        }
                    }
                }

                // calling funtion for set approval
                $this->_OsetApproval->_getApprovalInfo($input, $approverType);
                $responseArray['orderId'] = $setApprovalOrderId[$key];
                $resultApprovalInsert[] = $this->_OsetApproval->_approvalExist;
                // getting the values as array for only request level approval
                $responseArray['approvalSettingsCheckInfo'] = $this->_OsetApproval->_approvalCheckInfo;
                $responseArray['approvalTrackingInfo'] = $this->_OsetApproval->_approvalTrackingInfo;
                // setting response for request level approval flow.
                $responseArray['reqApprovalSettingsCheckInfo'][] = $this->_OsetApproval->_approvalCheckInfo;
                $responseArray['reqApprovalTrackingInfo'][$responseArray['orderId']] = $this->_OsetApproval->_approvalTrackingInfo;
            }
        }

        // checking the if approval exist or not.
        if (in_array(false, $resultApprovalInsert)) {
            $aggregateExist = 0; // Approval Not set
        } else {
            $aggregateExist = 1; // Approval set
        }

        /** set input data for request level of input(class.tpl.flightSearchDetailsTpl.php) * */
        $this->_IinputData['approvalExist'] = $aggregateExist;
        $this->_IinputData['intimationApproverExist'] = $this->_OsetApproval->_IntimationApproverExist;
        $this->_IinputData['workFlowCaption'] = $this->_workFlowCaption;
        /** ends * */
        $responseArray['aggregateExist'] = array('status_code' => 0, 'aggregateExist' => $aggregateExist);
        $this->_checkButtonStatus($responseArray, $aggregateExist);
    }

    //function used to set the button status for display
    public function _checkButtonStatus($responseArray,$aggregateExist){

        $defaultFlow = false;

        //condition for checking workflow show the send to approval and book flight button.
        if($this->_workFlowCaption != "CMP_NO_APPROVAL") {
            if($this->_OsetApproval->_IntimationApproverExist == 'Y') {
                $responseArray['sendToApprovalButton'] = false;
                $responseArray['bookFlightButton'] = true;
            } 
            else{
                $responseArray['sendToApprovalButton'] = true;
            }
        } 
        else{
            $responseArray['sendToApprovalButton'] = false;
            $responseArray['bookFlightButton'] = true;
            $defaultFlow = true;
        }

        //condition for show the book flight button for the user.
        if ($_SESSION['userTypeId'] == 4) {
            if ($aggregateExist && !$defaultFlow && $this->_OsetApproval->_IntimationApproverExist != 'Y') {
                $responseArray['bookFlightButton'] = false;
            } else {
                $responseArray['bookFlightButton'] = true;
            }
        } else {
            $responseArray['bookFlightButton'] = true;
            if ($aggregateExist && !$defaultFlow && $this->_OsetApproval->_IntimationApproverExist != 'Y') {
                $responseArray['sendToApprovalButton'] = true;
            } else {
                $responseArray['sendToApprovalButton'] = false;
            }
        }

        $responseArray['intimationApproverExist'] = $this->_OsetApproval->_IntimationApproverExist;

        //get current approval type 
        $orderApprovalLeverl = $this->_OcommonDBO->_select('order_details','approval_level','order_id',$responseArray['orderId'])[0]['approval_level'];
        
        //if reapproval process, skip the approval for current employee
        if(isset($this->_IinputData['reApprovalFlag']) && $this->_IinputData['reApprovalFlag'] != ''){            
            
            //get approver id info.
            $approverIdInfo  = array_column($responseArray['approvalTrackingInfo'],'approver_id');
            
            //get the key
            $sessionApproverLevel  = array_search($_SESSION['employeeId'],$approverIdInfo);
            
            $timeBasedReapproval = 'N';

            //get the approver info other than the session employee
            foreach($responseArray['approvalTrackingInfo'] as $approverKey => $approverInfo){

                if($approverInfo['approver_id'] != $_SESSION['employeeId'] && $approverInfo['approval_level'] > $responseArray['approvalTrackingInfo'][$sessionApproverLevel]['approval_level']){
                    $approvalInfo[] = $approverInfo;
                }
                if($approverInfo['approver_id'] == $_SESSION['employeeId'] && $approverInfo['approval_level'] == $orderApprovalLeverl  && $approverInfo['approval_type'] == 'TA'){
                    $timeBasedReapproval = 'Y';
                }
            }

            if(count($approvalInfo) > 0 && $timeBasedReapproval == 'N'){ 
                $approverLen  = count($approvalInfo);                
                foreach($approvalInfo as $k => $value){ 
                    $value['next_level_status'] = ($k == ($approverLen-1)) ? 'N' : 'Y';
                    $finalApprovalInfo[] = $value;
                }
                $responseArray['approvalTrackingInfo'] = $finalApprovalInfo;
                $responseArray['sendToApprovalButton'] = true;
            }
            else{
                $responseArray['sendToApprovalButton'] = false;
                $responseArray['approvalTrackingInfo'] = array();
            }
        }
      
        // Request level approval flow
        if ($this->_workFlowCaption == "CMP_REQUEST_APPROVAL") {
            // assign the service response
            $this->_AserviceResponse = $responseArray;
            $this->_AserviceResponse['moduleInputData'] = $this->_IinputData['factBookingDetails'];
            // set the input for request level approval(class.tpl.flightSearchDetailsTpl.php)
            $this->_IinputData['requestApprovalSettingsInfo'] = $responseArray;
            $this->_IinputData['approvalTrackingInfo'] = $responseArray['reqApprovalTrackingInfo'];
        } 
        else{
            // except request approval flow
            $this->_AfinalResponse = $responseArray;
        }

        $this->_AserviceResponse['IAExist'] = 'Y';
        $this->_approvalCheckResponse = $responseArray;
    }

    /**
     * @Description :function used to assign the twig values.
     * @param : array | $responseArray
     */
    private function _templateAssign() {
        //setting from session for harinim SSO
        $this->_AtwigOutputArray['bookingType'] = $_SESSION['userApplicationSettings']['EXPENSE_BORNE'];
    }

    /**
     * @Description :this function is used to insert Booking History table with particular order id
     * @param : 
     */
    public function _insertBookingDetails() {


        $employeeId = $this->_IinputData['passenger']['ADT'][0]['r_employee_id']!=''?$this->_IinputData['passenger']['ADT'][0]['r_employee_id']:$_SESSION['employeeId'];      
        global $CFG;
        $this->_ObookingHistory = new bookingHistoryManipulation();
        $insertArray['r_agency_id'] = $_SESSION['agencyId'] ? $_SESSION['agencyId'] : $this->_IagencyId;
        $insertArray['r_corporate_id'] = $_SESSION['corporateId'] ? $_SESSION['corporateId'] : $this->_IcorporateId;
        $insertArray['package_id'] = $this->_IinputData['factBookingDetails']['r_package_id'];
        $insertArray['travel_mode'] = $this->_IinputData['travel_mode'];
        $insertArray['trip_type'] = $this->_IinputData['masterInfo']['requestTableData']['trip_type'];
        $insertArray['r_booked_by'] = $this->_IinputData['factBookingDetails']['r_employee_id'] ? $this->_IinputData['factBookingDetails']['r_employee_id'] : $_SESSION['employeeId'] ;
        $insertArray['payment_status'] = 'N';
        $insertArray['transaction_type'] = 'booking';
        $insertArray['no_of_passenger'] = $this->_IinputData['masterInfo']['requestTableData']['num_passenger'];
        $insertArray['adult'] = $this->_IinputData['masterInfo']['requestTableData']['adult_count'];
        $insertArray['child'] = $this->_IinputData['masterInfo']['requestTableData']['child_count'];
        $insertArray['infant'] = $this->_IinputData['masterInfo']['requestTableData']['infant_count'];
        $insertArray['request_date'] = $CFG['created_date'];
        //for multi city insert data
        $combined = array_combine($this->_IinputData['orderId'], $this->_IinputData['airRequestDetails']);
        if (isset($this->_IinputData['orderId']) && count($this->_IinputData['orderId']) > 0) {
            foreach ($combined as $key => $value) {
                $insertArray['order_id'] = $key;
                $insertArray['sector_from'] = $value['originCode'];
                $insertArray['sector_to'] = $value['destinationCode'];
                $insertArray['onward_depature_date'] = $this->_IinputData['airRequestDetails'][0]['requestTableData']['onward_date'];
                $insertArray['booking_type'] = '1';
                $resultApprover = $this->_ObookingHistory->_insertBookingHistory($insertArray);
            }
        }
        //for oneway/round trip insert data
        else {
            $insertArray['order_id'] = $this->_IinputData['factBookingDetails']['r_order_id'];
            $insertArray['sector_from'] = $this->_IinputData['airRequestDetails'][0]['originCode'];
            $insertArray['sector_to'] = $this->_IinputData['airRequestDetails'][0]['destinationCode'];
            $insertArray['onward_depature_date'] = $this->_IinputData['airRequestDetails'][0]['requestTableData']['onward_date'];
            $insertArray['return_depature_date'] = $this->_IinputData['masterInfo']['requestTableData']['return_date'];
            $insertArray['booking_type'] = '1';
            $resultApprover = $this->_ObookingHistory->_insertBookingHistory($insertArray);
        }
    }

    //update master table data
    public function _employeeMasterUpdate($pasMain, $pasOther, $type = '') {
        
        $this->_OcommonDBO = new commonDBO();
        

        $mainTableDmEmployee['first_name'] = $pasMain['first_name'];
        $mainTableDmEmployee['last_name'] = $pasMain['last_name'];
        $mainTableDmEmployee['email_id'] = $pasMain['email_id'];
        $mainTableDmEmployee['mobile_no'] = $pasMain['mobile_no'];
        $mainTableDmEmployee['title'] = $pasMain['title'];
        $resultUpdateMaster = $this->_OcommonDBO->_update('dm_employee', $mainTableDmEmployee, 'employee_id', $pasMain['r_employee_id']);
        // cost conter details insert
        //type parameter added for direct update from request form  if type is 1 then updated async
        if ($type != 1) {
            $this->_Oemployee = new employee();
            $resultCostCenterCode = $this->_Oemployee->_getEmployeeInfo($pasMain['r_employee_id']);
            if ($resultCostCenterCode['ed.r_cost_center_code_id'] == '') {
                $dataCosteCenter['r_corporate_id'] = $_SESSION['corporateId'];
                $dataCosteCenter['cost_center_code'] = $pasOther['project_code'];
                $dataCosteCenter['r_travel_mode_id'] = 1;
                $dataCosteCenter['status'] = 'Y';
                $insertCostCenter = $this->_OcommonDBO->_insert('cost_center_code_details', $dataCosteCenter);
            }
            //employee_details
            $employeeDetailsUpdate['r_cost_center_code_id'] = $insertCostCenter;
        }
        
        $employeeDetailsUpdate['aadhaar_no'] = $pasOther['aadhar_number'];
        $resultEmployeeDetailsUpdate = $this->_OcommonDBO->_update('employee_details', $employeeDetailsUpdate, 'r_employee_id', $pasMain['r_employee_id']);

        return true;
    }

    /**
     *  update passport details in table dm_employee/ employee_details
     * @param | array | $_ApasMainDetails
     * @param | array   | $pasOther  (passenger other details) 
     * @param | array   | $type  (other details) 
     * @return boolean
     * @Author:- puroskhan.M
     */
    //update master  data for multiple passenger 
    public function _multipleEmployeesMasterUpdate($_ApasMainDetails, $pasOther, $type = '') {
        
        $this->_OcommonDBO = new commonDBO();
      foreach ($_ApasMainDetails as $key => $pasMain) 
      {
            $mainTableDmEmployee['first_name'] = $pasMain['first_name'];
            $mainTableDmEmployee['last_name'] = $pasMain['last_name'];
            $mainTableDmEmployee['email_id'] = $pasMain['email_id'];
            $mainTableDmEmployee['mobile_no'] = $pasMain['mobile_no'];
            $mainTableDmEmployee['title'] = $pasMain['title'];
            $resultUpdateMaster = $this->_OcommonDBO->_update('dm_employee', $mainTableDmEmployee, 'employee_id', $pasMain['r_employee_id']);
            // cost conter details insert
            //type parameter added for direct update from request form  if type is 1 then updated async
            if ($type != 1) {
                $this->_Oemployee = new employee();
                $resultCostCenterCode = $this->_Oemployee->_getEmployeeInfo($pasMain['r_employee_id']);
                if ($resultCostCenterCode['ed.r_cost_center_code_id'] == '') {
                    $dataCosteCenter['r_corporate_id'] = $_SESSION['corporateId'];
                    $dataCosteCenter['cost_center_code'] = $pasMain['project_code'];
                    $dataCosteCenter['r_travel_mode_id'] = 1;
                    $dataCosteCenter['status'] = 'Y';
                    $insertCostCenter = $this->_OcommonDBO->_insert('cost_center_code_details', $dataCosteCenter);
                }
                //employee_details
                $employeeDetailsUpdate['r_cost_center_code_id'] = $insertCostCenter;
            }
            
            $employeeDetailsUpdate['aadhaar_no'] = $pasMain['aadhar_number'];
            $resultEmployeeDetailsUpdate = $this->_OcommonDBO->_update('employee_details', $employeeDetailsUpdate, 'r_employee_id', $pasMain['r_employee_id']);
       }
        return true;
    }

    // fucntion used to while clicking the modify request it sets the service response.
    public function _getResponseInModifyRequest() {
        
        //set the service response value.
        $this->_AserviceResponse['IAExist'] = 'Y';
        $this->_AserviceResponse['modifyRequestBooking'] = "modifyRequestBooking";

        //get order details info.
        $packageType = $this->_Opackage->_getPaidPackageDetails($this->_IinputData['factBookingDetails']['r_package_id']);
        
        //if package type is multicity.
        if($packageType[0]['package_type'] == 1) {
            $this->_AserviceResponse['multiCityRequestBooking'] = 'requestBookFlight';
            $this->_AserviceResponse['multicityorderid'] = $this->_IinputData['factBookingDetails']['r_order_id'];
        }
            
        //set policy checking flag
        $this->_AserviceResponse['POLICY_CHECK']['BOOKING_LEVEL'] = in_array("BOOKING_LEVEL",$_SESSION['userApplicationSettings']['POLICY_CHECK']) ? 'YES' : 'NO';
        
        //get time violation limit.
        $this->_AserviceResponse['timeViolationCount'] = $this->_OcommonQuery->_getTimeViolationCount($this->_IinputData['factBookingDetails']['r_package_id']);
    }

    //get approver type based on corporate.
    public function _setApprovalAfterPolicyViolated($violatedPolicyArray, $updateInput) {

        $this->_OcommonFlightSearchRequestInsert = common::_checkClassExistsInNameSpace('commonFlightSearchRequestInsert');

        //if policy is violated.
        if ($violatedPolicyArray) {
            //check exception approver for the corporate.
            $_SESSION['userApplicationSettings']['EXCEPTION_APPROVER'] == 'YES' ? $approverType = 'EA' : '';
        }
        if($this->_IinputData['guestApproval']){
            //set service response.
            $this->_AserviceResponse['guestApproverInfo'] = $this->_OcommonFlightSearchRequestInsert->_getServiceResponseOptionalApprover($this->_IinputData);
            return true;
        }

        //set approval only in request approval flow set in session for the corporate.
        if ($this->_workFlowCaption == "CMP_REQUEST_APPROVAL" && $this->_IinputData['action'] != 'combo') {
            //calling function.
            $approverType ? $this->_setApproval($approverType) : $this->_setApproval();
        }
    }

    /**
     *  inserts passport details in table dm_passport/ employee_passport_mapping
     * @param type $input
     * @param type int $passId  (last insert id for a passenger which we get above) 
     * @return boolean
     * @Author:- Vishwa Raj
     */
    public function _insertPassportDetails($inputData){

        
    foreach ($inputData as $key => $input){
            // checkwhether that employee is present or not and type of passenger
            //step 1:- if present check whether it is employee or guest/ if employee and his data is not present insert for that emoployee
            $sql = "SELECT * FROM passenger_details WHERE passenger_id = ";
            if(isset($input['passId']) && $input['passId'] != ''){
                $sql .= $input['passId'];
            }
            
            // check the employee code if guest insert directly else
            $passDetails = $this->_OcommonDBO->_getResult($sql);
            
            // insert Array for dm_passport
            $insertUpdateArray = array(
                "first_name" => $input['first_name'],
                "last_name" => $input['last_name'],
                "number" => $input['passport_number'],
                "place" => $input['place_of_issue'],
                "country" => $input['country'],
                "issuedate" => $input['issue_date'],
                "expirydate" => $input['expiry_date'],
                "dob" => $input['date_of_birth'],
                "address" => $input['address_one'],
                "address_two" => $input['address_two'],
                "pincode" => $input['pincode'],
                "gender" => $input['gender'],
                "place_of_issue_code" => $input['place_of_issue_code'],
                "country_code" => $input['country_code']
            );
            // check if the passenger is employee or guest
            if($passDetails[0]['employee_code'] == 'GUEST') {
                //insert into the tables
                $result = $this->_insertGuestPassport($input, $insertUpdateArray, $input['passId']);
            } 
            else{
                // update if passport data exist for that employee else insert
                $result = $this->_checkAndInsertEmployee($input, $insertUpdateArray, $passDetails[0]);
            }
            
            //update the name in the passenger details which is given in passport.
            $update['first_name'] = $input['first_name'];
            $update['last_name'] = $input['last_name'];
            $updatePassengerDetails = $this->_OcommonDBO->_update("passenger_details",$update,"passenger_id",$input['passId']);
            }
    return true;
    }

    /**
     * checks if the employee data is already present or not if present then update else insert
     * @param type $input
     * @param type $insertUpdateArray
     * @param type $passDetails
     * @return type int
     */
    public function _checkAndInsertEmployee($input,$insertUpdateArray,$passDetails){
        $result = $this->_OcommonDBO->_select("employee_passport_mapping", array("r_employee_id"),"r_employee_id",$passDetails['r_employee_id']);
        if(!empty($result)){
            // update that details
            $result = $this->_Opassenger->_updatePassportDetails($input,$passDetails);
        } 
        else{
            // insert
            $lastInsId = $this->_OcommonDBO->_insert("dm_passport", $insertUpdateArray);
            $insertArray = array(
                "r_passport_id" => $lastInsId,
                "r_employee_id" => $passDetails['r_employee_id'],
                "r_passenger_id"=> $passDetails['passenger_id']
            );
            return $lastInsId = $this->_OcommonDBO->_insert("employee_passport_mapping", $insertArray);
        }
    }

    /**
     * for guest updates the details with same passengerID else insert 
     * @param type $input
     * @param type $insertUpdateArray
     * @param type $passId
     * @return boolean
     */
    public function _insertGuestPassport($input,$insertUpdateArray,$passId){
        // for guest check with respect to passenger Id
        $result = $this->_OcommonDBO->_select("employee_passport_mapping", array("r_passenger_id"),"r_passenger_id",$passId);
        if(!empty($result)){
            // update that details
            $passDetails = array();
            $passDetails['r_passenger_id'] = $result[0]['r_passenger_id'];
            $result = $this->_Opassenger->_updatePassportDetails($input,$passDetails);
        }else{
            // insret the data
            $lastInsId = $this->_OcommonDBO->_insert("dm_passport", $insertUpdateArray);
            $insertArray = array(
                "r_passport_id" => $lastInsId,
                "r_employee_id" => '0',
                "r_passenger_id" => $passId
            );

            return $lastInsId = $this->_OcommonDBO->_insert("employee_passport_mapping", $insertArray);
        }
        return true;
    }
}

?>
