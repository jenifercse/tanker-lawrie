<?php
/************************************************************************
 * @Class Name	: class.errorHandling.php
 * @Created on	: 2017-10-23
 * @Created By	: Baskar.V.P
 * @Description	: This file is used to error handling mail sending process while under flow
 **************************************************************************/
fileRequire("lib/common/commonMethods.php");
class errorHandling{
    
    public function __construct(){
        
    }
    
   /**
    * @Description :This function is used to send mail while booking flow not getting proceessed scenario
    */
    public function _errorHandlingFlow($mailData,$subject,$msg,$devCheck='N'){
        $this->_Otwig = init();
        $mailData  .= "\n\n Server Host   : ".$_SERVER['HTTP_HOST']."\n\n";
        $this->_AtwigOutputArray['error_data'] = $mailData;
        $this->_AtwigOutputArray['warmText'] = $devCheck == 'N' ? 'Balmer' : 'Team';
        $this->_AtwigOutputArray['msg'] = $msg;
        $this->_AtwigOutputArray['mailSignature'] = EMAIL_SIGNATURE;
        $str = $this->_Otwig->render('errorMails.tpl',$this->_AtwigOutputArray);
        $OcommonMethods = new commonMethods();
        if($devCheck == 'N'){
            $returnValue = $OcommonMethods->_sendMail(BALMER_MAIL_REQUEST_INFO,'support@atyourprice.in',$subject,$str,'','',BALMER_MAIL_REQUEST_BCC);
        }else{
            $returnValue = $OcommonMethods->_sendMail(TOMAILID,'support@atyourprice.in',$subject,$str);
        }
        
        return $returnValue;
    }    
    /**
     * @Description  This method is used to send the error mail to developer.
     * @param|array,string,string:$requestData,$errorSyncName,$errorMsg
     * @date: 24-01-2018
     * @return|array:$response
     * @author:Karthika.M
     */ 
    public function _setErrorMsg($requestData,$errorSyncName,$errorMsg){
        $response = $this->_errorHandlingFlow(json_encode($requestData),$errorSyncName,$errorMsg,'Y');
        
        return array('status' => 0,'response' => 'FAILURE','message' => $errorMsg,'mailResponse' => $response);
    }
}