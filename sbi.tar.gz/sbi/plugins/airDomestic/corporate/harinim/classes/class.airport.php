<?php
/** * **********************************************************************
 * @Class Name	: airport
 * @Created on	: 2016-07-05
 * @Created By	: Thirumal
 * @Updated By  : --
 * @Update Info : -- 
 * @Description	: This file is used to insert,update and get airport related datas
 * ************************************************************************ */
            
fileRequire("lib/common/commonMethods.php");

class airport{
    private $_OcommonDBO;
    public $_SemailId='';
    public $_IemployeeId=0;

    //Constructor
    public function __construct(){
       $this->_OcommonDBO=new commonDBO();
    }
    
    /**
     * @description method to get airport details
     * @param string $airportCode unique id of the airport, if code found return airport id else return all the fields
     * @return type array
     */
    public function _getAirportData($airportCode=''){
         
        if($airportCode!=''){
            $result =  $this->_OcommonDBO->_select('dm_airport','airport_id','airport_code',$airportCode);
            if($result!==false){
                
                return $result[0]['airport_id'];
            }else{

                return false;
            }
        }
        else{
            $result =  $this->_OcommonDBO->_select('dm_airport','*','airport_code',$airportCode);
            if($result){

                return $result;
            }else{

                return false;
            }
        }
    }
    
    public function _getAllCityAirports(){
        $sql = "SELECT da.airport_id,da.airport_code,da.city_name,ds.state_name
                FROM dm_airport da 
                INNER JOIN dm_country dc ON da.r_country_id = dc.country_id
                INNER JOIN fact_location fl ON dc.country_id = fl.r_country_id
                INNER JOIN dm_state ds ON fl.r_state_id = ds.state_id
                WHERE dc.country_code_ISO1 = '".$this->_IcountryId."'";
        
        $result = $this->_OcommonDBO->_getResult($sql);
        
        return $result;
    }
    
    
    public function _getAllAirports(){
        $sql = "SELECT da.airport_id,da.airport_code,da.city_name
                FROM dm_airport da INNER JOIN dm_country dc ON da.r_country_id = dc.country_id
                WHERE dc.country_code_ISO1 = '".$this->_IcountryId."'";
        $result = $this->_OcommonDBO->_getResult($sql);
        
        return $result;
    }
    
    /**
     * @param type $airportid
     * @return type
     */
    public function _getAirportName($airportid){
        $sql = "SELECT dma.airport_code,ad.airport_name,dma.city_name,dma.airport_desc,ad.airport_name
                FROM dm_airport dma 
                LEFT JOIN airport_details ad ON dma.airport_id=ad.r_airport_id
                WHERE airport_id=".$airportid;
        $result = $this->_OcommonDBO->_getResult($sql);
        
        return $result;
    }
    
    /**
     * @Function _getMealType
     * @param type $meal_code_id
     * @return type Array
     * @Author SELVAKUMAR.S
     * @Description To get Meal type by Meal code id 
     */
    public function _getMealType($meal_code_id){
        $sql = "SELECT meal_description
                FROM dm_meal_code_details
                WHERE meal_code_id=".$meal_code_id;
        $result = $this->_OcommonDBO->_getResult($sql);
        
        return $result;        
    }
    
    /**
     * @Function _getMultipleAirportCity
     * @param array|$airportCodeArray
     * @return resultset|$returnValue
     * @Description To get cityies with the airport code 
     */
    public function _getMultipleAirportCity($airportCodeArray){
        
        $_AAirlineCode          = $this->_getAirLineCode();
        $_AAirlineCodeCityName  = array_column($_AAirlineCode, 'city_name','airport_code');
        $_AAirlineCodeAbbr      = array_column($_AAirlineCode, 'airport_code','airport_code');
        
        if(is_array($airportCodeArray)){
            array_walk($airportCodeArray, function(&$value, &$key) use($_AAirlineCodeCityName, $_AAirlineCodeAbbr) {
                $pos      = strstr($value, "(");
                $citycode = $pos ? substr(trim($value),-4,3) : $value;
                $value    = array('city_name' => $_AAirlineCodeCityName[$citycode], 'order_id' => $key, 'airport_code' => $_AAirlineCodeAbbr[$citycode]);
            });
            $returnValue = $airportCodeArray;
        }else {
            $returnValue = false;
        }
        
        return $returnValue;
    }
    
    private function _getAirLineCode(){
        $sql         = "SELECT city_name, airport_code FROM dm_airport";
        $result      = $this->_OcommonDBO->_getResult($sql);
        
        return $result;
    }
}
?>