<?php
/* * **************************************************************************
 * @File             : class.overRideNewItinerary.php
 * @Description      : This file is used to send approval and insert the flight itinerary details
 * @Tables Affected  :1.air booking details 2.via_fare_details 3.via_flight_details 4.fact_air_itinerary 5.passenger_via_details
 * @Author           : Karthika
 * @Created Date     : 08/12/2016
 * @Modified Date    : 
 * ****************************************************************************/
pluginFileRequireBasic('common/','interface/commonConstants.php');
class overRideNewItinerary implements commonConstants{

    public function __construct(){
        $this->_OcommonDBO =new commonDBO();
        $this->_OFlightItinerary = new flightItinerary();
        $this->_Opackage = new package();
        $this->_OcommonQuery = common::_checkClassExistsInNameSpace('commonQuery');
        $this->_OairRequest = new airRequest();
        $this->_Otwig = init();
        $this->_IorderTripType = 0;
    }
    
    public function _insertOverRideItinerary($input){
                
        //set trip typess
        $this->_IorderTripType = $input['tripType'];      
        
        //get the travel mode id.
        $travelMode = $this->_OcommonDBO->_select('order_details',array('r_travel_mode_id'),'order_id',$input['order_id'])[0]['r_travel_mode_id'];
       
        //for international round trip.
        if($travelMode == SELF::INTERNATIONAL_AIR_MODE_ID && $input['tripType'] == 1){  
            $this->_ItripType = '0,1';
            $finalResponse = $this->_overrideNewItinerary($input,'0,1','onwardFlightOverRide'); 
        }      
        else if($input['tripType'] == 0){//Domestic one way , International one way
            $this->_ItripType = 0;
            $finalResponse = $this->_overrideNewItinerary($input,$input['tripType']);             
        }
        else if($input['tripType'] == 1){//Domestic round trip.
            $finalResponse = $this->_overrideSingleItineraryByAction($input);
        }       
        return $finalResponse;        
    }    
    
    //function used to insert the new selected itinerary based on the trip type and action.
    public function _overRideSingleItinerary($finalArray,$tripType,$orderId,$action = ''){
        
        $this->_OfareDetails= new fareDetails();
        $this->_OpassengerPreferences = new passengerPreferences();
         
        // get travel mode
        $_ItravelModeId = $this->_Opackage->_getOrderDetails($orderId, array('r_travel_mode_id'))[0]['r_travel_mode_id'];        
       
        // get travel class id        
        $_ItravelClassId  = $this->_OairRequest->_getAirRequestDetails($orderId)[0]['r_travel_class_id'];          
        
        // get fact booking details info      
        $_AfactBookingInfo  = $this->_OcommonDBO->_select('fact_booking_details','*', 'r_order_id', $orderId)[0];        
        
        //set required values for insert flight itinerary functionality
        $this->_OFlightItinerary->_corporateId    = $_AfactBookingInfo['r_corporate_id'];
        $this->_OFlightItinerary->_orderId        = $_AfactBookingInfo['r_order_id'];
        $this->_OFlightItinerary->_IemployeeId    = $_AfactBookingInfo['r_employee_id'];
        $this->_OFlightItinerary->_ITravelModeId  = $_ItravelModeId;
        $this->_OFlightItinerary->_ITravelClassId = $_ItravelClassId;
        
        //get user application settings info.
        $Ocorporate = new corporateCustomization();
        $Ocorporate->_IcorporateId = $_AfactBookingInfo['r_corporate_id'];;
        $this->_AsettingsArray = $Ocorporate->_getCorporateSettingsFromJSON();
        
        $airBookingFieldArray = array('air_booking_details_id');
        $airBookingDetailsId  = $this->_OcommonDBO->_select('air_booking_details', $airBookingFieldArray, 'r_order_id', $orderId)[0];
        $this->_OFlightItinerary->_AairBookingDetailsId = $airBookingDetailsId['air_booking_details_id'];       
        
        //assigning flight search array to variables
        if($tripType == 0){
           $selectedOnwardFlight = $finalArray['selectedOnwardFlight']; 
        }
        else if($tripType == 1){
            if($action == 'onwardFlightOverRide'){
               $selectedOnwardFlight = $finalArray['selectedOnwardFlight']; 
            }
            else if($action == 'returnFlightOverRide'){
               $selectedReturnFlight = $finalArray['selectedReturnFlight'];
            }
            else{
               $selectedOnwardFlight = $finalArray['selectedOnwardFlight'];
               $selectedReturnFlight = $finalArray['selectedReturnFlight'];
            }           
        }
        
        fileRequire("./plugins/common/classes/class.insertFlightItinerary.php");
        $this->_OitinerayInsert = new commonInsertFlightItinerary();
        $this->_OitinerayInsert->_IinputData = $finalArray;
        $this->_OitinerayInsert->_AsettingsArray = $this->_AsettingsArray;  
        $this->_OitinerayInsert->_IinputData['employeeInfo']   = $_AfactBookingInfo; 
        
        //Get fee array for GST calculation
        $feeTotal =  $this->_OitinerayInsert->_getFeeValues();
        $this->_OFlightItinerary->_AfeeArray = $this->_OitinerayInsert->_AfeeArray;
        $this->_OFlightItinerary->_BcalculateCommission = $this->_OitinerayInsert->_BcalculateCommission;
        $this->_OFlightItinerary->_IorderTipType = $this->_IorderTripType;

        //insert onward selected fare details
        if(isset($selectedOnwardFlight) && !empty($selectedOnwardFlight)){
            $this->_SselectedFlight  = 'Y';             
            $this->_tripType = 0;
            $responseValue = $this->_OFlightItinerary->_insertFlightItinerary($selectedOnwardFlight, '', $this->_tripType, $this->_SselectedFlight);
        }        
        //insert return selected fare details
        if(isset($selectedReturnFlight) && !empty($selectedReturnFlight)){
            $this->_SselectedFlight  = 'Y';    
            $this->_tripType = 1;
            $responseValue = $this->_OFlightItinerary->_insertFlightItinerary($selectedReturnFlight, '', $this->_tripType, $this->_SselectedFlight);
        }
        
        $this->_OitinerayInsert->_IinputData['travelModeId']    = $_ItravelModeId;
        $this->_OitinerayInsert->_IinputData['travelClassId']   = $_ItravelClassId; 
       
        $this->_OitinerayInsert->_getFeeDetailsForBooking("UPDATE",$orderId);  

        //upadate discount fee on itinerary change
        $this->_OitinerayInsert->_updateBookingFeeDetails($orderId);
        
        $updatedBookingfeeStatus = $this->_OitinerayInsert->_updatedbookingFeeMapping;
        
        //clear the SSR info.
        $this->_resetSSRByTripType($orderId,$this->_ItripType);        
       
        //calculate the total amount for the order id.
        $orderTotalAmount = $this->_OfareDetails->_calculateOrderTotalAmount($orderId);

        // update total amount in order details
        $updateOrderArray['total_amount'] = $orderTotalAmount;
        $orderUpdateResult = $this->_Opackage->_updateOrderDetails($updateOrderArray,$orderId);

        // update booking history total amount 
        $bookingHistoryUpdate = $this->_Opackage->_updateBookingHistory($updateOrderArray,$orderId);
        if($orderUpdateResult != 0 && $responseValue != 0){           
            return 1;
        }
    }
    
    //function used to get the request level data.
    public function _getRequestLevelData($orderId,$inputData){
        
        $this->_Oairline = new airline();
        $this->_OairRequest=new airRequest();
        $this->_Oitinerary = new flightItinerary();
   
        $this->_AserviceResponse['markUpXml'] = 'EMPTY';
        
        //get air request data
        $resultArrayForRequest = $this->_OairRequest->_getAirRequestDetails($orderId);
        $_AjsonTOArray=json_decode($resultArrayForRequest[0]['customize_fields'],1);
        $validateAdvanceSearchDeatils=$this->_OairRequest->_validateAdvanceSearchDeatils($_AjsonTOArray);
        if($inputData['travelModeData'] != 'I'){
            $resultArrayForRequestAmount = $this->_OairRequest->_getAirRequestBookingDetailsAmount($orderId,$inputData['tripType']);
        }
        else{
            $resultArrayForRequestAmount = $this->_OairRequest->_getAirRequestBookingDetailsAmount($orderId);
        }

        $countStops = count($resultArrayForRequestAmount) -1;
        //request forming for low fare flight search
        $this->_requestData['cabinclass'] = $resultArrayForRequest[0]['cabinClass'];
        $this->_requestData['agentId'] = SERVICE_AGENCY_ID;
        $this->_requestData['num_passenger'] = $resultArrayForRequest[0]['num_passenger'];
        $this->_requestData['cabinclassTrigger'] = $resultArrayForRequest[0]['cabinClass'];
        $this->_requestData['cabinclassTotal'] = $this->_OcommonQuery->_setCabinClass($resultArrayForRequest[0]['cabinClass']);
        $this->_requestData['refundableFare'] = 'N'; // N
        $this->_requestData['currency_type'] = 'INR'; // INR
        $this->_requestData['sector']['origin'] = $resultArrayForRequest[0]['mainOriginCode'];
        $this->_requestData['sector']['destination'] = $resultArrayForRequest[0]['mainDestinationCode'];
        $this->_requestData['date']['onward'] = $resultArrayForRequest[0]['onward']; // 2017-03-06
        $this->_requestData['date']['return'] = $resultArrayForRequest[0]['returnDate']; // 2017-03-06
        $this->_requestData['types']['requestedAirline'] = array('0'=>array('9W','AI','UK'),'1'=>'9W','2'=>'AI','3'=>'UK');
        $this->_requestData['passengers'] = array(
                                                'adult'  => $resultArrayForRequest[0]['ADT'],
                                                'child'  => $resultArrayForRequest[0]['CH'],
                                                'infant' => $resultArrayForRequest[0]['INF']
                                                ); 
        $this->_requestData['promoCode']['airline'] = array();
        $this->_AfinalResponse['travelInfo']['adult'] = $resultArrayForRequest[0]['ADT'];
        $this->_AfinalResponse['travelInfo']['child'] = $resultArrayForRequest[0]['CH'];
        $this->_AfinalResponse['travelInfo']['infant'] = $resultArrayForRequest[0]['INF'];
        
        $this->_AfinalResponse['date_departure'] = $resultArrayForRequestAmount[0]['departure_date'];
        $this->_AfinalResponse['stops'] = $countStops;        
        
        $baseFare = array_sum(array_column($resultArrayForRequestAmount,'base_fare'));
        $tax = array_sum(array_column($resultArrayForRequestAmount,'tax'));
        $serviceTax = array_sum(array_column($resultArrayForRequestAmount,'service_tax'));
        
        $this->_requestData['order_amount']      = $baseFare + $tax + $serviceTax;
        $this->_requestData['orderTotalAmount']  = $baseFare + $tax;
        $this->_requestData['time_departure']    = $resultArrayForRequestAmount[0]['time_departure'];
        $this->_AfinalResponse['date_departure'] = $resultArrayForRequestAmount[0]['departure_date'];
        
        //Tax code from config 
         $this->_AfinalResponse['configTaxCode']= array('SG'=>array('WO'=>'','YQ'=>'','CMF'=>'','RCS'=>''),'6E'=>array('PHF'=>'','YQ'=>'','TTF'=>'','RCS'=>'','RCF'=>''),'G8'=>array('PHF'=>'','YQ'=>'','RCS'=>''),'9W'=>array('YR'=>'','YQ'=>''),'AI'=>array('YR'=>'','YQ'=>''),'UK'=>array('YR'=>'','YQ'=>''));

         $sysParamValue =  $this->_Oitinerary->_getTaxValues('SERVICE_TAX',0);
         if($sysParamValue!=''){
             $this->_AfinalResponse['serviceTaxPercent'] =$sysParamValue;
         }
        $this->_AfinalResponse['fareProfileSettings'] = $this->_OcommonQuery->_getSettingsDisplayData($inputData['packageId'], 'Flight_Search_Configurations');

        foreach ($this->_AfinalResponse['fareProfileSettings']['Businsess_class_Settings'] as $key => $value) {
            $this->_requestData['bookingClassData'][$key] = explode(",",$value);
        }
        
       if(!empty($validateAdvanceSearchDeatils)) {
        $this->_AfinalResponse['validAdvancedSearchDetails'] = $validateAdvanceSearchDeatils;
       }
        $this->_AfinalResponse['dataForRequest'] =$this->_requestData;        
        return true;
    }
    
    public function _removeSSR($orderId,$tripType){
        $sql = "DELETE FROM fact_passenger_preferences  
                WHERE r_order_id = ".$orderId." AND trip_type in(".$tripType.")";        
        $this->_OcommonDBO->_getResult($sql);
    }
    
    public function _setFactPassengerPreferenceInput($orderId){
        $sql = "SELECT od.order_id,od.order_id AS r_order_id,od.r_travel_mode_id AS travelMode,dp.package_type,
                od.r_travel_mode_id,fbd.r_request_id,od.total_amount,od.sync_order_id,dp.package_id,ard.trip_type   
                FROM fact_booking_details fbd,order_details od,dm_package dp,air_request_details ard 
                WHERE fbd.r_order_id = ".$orderId." AND od.order_id = fbd.r_order_id 
                AND dp.package_id = fbd.r_package_id AND ard.air_request_id = fbd.r_request_id";
        return $this->_OcommonDBO->_getResult($sql);
    }
    
    // function used to rendering the template with selected new itinerary array    
    public function _getRenderOverRideDiv($input){
        // rendering the array twig template.
        $input['itineraryInfo']['reqAirCode'] = gettype($input['itineraryInfo']['reqAirCode']) == 'array' ? 'SB' : $input['itineraryInfo']['reqAirCode'];
        $_AtwigOutputArray['allItineraryInfo'] = $input['itineraryInfo'];
        $_AtwigOutputArray['oldItineraryInfo'] = $input['oldItineraryInfo'];
        // to set displat settings color code itenarty
        $_AtwigOutputArray['settingsDisplayData'] = $this->_OcommonQuery->_getSettingsDisplayData($input['packageId'],'Itinerary_Level_Configurations');
        // to set displat settings color code flight
        $_AtwigOutputArray['settingsDisplayDataColorCode'] = $this->_OcommonQuery->_getSettingsDisplayData($input['packageId'],'Flight_Search_Configurations');
        $_AtwigOutputArray['action'] = $input['trip'];
        if($input['trip'] == 'onwardFlightOverRide'){
            $_AtwigOutputArray['onwardItineraryInfo'] = $input['itineraryInfo'];
        }else{
            $_AtwigOutputArray['returnItineraryInfo'] = $input['itineraryInfo'];
        }
        $this->_AfinalResponse['template'] = $this->_Otwig->render('corporateItinerary/overRideFlightItinerary.tpl', $_AtwigOutputArray);        
    }

    //function used to override the previous itinerary with selected low fare itinerary for domestic one way and internation oneway and round trip.
    public function _overrideNewItinerary($input,$tripType,$action = ''){
        
        //set new selected itinerary array.
        $finalArray['selectedOnwardFlight']  = $input['newItineraryInfo']['onwardFlightData']; 
        
        if(is_array($input['newItineraryInfo']['returnFlightData']) && count($input['newItineraryInfo']['returnFlightData']) > 0){
            $finalArray['selectedReturnFlight'] = $input['newItineraryInfo']['returnFlightData'];
        }
        
        //update the status in fact air itinerary for old via flights
        $updatedStatus =  $this->_OFlightItinerary->_updateFactAirItineraryStatus($input['order_id'],$tripType);  
        
        //insert the new itinerary.
        $insertedNewItinerary = $this->_overRideSingleItinerary($finalArray,$input['tripType'],$input['order_id'],$action);
        if($updatedStatus != 0 && $insertedNewItinerary != 0){
            return "Success";
        }        
    }
    
    //override either onward or return for domestic round trip.
    public function _overrideSingleItineraryByAction($input){
        
        //override the both the itinerary in domestic roundtrip.
        if($input['newItineraryInfo']['action'] == 'both'){
            $this->_ItripType = '0,1';
            return $this->_overrideNewItinerary($input,'0,1');
        }
        else{            
            //set trip type
            $tripType = 0;
            //set the value based on the action.
            if($input['newItineraryInfo']['action'] == 'onwardFlightOverRide'){
                $finalArrayIndex = 'selectedOnwardFlight';
                $finalArrayValue = 'onwardFlightData';
                $passengerFareIndex = 'selectedReturnFlight';
                $oldTripType = $tripType;
                $fareTripType = $input['tripType'];
                $this->_ItripType = 0;
            }
            else{
                $finalArrayIndex = 'selectedReturnFlight';
                $finalArrayValue = 'returnFlightData';
                $passengerFareIndex = 'selectedOnwardFlight';
                $oldTripType = $input['tripType'];
                $fareTripType = $tripType;
                $this->_ItripType = 1;
            }                
            
            //set the selected array
            $finalArray[$finalArrayIndex] = $input['newItineraryInfo'][$finalArrayValue];     
            
            //update the cancel status for previous itinerary
            $updatedStatus =  $this->_OFlightItinerary->_updateFactAirItineraryStatus($input['order_id'],$oldTripType);  
            
            //get the fare info of the previous itinerary
            $passengerFare = $this->_OFlightItinerary->_getFlightFareDetails($input['order_id'],$fareTripType);
            
            //set the array insert the fare details for the via flights.
            if(count($passengerFare) > 0){              
               $finalArray[$passengerFareIndex]['passenger_fare'] = $passengerFare['passengerFare'];
               $finalArray[$passengerFareIndex]['via_flights'] = $passengerFare['viaFlights'];    
               $finalArray[$passengerFareIndex]['taxBreakUP'] = $passengerFare['passengerFare'][0]['taxBreakUpDetails'];
               $overRideResponse = $this->_overRideSingleItinerary($finalArray,$input['tripType'],$input['order_id'],$input['newItineraryInfo']['action']);
            }   
            if($updatedStatus != 0 && $overRideResponse != 0){
                return "Success";
            }
        }
    }
    
    //function used to reset the ssr based on the trip type
    public function _resetSSRByTripType($orderId,$tripType){        
        
        //delete ssr details with respect to the order id and trip type.
        $this->_removeSSR($orderId,$tripType);
        
        //insert passenger preferences for overrided flights.
        $this->_setPassengerPreferencesInfo($orderId,$tripType);
        return TRUE;
    }    
    
    //function used to insert the passenger preferences info with respect to the trip type.
    public function _setPassengerPreferencesInfo($orderId,$tripType){
        
        $this->_OpassengerPreferences = new passengerPreferences();
        
        $preferencesType = explode(',', PREFERENCES_TYPE);
        
        $passengerPreferencesInfo = $this->_getPassengerPreferencesInfo($orderId,$tripType);
        
        foreach($preferencesType as $type){
            foreach($passengerPreferencesInfo as $key => $value){
                $value['status'] = 'Y';
                $value['preferences_type'] = $type;
                $lastInsertedPreferences[] = $this->_OpassengerPreferences->_insertPassengerPreference($value);
            }
        }
        return $lastInsertedPreferences;
    }
    
    //function used to get the passenger preferences info
    public function _getPassengerPreferencesInfo($orderId,$tripType){
        $sql = 'SELECT pvd.r_passenger_id,pvd.r_via_flight_id,vfd.trip_type,fbd.r_package_id,pvd.r_order_id
                FROM
                    passenger_via_details pvd
                    INNER JOIN fact_booking_details fbd ON fbd.r_order_id = pvd.r_order_id
                    INNER JOIN via_flight_details vfd ON vfd.via_flight_id = pvd.r_via_flight_id
                    INNER JOIN fact_air_itinerary fai ON pvd.r_via_flight_id = fai.r_via_flight_id
                WHERE 
                    fai.itinerary_status = '.SELECTED_ITINERARY.' AND pvd.r_order_id = '.$orderId.' AND vfd.trip_type IN('.$tripType.')';
        return $this->_OcommonDBO->_getResult($sql); 
    }
}