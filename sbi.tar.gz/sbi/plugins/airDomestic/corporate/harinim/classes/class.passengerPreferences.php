<?php
/** **********************************************************************
 * @Class Name	: class.passengerPreferences.php
 * @Created on	: 2017-01-30
 * @Created By	: sivaprakash.M
 * @Description	: This file is used to insert,update passenger preferences
 * ************************************************************************ */
class passengerPreferences{

    public function __construct(){
       $this->_OcommonDBO=new commonDBO();
       $this->_Opackage = new package();
    }

    /*
     * @functionName    :   _getSeatPreferences()
     * @description     :   to get the seat preferences
     * @param           :   $input array
     * @return          :   array details of seat preferences
     */
    public function _getSeatPreferences($input = ''){
        return $this->_OcommonDBO->_select('dm_seat_code_details', 'seat_code_id, seat_description', 'status', 'Y');
    }
    
    /*
     * @functionName    :   _getMealPreferences()
     * @description     :   to get the meal preferences
     * @param           :   $input array
     * @return          :   array details of meal preferences
     */
    public function _getMealPreferences($input = ''){
        return $this->_OcommonDBO->_select('dm_meal_code_details', 'meal_code_id, meal_description', 'status', 'Y');
    }
    
    /**
     * @functionName    :   _insertPassengerPreference()
     * @description     :   to insert the passenger preferences
     * @param           :   $input array
     * @return          :   lastInsertedPreferences ids
     * @author sivaprakash
     */
    public function _insertPassengerPreference($input = ''){
       return count($input) > 0 ? $this->_OcommonDBO->_insert('fact_passenger_preferences',$input) : FALSE;
    }
    
    /**
     * @functionName    :   _getPassengerPreference()
     * @description     :   to get passenger based preferences
     * @param           :   $input array
     * @return          :   passenger preference array
     * @author sivaprakash
     */
    public function _getPassengerPreference($input = ''){
       $sql = " SELECT seat_preference, meal_type FROM passenger_other_details
                WHERE r_passenger_id = '".$input['r_passenger_id']."'";
       return $this->_OcommonDBO->_getResult($sql);
    }
    
    /**
     * @functionName    :   _getPassengerFrequentFlyerDetails()
     * @description     :   to get passenger based frequent flyer details
     * @param           :   $input array
     * @return          :   frequent flyer array
     * @author sivaprakash
     */
    public function _getPassengerFrequentFlyerDetails($passengerId = '',$viaFlightId = ''){
       $sql = " SELECT frequent_flyer_no FROM passenger_via_details
                WHERE r_passenger_id = ".$passengerId." AND r_via_flight_id = ".$viaFlightId;
       return (!empty($passengerId) && !empty($viaFlightId)) ? $this->_OcommonDBO->_getResult($sql) : '';
    }
    
    /*
     * @functionName    :   _getPassengerFrequentFlyerDetails()
     * @description     :   to get passenger based frequent flyer details
     * @param           :   $input array
     * @return          :   frequent flyer array
     */
    public function _getFlightPassengerFrequentFlyerDetails($passengerId = '',$viaFlightId = ''){
        
       $sql = " SELECT pvd.frequent_flyer_no as number,(select airline_code from dm_airline where airline_id=vfd.r_airline_id) as airlineCode
                FROM passenger_via_details pvd INNER JOIN via_flight_details vfd ON vfd.via_flight_id = pvd.r_via_flight_id
                INNER JOIN fact_air_itinerary fai ON fai.r_via_flight_id=vfd.via_flight_id 
                WHERE fai.itinerary_status=".SELECTED_ITINERARY." ";
       
       if($passengerId!=0){
           $sql.=" AND pvd.r_passenger_id = ".$passengerId." ";
       }
       if($viaFlightId!=0){
           $sql.=" AND pvd.r_via_flight_id = ".$viaFlightId." ";
       }
       
       $sql.=" GROUP BY vfd.r_airline_id";
       return  $this->_OcommonDBO->_getResult($sql);
    }

    /*
     * @functionName    :   _getEmployeeMealType()
     * @description     :   to get employee meal details
     * @param           :   $empId  int
     * @return          :   mealpreferences array
     */
    public function _getEmployeeMealType($empId){
        $sql = " SELECT  mt.meal_description as meal FROM dm_meal_code_details  mt"
                . " INNER JOIN employee_details ed ON  ed.r_meal_id =mt.meal_code_id

                and  ed.r_employee_id = '".$empId."' ";
        return $this->_OcommonDBO->_getResult($sql);
    }
    
    /*
     * @functionName    :   _getEmployeeSeatType()
     * @description     :   to get employee seat details
     * @param           :   $empId  int
     * @return          :   seatpreferences array
     */
    public function _getEmployeeSeatType($empId){
        $sql = " SELECT  scd.seat_description as seat  FROM dm_seat_code_details  scd"
                . " INNER JOIN employee_details ed ON  ed.r_seat_code_id =scd.seat_code_id

                and  ed.r_employee_id = '".$empId."' ";
        return $this->_OcommonDBO->_getResult($sql);
    }
    
    /*
     * @functionName    :   _updateFrequentFlyerTable()
     * @description     :   to update frequent_flyer_no Table
     * @param           :   $UpdateArray array
     * @return          :   updated row count
     */
    public function _updateFrequentFlyerTable($UpdateArray){
        $sql = "UPDATE frequent_flyer_details SET frequent_flyer_no = '".$UpdateArray['frequent_flyer_no']."' WHERE r_employee_id = '".$UpdateArray['r_employee_id']."' AND r_airline_id = '".$UpdateArray['r_airline_id']."' ";
        $returnResult = $this->_OcommonDBO->_Oconnection->query($sql);
        $this->_OcommonDBO->_backTraceQuery($sql);
        !$returnResult ? $this->_OcommonDBO->_backTraceQuery($sql, 'SqlError', 'frequent_flyer_details') : '';
        return !$returnResult ? '' : $returnResult->rowCount();
    }
    
    /*
     * @functionName    :   _updatePassengerViaDetails()
     * @description     :   to update passenger_via_details table
     * @param           :   $UpdateArray array
     * @return          :   updated row count
     */
    public function _updatePassengerViaDetails($UpdateArray){
        $sql =" UPDATE passenger_via_details SET frequent_flyer_no = '".$UpdateArray['frequent_flyer_no']."' WHERE r_via_flight_id = '".$UpdateArray['r_via_flight_id']."' AND r_passenger_id = '".$UpdateArray['r_passenger_id']."' ";
        $returnResult = $this->_OcommonDBO->_Oconnection->query($sql);
        $this->_OcommonDBO->_backTraceQuery($sql);
        !$returnResult ? $this->_OcommonDBO->_backTraceQuery($sql, 'SqlError', 'passenger_via_details') : '';
        return !$returnResult ? '' : $returnResult->rowCount();
    }
    
   /*
    * @functionName    :   _setPassengerPreferences()
    * @description     :   to set the passenger preferences details and form array
    * @param           :   $orderArray $inputdata |array
    * @return          :   lastInsertedPreferences ids
    */
    public function _setPassengerPreferences($orderArray,$inputdata,$tripType=''){
        if($tripType==""){
            foreach ($orderArray as $ordkey => $ordvalue){
                // delete preferences before insert data exists
                $this->_OcommonDBO->_delete('fact_passenger_preferences', 'r_order_id',$ordvalue['r_order_id']);
            }
        }

        // prepare array for preferences type
        $preferencesType = explode(',', PREFERENCES_TYPE);
        for($trip = $inputdata['trip_type']; $trip >= 0; $trip--){
            foreach ($orderArray as $ordkey => $ordvalue){
                
                $passengerId = $this->_OcommonDBO->_select('passenger_details', 'passenger_id', 'r_order_id',$ordvalue['r_order_id']);
                
                //assigining data for passenger details array
                foreach ($passengerId as $paskey => $pasvalue){

                    $insertData['r_package_id'] = $inputdata['package_id'];
                    $insertData['r_order_id'] = $ordvalue['r_order_id'];
                    $insertData['r_passenger_id'] = $pasvalue['passenger_id'];

                    $viaFlightIdArray = $this->_getViaFlightIdBasedOnOrderPassengerTripType($ordvalue['r_order_id'],$pasvalue['passenger_id'],$trip);

                    foreach ($viaFlightIdArray as $viakey => $viavalue){
                        $insertData['r_via_flight_id'] = $viavalue['r_via_flight_id'];
                        $insertData['status'] = 'Y';
                        // assigining preferences details array for the passenger based on trip type
                        foreach ($preferencesType as $prefkey => $prefvalue){
                            $insertData['preferences_type'] = $prefvalue;
                            $insertData['trip_type'] = $trip;
                            if($tripType!=""){
                                if($tripType==$trip){
                                    // call function to insert passenger preferences
                                    $lastInsertedPreferences[] = $this->_insertPassengerPreference($insertData);
                                }
                            }else{
                        // insert gds ssr details    
                            if(isset($inputdata['gdsSsretails']) && count($inputdata['gdsSsretails'] > 0)){
                                $insertData['ssr_preferences_fare'] = $inputdata['gdsSsretails'][$trip][$paskey][$viakey][$prefvalue]['ssr_preferences_fare'];
                                $insertData['ssr_preferences_name'] = $inputdata['gdsSsretails'][$trip][$paskey][$viakey][$prefvalue]['ssr_preferences_name'];
                            }
                                // call function to insert passenger preferences
                                $lastInsertedPreferences[] = $this->_insertPassengerPreference($insertData);
                            }
                        }
                    }
                }
            }
            unset($insertData);
        }
        return $lastInsertedPreferences;
    }
    
    /**
     * used to get the passenger via flight based on orderid passengerid trip type
     * @param type $orderId
     * @param type $passengerId
     * @param type $tripType
     * @return type viaflightid | int or boolean false
     * @author sivaprakash
     */
    private function _getViaFlightIdBasedOnOrderPassengerTripType($orderId,$passengerId,$tripType = 0){

        $sql="  SELECT
                    psd.r_via_flight_id
                FROM
                    passenger_via_details psd
                    INNER JOIN via_flight_details vfd ON psd.r_via_flight_id = vfd.via_flight_id
                WHERE
                    psd.r_order_id = $orderId AND psd.r_passenger_id = $passengerId
                    AND vfd.trip_type = $tripType AND vfd.low_fare_status = 'Y' ";

        return (!empty($orderId) && !empty($passengerId)) ? $this->_OcommonDBO->_getResult($sql) : FALSE;
    }
    
   /**
    * used to get ordere based ssr fare details
    * @param type $orderId int
    * @param type $viaFlightId int
    * @param type $passengerId int
    * @return type Description array consist of ssr details request array fare or boolean false
    * @author sivaprakash
    */
    public function _getSSRpreferencesFareDetails($orderId,$viaFlightId = 0,$passengerId = 0){

        $sql =" SELECT
                    fpp.ssr_preferences_fare, fpp.ssr_preferences_name, uncompress(fpp.ssr_preferences_value) as ssr_preferences_value, fpp.preferences_type,fpp.preferences_value_id,
                    fpp.r_passenger_id, fpp.r_order_id, fpp.r_via_flight_id, fpp.trip_type, pd.email_id,pd.passenger_type
                FROM
                    fact_passenger_preferences fpp
                    INNER JOIN passenger_details pd ON fpp.r_passenger_id = pd.passenger_id
                WHERE
                    fpp.r_order_id = $orderId ";
            // check query based on condition on via flight id
            ($viaFlightId != 0) ? $sql.=" AND fpp.r_via_flight_id IN(".$viaFlightId.")" : FALSE;
            // check query based on condition on passenger id
            ($passengerId != 0) ? $sql.=" AND fpp.r_passenger_id =".$passengerId. " ORDER BY fpp.r_via_flight_id" : FALSE;   
            
            if($viaFlightId == 0 && $passengerId == 0){
                $sql .= " GROUP BY fpp.passenger_preferences_id ORDER BY fpp.trip_type,fpp.r_via_flight_id";    
            }
            return !empty($orderId) ? $this->_OcommonDBO->_getResult($sql) : FALSE;
        }

    /*
     * @Description  Function used to get the meal code details.
     * @param array|$mealInfo
     * @return array|$finalArray
     * @date|10.09.2017
     * @author|Karthika.M
     */
    public function _getMealCodeInfo($mealInfo){
        $sql = "SELECT *
                FROM dm_meal_code_details dmc
                WHERE dmc.meal_description = '".trim($mealInfo['SSRName'])."' AND dmc.meal_code = '".trim($mealInfo['SSRCode'])."' AND
                dmc.r_airline_code = '".trim($mealInfo['airlineCode'])."' AND dmc.status = 'Y'";
        return  $this->_OcommonDBO->_getResult($sql);
    }

    /*
     * @Description  Function used to insert the meal code details.
     * @param array|$mealInfo
     * @return int|insertedId
     * @date|10.09.2017
     * @author|Karthika.M
     */
    public function _insertMealCodeInfo($mealInfo){
        $mealInsertInfo['meal_code'] = trim($mealInfo['SSRCode']);
        $mealInsertInfo['meal_description'] = trim($mealInfo['SSRName']);
        $mealInsertInfo['r_airline_code'] = trim($mealInfo['airlineCode']);
        $mealInsertInfo['status'] = 'Y';
        return $this->_OcommonDBO->_insert('dm_meal_code_details',$mealInsertInfo);
    }

    /*
     * @Description  Function used to get the baggage code details.
     * @param array|$baggageInfo
     * @return array|$finalArray
     * @date|10.09.2017
     * @author|Karthika.M
     */
    public function _getBaggageCodeInfo($baggageInfo){
        $sql = "SELECT *
                FROM dm_baggage_code_details dbc
                WHERE dbc.baggage_description = '".trim($baggageInfo['SSRName'])."' AND dbc.baggage_code = '".trim($baggageInfo['SSRCode'])."' AND
                dbc.r_airline_code = '".trim($baggageInfo['airlineCode'])."' AND dbc.status = 'Y'";
        return  $this->_OcommonDBO->_getResult($sql);
    }

    /*
     * @Description  Function used to insert the baggage code details.
     * @param array|$baggageInfo
     * @return int|insertedId
     * @date|10.09.2017
     * @author|Karthika.M
     */
    public function _insertBaggageCodeInfo($baggageInfo){
        $baggage['baggage_code'] = trim($baggageInfo['SSRCode']);
        $baggage['baggage_description'] = trim($baggageInfo['SSRName']);
        $baggage['r_airline_code'] = trim($baggageInfo['airlineCode']);
        $baggage['status'] = 'Y';
        return $this->_OcommonDBO->_insert('dm_baggage_code_details',$baggage);
    }

    /*
     * @Description  Function used to get the seat code details.
     * @param array|$seatInfo
     * @return array|$finalArray
     * @date|13.10.2017
     * @author|Karthika.M
     */
    public function _getSeatCodeInfo($seatInfo){
        $sql = "SELECT *
                FROM dm_seat_code_details dsc
                WHERE dsc.seat_description = '".trim($seatInfo['SSRName'])."' AND dsc.seat_code = '".trim($seatInfo['SSRCode'])."' AND
                dsc.r_airline_code = '".trim($seatInfo['airlineCode'])."' AND dsc.status = 'Y'";
        return  $this->_OcommonDBO->_getResult($sql);
    }

    /*
     * @Description  Function used to insert the seat code details.
     * @param array|$seatInfo
     * @return int|insertedId
     * @date|13.10.2017
     * @author|Karthika.M
     */
    public function _insertSeatCodeInfo($seatInfo){
        $seat['seat_code'] = trim($seatInfo['SSRCode']);
        $seat['seat_description'] = trim($seatInfo['SSRName']);
        $seat['r_airline_code'] = trim($seatInfo['airlineCode']);
        $seat['status'] = 'Y';
        return $this->_OcommonDBO->_insert('dm_seat_code_details',$seat);
    }

    /*
    * @Description  Function used to update the seat code details.
    * @param array|$input
    * @date|10.09.2017
    * @author|sathees
    */
    public function _updateSelectedSeatDetails($input){
        foreach ($input['seatInfo'] as $iKey => $iValue){
            foreach($iValue as $key => $value) {
                foreach ($value as $innerKey => $innerValue){
                    if($innerValue['seatSelected'] == 1){
                        $seatInfo['seat_code'] = $innerValue['seatNo'];
                        $seatInfo['seat_description'] = $innerValue['seatType'];
                        $seatInfo['r_airline_code'] = $innerValue['airlineId'];
                        $seatInfo['status'] = 'Y';
                        $insertedId = $this->_OcommonDBO->_insert('dm_seat_code_details',$seatInfo);
                        //query for update the selected seat details.
                        $sql = "UPDATE fact_passenger_preferences fpp
                                SET
                                    fpp.preferences_value_id = ".$insertedId.",
                                    fpp.ssr_preferences_value = compress('".json_encode($innerValue['seatResponse'],true)."'),
                                    fpp.ssr_preferences_fare = ".$innerValue['seatFare'].",
                                    fpp.ssr_preferences_name = '".$innerValue['seatNo'].' '.$innerValue['seatType']."'
                                WHERE
                                    fpp.r_package_id = ".$input['packageId']."
                                    AND fpp.r_order_id = ".$innerValue['orderId']."
                                    AND fpp.r_passenger_id = ".$innerValue['passengerId']."
                                    AND fpp.r_via_flight_id = ".$innerValue['viaFlightId']."
                                    AND fpp.trip_type = ".$innerValue['tripType']."
                                    AND fpp.preferences_type = 'seat'";
                        $updatedId = $this->_OcommonDBO->_executeQuery($sql);
                    }
                }
            }
        }
        $this->_OorderIds = $this->_Opackage->_getPaidPackageDetails($input['packageId']);
        if(count($this->_OorderIds) >= 2) {
            foreach($this->_OorderIds as $key=>$value) {
                $sql = "UPDATE order_details SET total_amount=".($this->_OorderIds[$key]['total_amount']+$input['multiCitySeatAmount'][$key])." WHERE order_id=".$this->_OorderIds[$key]['order_id'];
                $this->_OcommonDBO->_executeQuery($sql);
            }
        } else  {
            $sql = "UPDATE order_details SET total_amount=".($this->_OorderIds[0]['total_amount']+$input['seatTotalAmount'])." WHERE order_id=".$this->_OorderIds[0]['order_id'];
            $this->_OcommonDBO->_executeQuery($sql);
        }
    }

   /*
    * @Description  Function used to update the meal and baggage code details.
    * @param array|$input
    * @return array|updated id
    * @date|10.09.2017
    * @author|Karthika.M
    */
    public function _updateSelectedMealBaggageDetails($input){

        global $CFG;
        
        //initialize the array.
        $updateInfo = array();
        $this->_OflightItinerary = new flightItinerary();

        //get corporate id 
        $corporateId = $this->_OcommonDBO->_select('fact_booking_details',array('r_corporate_id'),'r_package_id',$input['packageId'])[0]['r_corporate_id'];
       
        //set inputs
        $selectedSSRinfo = $input['mealBaggageInfo'];

        //looping the array.
        if(count($selectedSSRinfo) > 0){
            foreach ($selectedSSRinfo as $orderId => $orderValue){                
                //get ssr amount for the meal and baggage.
                $ssrMealBaggageFare = $this->_mealBaggageSSRfare("'meal','baggage'",$orderId)[0]['ssrTotalFare'];
                foreach($orderValue as $paxKey => $paxVal){
                    foreach ($paxVal as $tripKey => $tripValue){
                        foreach ($tripValue as $viaKey => $viaValue){                            
                            //get via flight info.
                            $viaFlightInfo = $this->_OflightItinerary->_getViaFlightInfo($viaKey)[0];                            
                            foreach($viaValue as $key => $type){
                                foreach($type as $ssrKey => $ssrValue){                                    
                                    //forming the array with -> pax id, trip, via flight id,
                                    $updateInfo[$paxKey][$tripKey][$viaKey][$key]['r_package_id'] =  $input['packageId'];
                                    $updateInfo[$paxKey][$tripKey][$viaKey][$key]['r_order_id'] = $orderId;
                                    $updateInfo[$paxKey][$tripKey][$viaKey][$key]['trip_type'] = $tripKey;
                                    $updateInfo[$paxKey][$tripKey][$viaKey][$key]['r_passenger_id'] = $paxKey;
                                    $updateInfo[$paxKey][$tripKey][$viaKey][$key]['r_via_flight_id'] = $viaKey;
                                    $updateInfo[$paxKey][$tripKey][$viaKey][$key]['ssr_preferences_fare'] += $ssrValue['ssrFareInfo'];
                                    $updateInfo[$paxKey][$tripKey][$viaKey][$key]['ssr_preferences_name'] .= $ssrKey == count($type)-1 ? $ssrValue['ssrName']: $ssrValue['ssrName'].',';
                                    $updateInfo[$paxKey][$tripKey][$viaKey][$key]['preferences_type'] = $key;
                                    $updateInfo[$paxKey][$tripKey][$viaKey][$key]['preferences_value_id'] .= $ssrKey == count($type)-1 ? $this->_getPreferenceValueId($ssrValue['ssrInfo']) : $this->_getPreferenceValueId($ssrValue['ssrInfo']).',';
                                    unset($ssrValue['ssrInfo']['$$hashKey']);    
                                    $updateInfo[$paxKey][$tripKey][$viaKey][$key]['ssr_preferences_value'][$ssrKey] = $ssrValue['ssrInfo'];
                                }                                
                                //get the ssr preference value.
                                $ssrValueinfo = $updateInfo[$paxKey][$tripKey][$viaKey][$key]['ssr_preferences_value'];
                                $ssrValueinfo ? $updateInfo[$paxKey][$tripKey][$viaKey][$key]['ssr_preferences_value'] = json_encode($ssrValueinfo):'';
                                $updateInfo[$paxKey][$tripKey][$viaKey][$key] ? $result[] = $this->_updateFactPaxPreferences($updateInfo[$paxKey][$tripKey][$viaKey][$key]) :'';
                            }
                        }
                    }
                }
                //find total meal & baggage fare for update in order_details.
                $ssrTotalFareAfterUpdate = $this->_mealBaggageSSRfare("'meal','baggage'",$orderId)[0]['ssrTotalFare'];
                
                //update the meal and baggage amount in order_details.
                $this->_updateSSRfareinOrder($orderId,$ssrTotalFareAfterUpdate);
            }
        }
        
        $totalFare = array();
        //get package wise and order wise total amount.
        if($input['paymentProcessType'] == 'packagePayment'){
            $totalFare = $this->_getSSRfareInfoByType('',$input['packageId']);            
        }
        else{
            $totalFare = $this->_getSSRfareInfoByType($input['orderId']);
        }
        return $totalFare;
    }
    
   /*
    * @Description  Function used to get the total fare with respect to the package id and order id.
    * @param int|$orderId,$packageId
    * @return array|$totalFare
    * @date|24.01.2018
    * @author|Karthika.M
    */
    public function _getSSRfareInfoByType($orderId = 0,$packageId = 0){        
        $totalFare['meal']  = $this->_mealBaggageSSRfare("'meal'",$orderId,$packageId)[0]['ssrTotalFare'];
        $totalFare['baggage'] = $this->_mealBaggageSSRfare("'baggage'",$orderId,$packageId)[0]['ssrTotalFare'];
        $totalFare['seat'] = $this->_mealBaggageSSRfare("'seat'",$orderId,$packageId)[0]['ssrTotalFare'];
        $totalFare['totalFare'] = $packageId ? $this->_Opackage->_packageTotalAmount($packageId)[0]['packageTotalAmount'] : $this->_OcommonDBO->_select('order_details','total_amount','order_id',$orderId)[0]['total_amount'];
        return $totalFare;
    }

   /*
    * @Description  Function used to get the preferences value id
    * @param array|$ssrInfo
    * @return array|updated id
    * @date|10.09.2017
    * @author|Karthika.M
    */
    public function _getPreferenceValueId($ssrInfo){
        switch ($ssrInfo['SSRType']){
            //meal
            case 'ML':
                //get meal code info.
                $mealInfo = $this->_getMealCodeInfo($ssrInfo);
                //meal code not there.
                if(!$mealInfo){
                    return $this->_insertMealCodeInfo($ssrInfo);
                }
                else{
                    //set ssr id.
                    return $mealInfo[0]['meal_code_id'];
                }
                break;

            //baggage
            case 'BG':
                //get baggage code info.
                $baggageInfo = $this->_getBaggageCodeInfo($ssrInfo);
                //baggage code not there.
                if(!$baggageInfo){
                    return  $this->_insertBaggageCodeInfo($ssrInfo);
                }
                else{
                    //set ssr id.
                    return $baggageInfo[0]['baggage_code_id'];
                }
                break;

            //Seat
            case 'ST':
                //get seat code info.
                $seatInfo = $this->_getSeatCodeInfo($ssrInfo);
                //baggage code not there.
                if(!$seatInfo){
                    return  $this->_insertSeatCodeInfo($ssrInfo);
                }
                else{
                    //set ssr id.
                    return $seatInfo[0]['seat_code_id'];
                }
                break;

            default:
                break;
        }
    }

   /*
    * @Description  Function used to update the ssr info.
    * @param array|$input
    * @return int|updated id
    * @date|10.09.2017
    * @author|Karthika.M
    */
    public function _updateFactPaxPreferences($input){
        $sql = "UPDATE fact_passenger_preferences fpp
                SET fpp.ssr_preferences_value = compress('".$input['ssr_preferences_value']."'),
                    fpp.ssr_preferences_fare = ".trim($input['ssr_preferences_fare']).",
                    fpp.ssr_preferences_name = '".trim($input['ssr_preferences_name'])."',
                    fpp.preferences_value_id = '".trim($input['preferences_value_id'])."'
                WHERE
                    fpp.r_package_id = ".$input['r_package_id']." AND fpp.r_order_id = ".$input['r_order_id']."
                    AND fpp.trip_type = ".$input['trip_type']." AND fpp.r_passenger_id = ".$input['r_passenger_id']."
                    AND fpp.r_via_flight_id = ".$input['r_via_flight_id']." AND fpp.preferences_type = '".$input['preferences_type']."'";
        $updatedId = $this->_OcommonDBO->_executeQuery($sql);
        return !$updatedId ? 0 : $updatedId->rowCount();
    }

   /*
    * @Description  Function used to get the the ssr code info.
    * @param int,string|$ssrId,$ssrType
    * @return string|$ssrCode
    * @date|10.09.2017
    * @author|Karthika.M
    */
    public function _getSSRpreferenceCode($ssrId,$ssrType){
        //for meal
        if($ssrType == 'meal'){
            $ssrCode = $this->_OcommonDBO->_select("dm_meal_code_details","meal_code","meal_code_id",$ssrId)[0]['meal_code'];
        }
        //if baggage
        else if($ssrType == 'baggage'){
            $ssrCode = $this->_OcommonDBO->_select("dm_baggage_code_details","baggage_code","baggage_code_id",$ssrId)[0]['baggage_code'];
        }
        return $ssrCode;
    }

    /*
    * @Description  Function used to get ssr fare for the order id.
    * @param int|$orderId
    * @return int|$totalFare
    * @date|10.09.2017
    * @author|Karthika.M
    */
    public function _calculateSSRfare($orderId){
        return $this->_OcommonDBO->_select('fact_passenger_preferences','sum(ssr_preferences_fare) as ssrTotalFare','r_order_id',$orderId)[0]['ssrTotalFare'];
    }

    /*
    * @Description  Function used to get ssr fare for the order id with respect to the ssr type.
    * @param int|$orderId
    * @return int|$totalFare
    * @date|10.09.2017
    * @author|Karthika.M
    */
    public function _mealBaggageSSRfare($ssrType,$orderId = 0,$packageId = 0,$viaFlightId =0,$passengerId = 0){
        $sql = "SELECT sum(ssr_preferences_fare) as ssrTotalFare
                FROM fact_passenger_preferences
                WHERE preferences_type IN(".$ssrType.")";

        $orderId ? $sql .= " AND r_order_id = ".$orderId : '';
        $packageId ? $sql .= " AND r_package_id = ".$packageId:'';
        $viaFlightId ? $sql .= " AND r_via_flight_id IN(".$viaFlightId.")":'';
        $passengerId ? $sql .= " AND r_passenger_id = ".$passengerId:'';
        return  $this->_OcommonDBO->_getResult($sql);
    }

    /*
    * @Description  Function used to update the ssr amount in order_details.
    * @param int|$orderId
    * @return int|$totalFare
    * @date|10.09.2017
    * @author|Karthika.M
    */
    public function _updateSSRfareinOrder($orderId,$ssrFare){
        //get total amount from the order_details.
        $orderTotalAmount = $this->_OcommonDBO->_select('order_details','total_amount','order_id',$orderId)[0]['total_amount'];
        //final total amount after adding the meal and baggage.
        $orderTotalAmountInfo = $orderTotalAmount + $ssrFare;
        
        //update the order_details.
        $updateOrderArray['total_amount'] = $orderTotalAmountInfo;
        return $this->_Opackage->_updateOrderDetails($updateOrderArray,$orderId);
    }

   /*
    * @Description  Function used to insert the selected meal and baggage amount.
    * @param array|$input
    * @date|13.10.2017
    * @author|Karthika.M
    */
    public function _insertSelectedMealBaggageDetails($input){
        $info = array();
        foreach ($input['mealBaggageInfo'] as $orderId => $orderValue){
            foreach($orderValue as $paxKey => $paxVal){
                foreach ($paxVal as $tripKey => $tripValue){
                    foreach ($tripValue as $viaKey => $viaValue){
                        foreach ($viaValue as $key => $type){
                            foreach ($type as $ssrKey => $ssrValue){
                                if($ssrValue['ssrName'] !=''){
                                    //forming the array with -> pax id, trip, via flight id,
                                    $info[$paxKey][$tripKey][$viaKey][$key]['r_package_id'] =  $input['packageId'];
                                    $info[$paxKey][$tripKey][$viaKey][$key]['r_order_id'] = $orderId;
                                    $info[$paxKey][$tripKey][$viaKey][$key]['trip_type'] = $tripKey;
                                    $info[$paxKey][$tripKey][$viaKey][$key]['r_passenger_id'] = $paxKey;
                                    $info[$paxKey][$tripKey][$viaKey][$key]['r_via_flight_id'] = $viaKey;
                                    $info[$paxKey][$tripKey][$viaKey][$key]['ssr_preferences_fare'] += $ssrValue['ssrFareInfo'];
                                    $info[$paxKey][$tripKey][$viaKey][$key]['ssr_preferences_name'] .= $ssrKey == count($type)-1 ? $ssrValue['ssrName']: $ssrValue['ssrName'].',';
                                    $info[$paxKey][$tripKey][$viaKey][$key]['preferences_type'] = $key;
                                    $info[$paxKey][$tripKey][$viaKey][$key]['preferences_value_id'] .= $ssrKey == count($type)-1 ? $this->_getPreferenceValueId($ssrValue['ssrInfo']) : $this->_getPreferenceValueId($ssrValue['ssrInfo']).',';
                                    unset($ssrValue['ssrInfo']['$$hashKey']); 
                                    $info[$paxKey][$tripKey][$viaKey][$key]['ssr_preferences_value'][$ssrKey] = $ssrValue['ssrInfo'];
                                }
                            }
                            //get the ssr preference value.
                            $ssrValueinfo = $info[$paxKey][$tripKey][$viaKey][$key]['ssr_preferences_value'];
                            $ssrValueinfo ? $info[$paxKey][$tripKey][$viaKey][$key]['ssr_preferences_value'] = json_encode($ssrValueinfo):'';
                            $info[$paxKey][$tripKey][$viaKey][$key] ? $factPassengerId[] = $this->_insertFactPassengerPreferences($info[$paxKey][$tripKey][$viaKey][$key]):'';
                        }
                    }
                }
            }
        }
    }

    /*
    * @Description  Function used to insert the selected seat amount.
    * @param array|$input
    * @date|13.10.2017
    * @author|Karthika.M
    */
    public function _insertSelectedSeatDetails($input){        
        foreach ($input['seatInfo'] as $iKey => $iValue){
            foreach($iValue as $key => $value) {
                foreach ($value as $innerKey => $innerValue){

                    if($innerValue['seatSelected'] == 1){
                        //set inputs for get seat code details.
                        $seatInfo['SSRType'] = 'ST';
                        $seatInfo['SSRCode'] = $innerValue['seatNo'];
                        $seatInfo['SSRName'] = $innerValue['seatType'];
                        $seatInfo['airlineCode'] = $innerValue['airlineId'];
                        $seatInfo['status'] = 'Y';
                        //set inputs for seat info.
                        $insertSeatInfo['r_package_id'] =  $input['packageId'];
                        $insertSeatInfo['r_order_id'] = $innerValue['orderId'];
                        $insertSeatInfo['trip_type'] = $innerValue['tripType'];
                        $insertSeatInfo['r_passenger_id'] = $innerValue['passengerId'];
                        $insertSeatInfo['r_via_flight_id'] = $innerValue['viaFlightId'];
                        $insertSeatInfo['preferences_type'] = 'seat';
                        $insertSeatInfo['preferences_value_id'] = $this->_getPreferenceValueId($seatInfo);
                        $insertSeatInfo['ssr_preferences_value'] = json_encode($innerValue['seatResponse'],true);
                        $insertSeatInfo['ssr_preferences_fare'] = $innerValue['seatFare'];
                        $insertSeatInfo['ssr_preferences_name'] = $innerValue['seatNo'].' '.$innerValue['seatType'];
                        $insertedSeatId[] = $this->_insertFactPassengerPreferences($insertSeatInfo);
                    }
                }
            }
        }
    }
    
    /*
    * @Description  Function used to insert the fact passenger preferences table.
    * @param array|$ssrInfo
    * @date|13.10.2017
    * @author|Karthika.M
    */
    public function _insertFactPassengerPreferences($ssrInfo){
        $sql = "INSERT INTO fact_passenger_preferences
                (r_package_id,r_order_id,trip_type,r_passenger_id,r_via_flight_id,preferences_type,preferences_value_id,ssr_preferences_value,ssr_preferences_fare,ssr_preferences_name)
                VALUES (".$ssrInfo['r_package_id'].",".$ssrInfo['r_order_id'].",".$ssrInfo['trip_type'].",".$ssrInfo['r_passenger_id'].",".
                $ssrInfo['r_via_flight_id'].",'".$ssrInfo['preferences_type']."',".$ssrInfo['preferences_value_id'].",compress('".$ssrInfo['ssr_preferences_value']."'),".$ssrInfo['ssr_preferences_fare'].",'".$ssrInfo['ssr_preferences_name']."')";
        $result = $this->_OcommonDBO->_executeQuery($sql);
        return $result;
    }
    
    /*
    * @Description  Function used to clear the selected passenger preferences details with respect to the order id.
    * @param int|$packageId,$orderId
    * @date|15.11.2018
    * @author|Karthika.M
    */
    public function _resetSSRDetails($packageId = 0,$orderId = 0,$tripType = 0){
        
        if($orderId ==  0  && $packageId == 0){
            return false;
        }
    
        $sql = "UPDATE 
                    fact_passenger_preferences
                SET 
                    ssr_preferences_value = '',ssr_preferences_fare = '',ssr_preferences_name = '',preferences_value_id = 0                     
                WHERE 1";
        
        ($orderId != 0) ? $sql .= " AND r_order_id = ".$orderId : "";
        ($packageId != 0) ? $sql .= " AND r_package_id = ".$packageId : "";
        ($tripType != 0) ? $sql .= " AND trip_type IN (".$tripType.")" : "";
        return $this->_OcommonDBO->_executeQuery($sql);
    }
    
    /*
    * @Description get ssr selected status
    * @param int|$orderId
    * @date|27.11.2018
    * @author|Karthika.M
    */
    public function _getSSRselectedStatus($orderId){
        
        $this->_Opassenger = new passenger();
        
        $ssrSelectedStatus = array();   
        
        //get passenger details.
        $paxDetails  = $this->_Opassenger->_getAllPassengerDetailsByOrderId($orderId);  
        $index = 0;
        foreach($paxDetails as $paxValue){
            if($paxValue['passenger_type'] != 'INF'){
                $paxInfo[$paxValue['passenger_id']] = $index;
                $index++;
            }
        }
        
        //get passenger preferences details with respect to the order id.
        $ssrInfo = $this->_getSSRpreferencesFareDetails($orderId);
        foreach($ssrInfo as $key => $value){
            if($value['passenger_type'] != 'INF'){
                $paxIndex = $paxInfo[$value['r_passenger_id']];
                $ssrSelectedStatus[$value['preferences_type']][$orderId][$paxIndex][$value['trip_type']][] = ($value['ssr_preferences_name']) ? 'Y' : 'N'; 
            }
        }
        return $ssrSelectedStatus;
    }

         /*
    * @Description  Function used to update the passenger preerence based on fare increase update
    * @param array|$ssrInfo
    * @date|11.05.2018
    * @author|Baskar.V.P
    */
    public function _updatePassengerPreferenceFareCheck($input){
        fileWrite(print_r($input,1),"updatedInput","a+");

        // before update fileWrite for the previous order
        $sqlSelectSeat = "SELECT * FROM fact_passenger_preferences fpp WHERE fpp.r_via_flight_id = ".$input['r_via_flight_id']." AND fpp.preferences_type = '".$input['preferences_type']."'";
        $previousData = $this->_OcommonDBO->_getResult($sqlSelectSeat);
        fileWrite(print_r($previousData,1),'SEAT','a+');

        //query for update 
        $sql = "UPDATE fact_passenger_preferences fpp
                SET fpp.ssr_preferences_value = compress('".$input['ssr_preferences_value']."'),
                    fpp.ssr_preferences_fare = ".trim($input['ssr_preferences_fare'])."
               WHERE
                    fpp.r_order_id = ".$input['r_order_id']."
                    AND fpp.r_via_flight_id = ".$input['r_via_flight_id']." AND fpp.preferences_type = '".$input['preferences_type']."'";
        fileWrite($sql,"updated","a+");
        $updatedId = $this->_OcommonDBO->_executeQuery($sql);
        return !$updatedId ? 0 : $updatedId->rowCount();
    }
}