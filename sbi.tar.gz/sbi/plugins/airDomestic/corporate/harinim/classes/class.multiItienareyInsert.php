<?php
/* * **************************************************************************
 * @File             : class.multiItienareyInsert.php
 * @Description      : This file is used to insert itienary details for the multi city
 * @Author           : M.Karthika
 * *************************************************************************** */

class commonMultiItienaryInsert{
    public function __construct(){
        $this->_multi = new airMultiCity();
        $this->package = new package();
        $this->_OcommonDBO = new commonDBO();
    }
    public function _getDisplayInfo(){
        $input = $this->_IinputData;
        if((isset($input)) && count($input)> 0){
           // set the ticket status in order_details
           if($input['action'] == "BOOK"){
               $ticketStatus = NOT_PAID;
            }else{
               $ticketStatus = SEND_FOR_APPROVAL;
           }
           
           $insertFlightItineraryInfo = $this->_insertFlightItineraryInfo($input['flightItineryInfo'],$input['flightItineryInfo']['tripType'],$ticketStatus);
           if($insertFlightItineraryInfo == 1){
              $this->_AserviceResponse['status_message'] =  "Success";
           }
        }
    }
        
    // Insert the flight itinerary details in table
    public function _insertFlightItineraryInfo($input,$tripType,$status){
        $this->_Sstatus = $status;
        $finalArray= $input;      
        // set employee info      
        $input['flightSearchData']['employeeInfo'] = $input['factBookingDetails'];
        
        // assigining the fareSplitUp and  flightSearchData for insert flight details 
        $input['tempData'] =  $input['flightSearchData'];  
        
        // get package info
        $package =  $this->package->_getPaidPackageDetails($input['tempData']['employeeInfo']['r_package_id']);

        $orderIdInfo = array_column($package,'r_order_id');
        // assign the inputs
        $inputInfo['status'] = $status;
        $inputInfo['package'] = $package;
        $inputInfo['tripType'] = $tripType;
        $inputInfo['orderIdInfo'] = $orderIdInfo;
        if($package[0]['package_type'] == 1){
            $this->_insertMulticityItineraryInfo($input,$inputInfo);
        }
        else if($package[0]['package_type'] == 3 && $tripType == 2){
            $this->_insertMulticityItineraryInfo($input,$inputInfo);
        }else{
            $input['tempData']['onwardflightreason'] = $input['onwardflightreason'];
            $input['tempData']['returnflightreason'] = $input['returnflightreason'];
            $this->insertFlightItienary = new commonInsertFlightItinerary();
            // passing reasssigned tempData to insert flight itinerary details
            $this->insertFlightItienary->_IinputData = $input['tempData'];
            $this->insertFlightItienary->_Sstatus = $this->_Sstatus;
            $this->insertFlightItienary->_getDisplayInfo(); 
            $response = $this->insertFlightItienary->_AfinalResponse;
            
            //update total amount in order details
            $updateOrderArray['total_amount'] = $this->insertFlightItienary->_IorderTotalAmount;
            $updateOrderArray['r_ticket_status_id'] = $status; 
            $orderUpdateResult = $this->package->_updateOrderDetails($updateOrderArray, $input['tempData']['employeeInfo']['r_order_id']);
            
            // insert in to booking history table
            $updatedtBookingHistoryInfo = $this->_updateBookingHistory($input['tempData'],$tripType);  
            $_SESSION['total_amount']= $input['tempData']['selectedOnwardFlight']['newTotalFare'];
        }
        
        $finalArray['flightSearchData'] = $input['tempData'];   
        $input['packageId'] = $finalArray['flightSearchData']['employeeInfo']['r_package_id'];
        $input['total_amount'] = $_SESSION['total_amount']; 
        if(($updatedtBookingHistoryInfo == 'success') && ($response == 1)){
            $finalResponse = "success";
        }
        
        return $finalResponse;
    }
    
    // insert the multicity flight details     
    public function _insertMultipleBookingAirDetails($flightBookingArray,$tempData,$orderIdInfo){
        if(count($flightBookingArray) > 0){
            $this->insertFlightItienary = new commonInsertFlightItinerary();
            $this->insertFlightItienary->_IinputData = $tempData;
            
            foreach ($flightBookingArray as $key => $bookingArray){
                if($key!=0){
                     //re-initialize old existing values 
                    $this->insertFlightItienary->_OFlightItinerary->_IorderTotalFare         = 0;
                    $this->insertFlightItienary->_OFlightItinerary->_IorderTotalServiceTax   = 0;
                    $this->insertFlightItienary->_OFlightItinerary->_IorderCalTransBaseFare  = 0;
                    $this->insertFlightItienary->_OFlightItinerary->_IorderCalSystemBaseFare = 0;
                    $this->insertFlightItienary->_OFlightItinerary->_IorderDiscountBaseFare  = 0;
                    $this->insertFlightItienary->_Sstatus = $this->_Sstatus;      
                    // passing reasssigned tempData to insert flight itinerary details                    
                    $responseArray[]['status'] = $this->insertFlightItienary->_insertIntineraryDetails($bookingArray);
                    $this->_multicityTotalAmount[] = $this->insertFlightItienary->_IorderTotalAmount;
                     //update total amount in order details
                    $updateOrderArray['total_amount'] = $this->insertFlightItienary->_IorderTotalAmount;
                    $updateOrderArray['r_ticket_status_id'] = $this->_Sstatus; 
                    $orderUpdateResult = $this->package->_updateOrderDetails($updateOrderArray, $orderIdInfo[$key-1]);
                }
            }
            
            return $responseArray;
        }        
    }
    
    // update the booking history table    
    public function _updateBookingHistory($input,$tripType){
       global $CFG;
       if((isset($input)) && count($input) > 0){
           // oneway & roundtrip
            if ($tripType != 2){
                if((isset($input['selectedOnwardFlight'])) && count($input['selectedOnwardFlight']) > 0){
                    $onwardFlightInfo = $input['selectedOnwardFlight']; 
                    $viaFlightCount = count($onwardFlightInfo['via_flights']);
                    
                    $bookingHistoryInfo[0]['onward_depature_date'] = $onwardFlightInfo['date_departure'] .' '.$onwardFlightInfo['time_departure'];  
                    $bookingHistoryInfo[0]['onward_arrival_date']  = $onwardFlightInfo['date_departure'] .' '.$onwardFlightInfo['time_arrival'];
                }
                if((isset($input['selectedReturnFlight'])) && count($input['selectedReturnFlight']) > 0){
                    $returnFlightInfo = $input['selectedReturnFlight']; 
                    $bookingHistoryInfo[0]['return_depature_date'] = $returnFlightInfo['date_departure'] .' '.$returnFlightInfo['time_departure'];   
                    $bookingHistoryInfo[0]['return_arrival_date']  = $returnFlightInfo['via_flights'][$viaFlightCount-1]['arrival_date'] .' '.$returnFlightInfo['time_arrival'];
                }    
                $bookingHistoryInfo[0]['total_amount'] = $this->insertFlightItienary->_IorderTotalAmount;
                $bookingHistoryInfo[0]['package_amount'] = $this->insertFlightItienary->_IorderTotalAmount;
                $bookingHistoryInfo[0]['initial_fare'] = $this->insertFlightItienary->_IorderTotalAmount;
                $bookingHistoryInfo[0]['package_id'] = $input['employeeInfo']['r_package_id'];
                $bookingHistoryInfo[0]['order_id']= $input['employeeInfo']['r_order_id'];
                $bookingHistoryInfo[0]['booking_date']= $CFG['created_date'];
            }else{
                $totalAmount = $this->_multicityTotalAmount;
                foreach($input as $key => $data){
                    if($key!=0){
                        $viaFlightCount = count($input[$key]['selectedOnwardFlight']['via_flights']);
                        $multiBookingHistoryInfo['onward_depature_date'] = $input[$key]['selectedOnwardFlight']['date_departure'] .' '.$input[$key]['selectedOnwardFlight']['time_departure'];  
                        $multiBookingHistoryInfo['onward_arrival_date']  = $input[$key]['selectedOnwardFlight']['date_departure'] .' '.$input[$key]['selectedOnwardFlight']['time_arrival'];
                        $multiBookingHistoryInfo['total_amount'] = $totalAmount[$key-1];
                        $multiBookingHistoryInfo['package_amount'] = $totalAmount[$key-1];                
                        $multiBookingHistoryInfo['initial_fare'] = $totalAmount[$key-1];
                        $multiBookingHistoryInfo['package_id']= $input[$key]['employeeInfo']['r_package_id'];
                        $multiBookingHistoryInfo['order_id'] = $input[$key]['employeeInfo']['r_order_id'];
                        $multiBookingHistoryInfo['booking_date']= $CFG['created_date'];
                        $bookingHistoryInfo[] = $multiBookingHistoryInfo;                            
                    }
                } 
            }               
            $updateBookingHistoryTable = $this->_updateBookingHistoryTable($bookingHistoryInfo);
            if(count($updateBookingHistoryTable) > 0){
                foreach ($updateBookingHistoryTable as $data){
                    if($data != 0){
                       $response   = "success";
                    }else{
                       $response   = "failed";
                    }
                }
                
                return $response;
            }
        }  
    }
    
    // update function for booking history.
    public function _updateBookingHistoryTable($bookingHistoryInfo){
        if(count($bookingHistoryInfo)>0){
            foreach ($bookingHistoryInfo as $value){
                $packageId = $value['package_id'];
                $orderId = $value['order_id'];
                unset($value['package_id']);
                unset($value['order_id']);
                $updatesBookingHistory[] = $this->_OcommonDBO->_update('booking_history', $value, 'order_id', $orderId);
            }
            
            return $updatesBookingHistory;
        }
    }
    
    public function _insertMulticityItineraryInfo($input,$inputInfo){
        if($input['multicityRequestBooking'] !=  ""){
            $input['tempData']['onwardflightreason'] = $input['onwardflightreason'];
            $input['tempData']['returnflightreason'] = $input['returnflightreason'];

            pluginFileRequire('common/', 'classes/class.insertFlightItinerary.php');
            $this->insertFlightItienary = new commonInsertFlightItinerary();
            // passing reasssigned tempData to insert flight itinerary details
            $this->insertFlightItienary->_IinputData = $input['tempData'];
            $this->insertFlightItienary->_Sstatus = $this->_Sstatus;
            $this->insertFlightItienary->_getDisplayInfo(); 
            $response = $this->insertFlightItienary->_AfinalResponse;

            //update total amount in order details
            $updateOrderArray['total_amount'] = $this->insertFlightItienary->_IorderTotalAmount;
            $updateOrderArray['r_ticket_status_id'] = $inputInfo['status']; 
            $orderUpdateResult = $this->package->_updateOrderDetails($updateOrderArray, $input['tempData']['employeeInfo']['r_order_id']);

            // insert in to booking history table
            $updatedtBookingHistoryInfo = $this->_updateBookingHistory($input['tempData'],$inputInfo['tripType']);  
            $_SESSION['total_amount']= $input['tempData']['selectedOnwardFlight']['newTotalFare'];
        }else{   
            foreach($input['tempData']['multicity'] as $key=>$value){
                if($key!=0){
                    $input['multicity'][$key]['employeeInfo']= $input['tempData']['employeeInfo'];
                    $input['multicity'][$key]['employeeInfo']['r_order_id']= $inputInfo['package'][$key-1]['r_order_id'];
                    $input['multicity'][$key]['selectedOnwardFlight']= $input['tempData']['multicity'][$key]['selected'];
                    $input['multicity'][$key]['onwardLowestFlight']= $input['tempData']['multicity'][$key]['lowfare'];
                    $input['multicity'][$key]['onwardflightreason']= $input['lowFareInfo'][$key-1];
                    $input['multicity'][$key]['class_id']= $input['tempData']['class_id'];
                    $input['multicity'][$key]['travel_mode_id']= $input['tempData']['travel_mode_id']; 
                }
            }
            $input[0]['multicity']= $input['multicity'];

            $multicityResponse = $this->_insertMultipleBookingAirDetails($input['multicity'],$input['tempData'],$inputInfo['orderIdInfo']);            
            if(count($multicityResponse) > 0 ){
                foreach ($multicityResponse as $data){
                    if($data['status'] != 0){
                       $response   = 1;
                    }
                }
            }
            $updatedtBookingHistoryInfo = $this->_updateBookingHistory($input['multicity'],$inputInfo['tripType']);
        }
    }
}
?>
