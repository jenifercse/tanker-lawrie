<?php
/** * **************************************************************************
 * @File             : class.commonFlightSearchRequestInsert.php
 * @Description      : This file is used to insert primary booking request details
 * @Tables Affected  : package_details,order_details,passenger_details,fact_booking_details
 * @Author           : Baskar.V.P
 * @Created Date     : 01/07/2016
 * @Modified Date    :
 * ****************************************************************************/
class commonFlightSearchRequestInsert{
      public function __construct(){
        $this->_Oemployee = new employee();
        $this->_Olocation = new location();
        $this->_OapplicationSettings = new applicationSettings();
        $this->_Opackage = new package();
        $this->_Opassenger = new passenger();
        $this->_OdynamicInsertion = new dynamicFormElementManipulation();
        $this->_Opolicy = new policy();
        $this->_OcommonQuery = new commonQuery();
        $this->_OcommonDBO = new commonDBO();
        $this->_airRquest = new airRequest();
        $this->_OtravelPlan = new travelPlan();
        $this->_commonFlight = new commonFlightSearchDetails();
        $this->_OtripCreation = new tripCreation();
        $this->_OsetApprovalProcess = new setApprovalProcess();
    }
    
    /**
     * @functionName    :   _getDisplayInfo()
     * @description     :   default module method
     */
    public function _getDisplayInfo(){  
       
        if($this->_IinputData['action']!= ''){
            $action = 'update';
        }else{
            $action ='insert';
        }
        switch ($action){
            case 'update':
                if(isset($this->_IinputData['passengerDynamic']) &&  count($this->_IinputData['passengerDynamic'])>0){
                    $this->_CheckInsertPassengerDynamicValue = in_array(CUSTOM_FIELD_ID_OF_OPTIONAL_APPROVAL, array_column($this->_IinputData['passengerDynamic'], 'id')) ? TRUE : FALSE;
                }                
                $this->_requestUpdateFlow();
                break;
            case 'insert':
                $this->_requestInsertionFlow();
                break;
            default:
                break;
        }
    }

    // insertn flow
    public function _requestInsertionFlow(){
        $finalArray=$this->_IinputData;
        //Calling function to insert package details
        $this->_IinputData['tripType']=$this->_IinputData['masterInfo']['requestTableData']['trip_type'];
        $this->_IinputData['currency_name']=$this->_IinputData['masterInfo']['currency_name'];
        $this->_IinputData['travel_mode']=$this->_IinputData['masterInfo']['requestTableData']['travel_type'];

        $db = new commonDBO();

        $sql    = "SHOW TABLE STATUS WHERE `Name` = 'dm_package'";
        $result = $db->_getResult($sql);

        $_SESSION['currentPackageId'] = $result[0]['Auto_increment'];
        
        $responseDataArray = array('factBookingId' => 0);

        $this->_AserviceResponse['packageId'] = array('status_code'=>0,'packageId'=>0);
        
        // $this->_getTripPackageId();
        if($this->_IinputData['comboFlag'] != 'combo'){
            $resultPackageId = $this->_packageInsert();
            $this->_packageId = $resultPackageId;
        }else{
            //assign the value of package id given while submitting the trip form
            $resultPackageId = $this->_packageId;
        }
        
        $resultPackageId =$this->_packageId ;
        $this->_AserviceResponse['packageId'] = array('status_code'=>0,'packageId'=>$this->_packageId);

        $_SESSION['currentPackageId'] = $resultPackageId;
       
        if($resultPackageId > 0 || !$resultPackageId){

            $this->_IinputData['factBookingDetails']['r_package_id'] = $resultPackageId;

            if ($this->_IinputData['tripType'] != 2){ // oneway & roudtrip
                $resultOrderId = $this->_orderInsert();
                
                //set order id
                $this->IorderId = $resultOrderId;

                //insert the fact trip order details
                $factTripOrderId = $this->_factTripOrderInsert($resultOrderId);

                if($resultOrderId > 0 || !$resultOrderId){
                    //set order id
                    $this->_IinputData['factBookingDetails']['r_order_id'] = $resultOrderId;

                    //Calling function to insert fact booking details.
                    $resultFactId = $this->_factBookingInfoInsert();
                    if($resultFactId > 0){
                        $responseDataArray = array('factBookingId' => $resultFactId);
                    }
                    //call function to insert trip plan details
                    $this->_OtravelPlan->_insertTripPlanDetails($resultOrderId,$this->_IinputData['tripPlan']);
                }
            }
            else{
                $input_array = $this->_IinputData;
                foreach($input_array['airRequestDetails'] as $key => $value){
                    $resultOrderId = $this->_orderInsert();
                    if($resultOrderId > 0 || !$resultOrderId){
                        $this->_IinputData['orderId'][$key] = $resultOrderId;
                        $this->_IinputData['factBookingDetails']['r_order_id'] = $resultOrderId;
                        $this->IorderId[] = $this->_IinputData['orderId'];

                        //insert the fact trip order details.
                        $factTripOrderId = $this->_factTripOrderInsert($resultOrderId);
                        
                        //Calling function to insert fact booking details
                        $resultFactId = $this->_factBookingInfoInsert();
                        if ($resultFactId > 0){
                            $responseDataArray = array('factBookingId' => $resultFactId);
                            $this->_IinputData['factId'][$key] = $resultFactId;
                        }

                        //call function to insert trip plan details
                        $this->_OtravelPlan->_insertTripPlanDetails($resultOrderId,$this->_IinputData['tripPlan']);
                    }
                }
            }
            if(isset($this->_IinputData['requestDynamic']) && count($this->_IinputData['requestDynamic'])>0){
                $resultForDynamic =$this->_OdynamicInsertion->_insertDynamicFields($resultOrderId,'1',$this->_IinputData['requestDynamic']);
            }
            if(isset($this->_IinputData['otherDynamic']) && count($this->_IinputData['otherDynamic'])>0){
               $resultForDynamic =$this->_OdynamicInsertion->_insertDynamicFields($resultOrderId,'1',$this->_IinputData['otherDynamic']);
            }
        }
        $this->_assigModuleResponseData($responseDataArray);
    }

    /**
     * @Description :This function is used to insert the package details
     * @param :
     * @return integer |$resultPackageId - inserted package id
     */
    public function _packageInsert(){
        $this->_Opackage->_Oconnection = $this->_Oconnection;

        $this->_IinputData['packageDetails']['package_type'] = ($this->_IinputData['tripType'] == 2) ? 1 : 0;
                    
        $this->_IinputData['packageDetails']['created_date'] = date('Y-m-d H:i:s');

        //Check whether the requested by email exists or not in input data,if exists get the employee id else assign session employee id
        if(isset($this->_IinputData['packageDetails']['requested_by']) && $this->_IinputData['packageDetails']['requested_by'] != ''){
            $employeeId = $this->_Oemployee->_checkAccountExist($this->_IinputData['passenger']['ADT'][0]['email_id'], 'employee_id');

            if (count($employeeId) > 0 || !$employeeId){
                $this->_IinputData['packageDetails']['requested_by'] = $this->_IinputData['packageDetails']['requested_by'];
                $this->_IinputData['packageDetails']['r_fact_employee_id'] = $employeeId[0];
            }else{
                $this->_IinputData['packageDetails']['requested_by'] = $_SESSION['employeeEmailId'];
                $this->_IinputData['packageDetails']['r_fact_employee_id'] = $_SESSION['factEmployeeId'];
            }
        }else{
            $this->_IinputData['packageDetails']['requested_by'] = $_SESSION['employeeEmailId'];
            $this->_IinputData['packageDetails']['r_fact_employee_id'] = $_SESSION['factEmployeeId'];
        }
        $this->_IinputData['packageDetails']['booking_type']='1';
        $this->_IinputData['packageDetails']['booking_mode'] = $_SESSION['userType'] =='TA'?1:0;
        //Calling function to insert package details
        $resultPackageId = $this->_Opackage->_insertPackage($this->_IinputData['packageDetails']);
        
        return $resultPackageId;
    }

    /**
     * @Description :This function is used to insert the order details
     * @param :
     * @return integer |$orderId - inserted order id
     */
    public function _orderInsert(){
        //Check whether the currency name exists or not in input data,if exists get the currency id else assign 0
        if (isset($this->_IinputData['currency_name']) && $this->_IinputData['currency_name'] != ''){
            //Calling function to get currency id for the input currency
            $currencyId = $this->_Olocation->_getCurrencyType($this->_IinputData['currency_name'], 'currency_id');

            if (count($currencyId) > 0 || !$currencyId){
                $this->_IinputData['orderDetails']['r_currency_type_id'] = $currencyId[0]['currency_id'];
            }else{
                $this->_IinputData['orderDetails']['r_currency_type_id'] = 0;
            }
        }elseif(!isset($this->_IinputData['orderDetails']['r_currency_type_id'])) {
            $this->_IinputData['orderDetails']['r_currency_type_id'] = 0;
        }
        //Check whether the travel mode exists or not in input data,if exists get the travel mode id else assign 0
        if (isset($this->_IinputData['travel_mode']) && $this->_IinputData['travel_mode'] != ''){
            //Calling function to get travel mode id for the input travel mode
            $travelModeId = $this->_OapplicationSettings->_getTravelMode(array('travel_mode_id'), 'travel_mode_code', $this->_IinputData['travel_mode']);

            if (count($travelModeId) > 0 || !$travelModeId){
                $this->_IinputData['orderDetails']['r_travel_mode_id'] = $travelModeId[0]['travel_mode_id'];
            }else{
                $this->_IinputData['orderDetails']['r_travel_mode_id'] = 0;
            }
        }elseif(!isset($this->_IinputData['orderDetails']['r_travel_mode_id'])){
            $this->_IinputData['orderDetails']['r_travel_mode_id'] = 0;
        }
        $this->_IinputData['orderDetails']['r_ticket_status_id'] = REQUESTED;
        $this->_IinputData['orderDetails']['r_payment_status_id'] = PAYMENT_NOT_DONE;
        $this->_IinputData['orderDetails']['created_date'] = date('Y-m-d h:m:s');
        $this->_IinputData['orderDetails']['travel_purpose'] = $this->_IinputData['travel_purpose'];
        $this->_IinputData['orderDetails']['expense_borne'] =$this->_IinputData['expense_borne'];
        //Get billto id for the order
        $billToId = $this->_IinputData['passenger']['r_billto_id'];
        $this->_IinputData['orderDetails']['r_billto_id'] = (isset($billToId)&&$billToId!='')?$billToId:$this->_Opackage->_getPassengerBillToId($this->_IinputData['passenger']);
        //Calling function to insert order details
        $orderId = $this->_Opackage->_insertOrderDetails($this->_IinputData['orderDetails']);
        $this->_policyVoilationInsert($orderId);
        
        return $orderId;
    }

    /**
     * @Description :This function is used to insert the fact booking details
     * @param :
     * @return integer |$factBookingId - inserted fact booking id
     */
    public function _factBookingInfoInsert(){
        
        $employeeId = $this->_IinputData['passenger']['ADT'][0]['r_employee_id']!=''?$this->_IinputData['passenger']['ADT'][0]['r_employee_id']:$_SESSION['employeeId'];
        $this->_IinputData['factBookingDetails']['travel_mode'] =  $this->_IinputData['orderDetails']['r_travel_mode_id'];
        $this->_IinputData['factBookingDetails']['r_employee_id'] = $employeeId;
        $this->_IinputData['factBookingDetails']['r_corporate_id'] = $_SESSION['corporateId'];
        $this->_IinputData['factBookingDetails']['r_agency_id'] = $_SESSION['agencyId'];
        //Calling function to insert fact booking details
        $factBookingId = $this->_Opackage->_insertFactBookingDetails($this->_IinputData['factBookingDetails']);
        $this->_IinputData['AirtripType']=$this->_IinputData['masterInfo']['requestTableData']['trip_type'];
       
        return $factBookingId;
    }

    /**
     * @Description :This function is used to insert the passenger details
     * @param :
     * @return integer |$factBookingId - inserted fact booking id
     */
    public function _passengerInsert(){
        return true;
    }

    public function _assigModuleResponseData($dataArray){
        $this->_AModuleResponseData = $dataArray;
    }

    public function _setPassengerCostCenterCode($costCenterCode){
        return $costCenterCode;
    }
    
    //update flow for request level
    public function _requestUpdateFlow(){

        //order details update
        $orderArray['r_travel_mode_id'] =$this->_IinputData['masterInfo']['r_travel_mode_id'];
        $orderArray['travel_purpose'] =$this->_IinputData['travel_purpose'];
        $orderArray['expense_borne'] =$this->_IinputData['expense_borne'];

        //Get billto id for the order
        $billToId = $this->_IinputData['passenger']['r_billto_id'];
        $orderArray['r_billto_id'] = (isset($billToId)&&$billToId!='')?$billToId:$this->_Opackage->_getPassengerBillToId($this->_IinputData['passenger']);
        $resultOrder = $this->_OcommonDBO->_update('order_details',$orderArray,'order_id',$this->_IinputData['updatePassenger']['orderId']);

        //air request details
        $fieldArray = array('airport_id');
        $orginId= $this->_OcommonDBO->_select('dm_airport',$fieldArray,'airport_code',$this->_IinputData['airRequestDetails'][0]['requestTableData']['r_origin_airport_id']['cityCode']);
        $destinationId = $this->_OcommonDBO->_select('dm_airport',$fieldArray,'airport_code',$this->_IinputData['airRequestDetails'][0]['requestTableData']['r_destination_airport_id']['cityCode']);
        $airRequest ['r_origin_airport_id'] = $this->_commonFlight->_getCityCodeAirportId($this->_IinputData['airRequestDetails'][0]['requestTableData']['r_origin_airport_id']['cityCode'],$this->_IinputData['airRequestDetails'][0]['requestTableData']['r_origin_airport_id']);
        $airRequest['r_destination_airport_id'] = $this->_commonFlight->_getCityCodeAirportId($this->_IinputData['airRequestDetails'][0]['requestTableData']['r_destination_airport_id']['cityCode'],$this->_IinputData['airRequestDetails'][0]['requestTableData']['r_destination_airport_id']);
        
        $airRequest ['onward_date']=$this->_IinputData['airRequestDetails'][0]['requestTableData']['onward_date'];
        $airRequest ['return_date']=$this->_IinputData['masterInfo']['requestTableData']['return_date'];
        $airRequest ['trip_type']=$this->_IinputData['masterInfo']['requestTableData']['trip_type'];
        $airRequest['r_travel_class_id']=$this->_IinputData['masterInfo']['requestTableData']['r_travel_class_id'];
        $airRequest['customize_fields']=(string)json_encode($this->_IinputData['masterInfo']['advancedsearch']);
        $airRequestId = $this->_airRquest->_getAirRequestDetails($this->_IinputData['updatePassenger']['orderId']);
        $resultAir = $this->_OcommonDBO->_update('air_request_details',$airRequest,'air_request_id',$airRequestId[0]['airRequest']);

        //booking History Update
        $bookingHistoryUpdate['sector_from'] =$this->_IinputData['airRequestDetails'][0]['originCode'];
        $bookingHistoryUpdate['sector_to'] =$this->_IinputData['airRequestDetails'][0]['destinationCode'];
        $bookingHistoryUpdate['onward_depature_date'] =$this->_IinputData['airRequestDetails'][0]['requestTableData']['onward_date'];
        $bookingHistoryUpdate['return_depature_date'] =$this->_IinputData['masterInfo']['requestTableData']['return_date'];
        $bookingHistoryUpdate['trip_type'] =$this->_IinputData['masterInfo']['requestTableData']['trip_type'];
        //$bookingHistoryUpdate['booking_type'] ='C';

        $resultBookingHistory = $this->_OcommonDBO->_update('booking_history',$bookingHistoryUpdate,'order_id',$this->_IinputData['updatePassenger']['orderId']);

        //passenger Details updation
        $passengerDetails= $this->_IinputData['passenger'];
        $passengerDetailsForId= $this->_IinputData['passenger']['ADT'];

        //to get band designation and department
        $employeeIds = array_column($passengerDetailsForId,'r_employee_id');

        //checking the employee array for empty null values()
        $employeeIds = array_filter($employeeIds);

        //checking this as we will get employees_id only in case of employees not guest
        if(sizeof($employeeIds)>0){
            $empData = $this->_Oemployee->_getEmployeeOtherDetails($employeeIds);
        }
        $passngerUpdate =$this->_IinputData['updatePassenger']['info'];

        /*passenge details array farmation for mutiple pax*/
        $paxUpdateDetails = $this->_passengerDetailsUpdateArrayFormat($passengerDetails,$passngerUpdate);
            
        foreach ($paxUpdateDetails as $key => $passengerUpd){
            
            foreach ($passengerUpd['newVal'] as $paxKey => $paxValue) {

                $passOther['project_code'] = $this->_setPassengerCostCenterCode($paxValue['cost_center']);
                $passOther['aadhar_number'] =$paxValue['aadhar_number'];
                $empOtherData = $empData[$paxValue['r_employee_id']][0];
                $passOther['department'] = $empOtherData['department_name'];
                $passOther['designation'] = $empOtherData['designation_name'];
                $passOther['branch'] = $empOtherData['branch_name'];

                $paxName=array();
                $paxName[$key]['first_name'] = $paxValue['first_name'];
                $paxName[$key]['last_name'] = $paxValue['last_name'];
                $passengerDetailsIds = $this->_OcommonDBO->_update('passenger_details',$paxName[$key],'passenger_id',$passengerUpd['passenger_id']);
                $passengerOtherDetails = $this->_OcommonDBO->_update('passenger_other_details',$passOther,'r_passenger_id',$passengerUpd['passenger_id']);
                (!empty($this->_CheckInsertPassengerDynamicValue) &&  $paxValue['employee_code'] != 'GUEST') ? $this->_OdynamicInsertion->_updatePassengerDynamicFieldValue($passengerUpd['passenger_id'], CUSTOM_FIELD_ID_OF_OPTIONAL_APPROVAL, $this->_IinputData['passengerDynamic'][$paxValue['r_employee_id']]) : FALSE;
            }
        }
           
        //to get package id from table
        $package =new package();
        $resPackage =$package->_getTravelType($this->_IinputData['updatePassenger']['orderId']);
        $this->_IinputData['factBookingDetails']['r_package_id'] =$resPackage[0]['package'];
        $this->_IinputData['factBookingDetails']['r_request_id'] =$airRequestId[0]['airRequest'];
        $this->_IinputData['factBookingDetails']['r_employee_id'] = $_SESSION['employeeId'];
        $this->_IinputData['factBookingDetails']['r_corporate_id'] = $_SESSION['corporateId'];
        $this->_IinputData['factBookingDetails']['r_order_id'] = $this->_IinputData['updatePassenger']['orderId'];
        $this->_IinputData['flagUpdate'] = 'Y';
        if($this->_IinputData['updateMasterPassenger'] == 1){
            $this->_OpassengerPrefence = new passengerPreferences();
            foreach ($this->_IinputData['passenger'] as $key => $passenger){
               foreach ($passenger as $index => $pas){
                    $passOther['project_code'] =$this->_setPassengerCostCenterCode($pas['cost_center']);
                    $passOther['aadhar_number'] =$pas['aadhar_number'];
                    unset($pas['cost_center']);
                    unset($pas['aadhar_number']);
                    $pas['first_name']=addslashes($pas['first_name']);
                    $pas['last_name']=addslashes($pas['last_name']);
                    if($pas['r_employee_id'] !=''){
                        $mealType = $this->_OpassengerPrefence->_getEmployeeMealType($pas['r_employee_id']);
                        $seatType =$this->_OpassengerPrefence->_getEmployeeSeatType($pas['r_employee_id']);
                        $passOther['meal_type']=$mealType[0]['meal'] ? $mealType[0]['meal'] : 'No Meal';
                        $passOther['seat_preference']=$seatType[0]['seat'] ? $seatType[0]['seat'] : 'Any';
                    }
                    $this->_employeeMasterUpdate($pas,$passOther);
                }
            }
        }
        $this->_policyVoilationLogInsertion($this->_IinputData['updatePassenger']['orderId']);
        $this->_OtravelPlan->_deleteExistingTravelPlan($this->_IinputData['updatePassenger']['orderId'],$this->_IinputData['tripPlan']);

        //update the workflow caption in order details based on the selection
        $this->_factTripOrderUpdate($this->_IinputData['updatePassenger']['orderId']);
        
        return $passengerDetails;
    }
    
    public function _employeeMasterUpdate($pasMain,$pasOther){
        $this->_OcommonDBO = new commonDBO();
        $mainTableDmEmployee['first_name']=$pasMain['first_name'];
        $mainTableDmEmployee['last_name']=$pasMain['last_name'];
        $mainTableDmEmployee['email_id']=$pasMain['email_id'];
        $mainTableDmEmployee['mobile_no']=$pasMain['mobile_no'];
        $mainTableDmEmployee['title']=$pasMain['title'];
        $resultUpdateMaster = $this->_OcommonDBO->_update('dm_employee',$mainTableDmEmployee,'employee_id',$pasMain['r_employee_id']);
        
        // cost conter details insert
        $this->_Oemployee = new employee();
        $resultCostCenterCode = $this->_Oemployee->_getEmployeeInfo($pasMain['r_employee_id']);
        
        if($resultCostCenterCode['ed.r_cost_center_code_id'] == ''){
            $dataCosteCenter['r_corporate_id']=$_SESSION['corporateId'];
            $dataCosteCenter['cost_center_code']= $pasOther['project_code'] ;
            $dataCosteCenter['r_travel_mode_id']=1;
            $dataCosteCenter['status']='Y';
            $insertCostCenter = $this->_OcommonDBO->_insert('cost_center_code_details', $dataCosteCenter);
        }
        
        //employee_details
        $employeeDetailsUpdate['r_cost_center_code_id'] =$insertCostCenter ;
        $employeeDetailsUpdate['aadhaar_no'] = $pasOther['aadhar_number'];
        $resultEmployeeDetailsUpdate = $this->_OcommonDBO->_update('employee_details',$employeeDetailsUpdate,'r_employee_id',$pasMain['r_employee_id']);
        
        return true;
    }
    
    //this function is use for inserting the details of violated policy
    public function _policyVoilationInsert($orderIdValue){
        if(!$this->_IinputData['policyDataInsert']['status']){
            $policyInsertDetails = $this->_IinputData['policyDataInsert']['result'];
            foreach ($policyInsertDetails as $key => $value){
                $input['r_order_id'] = $orderIdValue;
                $input['r_policy_id'] = $value[0]['r_policy_id'];
                $input['policy_violated_level'] = "R";
                $policyViolationLogId = $this->_OcommonDBO->_insert('policy_Violation_log',$input);
            }
        }
    }
    
    //this function is to delete the policy voilated order ID
    public function _policyVoilationLogInsertion($orderIdValue){
        $this->_OcommonDBO->_delete('policy_Violation_log','r_order_id',$orderIdValue);
        $this->_policyVoilationInsert($orderIdValue);
    }


    /**
     * check duplicate bookings
     * @return boolean
     */
    public function _checkDuplicateBooking(){
            $insertingDataFullArray = $this->_IinputData;
            $paxEmployee = array_column($insertingDataFullArray['passenger']['ADT'], 'r_employee_id');
            $airRequestDetails = $insertingDataFullArray['airRequestDetails'];
            foreach ($airRequestDetails as $key => $value) {
                foreach ($paxEmployee as $paxkey => $paxvalue) {
                    if($paxvalue != 0){
                        $sql = "select * from air_request_details ard 
                            INNER JOIN fact_booking_details fbd  on ard.air_request_id=fbd.r_request_id 
                            INNER JOIN passenger_details pd ON pd.r_order_id = fbd.r_order_id
                            INNER JOIN order_details od ON od.order_id = fbd.r_order_id 
                            where ard.r_origin_airport_id ='". $value['requestTableData']['r_origin_airport_id']['cityId'] ."' and
                            ard.r_destination_airport_id ='". $value['requestTableData']['r_destination_airport_id']['cityId'] ."' and
                            ard.onward_date ='". $value['requestTableData']['onward_date'] ."' and
                            pd.r_employee_id IN (". implode(',', $paxEmployee). ") 
                            AND r_payment_status_id IN(".PAYMENT_NOT_DONE.",".PAYMENT_DONE.") AND r_ticket_status_id IN (".PAID.",".SEND_FOR_APPROVAL.",".APPROVED.",".TICKETTED.")";
                            //payme N0T IN (15,16)  and tikcte 2 send to approval 
                        $resultDuplicate[$key] = $this->_OcommonDBO->_getResult($sql) ? true : false;
                    }
                }
            }
            if (in_array(true, $resultDuplicate)){
                $this->_AfinalResponse['FLAG'] = "DUPLICATE";
                $this->_AfinalResponse['error_alert'] = "Booking already exist for the same employee in same date .";
            }
            return TRUE;
    }


     /**
     * check duplicate bookings
     * @return boolean
     */
    public function _checkDuplicateBookingItinerary(){
        $insertingDataFullArray = $this->_IinputData;     
        $sql = "select   vfd.time_arrival,vfd.segment_order,vfd.departure_date  from air_request_details ard 
                            INNER JOIN fact_booking_details fbd  on ard.air_request_id=fbd.r_request_id 
                            INNER JOIN passenger_details pd ON pd.r_order_id = fbd.r_order_id
                            INNER JOIN order_details od ON od.order_id = fbd.r_order_id
                            INNER JOIN air_booking_details abd ON od.order_id = abd.r_order_id
                            INNER JOIN fact_air_itinerary fai ON abd.air_booking_details_id = fai.r_air_booking_details_id
                            INNER JOIN via_flight_details vfd ON  fai.r_via_flight_id = vfd.via_flight_id
                            where 
                            pd.r_employee_id IN (".$insertingDataFullArray['employeeId']. ")  
                            AND (r_payment_status_id IN(".PAYMENT_NOT_DONE.",".PAYMENT_DONE.") AND r_ticket_status_id IN(".SEND_FOR_APPROVAL.",".TICKETTED.",".PAID.",".APPROVED.")) AND fai.itinerary_status =" .SELECTED_ITINERARY." AND vfd.arrival_date ='". $insertingDataFullArray['currDate'] ."' AND  (vfd.time_arrival  BETWEEN '". $insertingDataFullArray['previousTime'] ."'  AND '". $insertingDataFullArray['nextTime'] ."'   )";
                        //payme N0T IN (15,16)  and tikcte 2 send to approval 
        $resultDuplicate = $this->_OcommonDBO->_getResult($sql)  ? true : false;
        if ($resultDuplicate ==true){
            $this->_AfinalResponse['FLAG'] = "DUPLICATE";
            $this->_AfinalResponse['error_alert'] = "Booking already exist for the same employee in same date .";
        }
        return TRUE;
    }
    
   /**
     * this function used to arrange array format for passenger new details from modify request
     * param | array passengerDetails
     * param | array  passngerUpdate
     * @return array | passngerUpdate
     * auther puroskhan.m
     */
    public function _passengerDetailsUpdateArrayFormat($passengerDetails,$passngerUpdate ) {
          foreach ($passengerDetails as $tempkey => $tempvalue) {
                     foreach ($tempvalue as $k => $v) {
                        $tempVal[]=$v;
                     }
                  } 
          foreach ($passngerUpdate as $updatekey => $updatevalue) {
                $passngerUpdate[$updatekey]['newVal'][0] =$tempVal[$updatekey];

            }
            return $passngerUpdate;
    }    

    public function _factTripOrderInsert(){
        return true;
    }    

    public function _factTripOrderUpdate(){
        return true;
    }
   
    public function _getServiceResponseOptionalApprover(){
        return true;    
    }

    public function _updateAirRequestDetails(){
        return true;
    }
}
?>