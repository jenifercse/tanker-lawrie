<?php
/** * **************************************************************************
 * @File            cancellation request details
 * @Description     This class has the cancel request itinerary and passenger info
 * @Author          Priya
 * @Created Date    18/08/2016
 * @update Date
 * @update By
 * *************************************************************************** */
pluginFileRequire('common/', 'interface/commonConstants.php');

class noShowRequestDetailsTpl implements commonConstants{
    //Class variables    
    public $_Oconnection;
    //public $_Oreschedule;
    public $_AorderDetails;
    var $_ApaxDetails;
    public $_AnoShowDetails;
    public $_AitineraryDetails;

    public function __construct(){
        $this->_OcommonDBO = new commonDBO();
        $this->_OpassengerDetails = new passenger();
        $this->_OairRequest = new airRequest();
        $this->_ApassengerType = array('ADT' => 'Adult', 'INF' => 'Infant', 'CNN' => 'Child');
        $this->_Ostatus_value = new applicationSettings();
        $this->_OpackageDetails = new package();
        $this->_OairlineDetails = new airline();
        $this->_OflightItinerary = new flightItinerary();
        //$this->_Oreschedule = new reschedule();
        //$this->_SrescheduleStatus = 'N';
        $this->_Ppreferences = new passengerPreferences();
        $this->_AtravelModeId = array('D' => 1,'I'=> 9);
        $this->_OcancellationInsert = common::_checkClassExistsInNameSpace('cancellationInsert');
    }

    /**
     * @Description  this function handles the create agency logic and template to be ovewridden and displayed
     * @param 
     * @return 
     */
    public function _getDisplayInfo(){
        $input = $this->_IinputData;
        $this->_getNoShowRequestInfo($input);
        $this->_templateAssign($input);
    }

    /**
     * @Description  this function get the basic info of the itinerary
     * @param 
     * @return 
     */
    private function _getNoShowRequestInfo($input){
        $cancellation = new cancellation();
        $cancellation->_Oconnection = $this->_Oconnection;

        if(isset($input['order_id'])){
            $orderId = $input['order_id'];
        }else{
            $orderId = 0;
        }
        
        if($input['action'] != 'corporateComboCancellation'){
            //get order id 
            $orderDetails = $this->_OpackageDetails->_getPaymentCompletedPackageDetails($input['package_id'], '', $orderId);

            //Set air input data
            $input['order_id']    = $orderDetails[0]['r_order_id'];
            $input['travel_mode'] = $orderDetails[0]['r_travel_mode_id'];      
            
             // set order id for twig 
            $this->_IorderId = $input['order_id'];
            $this->_IairTotalAmount = $orderDetails[0]['total_amount'];
            $this->_IpackageType = $orderDetails[0]['package_type'];
        }

        /* * * to get the basic info of booking * */
        $_AorderDetails = $this->_OpackageDetails->_getOrderDetailsInfo($input['order_id']);
        if ($_AorderDetails != ''){
            $this->_IbookingType = $_AorderDetails[0]['booking_type'];
            $this->_AorderDetails = $this->_OpackageDetails->_getOrderInfo($_AorderDetails);
        }

        /* * * to get travel type for air request id * */
        $this->_OtravelType = $this->_OairRequest->_getAirRequest($this->_AorderDetails['0']['r_request_id'], 'travel_type');

        /* * * to get the itinerary info of booking * */
        $_AitineraryDetails = $this->_OflightItinerary->_getFlightItineraryDetails($input['order_id']);

        foreach($_AitineraryDetails as $data => $value){  
            $passengerViaInfo = $this->_OflightItinerary->_getPassengerViaInfo($orderId,$value['via_flight_id'])[0];          
            $_AitineraryDetails[$data]['pnr'] = $passengerViaInfo['pnr'];
             $_AitineraryDetails[$data]['ticketStatus'] = $passengerViaInfo['r_booking_status_id'] != NOTHING_REQUESTED ? $passengerViaInfo['status_value'] : '';
        }
        
        if ($_AitineraryDetails != ''){
            $this->_AitineraryDetails = $this->_OflightItinerary->_getItineraryInfo($_AitineraryDetails);
        }
        
        /* * * to get the per pax no show detials  * */
        $_AnoShowDetails = $cancellation->_getCancelCharge($input['order_id']);
        
        if ($_AnoShowDetails != ''){
            $this->_AnoShowDetails = $this->_getNoShowInfo($_AnoShowDetails, $cancellationAmount);
        }

        /* * * to get the passenger info of booking * */
        $this->_ApaxDetails = $this->_OpassengerDetails->_getPassengerDetails($input['order_id']);
        $adtCount = 0;
        $chdCount = 0;
        $infCount = 0;
        $this->_paxCountStatus = 'N';
        foreach ($this->_ApaxDetails as $key => $values){
            if($values['passenger_type'] == 'ADT'){
                $adtCount = $adtCount + 1;
            }elseif($values['passenger_type'] == 'CNN'){
                $chdCount = $chdCount + 1;
            }elseif($values['passenger_type'] == 'INF'){
                $infCount = $infCount + 1;
            }
        }
        if($adtCount > 2 || $chdCount > 2 || $infCount > 2){
            $this->_paxCountStatus = 'Y';
        }

    }

   
    /**
     * @Description  this function  get the no show info
     * @param array |$resultCancel
     * @return array |$cancelRow
     */
    private function _getNoShowInfo($resultCancel){

        if($resultCancel != ''){
            foreach ($resultCancel as $data){
                /* * * to get the airline details * */
                if($data['r_airline_id'] != ''){
                    $airlineInfo = $this->_OairlineDetails->_getAirlineDetails($data['r_airline_id']);
                    $data['airlineCode'] = $airlineInfo[0]['airline_code'];
                }

                /* * * end of airline details * */
                $result = $this->_OflightItinerary->_getSplitupForViaFareId($viaFareId, $travelModeId);
                
                /* * * to get the responsible passenger for the infant * */
                if($data['passenger_type'] == 'ADT'){
                    $infantInfo = $this->_OpassengerDetails->_getPassengerInfantMapping($data['paxId'], 'r_infant_id');
                    if($infantInfo[0] != 0){
                        $data['infantPaxId'] = $infantInfo[0]['r_infant_id'];
                         /* * status in 'Y' having the infant */ 
                        $data['paxStatus'] = 'Y';
                    }
                }
                
                /* * * to get the responsible passenger for the infant * */
                if($data['passenger_type'] == 'INF'){
                    $data['paxStatus'] = 'Y';
                }
                /* * * end of infant_details * */
                /* * * to get the passenger type details * */
                if(array_key_exists($data['passenger_type'], $this->_ApassengerType)){
                    $data['paxType'] = $this->_ApassengerType[$data['passenger_type']];
                }
                /* * * to get the status value * */
                if($data['r_booking_status_id'] != ''){
                    $_status = $this->_Ostatus_value->_getTicketStatus($data['r_booking_status_id']);
                    $data['booking_status'] = $_status[0]['status_value'];
                }
                $_ItravelMode = $this->_OpackageDetails->_getOrderDetailsInfo($this->_IinputData['order_id']);
                $data['travel_mode'] = $_ItravelMode[0]["travelMode"];

                $cancelRow[] = $data;
            }
        }
        return $cancelRow;
    }

     /**
     * used to set the ssr request fare details in array for display purpose
     * @param type $orderId int
     */
    public function _getSSRFareDetails($orderId){
        $ssrFareDetails = array();
        // get ssr fare and ssr preferences type and details
        $ssrFareDetails = call_user_func(array($this->_Ppreferences, '_getSSRpreferencesFareDetails'), $orderId);
        
        // form ssr fare details and ssr condfirmation page display
        array_walk($ssrFareDetails, function($value, $key) use($orderId){
            // fare break up details
            $this->_AtwigOutputArray['ssrFareBreakUp'][$value['preferences_type']] += $value['ssr_preferences_fare'];
            // ssr display details
            $this->_AtwigOutputArray['passengerSSRdetails'][$orderId][$value['email_id']][$value['r_via_flight_id']][$value['preferences_type']] = $value['ssr_preferences_name'].'-'.$value['ssr_preferences_fare'];
        });
    }

    public function _getNoShowReason($noShowId){

        $sql = "SELECT 
                    dmns.reason_value,nsd.r_no_show_reason_type_id
                FROM 
                    no_show_details nsd
                INNER JOIN dm_no_show_reason_type dmns ON nsd.r_no_show_reason_type_id = dmns.no_show_reason_type_id
                WHERE nsd.no_show_details_id = " .$noShowId;

        return $this->_OcommonDBO->_getResult($sql);

    }

    public function _templateAssign($input){
        
        $_OcommonQuery = new commonQuery();
        
        $this->_AtwigOutputArray['itenaryAction'] = $input['action'];
        $this->_AtwigOutputArray['orderInfo'] = $this->_AorderDetails;
        $this->_AtwigOutputArray['paxInfo'] = $this->_ApaxDetails;
        $this->_AtwigOutputArray['paxCountStatus'] = $this->_paxCountStatus;
        $this->_AtwigOutputArray['noShowInfo'] = $this->_AnoShowDetails;
        $this->_AtwigOutputArray['itineraryInfo'] = $this->_AitineraryDetails;
        $this->_AtwigOutputArray['statusId'] = NOTHING_REQUESTED;
        $this->_AtwigOutputArray['travelType'] = $this->_OtravelType['0']['travel_type'];
        $this->_AtwigOutputArray['packageType'] = $this->_IpackageType;
        $this->_AtwigOutputArray['referenceValueOfCorporate'] = $_SESSION['syncAgencyReference'] ? $_SESSION['syncAgencyReference'] : $_REQUEST['syncAgencyReference'];
        $request_date = $this->_OcommonDBO->_select('booking_history', 'DATE(request_date)', 'order_id', $this->_IorderId)[0]['DATE(request_date)'];
        $this->_AtwigOutputArray['gstDisplay'] = (strtotime($request_date) >= strtotime(GST_DISPLAY_DATE)) ? GST_DISPLAY_NAME : 'Service Tax' ;
        $this->_AtwigOutputArray['orderId'] = $this->_IorderId;
        $this->_AtwigOutputArray['travelModeId'] = $this->_AtravelModeId[$this->_OtravelType['0']['travel_type']];       
        $this->_getSSRFareDetails($this->_IorderId);        
        $this->_AtwigOutputArray['userApplicationSettings'] = $_OcommonQuery->_getUserApplicationSettingsInfo($this->_IorderId);
        // to get Booking Reference  Prefix String
        $this->_AtwigOutputArray["BookingReferencePrefixString"] = $_OcommonQuery->_getBookingReferencePrefixStingBasedOnOrder($this->_IorderId);
        $this->_AtwigOutputArray['bookingType'] = ($this->_IbookingType == '1') ? 'C' : 'P';
     
        // iocl  trip details
        $this->_AtwigOutputArray['tripDetails'] = $this->_OcancellationInsert->_getTripInfo($this->_IinputData['package_id']);
        $this->_AtwigOutputArray['NOSHOWBUTTON'] = 'Y';
        $this->_AtwigOutputArray['noShowrequestReason'] = $this->_getNoShowReason($input['noShowId'])[0];
        $this->_AtwigOutputArray['noShowReason'] = $this->_OcommonDBO->_select('dm_no_show_reason_type','reason_value');
        $this->_AtwigOutputArray['buttonDisplay'] = $input['buttonDisplay'] != '' && $input['buttonDisplay'] == 'noShowApprovalListButton.tpl' ? $input['buttonDisplay'] : '';   
        $this->_AtwigOutputArray['button'] = $input['buttonDisplay'] != '' ? 'N' : 'Y';
        $this->_AtwigOutputArray['message'] = $input['message'] ? $input['message'] : '';
        $this->_AtwigOutputArray['payment_status'] = $input['buttonStatus'] == 'N' ? 0 : '';
        $this->_AtwigOutputArray['noShowId'] = $input['noShowId'] !='' ? $input['noShowId'] : '' ;
        $checkReturndateExpire = $this->_OcommonDBO->_select('booking_history', 'return_depature_date', 'order_id', $this->_IorderId)[0]['return_depature_date'];
        $sysdate = strtotime(date("Y-m-d H:i:s"));
        $this->_AtwigOutputArray['returnDateExpire'] = ($sysdate > strtotime($checkReturndateExpire)) ? 'Y' : 'N';
        fileWrite(print_r($this->_AtwigOutputArray,1),'noSHow','a+');

    }
}
?>