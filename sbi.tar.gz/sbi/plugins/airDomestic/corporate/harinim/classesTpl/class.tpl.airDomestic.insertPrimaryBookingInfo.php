<?php

/** * **************************************************************************
 * @File             : class.tpl.insertPrimaryBookingDetails.php
 * @Description      : This file is used to insert primary booking request details
 * @Tables Affected  : package_details,order_details,passenger_details,fact_booking_details
 * @Author           : Priyadharsini.M
 * *************************************************************************** */
class insertPrimaryBookingInfo {

    public function __construct() {
        $this->_Oemployee = new employee();
        $this->_Olocation = new location();
        $this->_OapplicationSettings = new applicationSettings();
        $this->_Opackage = new package();
        $this->_Opassenger = new passenger();
        $this->_OcommonDBO = new commonDBO();
        $this->_Itineray = new flightItinerary();
        $this->_request = new airRequest();
        $this->_OdynamicInsertion = new dynamicFormElementManipulation();
        $this->_OcommonQuery = new commonQuery();
        $this->_OapprovalTracking = common::_checkClassExistsInNameSpace('approvalTracking');
        $this->_OcommonInsertPrimary = common::_checkClassExistsInNameSpace('commonInsertPrimaryBookingInfo', 'airDomestic');
        $this->_AfinalResponse['error_alert'] = '';
        $this->_AfinalResponse['status'] = 0;
    }

    /**
     * @functionName    :   _getDisplayInfo()
     * @description     :   default module method
     */
    public function _getDisplayInfo() {
        //assigning the inputs
        $this->_OcommonInsertPrimary->_IinputData = $this->_IinputData;
        $this->_OcommonInsertPrimary->_AserviceResponse = $this->_AserviceResponse;

        //Flow will come here when fares are selected
        if ($this->_IinputData['action'] == 'checkApprovalExist') {
            $this->_setApprovalInfo();
        }
        if ($this->_IinputData['action'] == 'insertAirBookingRequest') {
            //Flow will come here when request is modified
            $action = 'insert';
        } elseif($this->_IinputData['action'] == 'updateAirBookingRequest') {
            //Flow will come here when request is submitted
            $action = 'update';
        }
        if ($this->_IinputData['action'] == 'insertPassportDetails') {
            $action = 'insertPassportDetails';
        }
	if ($this->_IinputData['action'] == 'employeeMasterUpdate') {
            $action = 'employeeMasterUpdate';
        }
        switch ($action) {
            case 'update':
                $this->_OcommonInsertPrimary->_getResponseInModifyRequest();
                $this->_reassign();
                $this->_AserviceResponse['airRequestDetails'] = $this->_IinputData['airRequestDetails'];
                $this->_AserviceResponse['requestLevelInsetedData'] = $this->_IinputData;
                $this->_AserviceResponse['requestLevelInsetedData']['orderId'] = $this->_IinputData['action'];
                break;
            case 'insert':
                $this->_OcommonInsertPrimary->_passengerInsertionFlow();
                $this->_reassign();
                $this->_AserviceResponse['airRequestDetails'] = $this->_IinputData['airRequestDetails'];
                break;
            case 'insertPassportDetails':
                // get all the passport details and insert into passenger_passport_details
                $result = $this->_OcommonInsertPrimary->_insertPassportDetails($this->_IinputData['data']);
                return $this->_AfinalResponse = array("status" => 1, "message" => 'Passport details updated successfully');
                break;
            case 'employeeMasterUpdate':
                $this->_OcommonInsertPrimary->_multipleEmployeesMasterUpdate($this->_IinputData['passengerData'], '', 1);
                return $this->_AfinalResponse = array("status" => 1, "message" => 'Employee details updated successfully');
                break;

            default:
        }
    }

    //check the approver type and set the approver.
    public function _setApprovalInfo() {
        //check the exception approver form the session
        $approverType = $_SESSION['userApplicationSettings']['EXCEPTION_APPROVER'] == 'YES' ? ($this->_IinputData['policyViolationFlag'] ? 'EA' : '') : '';

        //get workflow caption from order_details based on order_id
        $this->_workFlowCaption = $this->_OcommonQuery->_getWorkFlowForOrder($this->_IinputData['factBookingDetails']['r_order_id']);

        //set workflowcatpion.
        $this->_OcommonInsertPrimary->_workFlowCaption = $this->_workFlowCaption;

        //calling the set approval function while request approval flow is set in session.
        if ($this->_workFlowCaption != "CMP_REQUEST_APPROVAL") {
            $approverType ? $this->_OcommonInsertPrimary->_setApproval($approverType) : $this->_OcommonInsertPrimary->_setApproval();
            $this->_reassign();
        }
    }

    /**
     * @functionName    :   _reassign()
     * @description     :   assign values from class to current object
     */
    private function _reassign() {
        //assigning values of $this->_OcommonInsertPrimary to current this variable.
        foreach (get_object_vars($this->_OcommonInsertPrimary) as $key => $value) {
            $this->$key = $value;
        }
    }

}

?>
