<?php
/** * **************************************************************************
 * @File             : class.tpl.modifyAirRequestTpl.php
 * @Description      : This file is used to modify air request
 * @Author           : PRIYADHARSINI.M
 * *************************************************************************** */
class addPassengerTpl{

    public function __construct(){
        $this->_Itineray=new flightItinerary();
        $this->_request = new airRequest();
    }
    
    /**
     * @functionName    :   _getDisplayInfo()
     * @description     :   default module method
     */
    public function _getDisplayInfo(){
        $orderId=$this->_IinputData['r_order_id'];
        $itinerayDetails = $this->_Itineray->_getOrderBookingDetails($orderId);
        $fieldArray=array('adult_count','child_count','infant_count');
        $requestDetails =  $this->_request->_getAirRequest($itinerayDetails['r_request_id'],$fieldArray);
        foreach ($requestDetails[0] as $key => $value){
          $this->_AtwigOutputArray[$key] = $requestDetails[0][$key];
        }
        $this->_AtwigOutputArray['order_id']=$orderId;
    }
}
