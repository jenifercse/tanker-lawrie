<?php
/** * **************************************************************************
 * @File             : class.tpl.cancellationListTpl.php
 * @Author           : Sivaprakash.M
 * @Created Date     : 10/01/2017
 * @Modified Date    : 
 * ****************************************************************************/
class cancellationListTpl{
    
    public function __construct(){
        $this->_objListDisplay = new listDisplay();
    }
    
    /**
     * @functionName    :   _getDisplayInfo()
     * @description     :   common module function
     */
    public function _getDisplayInfo(){
        $_SESSION['order_id'] = $this->_IinputData['orderId'] ? $this->_IinputData['orderId'] : 0 ;
        
        $CANCELBOOKINGS = $this->_objListDisplay->_getBookingsList('CANCELBOOKINGS', $this->_IinputData, 'returnQuery');

        $POSTCANCELBOOKINGS = $this->_objListDisplay->_getBookingsList('POSTCANCELBOOKINGS', $this->_IinputData, 'returnQuery');

        $this->_AfinalResponse = $this->_objListDisplay->_getCombinedQueryResult($CANCELBOOKINGS, $POSTCANCELBOOKINGS);
        $this->_AfinalResponse ? $this->_AfinalResponse[0]['listBookingReferences'] = $this->_objListDisplay->_referenceValueOfCorporate : '';
        
        $this->_templateAssign();
    }
    
    /**
     * @functionName    :   _templateAssign()
     * @description     :   common module function
     */    
    public function _templateAssign(){
        $this->_AtwigOutputArray['cancellationList'] = $this->_AfinalResponse;
    }
}
?>
