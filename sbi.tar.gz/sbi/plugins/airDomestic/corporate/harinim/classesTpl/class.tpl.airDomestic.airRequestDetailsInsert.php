<?php
/** * **************************************************************************
 * @File             : class.tpl.airRequestDetailsInsert.php
 * @Description      : This file is used to insert air request details
 * @Tables Affected  : air_request_details
 * @Author           : Lakshmi.S
 * @Created Date     : 05/07/2016
 * @Modified Date    : 
 * ****************************************************************************/
class airRequestDetailsInsert{
    
    public function __construct(){
        //calling the function to insert the request level details.
        $this->_OairRequestInsert = new commonAirRequestDetailsInsert();
    }
        
    // calling base module function.
    public function _getDisplayInfo(){
        // Assigning the inputs.
        $this->_OairRequestInsert->_IinputData = $this->_IinputData;
        $this->_OairRequestInsert->_AserviceResponse = $this->_AserviceResponse;
        $this->_OairRequestInsert->_AModuleResponseData = $this->_AModuleResponseData;
        $this->_OairRequestInsert->_Otwig = $this->_Otwig;

        //calling the function.
        $this->_OairRequestInsert->_airRequestInfo();

        //assign the this of commonAirRequestDetailsInsert in to this class variable
        foreach (get_object_vars($this->_OairRequestInsert) as $key => $value){
            $this->$key = $value;
        }
    }
}
?>