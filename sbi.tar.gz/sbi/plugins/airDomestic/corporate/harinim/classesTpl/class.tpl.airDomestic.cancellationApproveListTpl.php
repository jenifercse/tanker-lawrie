<?php
/** * **************************************************************************
 * @File             : class.tpl.cancellationApproveListTpl.php
 * @Author           : Sivaprakash.M
 * @Created Date     : 10/01/2017
 * @Modified Date    : 
 * ****************************************************************************/
class cancellationApproveListTpl{
    
    public function __construct(){
        $this->_objListDisplay = new listDisplay();
        $this->_CcommonQuery = new commonQuery();
    }
    
    /**
     * @functionName    :   _getDisplayInfo()
     * @description     :   common module function
     */
    public function _getDisplayInfo(){
        $r_agency_id = $_SESSION['agencyId'] ? $_SESSION['agencyId'] : $_REQUEST['agencyId'];
        $r_corporate_id = $_SESSION['corporateId'] ? $_SESSION['corporateId'] : $_REQUEST['corporateId'];
        $r_employee_id = $_SESSION['employeeId'] ? $_SESSION['employeeId'] : $_REQUEST['employeeId'];
        $this->_SsessionId = compact('r_agency_id', 'r_corporate_id', 'r_employee_id');  
        $_SESSION['order_id'] = $this->_IinputData['orderId'] ? $this->_IinputData['orderId'] : 0 ;
        switch($this->_IinputData['action']){
            case 'viewItinerary':
                $this->_objListDisplay->_Otwig = $this->_Otwig;
                $this->_AfinalResponse = $this->_objListDisplay->_showAllBookingItinerary($this->_IinputData['Package_id']);
                break;                
            default :
                $this->_SsessionId['process_type'] = 'Cancellation';
                $this->_AfinalResponse = $this->_objListDisplay->_getBookingsList('PENDINGAPPROVECANCELBOOKINGS', $this->_SsessionId);
                $this->_AfinalResponse ? $this->_AfinalResponse[0]['listBookingReferences'] = $this->_LlistDetails->_referenceValueOfCorporate : '';
                break;
        }
        fileWrite(print_r($this->_AfinalResponse,1),'cancellationApproveListTpl');
        $this->_templateAssign();
    }
    
    /**
     * @functionName    :   _templateAssign()
     * @description     :   common module function
     */
    public function _templateAssign(){
        $this->_AtwigOutputArray['cancellationApproveList'] = $this->_AfinalResponse;
    }
}
?>
