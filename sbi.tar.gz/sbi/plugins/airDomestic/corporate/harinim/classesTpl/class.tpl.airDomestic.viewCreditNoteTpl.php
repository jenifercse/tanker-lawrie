<?php
/** * **************************************************************************
 * @File             : class.tpl.viewCreditNoteTpl.php
 * @Description      : This file is used to view credit note 
 * @Author           : Sivaprakash.M
 * @Created Date     : 20/04/2017
 * @Modified Date    : 
 * *************************************************************************** */
class viewCreditNoteTpl{

    public function __construct(){
        $this->_CcreditnoteDetails = new creditnoteDetails();
        $this->_GgenarateHtmlAndMailDetails = new genarateHtmlAndMailDetails();
    }

    /**
     * @functionName    :   _getDisplayInfo()
     * @description     :   used to call the toUpdateTable() function to process the request
     */
    public function _getDisplayInfo(){
        $_SESSION['order_id'] = $this->_IinputData['orderId'] ? $this->_IinputData['orderId'] : 0 ;
        $this->_IinputData['flagVariable'] = 'creditnote';
        switch ($this->_IinputData['action']){
            case 'htmlGeneration':
                $this->_AfinalResponse =  $this->_GgenarateHtmlAndMailDetails->eTicketHtmlGeneration($this->_IinputData);
                break;
            case 'sendCreditNoteMail':
                $this->_AfinalResponse =  $this->_GgenarateHtmlAndMailDetails->_sendEticket($this->_IinputData, 'corporate'); 
                break; 
            default:
                $this->_PpassengerViaFlightcreditnoteDetails = $this->_CcreditnoteDetails->_getCreditNoteDetails($this->_IinputData['orderId'], $this->_IinputData['cancellationId']);
                break;
        }
        $this->_templateAssign();
    }
    
    /**
     * @functionName    :   _templateAssign()
     * @description     :   common module function
     */
    public function _templateAssign(){
        $this->_AtwigOutputArray['E_TICKET_DISPLAY_ADDRESS_ONE'] = E_TICKET_DISPLAY_ADDRESS_ONE;
        $this->_AtwigOutputArray['E_TICKET_DISPLAY_ADDRESS_TWO'] = E_TICKET_DISPLAY_ADDRESS_TWO;
        $this->_AtwigOutputArray['E_TICKET_DISPLAY_ADDRESS_THREE'] = E_TICKET_DISPLAY_ADDRESS_THREE;
        $this->_AtwigOutputArray['E_TICKET_DISPLAY_ADDRESS_FOUR'] = E_TICKET_DISPLAY_ADDRESS_FOUR;
        $this->_AtwigOutputArray['E_TICKET_DISPLAY_ADDRESS_FIVE'] = E_TICKET_DISPLAY_ADDRESS_FIVE;
        $this->_AtwigOutputArray['tripPackageId'] = $this->_IinputData['packageId'];
        $this->_AtwigOutputArray['orderId'] = $this->_IinputData['orderId'];
        $this->_AtwigOutputArray['creditNoteDetails'] = $this->_PpassengerViaFlightcreditnoteDetails;
    }
}
?>