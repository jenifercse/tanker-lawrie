<?php
/** * **************************************************************************
 * @File             : class.tpl.insertPrimaryBookingDetails.php
 * @Description      : This file is used to insert primary booking request details
 * @Tables Affected  : package_details,order_details,passenger_details,fact_booking_details
 * @Author           : Lakshmi.S
 * @Created Date     : 01/07/2016
 * @Modified Date    : 
 * *************************************************************************** */

class insertPrimaryBookingDetails{

    public function __construct(){
        $this->_Oemployee = new employee();
        $this->_Olocation = new location();
        $this->_OapplicationSettings = new applicationSettings();
        $this->_Opackage = new package();
        $this->_Opassenger = new passenger();
    }

    /**
     * @functionName    :   _getDisplayInfo()
     * @description     :   default module method
     */
    public function _getDisplayInfo(){
        $finalArray=$this->_IinputData;

        //Calling function to insert package details
        $this->_IinputData['tripType']=$this->_IinputData['requestFormData']['masterInfo']['requestTableData']['trip_type'];
        $this->_IinputData['currency_name']=$this->_IinputData['requestFormData']['masterInfo']['currency_name'];
        $this->_IinputData['travel_mode']=$this->_IinputData['requestFormData']['masterInfo']['requestTableData']['travel_type'];

        $db = new commonDBO();

        $sql    = "SHOW TABLE STATUS WHERE `Name` = 'dm_package'";
        $result = $db->_getResult($sql);
        
        $_SESSION['currentPackageId'] = $result[0]['Auto_increment'];
        
        $resultPackageId = $this->_packageInsert();
        
        fileWrite($resultPackageId, 'packageInsert');
        
        $_SESSION['currentPackageId'] = $resultPackageId;
        
        if ($resultPackageId > 0 || !$resultPackageId){
            $this->_IinputData['factBookingDetails']['r_package_id'] = $resultPackageId;
            if ($this->_IinputData['tripType'] != 2){
                // oneway & roudtrip
                $resultOrderId = $this->_orderInsert();
                if ($resultOrderId > 0 || !$resultOrderId){
                    $this->_IinputData['factBookingDetails']['r_order_id'] = $resultOrderId;
                    //Calling function to insert fact booking details
                    $resultFactId = $this->_factBookingInfoInsert();
                    if ($resultFactId > 0){
                        $responseDataArray = array('factBookingId' => $resultFactId);
                    }
                }
            }else{
                $input_array = $this->_IinputData['requestFormData'];
                foreach ($input_array['airRequestDetails'] as $key => $value){
                    $resultOrderId = $this->_orderInsert();
                    if ($resultOrderId > 0 || !$resultOrderId){
                        $this->_IinputData['orderId'][$key] = $resultOrderId;
                        $this->_IinputData['factBookingDetails']['r_order_id'] = $resultOrderId;
                        //Calling function to insert fact booking details
                        $resultFactId = $this->_factBookingInfoInsert();
                        if ($resultFactId > 0){
                            $responseDataArray = array('factBookingId' => $resultFactId);
                            $this->_IinputData['factId'][$key] = $resultFactId;
                        }
                    }
                }
            }
            
            if(DEBUG_ORDER_TRACKING){
                unset($_SESSION['booking_history']);

                $orderId = $this->_IinputData['factBookingDetails']['r_order_id'];
                $_SESSION['booking_history'][$resultPackageId]['package_type']                   = $this->_IinputData['packageDetails']['package_type'];
                $_SESSION['booking_history'][$resultPackageId][$orderId]['trip_type']            = $this->_IinputData['tripType'];
                $_SESSION['booking_history'][$resultPackageId][$orderId]['travel_mode']          = $this->_IinputData['travel_mode'];
                $_SESSION['booking_history'][$resultPackageId][$orderId]['no_of_passenger']      = $this->_IinputData['requestFormData']['masterInfo']['requestTableData']['num_passenger'];
                $_SESSION['booking_history'][$resultPackageId][$orderId]['adult']                = $this->_IinputData['requestFormData']['masterInfo']['requestTableData']['adult_count'];
                $_SESSION['booking_history'][$resultPackageId][$orderId]['child']                = $this->_IinputData['requestFormData']['masterInfo']['requestTableData']['child_count'];
                $_SESSION['booking_history'][$resultPackageId][$orderId]['infant']               = $this->_IinputData['requestFormData']['masterInfo']['requestTableData']['infant_count'];
                $_SESSION['booking_history'][$resultPackageId][$orderId]['request_date']         = $this->_IinputData['packageDetails']['created_date'];
                $_SESSION['booking_history'][$resultPackageId][$orderId]['booking_date']         = date('Y-m-d H:i:s');

                if ($this->_IinputData['tripType'] != 2){
                    // oneway & roundtrip
                    $_SESSION['booking_history'][$resultPackageId][$orderId]['sector_from']          = $this->_IinputData['flightSearchData']['selectedOnwardFlight']['origin_airport_name'];
                    $_SESSION['booking_history'][$resultPackageId][$orderId]['sector_to']            = $this->_IinputData['flightSearchData']['selectedOnwardFlight']['dest_airport_name'];

                    $_SESSION['booking_history'][$resultPackageId][$orderId]['onward_depature_date'] = $this->_IinputData['flightSearchData']['selectedOnwardFlight']['date_departure'] .' '.$this->_IinputData['flightSearchData']['selectedOnwardFlight']['time_departure'];  
                    $_SESSION['booking_history'][$resultPackageId][$orderId]['onward_arrival_date']  = $this->_IinputData['flightSearchData']['selectedOnwardFlight']['date_departure'] .' '.$this->_IinputData['flightSearchData']['selectedOnwardFlight']['time_arrival'];
                    $_SESSION['booking_history'][$resultPackageId][$orderId]['return_depature_date'] = $this->_IinputData['flightSearchData']['selectedReturnFlight']['date_departure'] .' '.$this->_IinputData['flightSearchData']['selectedReturnFlight']['time_departure'];   
                    $_SESSION['booking_history'][$resultPackageId][$orderId]['return_arrival_date']  = $this->_IinputData['flightSearchData']['selectedReturnFlight']['date_departure'] .' '.$this->_IinputData['flightSearchData']['selectedReturnFlight']['time_arrival'];
                }else{ 
                    //multicity
                    $key = 0;
                    
                    foreach ($this->_IinputData['flightSearchData']['multicity'] as $res){
                        if(count($res) > 0 ){
                            $_SESSION['booking_history'][$resultPackageId][$this->_IinputData['orderId'][$key]]['trip_type']            = $this->_IinputData['tripType'];
                            $_SESSION['booking_history'][$resultPackageId][$this->_IinputData['orderId'][$key]]['travel_mode']          = $this->_IinputData['travel_mode'];
                            $_SESSION['booking_history'][$resultPackageId][$this->_IinputData['orderId'][$key]]['no_of_passenger']      = $this->_IinputData['requestFormData']['masterInfo']['requestTableData']['num_passenger'];
                            $_SESSION['booking_history'][$resultPackageId][$this->_IinputData['orderId'][$key]]['adult']                = $this->_IinputData['requestFormData']['masterInfo']['requestTableData']['adult_count'];
                            $_SESSION['booking_history'][$resultPackageId][$this->_IinputData['orderId'][$key]]['child']                = $this->_IinputData['requestFormData']['masterInfo']['requestTableData']['child_count'];
                            $_SESSION['booking_history'][$resultPackageId][$this->_IinputData['orderId'][$key]]['infant']               = $this->_IinputData['requestFormData']['masterInfo']['requestTableData']['infant_count'];
                            $_SESSION['booking_history'][$resultPackageId][$this->_IinputData['orderId'][$key]]['request_date']         = $this->_IinputData['packageDetails']['created_date'];
                            $_SESSION['booking_history'][$resultPackageId][$this->_IinputData['orderId'][$key]]['booking_date']         = date('Y-m-d H:i:s');
                            
                            $_SESSION['booking_history'][$resultPackageId][$this->_IinputData['orderId'][$key]]['sector_from']          = $res['selected']['origin_airport_name'];
                            $_SESSION['booking_history'][$resultPackageId][$this->_IinputData['orderId'][$key]]['sector_to']            = $res['selected']['dest_airport_name'];

                            $_SESSION['booking_history'][$resultPackageId][$this->_IinputData['orderId'][$key]]['onward_depature_date'] = $res['selected']['date_departure'] .' '.$res['selected']['time_departure'];  
                            $_SESSION['booking_history'][$resultPackageId][$this->_IinputData['orderId'][$key]]['onward_arrival_date']  = $res['selected']['date_departure'] .' '.$res['selected']['time_arrival'];
                            $key ++;
                        }
                    }
                }
            }
        }
        $this->_assigModuleResponseData($responseDataArray);
    }

    /**
     * @Description :This function is used to insert the package details
     * @param :
     * @return integer |$resultPackageId - inserted package id
     */
    private function _packageInsert(){
        $this->_Opackage->_Oconnection = $this->_Oconnection;
        
        if(isset($this->_IinputData['requestFormData']['packageType']) && $this->_IinputData['requestFormData']['packageType'] != ''){
            $this->_IinputData['packageDetails']['package_type'] = $this->_IinputData['requestFormData']['packageType'];
        }else{        
            if ($this->_IinputData['tripType'] == 2){
                    $this->_IinputData['packageDetails']['package_type'] = 1;
                }
            }
        $this->_IinputData['packageDetails']['created_date'] = date('Y-m-d H:i:s');

        //Check whether the requested by email exists or not in input data,if exists get the employee id else assign session employee id 
        if (isset($this->_IinputData['packageDetails']['requested_by']) && $this->_IinputData['packageDetails']['requested_by'] != ''){
            $employeeId = $this->_Oemployee->_checkAccountExist($this->_IinputData['packageDetails']['requested_by'], 'employee_id');

            if (count($employeeId) > 0 || !$employeeId){
                $this->_IinputData['packageDetails']['requested_by'] = $this->_IinputData['packageDetails']['requested_by'];
                $this->_IinputData['packageDetails']['r_fact_employee_id'] = $employeeId[0];
            }else{
                $this->_IinputData['packageDetails']['requested_by'] = $_SESSION['employeeEmailId'];
                $this->_IinputData['packageDetails']['r_fact_employee_id'] = $_SESSION['factEmployeeId'];
            }
        }else{
            $this->_IinputData['packageDetails']['requested_by'] = $_SESSION['employeeEmailId'];
            $this->_IinputData['packageDetails']['r_fact_employee_id'] = $_SESSION['factEmployeeId'];
        }
        //Calling function to insert package details
        $resultPackageId = $this->_Opackage->_insertPackage($this->_IinputData['packageDetails']);

        return $resultPackageId;
    }

    /**
     * @Description :This function is used to insert the order details
     * @param :
     * @return integer |$orderId - inserted order id
     */
    private function _orderInsert(){
        //Check whether the currency name exists or not in input data,if exists get the currency id else assign 0 
        if (isset($this->_IinputData['currency_name']) && $this->_IinputData['currency_name'] != ''){
            //Calling function to get currency id for the input currency
            $currencyId = $this->_Olocation->_getCurrencyType($this->_IinputData['currency_name'], 'currency_id');

            if (count($currencyId) > 0 || !$currencyId){
                $this->_IinputData['orderDetails']['r_currency_type_id'] = $currencyId[0]['currency_id'];
            }else{
                $this->_IinputData['orderDetails']['r_currency_type_id'] = 0;
            }
        }elseif(!isset($this->_IinputData['orderDetails']['r_currency_type_id'])){
            $this->_IinputData['orderDetails']['r_currency_type_id'] = 0;
        }
        //Check whether the travel mode exists or not in input data,if exists get the travel mode id else assign 0 
        if (isset($this->_IinputData['travel_mode']) && $this->_IinputData['travel_mode'] != '') {
            //Calling function to get travel mode id for the input travel mode
            $travelModeId = $this->_OapplicationSettings->_getTravelMode(array('travel_mode_id'), 'travel_mode_code', $this->_IinputData['travel_mode']);

            if (count($travelModeId) > 0 || !$travelModeId){
                $this->_IinputData['orderDetails']['r_travel_mode_id'] = $travelModeId[0]['travel_mode_id'];
            }else{
                $this->_IinputData['orderDetails']['r_travel_mode_id'] = 0;
            }
        }elseif(!isset($this->_IinputData['orderDetails']['r_travel_mode_id'])) {
            $this->_IinputData['orderDetails']['r_travel_mode_id'] = 0;
        }
        $this->_IinputData['orderDetails']['r_ticket_status_id'] = REQUESTED;
        $this->_IinputData['orderDetails']['r_payment_status_id'] = PAYMENT_NOT_DONE;
        $this->_IinputData['orderDetails']['created_date'] = date('Y-m-d h:m:s');
        //Calling function to insert order details
        $orderId = $this->_Opackage->_insertOrderDetails($this->_IinputData['orderDetails']);
        
        return $orderId;
    }

    /**
     * @Description :This function is used to insert the fact booking details
     * @param :
     * @return integer |$factBookingId - inserted fact booking id
     */
    private function _factBookingInfoInsert(){
        $this->_IinputData['factBookingDetails']['r_employee_id'] = $_SESSION['employeeId'];
        $this->_IinputData['factBookingDetails']['r_corporate_id'] = $_SESSION['corporateId'];
        //Calling function to insert fact booking details
        $factBookingId = $this->_Opackage->_insertFactBookingDetails($this->_IinputData['factBookingDetails']);

        return $factBookingId;
    }

    /**
     * @Description :This function is used to insert the passenger details
     * @param :
     * @return integer |$factBookingId - inserted fact booking id
     */
    private function _passengerInsert(){
        $paxCount = count($this->_IinputData['passengerDetails']);
        for ($num = 0; $num < $paxCount; $num++){
            $this->_IinputData['passengerDetails'][$num]['r_order_id'] = $this->_IinputData['factBookingDetails']['r_order_id'];
            $employeeCode = $this->_IinputData['passengerDetails'][$num]['employee_code'];
            $pos = strpos($employeeCode, '-');
            if ($pos > 0){
                $this->_IinputData['passengerDetails'][$num]['employee_code'] = substr($employeeCode, 0, $pos);
            }else{
                $passengerData = $this->_getGuestDetails($this->_IinputData['passengerDetails'][$num]['r_order_id']);
                $this->_IinputData['passengerDetails'][$num]['designation'] = $passengerData['designation'];
                $this->_IinputData['passengerDetails'][$num]['department'] = $passengerData['department'];
                $this->_IinputData['passengerDetails'][$num]['branch'] = $passengerData['branch'];
                $this->_IinputData['passengerDetails'][$num]['guest_phone_number'] = $this->_IinputData['passengerDetails']['mobile_no'];
                $this->_IinputData['passengerDetails'][$num]['guest_email_id'] = $this->_IinputData['passengerDetails']['email_id'];
            }
            //Calling function to insert fact booking details
            $passengerId = $this->_Opassenger->_insertPassengerMainDetails($this->_IinputData['passengerDetails'][$num]);

            if ($passengerId > 0 || !$passengerId){
                $this->_IinputData['passengerOtherDetails'][$num]['r_passenger_id'] = $passengerId;
                $passengerOtherId = $this->_Opassenger->_insertPassengerOtherDetails($this->_IinputData['passengerOtherDetails'][$num]);
            }
        }
        return true;
    }

    /**
     * @Description :This function is used to get guest details
     * @param : integer | $orderId - order id 
     * @return array |$returnValue - Booked employee designation,department,branch details
     */
    private function _getGuestDetails($orderId){
        $sqlEmployee = "SELECT ed.designation,ed.department,ed.branch 
                        FROM employee_details ed,fact_booking_details fbd
                        WHERE fbd.order_id=$orderId AND fbd.r_employee_id=ed.employee_id";

        $result = $this->_Oconnection->query($sqlEmployee);
        if (!$result){
            $returnValue = false;
        }else{
            $returnValue = array();
            if ($result->rowCount() > 0){
                while ($row = $result->fetch(PDO::FETCH_ASSOC)){
                    $returnValue = $row;
                }
            }else{
                $returnValue = false;
            }
        }
        return $returnValue;
    }

    public function _assigModuleResponseData($dataArray){
        $this->_AModuleResponseData = $dataArray;
    }

}

?>
