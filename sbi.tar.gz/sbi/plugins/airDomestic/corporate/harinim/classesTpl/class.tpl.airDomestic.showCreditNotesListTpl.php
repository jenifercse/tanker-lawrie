<?php
/** **************************************************************************
 * @File             : class.tpl.showCreditNotesListTpl.php
 * @Author           : Sivaprakash.M
 * @Created Date     : 10/01/2017
 * @Modified Date    : 
 * ****************************************************************************/
class showCreditNotesListTpl{
    
    public function __construct(){
        $this->_objListDisplay = new listDisplay();
    }
    
    /**
     * @functionName    :   _getDisplayInfo()
     * @description     :   common module function
     */
    public function _getDisplayInfo(){
        $_SESSION['order_id'] = $this->_IinputData['orderId'] ? $this->_IinputData['orderId'] : 0 ;
        
        $this->_CcreditNoteList = $this->_objListDisplay->_getCreditNoteListDetails('CREDITNOTE', $this->_IinputData);
        $this->_CcreditNoteList ? $this->_CcreditNoteList[0]['listBookingReferences'] = $this->_objListDisplay->_referenceValueOfCorporate : '';
                    
        $this->_templateAssign();
    }
    
    public function _templateAssign(){
        $this->_AtwigOutputArray['creditBookingListInfo'] = $this->_CcreditNoteList;
    }
}
?>
