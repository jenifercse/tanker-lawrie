<?php
/** * **************************************************************************
 * @File            cancellationQueryBoxTpl 
 * @Description     This class file holds all employee related informations
 * @Author          Selvakumar
 * @Created Date    19/08/2016
 * *************************************************************************** */
class cancellationQueryBoxTpl{
    
    public function __construct(){
        $this->_AapplicationError = array();
    }
    
    /**
     * @Description  this function handles the filter elements in template
     * @param 
     * @return 
     */
    public function _getDisplayInfo(){
        $this->_OAgency->_SmoduleAction = $this->_SmoduleAction;
        $this->_OAgency->_IinputData    = $this->_IinputData;
        $this->_getCancelDisplayFilter();
        $this->_templateAssign();
    }
    
    /**
     * @Description  function list all filter
     * @param 
     * @return 
     */
    private function _getCancelDisplayFilter(){
        $filter = (explode(',', FILTER));
        $this->_AtwigOutputArray['filter1Array']  = array_combine($filter,$filter);
        $this->_AtwigOutputArray['querybox'] = array('1'=>'Show By Period','2'=>'Show By Date Range','3'=>'Show By PNR');
    }
    
    private function _templateAssign(){
        $this->_AtwigOutputArray['action']     = $this->_action;
        $this->_AtwigOutputArray['moduleName'] = $this->_SmoduleName;
    }
}
?>