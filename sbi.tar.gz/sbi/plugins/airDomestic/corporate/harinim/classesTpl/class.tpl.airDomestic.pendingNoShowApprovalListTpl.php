<?php
/** * **************************************************************************
 * @File             : class.tpl.pendingNoShowApprovalListTpl.php
 * @Author           : Rajesh U
 * @Created Date     : 12/03/2019
 * @Modified Date    : 
 * ****************************************************************************/
class pendingNoShowApprovalListTpl{
    
    public function __construct(){
        $this->_objListDisplay = common::_checkClassExistsInNameSpace('listDisplay');
        $this->_Oreport = new report();
        $this->_ODBC = new commonDBO();
        $this->_OcommonQuery = new commonQuery();
        $this->_ONoShow = new noShowApproval();
    }
    
    /**
     * @functionName    :   _getDisplayInfo()
     * @description     :   common module function
     */
    public function _getDisplayInfo(){

        $this->_AtwigOutputArray['userTypeId'] = $_SESSION['userTypeId'];
        $_SESSION['order_id'] = $this->_IinputData['orderId'] ? $this->_IinputData['orderId'] : 0 ;

        if((isset($this->_IinputData['recordLimit']) || !isset($this->_IinputData['recordLimit'])) && $this->_IinputData['fileDownload'] != 'Y'){
            $this->_IinputData['recordLimit'] = $this->_Oreport->_recordLimit($this->_IinputData['recordLimit']);
        }
        $this->_IinputData['process_type'] = NO_SHOW_APPROVER;
        $this->_IinputData['r_employee_id'] = $_SESSION['employeeId'];
        $viewRequestData = $this->_ONoShow->_getNoShowApprovalList('PENDINGNOSHOWAPPROVALBOOKINGS', $this->_IinputData);
       // $viewRequestData ? $viewRequestData['listBookingReferences'] = $this->_objListDisplay->_referenceValueOfCorporate : '';
        $this->_AserviceResponse['viewRequestList'] = commonArrayFunctions::_formatSameArrayValueInArrayKey($viewRequestData);
        $this->_AserviceResponse['recordLimit'] = $this->_IinputData['recordLimit'];
        $this->_AserviceResponse['total'] = $this->_AtwigOutputArray['total'] = ($viewRequestData != '') ? sizeof($viewRequestData) : 0;
        
        //File download by checking the flag
        if ($this->_IinputData['fileDownload'] == 'Y') {
           $this->_AserviceResponse['fileDownload'] =  $this->_objListDisplay->_fileDownload($action, $this->_AserviceResponse['viewRequestList'],'PENDINGNOSHOWAPPROVALBOOKINGS', $this->_IinputData['fileTypeId']);
        }
        //set the passenger details
        $this->_AserviceResponse['viewRequestList'] = $this->_objListDisplay->_getPassengerInfo($this->_AserviceResponse['viewRequestList']);

        $this->_AserviceResponse['viewRequestList'] = $this->_objListDisplay->_getFlightDetailsInfo($this->_AserviceResponse['viewRequestList']);
        
        $this->_AserviceResponse['airlineCode'] = $this->_ODBC->_select('dm_airline','*', 'status','Y','','airline_name');

        // set BookingReferencePrefixString
        $this->_AtwigOutputArray["BookingReferencePrefixString"]= $this->_OcommonQuery->_getBookingReferencePrefixSting($_SESSION['corporateId']);
        $this->_AtwigOutputArray['fieldList'] = $_SESSION['permissions']['fieldList'];
        
    }
    public function _getPendingCombinedQueryResult($pendingApproval,$postApproval){
        return $this->_objListDisplay->_getCombinedQueryResult($pendingApproval, $postApproval);
    }
}
?>
