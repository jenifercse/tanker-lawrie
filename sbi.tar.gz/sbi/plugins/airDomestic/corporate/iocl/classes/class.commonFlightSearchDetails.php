<?php
/** * **************************************************************************
 * @File             : class.commonFlightSearchDetails.php
 * @Description      : This file is used to insert fact trip order details
 * @Tables Affected  : fact_trip_order_details
 * @Author           : Muruganandham
 * @Created Date     : 28/03/2019
 * @Modified Date    :
 * ****************************************************************************/

namespace iocl;

pluginFileRequireByTravelMode('classes/class.commonFlightSearchDetails.php', true);

class commonFlightSearchDetails extends \commonFlightSearchDetails
{
    public function __construct(){
        parent::__construct();
    }
    
     /* 
     * @Function Name             : _insertTripDetails
     * @Description               : This function used to insert Trip Details in GDS Booking flow.  
     * @Tables                    : 
     * @Author                    : Muruganandham.M
     * @Created Date              : 28/03/2019
     * @Modified Date             : 
    */   
    public function _insertTripDetails($tripDetails){

     $tripId = $this->_OtripCreation->_insertTripDetails($tripDetails)['tripId'];
     return $tripId;
    }
}
?>
