<?php
/** * **************************************************************************
 * @File             : class.commonFlightSearchRequestInsert.php
 * @Description      : This file is used to insert primary booking request details
 * @Tables Affected  : package_details,order_details,passenger_details,fact_booking_details
 * @Author           : Baskar.V.P
 * @Created Date     : 01/07/2016
 * @Modified Date    :
 * ****************************************************************************/
namespace iocl;

pluginFileRequireByTravelMode('classes/class.commonFlightSearchRequestInsert.php', true);

class commonFlightSearchRequestInsert extends \commonFlightSearchRequestInsert{
    
    public function __construct(){
        parent::__construct();
    }
    
    //function used to insert the trip order details.
    public function _factTripOrderInsert($orderId){

        //set trip status
        $tripStatusInfo = array(TRIP_APPROVED,TRIP_APPROVED_BOOKINGS_NOT_APPROVED);

        //set inputs
        $input['r_trip_request_details_id'] = $this->_IinputData['tripFormDetails']['tripId'];
        $input['r_package_id'] = $this->_packageId;
        $input['r_order_id'] = $orderId;
        $input['created_date'] = date('Y-m-d H:i:s');

        //get approval type
        $tripInfo = $this->_OcommonDBO->_select('trip_request_details','*','trip_request_details_id',$this->_IinputData['tripFormDetails']['tripId'])[0];

        // set ticket approval flow changes
        if($this->_IinputData['masterInfo']['advancedsearch']['orderPostApproval'] == 'Y' || $tripInfo['trip_flow_type'] == 'G'){
            $input['ticket_approval_flow_changes'] = 'Y';
        }

        //insertion
        return $this->_OcommonDBO->_insert('fact_trip_order_details',$input);
    }

    //function used to update the trip order details.
    public function _factTripOrderUpdate($orderId){

        //set trip status
        $tripStatusInfo = array(TRIP_APPROVED,TRIP_APPROVED_BOOKINGS_NOT_APPROVED);

        //get approval type
        $tripInfo = $this->_OcommonDBO->_select('trip_request_details','*','trip_request_details_id',$this->_IinputData['tripFormDetails']['tripId'])[0];

        $input['ticket_approval_flow_changes'] = 'N';

        // set ticket approval flow changes
        if($this->_IinputData['masterInfo']['advancedsearch']['orderPostApproval'] == 'Y' || $tripInfo['trip_flow_type'] == 'G'){
            $input['ticket_approval_flow_changes'] = 'Y';
        }

        //update fact_trip_order_details
        $this->_OcommonDBO->_update('fact_trip_order_details',$input,'r_trip_request_details_id',$this->_IinputData['tripFormDetails']['tripId']);

        //update the work flow caption in order details at the time of modify.
        $this->_OcommonQuery->_updateWorkFlowForOrder(array($orderId),'B',$this->_IinputData['masterInfo']['r_travel_mode_id']);
    }
    
     /**
    * @Description :function used to assign the service response.
    * @date : 14-02-2018 
    * @author Karthika.M
    */
    public function _getServiceResponseOptionalApprover($input){
        
        //set inputs
        $responseArray = $this->_getGuestApproverInfo($input);

        return $responseArray['guestApproverInfo'];
            
    }

    //function used to get guest approval info in admin flow
    public function _getGuestApproverInfo($input){       
        
        //get the approval tracking info.
        $approvalTrackingInfo = $this->_getGuestApprovalTrackingInfo($input);        
        
        //set the service response value.
        $responseArray['guestApproverInfo'] = $approvalTrackingInfo;       
        return $responseArray;
    }

     public function _getGuestApprovalTrackingInfo($input,$processType = 'Booking'){  

        //get intimation approval
        $intimationApproval['agencyId']     = $_SESSION['agencyId'];
        $intimationApproval['corporateId']  = $_SESSION['corporateId'];
        $intimationApproval['employeeId']   = $this->_getEmployeeId($input['order_id']);
        $intimationApproval['travelModeId'] = 1;
        $intimationApproval['order_id']     = $input['order_id']; 
        $intimationApproval['processType']  = 'Booking';

        $getIntimationApproval = $this->_OsetApprovalProcess->_getApprovalInfo($intimationApproval,'IA');

        $intimationApprovalInfo = $this->_OsetApprovalProcess->_approvalTrackingInfo;

        $intimation = array_column($intimationApprovalInfo,'approval_type');

        $unsetNormalInfo = array_combine(array_column($intimationApprovalInfo,'approval_type'), array_keys($intimation));

        unset($intimationApprovalInfo[$unsetNormalInfo['NA']]);


        //set the trip type.      
        if(isset($input['tripType'])){
            $input['tripType'] != 2 ? $input['orderId'][0] = $input['order_id'] : $input['orderId'];   
        }     
        //form the optional approver info.
        return $approvalTrackingInfo = $this->_guestApprovalTrackingInfoFormation($input['orderId'],$processType,$input,$intimationApprovalInfo);
    }

    public function _guestApprovalTrackingInfoFormation($orderIdInfo,$processType,$input,$intimationApprovalInfo){

        //looping the order_id info
        foreach ($orderIdInfo as $key => $orderId){
            //looping the approver info
                // $approvalTrackingInfo[$orderId][$key]['approver_id']  = $this->_OcommonDBO->_select('dm_employee','employee_id','employee_code',$input['guestApproval'])[0]['employee_id'];
                // $approvalTrackingInfo[$orderId][$key]['approval_level']  = 1 ;
                // $approvalTrackingInfo[$orderId][$key]['approval_order']  = 1 ;
                // $approvalTrackingInfo[$orderId][$key]['approval_type']  = 'NA';
                // $approvalTrackingInfo[$orderId][$key]['next_level_status']  = 'N';
                // $approvalTrackingInfo[$orderId][$key]['r_order_id']  = $orderId;
                // $approvalTrackingInfo[$orderId][$key]['process_type']  = $processType;
                // $approvalTrackingInfo[$orderId][$key]['created_date'] = date('Y-m-d H:i:s');
                $intimationIndex = array_keys($intimationApprovalInfo); 
                $approvalTrackingInfo[$orderId][0] = $intimationApprovalInfo[$intimationIndex[0]];
                $approvalTrackingInfo[$orderId][0]['r_order_id'] = $orderId;

        }

        //get approval id
        $tripApprovalId = $this->_OcommonDBO->_select('dm_employee','employee_id','employee_code',$input['guestApproval'])[0]['employee_id'];
        $tripapprovalInfo = $this->_OcommonDBO->_select('approval_tracking','*',array('reference_id','reference_type'),array($input['tripFormDetails']['tripId'],'TRIP_APPROVAL'));
    
        if(!in_array('NA', array_column($tripapprovalInfo,'approval_type'))){
            $this->_insertGuestApproval($tripApprovalId,$input);
        }
        else{
            //update trip approval account id 
            $this->_updateTripApprovalId($tripApprovalId,$input);
        }
        
        return $approvalTrackingInfo;
    }


    public function _insertGuestApproval($tripApprovalId,$input){

        $approvalTrackingInfo['approver_id']  = $tripApprovalId;
        $approvalTrackingInfo['approval_level']  = 1 ;
        $approvalTrackingInfo['approval_order']  = 1 ;
        $approvalTrackingInfo['r_order_id']  = 0 ;
        $approvalTrackingInfo['approval_type']  = 'NA';
        $approvalTrackingInfo['next_level_status']  = 'N';
        $approvalTrackingInfo['r_approval_settings_id']  = 0;
        $approvalTrackingInfo['reference_id']  = $input['tripFormDetails']['tripId'];
        $approvalTrackingInfo['reference_type']  = 'TRIP_APPROVAL';
        $approvalTrackingInfo['process_type']  = 'Booking';
        $approvalTrackingInfo['created_date'] = date('Y-m-d H:i:s');

        $updateApprovalLevel['approval_level'] = 1;

        $this->_OcommonDBO->_update('trip_request_details',$updateApprovalLevel,'trip_request_details_id',$input['tripFormDetails']['tripId']);

        return $this->_OcommonDBO->_insert('approval_tracking',$approvalTrackingInfo);


    }

    public function _updateTripApprovalId($tripApprovalId,$input){

        $sql = "UPDATE
                    approval_tracking
                SET
                    approver_id = ".$tripApprovalId ."
                WHERE
                    reference_type = 'TRIP_APPROVAL' AND approval_type = 'NA' AND reference_id = " .$input['tripFormDetails']['tripId'];

        return $this->_OcommonDBO->_getResult($sql);
    }

    public function _getEmployeeId($orderId){

        $sql = "SELECT 
                    dme.employee_id
                FROM 
                    fact_trip_order_details ftod
                INNER JOIN trip_request_details trd ON ftod.r_trip_request_details_id = trd.trip_request_details_id
                INNER JOIN dm_employee dme ON trd.r_employee_id = dme.employee_id
                WHERE
                    ftod.r_order_id = " .$orderId;

        return $this->_OcommonDBO->_getResult($sql)[0]['employee_id'];

    }

     /**
     * @Description :This function is used to insert the fact booking details
     * @param :
     * @return integer |$factBookingId - inserted fact booking id
     */
    public function _factBookingInfoInsert(){

        $employeeId = $this->_IinputData['passenger']['ADT'][0]['r_employee_id']!=''?$this->_IinputData['passenger']['ADT'][0]['r_employee_id']:$_SESSION['employeeId'];
        if($this->_IinputData['tripFormDetails']['tripFlowType'] == 'G' && $_SESSION['userTypeId'] == 2){
            $employeeId = $this->_IinputData['tripFormDetails']['employee'][0]['employee_id'];

        }
        $this->_IinputData['factBookingDetails']['travel_mode'] =  $this->_IinputData['orderDetails']['r_travel_mode_id'];
        $this->_IinputData['factBookingDetails']['r_employee_id'] = $employeeId;
        $this->_IinputData['factBookingDetails']['r_corporate_id'] = $_SESSION['corporateId'];
        $this->_IinputData['factBookingDetails']['r_agency_id'] = $_SESSION['agencyId'];
        //Calling function to insert fact booking details
        $factBookingId = $this->_Opackage->_insertFactBookingDetails($this->_IinputData['factBookingDetails']);
        $this->_IinputData['AirtripType']=$this->_IinputData['masterInfo']['requestTableData']['trip_type'];
       
        return $factBookingId;
    }
    /**
     * check duplicate bookings
     * @return boolean
     */
    public function _checkDuplicateBooking(){
            $insertingDataFullArray = $this->_IinputData;
            $paxEmployee = array_column($insertingDataFullArray['passenger']['ADT'], 'r_employee_id');
            $ticketReturnDate = $insertingDataFullArray['masterInfo']['requestTableData']['return_date'];
            $airRequestDetails = $insertingDataFullArray['airRequestDetails'];
            foreach ($airRequestDetails as $key => $value) {
                foreach ($paxEmployee as $paxkey => $paxvalue) {
                    if($paxvalue != 0){
                        $sql = "select ard.r_origin_airport_id,ard.r_destination_airport_id,ard.onward_date,ard.return_date,vfd.trip_type,pvd.r_booking_status_id from air_request_details ard 
                            INNER JOIN fact_booking_details fbd  on ard.air_request_id=fbd.r_request_id 
                            INNER JOIN passenger_details pd ON pd.r_order_id = fbd.r_order_id
                            INNER JOIN passenger_via_details pvd ON pvd.r_order_id = fbd.r_order_id
                            INNER JOIN via_flight_details vfd ON pvd.r_via_flight_id = vfd.via_flight_id
                            INNER JOIN order_details od ON od.order_id = fbd.r_order_id
                            INNER JOIN fact_trip_order_details ftod ON od.order_id = ftod.r_order_id
                            INNER JOIN trip_request_details trd ON ftod.r_trip_request_details_id = trd.trip_request_details_id 
                            INNER JOIN fact_air_itinerary fat ON fat.r_via_flight_id = pvd.r_via_flight_id  
                            INNER JOIN employee_details ed ON ed.r_employee_id = pd.r_employee_id
                            INNER JOIN dm_band dmb ON dmb.band_id = ed.r_band_id
                            where ( ard.onward_date ='". $value['requestTableData']['onward_date'] ."' OR ard.return_date ='".$ticketReturnDate."' OR ard.return_date ='".$value['requestTableData']['onward_date'] ."' OR ard.onward_date ='". $ticketReturnDate."') and
                            pd.r_employee_id IN (". implode(',', $paxEmployee). ") 
                            AND r_payment_status_id IN(".PAYMENT_NOT_DONE.",".PAYMENT_DONE.") AND r_ticket_status_id IN (".PAID.",".SEND_FOR_APPROVAL.",".APPROVED.",".TICKETTED.",".WAITING_FOR_TRIP_APPROVAL.",".PARTIALLY_CANCELLED.",".NOT_PAID.") AND band_name NOT IN ('AJ','AK') AND pvd.r_booking_status_id IN (".NOTHING_REQUESTED.") AND trd.r_status_id NOT IN (".TRIP_REQUESTED.") AND fat.itinerary_status NOT IN (".LOW_FARE_ITINERARY.") ";
                            //payme N0T IN (15,16)  and tikcte 2 send to approval 
                        $resultDuplicate = $this->_OcommonDBO->_getResult($sql);
                        $duplicateArrayFormation = $this->_duplicateArrayFormation($resultDuplicate);
                        $checkDuplicateBookingExits[$key] = $this->_checkDuplicateBookingExits($duplicateArrayFormation,$value['requestTableData']['r_origin_airport_id']['cityId'],$value['requestTableData']['r_destination_airport_id']['cityId'],$value['requestTableData']['onward_date'],$ticketReturnDate,$insertingDataFullArray['masterInfo']['requestTableData']['trip_type']);
                        $duplicateExits[$key] = in_array(true, $checkDuplicateBookingExits[$key]) ? true : false;
                        }
                }
            }
            if (in_array(true, $duplicateExits)){
                $this->_AfinalResponse['FLAG'] = "DUPLICATE";
                $this->_AfinalResponse['error_alert'] = "Booking already exist for the same employee in same date .";
            }
            return TRUE;
    }

    public function _duplicateArrayFormation($duplicate){

        foreach ($duplicate as $key => $value) {
            if($value['trip_type'] == 0){
                $onward[$key]['orgin'] = $value['r_origin_airport_id'];
                $onward[$key]['destination'] = $value['r_destination_airport_id'];
                $onward[$key]['date'] = $value['onward_date'];
                $onward[$key]['trip_type'] = $value['trip_type'];
            }
            else{
                $return[$key]['orgin'] = $value['r_destination_airport_id'];
                $return[$key]['destination'] = $value['r_origin_airport_id'];
                $return[$key]['date'] = $value['return_date'];
                $return[$key]['trip_type'] = $value['trip_type'];   
            }
        }
        return array_merge((array)$onward,(array)$return);

    }

    public function _checkDuplicateBookingExits($selectedAirRequest,$orgin,$destination,$onwardDate,$returnDate,$tripType){
        
        foreach ($selectedAirRequest as $key => $value) {
            if($tripType == 0){
                $result[$key] =( $value['orgin'] == $orgin && $value['destination'] == $destination && $value['date'] == $onwardDate) ? true : false ;
            }
            else{
                $result[$key] = (($value['orgin'] == $orgin && $value['destination'] == $destination && $value['date'] == $onwardDate) || ($value['orgin'] == $destination && $value['destination'] == $orgin && $value['date'] == $returnDate)) ? true : false ;
            }
        }      
        return $result;
    }
     /**
     * check duplicate bookings
     * @return boolean
     */
    public function _checkDuplicateBookingItinerary(){
        $insertingDataFullArray = $this->_IinputData;     
        $sql = "select   vfd.time_arrival,vfd.segment_order,vfd.departure_date  from air_request_details ard 
                            INNER JOIN fact_booking_details fbd  on ard.air_request_id=fbd.r_request_id 
                            INNER JOIN passenger_details pd ON pd.r_order_id = fbd.r_order_id
                            INNER JOIN employee_details ed ON ed.r_employee_id = pd.r_employee_id
                            INNER JOIN dm_band dmb ON dmb.band_id = ed.r_band_id
                            INNER JOIN order_details od ON od.order_id = fbd.r_order_id
                            INNER JOIN air_booking_details abd ON od.order_id = abd.r_order_id
                            INNER JOIN fact_air_itinerary fai ON abd.air_booking_details_id = fai.r_air_booking_details_id
                            INNER JOIN dm_package dmp On dmp.package_id = fbd.r_package_id
                            INNER JOIN via_flight_details vfd ON  fai.r_via_flight_id = vfd.via_flight_id
                            where 
                            pd.r_employee_id IN (".$insertingDataFullArray['employeeId']. ")  
                            AND (r_payment_status_id IN(".PAYMENT_NOT_DONE.",".PAYMENT_DONE.") AND r_ticket_status_id IN(".SEND_FOR_APPROVAL.",".TICKETTED.",".PAID.",".APPROVED.",".WAITING_FOR_TRIP_APPROVAL.")) AND fai.itinerary_status =" .SELECTED_ITINERARY." AND vfd.arrival_date ='". $insertingDataFullArray['currDate'] ."' AND  (vfd.time_arrival  BETWEEN '". $insertingDataFullArray['previousTime'] ."'  AND '". $insertingDataFullArray['nextTime'] ."' OR vfd.time_departure  BETWEEN '". $insertingDataFullArray['previousTime'] ."'  AND '". $insertingDataFullArray['nextTime'] ."'  ) AND band_name NOT IN ('AJ','AK') AND dmp.booking_type != '0'  ";
                        //payme N0T IN (15,16)  and tikcte 2 send to approval 
        if($insertingDataFullArray['packageId'] != ''){
            $sql .=" AND fbd.r_package_id != ".$insertingDataFullArray['packageId'];
         }
        $resultDuplicate = $this->_OcommonDBO->_getResult($sql) ? true : false;

        if ($resultDuplicate ==true){
            $this->_AfinalResponse['FLAG'] = "DUPLICATE";
            $this->_AfinalResponse['error_alert'] = "Booking already exist for the same employee in same date .";
        }
        return TRUE;
    }

    // update air request details changes
    public function _updateAirRequestDetails($input){
        // get air request detais based on order id 
        $sql = "SELECT r_request_id FROM fact_booking_details WHERE r_order_id =".$input['orderIdValue'];
        $requestId = $this->_OcommonDBO->_getResult($sql)[0]['r_request_id'];
        //get customized field value
        $sqlSelectAirReDetails = 'SELECT customize_fields FROM air_request_details WHERE air_request_id = '.$requestId;
        $resultAirRequestDetails = json_decode($this->_OcommonDBO->_getResult($sqlSelectAirReDetails)[0]['customize_fields'],1);
        if($input['onwardTimestart'] != ''){
                $resultAirRequestDetails['onwardTimeStart'] = $input['onwardTimestart'];
        }
        if($input['returnTimestart'] != ''){
            $resultAirRequestDetails['returnTimeStart'] =$input['returnTimestart'];
        }
        $updateCustomFieldValue['customize_fields'] = json_encode($resultAirRequestDetails);
        $this->_airRquest->_updateAirRequest($updateCustomFieldValue,$requestId);
    }
}
?>