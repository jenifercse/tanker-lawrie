<?php

/**
 * @File             : class.tpl.pendingApprovalListTpl.php
 * @Author           : sandhiya.c
 * @Created Date     : 28/02/2019
 * @Modified Date    : 
 */
namespace iocl;

pluginFileRequireByTravelMode('classesTpl/class.tpl.airDomestic.pendingApprovalListTpl.php', true);

class pendingApprovalListTpl extends \pendingApprovalListTpl{
	
	public function __construct()
	{
		//access the parent class construct.
        parent::__construct();
	}

	public function _getPendingCombinedQueryResult($pendingApproval,$postApproval){
		return $this->_objListDisplay->_getCombinedQueryResultForMybooking($pendingApproval, $postApproval);
	}

}
?>