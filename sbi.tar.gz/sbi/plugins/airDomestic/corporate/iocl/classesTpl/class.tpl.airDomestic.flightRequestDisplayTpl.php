<?php
/** * **********************************************************************
 * @Class Name  :   class.tpl.flightRequestDisplayTpl.php
 * @Description :   This file is used to set data to display flight request form for iocl
 * @Author      :   sandhiya.c
 * ************************************************************************ */
namespace iocl;

pluginFileRequireByTravelMode('classesTpl/class.tpl.airDomestic.flightRequestDisplayTpl.php', true);

class flightRequestDisplayTpl extends \flightRequestDisplayTpl{

    public function __construct(){
        parent::__construct();
    }
    /**
     *  Method  to get employee under A to C grade details 
     * @return true
     * @author sandhiya.c
     */
	public function _getEmployeeAggregateBandDetails($employee_id){

        $sql="SELECT 
                    sedd.check_box 
                FROM 
                    sap_employee_dependent_details sedd 
                WHERE 
                    sedd.r_employee_id = ".$employee_id;

        $result = $this->_OcommonDBO->_getResult($sql)[0];
        if(isset($result) && $result['check_box'] == 'X'){
            $this->_AtwigOutputArray['gradeDetails'] = 'Y';      
        }
        else{
            $this->_AtwigOutputArray['gradeDetails'] = 'N';      
        }
        return $this->_AtwigOutputArray['gradeDetails'];

    }
    /**
     *  Method  to set grade details flag in employee details array
     * @return true
     * @author sandhiya.c
     */
    public function _getEmployeeGradeDetails($employeeData,$employeeId=''){
        
        if (is_array($employeeData)){
            foreach ($employeeData as $key => $value){
                $employeeData[$key]['gradeDetails'] = $this->_getEmployeeAggregateBandDetails($value['employee_id']);
            }
        }
        if($employeeId){
            return $this->_getEmployeeAggregateBandDetails($employeeId);
        }
        if(!isset($this->_AserviceResponse['tripFormDetails'])){
            $this->_AserviceResponse['tripFormFlag'] = 'N';
        }
        return $employeeData;
    }
    /**
     *  Method  to get trip details while modifying the request
     * @return true
     * @author sandhiya.c
     */
    public function _getTripFormDetails(){
        $sql = "SELECT 
                    trd.trip_request_details_id as 'tripId', DATE_FORMAT(trd.start_date,'%d-%b-%Y') as 'startDate',DATE_FORMAT(trd.end_date,'%d-%b-%Y') as 'endDate',trd.start_time as 'startTime',trip_flow_type,tour_type
                FROM 
                    trip_request_details trd 
                INNER JOIN 
                    fact_trip_order_details ftrd ON ftrd.r_trip_request_details_id = trd.trip_request_details_id 
                WHERE 
                    ftrd.r_order_id = ".$this->_IinputData['orderId']; 
        $result = $this->_OcommonDBO->_getResult($sql)[0];
        $this->_AserviceResponse['tripFormDetails'] = $result;
        if($this->_AserviceResponse['tripFormDetails']){
            $this->_AserviceResponse['tripFormFlag'] = 'Y';
        }
        return $result;
    }

    /* 
    * @Function Name             : _getTicketApprovalDetails
    * @Description               : this function used to get ticket approval status
    * @Tables                    : --
    * @Author                    : Muruganandham M
    * @Created Date              : 30/03/2019
    */    
    public function _getTicketApprovalDetails($empId){

        $ticketApprovalStatus = $this->_OtripCreation->_checkTripCreationStatus($empId)[0];
        return $ticketApprovalStatus;
    }

    /**
     *  Method  to get permission level and cost center code data from table
     * @return true
     * @author Muruganandham M
     */
    public function _getPermissionDetails($input,$corporateId){
         if($this->_IinputData['tripFlowType'] == 'F' || $this->_AserviceResponse['tripFormDetails']['tripFlowType'] == 'F'){
            $input['r_employee_id'] = $_SESSION['employeeId'];
            $employeeData = $this->_Oemployee->_getEmployeeWithPermissionLevel($input,'N');
            $employeeDataCostCenter = $this->_Oemployee->_getCostcenterCodeDetails($corporateId);
                if (is_array($employeeData)){
                    foreach ($employeeData as $key => $value){
                        if (is_array($employeeDataCostCenter)){
                            foreach ($employeeDataCostCenter as $keyInside => $valueInside){
                                if ($value['parent'] == $valueInside['cost_center_code_id']){
                                    $employeeData[$key]['parent'] = $valueInside['cost_center_code'];
                                }
                            }
                        }
                    }
                }
            $employeeData = $this->_getEmployeeGradeDetails($employeeData);    
            // Get employee family details
            $familyDetails = $this->_getEmployeeFamilyDetails($employeeData);
            $employeeData[0]['passenger_type'] = 'ADT'; 
            if(!empty($familyDetails['familyDetails'])){
                 $employeeData = $familyDetails['employeeFlag'] == 'Y' ? array_merge($employeeData,$familyDetails['familyDetails']) : $familyDetails['familyDetails'];        
            }else{
                $employeeData = $familyDetails['employeeFlag'] == 'Y' ? $employeeData : '';        
            }
            $this->_AserviceResponse['adultCheckFlag'] = 'N';
            foreach ($employeeData as $key => $value) {
                    if($value['passenger_type'] == 'ADT'){
                        $this->_AserviceResponse['adultCheckFlag'] = 'Y';
                    }
            }
        }else{
            $flowcall = $input['r_employee_id'] ? 'N' : 'Y';
            if($this->_IinputData['action']  != 'EDIT'){
            $employeeData = $this->_Oemployee->_getEmployeeWithPermissionLevel($input,$flowcall);
                $employeeDataCostCenter = $this->_Oemployee->_getCostcenterCodeDetails($corporateId);
                if (is_array($employeeData)){
                    foreach ($employeeData as $key => $value){
                        if (is_array($employeeDataCostCenter)){
                            foreach ($employeeDataCostCenter as $keyInside => $valueInside){
                                if ($value['parent'] == $valueInside['cost_center_code_id']){
                                    $employeeData[$key]['parent'] = $valueInside['cost_center_code'];
                                }
                            }
                        }
                    }
                }
                $employeeData = $this->_getEmployeeGradeDetails($employeeData);
            }
        }
        //function call to get employee details with grade details       
        $this->_AserviceResponse['employee'] = $employeeData;
        return true;
    }
}
?>
