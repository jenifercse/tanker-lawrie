<?php


/**
* 
*/
class allService 
{
	
	function __construct()
	{

	}


	function getuserdetail($query){

		return "working fine";

	}
}