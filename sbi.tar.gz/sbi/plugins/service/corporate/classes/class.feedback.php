<?php
/**
 * Flight search result
 * @autor Ranjith Kumar C
 * @created on 08 Apr,2019 
 */

fileRequire('plugins/service/corporate/interface/iSearch.php');
class feedback extends serviceTemplate implements iConfig, iSearch 
{
	public function _invokeMember() {
		$feedbackId = $this->_saveFeedback();
		$this->_assignResponse($feedbackId);

	}

    /*@desc function saves feedback from the mobile 
    * @param 
    * @return - the feedbackId
    */
    public function _saveFeedback()
    {
    	$this->_OcommonDBO = self::getObject('commonDBO');
    	$feedbackId = $this->_OcommonDBO->_insert('mobile_feedback',$this->_InputData);
    	return $feedbackId;
    }
    public function _assignResponse($feedbackId)
    {
    	if($feedbackId != 0 && $feedbackId != '')
    	{
    		$this->_Oresponse['feedabackId'] = $feedbackId;
    		$this->_Oresponse['message'] = 'Feedback submitted';
    		$this->_Astatus = true;
    	}
    	else
    	{
    		$this->_Oresponse['message'] = 'Feedback not submitted';
    		$this->_Astatus = false;
    	}
    }
}