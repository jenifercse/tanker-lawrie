<?php
/* * **********************************************************************
 * @Class Name      :   class.cancellation.php
 * @Description     :   This file is used for cancel a booking
 * @Author          :   Ranjith Kumar
 * @Created Date    :   20-03-2019
 * ************************************************************************ */
fileRequire('plugins/airDomestic/corporate/harinim/classes/class.cancellationInsert.php');  
class mobileCancellation extends serviceTemplate implements iConfig 
{
    public function _invokeMember() 
    {
        $this->_OcancellationInsert = new cancellationInsert();
        $response = $this->_checkCancellationFee();
        fileWrite("fee-->".print_r($response,1),"mobileCancellation","a+");
        if($response['status'] == 1)
        {
            $this->_Oresponse = $this->_raiseCancelRequest();
        }
        else
        {
            $this->_Oresponse = $response;
        }
    }
    /**
     * @functionName    :   _checkCancellationFee()
     * @description     :   used to get the cancellation fee
     * @param           :   -
     * @return          :   array | cancellation fee and response
     */

    public function _checkCancellationFee()
    {
        $requestData['action'] = 'getServiceCancellationCharges';
        $requestData['orderid'] = $this->_InputData['orderid'];
        $requestData['cancelledNumberOfPax'] = $this->_InputData['cancelledNumberofPax'];
        $requestData['cancelInfo'] = array(
                                            'orderid' => $this->_InputData['orderid'],
                                            'onwardflight' => $this->_InputData['onwardflight'],
                                            'returnflight' => $this->_InputData['returnflight'],
                                            'triptype' => $this->_InputData['triptype']);
        $this->_OcancellationInsert->_IinputData = $requestData;
        return $this->_OcancellationInsert->_getDisplayInfo();
    }
    /**
     * @functionName    :   _raiseCancelRequest()
     * @description     :   used to raise the cancellation request
     * @param           :   -
     * @return          :   array | response after cancellation of order
     */

    public function _raiseCancelRequest()
    {
        unset($requestData);
        $requestData['orderid'] = $this->_InputData['orderid'];
        $requestData['onwardflight'] = $this->_InputData['onwardflight'];
        $requestData['returnflight'] = $this->_InputData['returnflight'];
        $requestData['triptype'] = $this->_InputData['triptype'];
        $requestData['cancelReason'] = $this->_InputData['cancelReason'];
            // $requestData['cancellation_service_charge'] = '3000';
        $this->_OcancellationInsert->_SagentEmailId = $this->_InputData['loginMailId'];
        $requestData['tplClassFile'] = 'airDomestic.cancellationInsertTpl';
        $requestData['moduleName'] = 'cancellationInsert';
        $this->_OcancellationInsert->_IinputData = $requestData;
        return $this->_OcancellationInsert->_getDisplayInfo();
    }
}