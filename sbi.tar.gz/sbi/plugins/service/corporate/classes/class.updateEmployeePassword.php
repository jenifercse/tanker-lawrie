<?php

/* * **********************************************************************
 * @Class Name	: class.updateEmployeePassword.php
 * @Created on	: 23-07-2018 
 * @Created By	: Deepak Pande
 * @Description	: update password 
 * ************************************************************************ */
class updateEmployeePassword extends serviceTemplate implements iConfig 
{
	
	public $_Aresponse;
	public $_Sstatus;

	function __construct(){

		//object creation
		$this->_OcommonDBO = new commonDBO();

	}

	/**
     * @function : _getServiceResponse
     * @author : Deepak Pande
     * @created date : 2018-07-19
     * @description : 
     */

	public function _invokeMember(){
        //get account id 
		 $this->_getAccountId();
		//calling update user password function
		$this->_updateUserPassword();
	}

    /**
     * @function : _updateUserPassword
     * @author : Puroskhan.M
     * @created date : 2018-09-10
     * @description : function update the user password
     */
	public function _getAccountId()
    {
    	if($this->_InputData['loginEmail'] !='' && isset($this->_InputData)) {
    		$email_id=trim($this->_InputData['loginEmail']);
    		$sql="SELECT fe.r_account_id
                   FROM   dm_employee de
                   INNER JOIN fact_employee fe
                   ON de.employee_id = fe.r_employee_id
                   WHERE  de.email_id ='".$email_id."'";
              $acountId=$this->_OcommonDBO->_getResult($sql);
              $this->_InputData['accountId'] =$acountId[0]['r_account_id'];
    	}
    }

	/**
     * @function : _updateUserPassword
     * @author : Deepak Pande
     * @created date : 2018-07-19
     * @description : function update the user password
     */
	public function _updateUserPassword(){
		if(isset( $this->_InputData['accountId']) && !empty($this->_InputData['accountId'])) {
		//assign the request input
		$input = $this->_InputData;

		$password =md5($input['password']);


		//forming the query for update
		$sql = "UPDATE 
					dm_account 
				SET
					login_password = " ."'". $password."'"."
				WHERE account_id = " . $input['accountId'];

        $tablename='dm_account ';
        $updateArray=array('login_password' => $password,"password_updated_date"=>date('Y-m-d'));
		$result = $this->_OcommonDBO->_update($tablename, $updateArray, 'account_id',$input['accountId']);
		$this->_updatePasswordResponse($result);
		return TRUE;
		}
	}

	/**
     * @function : _updatePasswordResponse
     * @author : Deepak Pande
     * @created date : 2018-07-23
     * @description : function update the user password response formation
     */

	public function _updatePasswordResponse($updateRowCount){

		//here the response status is assign
		$this->_Sstatus = $updateRowCount >= 1 ? TRUE : FALSE;
		//here the response message is assign
		$this->_Oresponse = $updateRowCount >= 1 ? 'Your Password update successfully' : 'Your Password not updated';

		return TRUE;

	}





}