<?php 
/* 
 * @Class Name      :   class.eTicket.php
 * @Description     :   This file is used get e-ticket related information
 * @Author          :   Ranjith Kumar
 * @Created Date    :   01 Mar, 2019
 * @Modified Date   :   --
 * @Modified By     :   --
 */
pluginFileRequire('misc/corporate/harinim/', "classesTpl/class.tpl.misc.eTicketDisplayTpl.php");

class eTicket extends serviceTemplate implements iConfig 
{   
    public function _invokeMember() 
    {
        //object to get the eTicket details
        $_OeTicketDisplay =  self::getObject('eTicketDisplayTpl');
        $input['order_id'] = $this->_InputData['order_id'];
        $input['package_type'] = $this->_InputData['package_id'];
        $input['mobileRequest'] = 'Y';
        //assigning response for the request
        $this->_Oresponse = $_OeTicketDisplay->displayEticket($input);
    }
}
?>