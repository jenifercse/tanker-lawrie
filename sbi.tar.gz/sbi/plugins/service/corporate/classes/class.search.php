<?php
/**
 * Flight search result
 * @autor Vijaykeerthi R
 * @Last modified date 28-Mar-2019
 * @Modified By Ranjith Kumar 
 */

fileRequire('plugins/service/corporate/interface/iSearch.php');
class search extends serviceTemplate implements iConfig, iSearch 
{
	
	public $_Aresponse;
	public $_Sstatus 		  = true;
	public $SBAirlines 		  = array('UK','AI','9W');
    public $CTBlockedAirlines = array('9W','AI','UK','G8','SG','6E','2T');

	public function __construct()
	{
		# initialize
		$this->_Aresponse = array();

		
	}

    /*@desc function invokes business logic
    * @param 
    * @return
    */
	public function _invokeMember() {
		$this->getFlightSearch();
	}

    /*@desc function does fight search and responds back
    * @param 
    * @return
    */
	protected function getFlightSearch(){

		$this->_InputData['currencyType'] = 'INR';
		### initialize necessary objects
		$_Ocommon 	   = self::getObject('common');
		$_OcommonQuery = self::getObject('commonQuery');

		### Get pomocode detail
		$corporateId 				  = $this->_InputData['corporateId'];
		$requestedData['cabinClass']  = $this->_InputData['cabinClass'];
		$requestedData['travelMode']  = $this->_InputData['travelMode'] == 'D' ? 1 : 9;
		$this->_InputData['promoCode']['airline'] = $_OcommonQuery->_discountFareFlightsPromoCode($this->_InputData['date']['onward'],'', $corporateId, $requestedData);

		### remove used array for memory management
		unset($requestedData);

		$this->_InputData['agentId'] 	   = SERVICE_AGENCY_ID;
		$this->_InputData['cabinclass']    = $this->_InputData['cabinClass'];
		$this->_InputData['currency_type'] = $this->_InputData['currencyType'];

		$this->_InputData['types'] = array(
			'requestedAirline' 	=>  $this->_InputData['travelMode'] == 'D' ? $this->SBAirlines : array(),
			'blockedAirlines'  	=>  $this->CTBlockedAirlines,
			'airlinecode' 		=>  $this->_InputData['airlineCode'],
			//'faretype' 		=>  $faretype,
			'tripType' 			=>  $this->_InputData['tripType'],
			'travel_type' 		=>  $this->_InputData['travelMode']
		);

		### build search request for onward
		$searchData = $this->_buildSearchRequest();
		### Get flight results
		### onward request

		fileWrite(print_r($searchData,1),"search");

		$_Jcontent = $_Ocommon->_getWebservicesResult($searchData, 'mobile');

		fileWrite('insdie onward response:'.print_r($_Jcontent,1), 'wsData','a+');
		fileWrite('insdie onward response:'.print_r($_Jcontent,1), 'wsData1','w+');

		### start counting unique id for sending through WS
		$this->IuniqueId = 1;

		### place response in class member for returning in response function - onward sector
		$_AOnwardResponse = $this->_formatResponseArray($_Jcontent, $this->_InputData['sector'], 0);
		fileWrite('Formatted onward response:'.print_r($_AOnwardResponse,1), 'wsData1','a+');
		### check if trip type is roundtrip
		// if($this->_InputData['date']['return'] != '' && $this->_InputData['tripType'] == 'R') {

		// 	//swap sector for roundtrip
		// 	$roundtripOrigin 	  = $this->_InputData['sector']['destination'];
		// 	$roundtripDestination = $this->_InputData['sector']['origin'];

		// 	$this->_InputData['sector']['origin'] 	   = $roundtripOrigin;
		// 	$this->_InputData['sector']['destination'] = $roundtripDestination;

		// 	//swap date for roundtrip and clear the return date
		// 	$roundtripJourneyDate = $this->_InputData['date']['return'];

		// 	$this->_InputData['date']['onward'] = $roundtripJourneyDate;
		// 	$this->_InputData['date']['return'] = '';

		// 	### build search request for return
		// 	unset($searchData);
		// 	$searchData = $this->_buildSearchRequest();

		// 	$_JcontentReturn = $_Ocommon->_getWebservicesResult($searchData, 'mobile');
		// 	fileWrite('insdie return response:'.print_r($_JcontentReturn,1), 'wsData','a+');

		// 	### place response in class member for returning in response function - return sector
		// 	$_AReturnResponse = $this->_formatResponseArray($_JcontentReturn, $this->_InputData['sector'], 1);
		// 	fileWrite('Formatted return response:'.print_r($_AReturnResponse,1), 'wsData','a+');

		// 	if(is_array($_AReturnResponse)) {

		// 		$this->_Oresponse['flightSearchData']['airlineData'] = array_merge($_AOnwardResponse['flightSearchData']['airlineData'], $_AReturnResponse['flightSearchData']['airlineData']);
				
		// 		$this->_Oresponse['flightSearchData']['fareType'] = array_unique(array_merge($_AOnwardResponse['flightSearchData']['fareType'], $_AReturnResponse['flightSearchData']['fareType']), SORT_REGULAR);
		// 		$this->_Oresponse['flightSearchData']['stops'] 		   	= $_AOnwardResponse['flightSearchData']['stops'];
		// 		$this->_Oresponse['flightSearchData']['airlines'] 	   	= $_AOnwardResponse['flightSearchData']['airlines'];
		// 		$this->_Oresponse['flightSearchData']['sectorMain']    	= $_AOnwardResponse['flightSearchData']['sectorMain'];
		// 		$this->_Oresponse['flightSearchData']['departureTime'] 	= $_AOnwardResponse['flightSearchData']['departureTime'];

		// 	}
			
		// 	unset($_AOnwardResponse);
		// 	unset($_AReturnResponse);
			
		// } else {
			$this->_Oresponse = $_AOnwardResponse;
			unset($_AOnwardResponse);
		// }

		fileWrite(print_r(json_encode($this->_Oresponse), 1), 'FlightSearchResponseJSON');

		### removed unwanted variable for optimization
		unset($_Jcontent);
		unset($this->_InputData);
		unset($searchData);

	}

    /*@desc build search request form
    * @param 
    * @return array|$searchData
    */
	protected function _buildSearchRequest($journeyType = 0) {

		### initialize necessary objects
		$_Ocommon = self::getObject('common');

		$searchData['data']['airline_code'] = $this->_InputData['types']['airlinecode'];

		$responseKey = self::RESPONSE_KEY;

		//Prerpare Retail fare data
		$this->_InputData['types']['faretype']  	 = self::RETAIL_FARE_ABBR;
		$searchData['data'][self::RETAIL_FARE_ABBR]  = base64_encode($_Ocommon->aesEncryption($responseKey, base64_encode(((json_encode($this->_InputData))))));
		
		//Prepare corporate fare data
		$this->_InputData['types']['faretype'] 	= self::CORPORATE_FARE_ABBR;

		$fscAirlineCodes = self::AIRLINES_FSC;

		fileWrite('InputData:'.print_r($this->_InputData,1), 'FlightSearchData', 'a+');
		
		if($searchData['data']['airline_code'] == 'SB'){ ### This is for FSC carriers
			foreach ($fscAirlineCodes as $key => $airlinecode) {
				$this->_InputData['types']['requestedAirline'] = array($airlinecode);
				$searchData['data'][$airlinecode.self::CORPORATE_FARE_ABBR] = base64_encode($_Ocommon->aesEncryption($responseKey, base64_encode(((json_encode($this->_InputData))))));
			}
		} else {//This is for LCC carriers
			$searchData['data'][self::CORPORATE_FARE_ABBR] = base64_encode($_Ocommon->aesEncryption($responseKey, base64_encode(((json_encode($this->_InputData))))));
		}

		### set corporateFlat and non-refundable fare tag is sent else set as no
		$searchData['corporateFlag'] 	 = isset($this->_InputData['corporateFlag']) && !empty($this->_InputData['corporateFlag']) ? $this->_InputData['corporateFlag'] : 'NO';
		$searchData['nonRefundableFare'] = isset($this->_InputData['nonRefundableFare']) && !empty($this->_InputData['nonRefundableFare']) ? $this->_InputData['nonRefundableFare'] : 'YES';

		return $searchData;
	}

    /*@desc formats response array based on input
    * @param string|$searchDataJSON
    * @param array|$sectorInfo
    * @return array|$responseArray
    */
	protected function _formatResponseArray($searchDataJSON, $sectorInfo, $journeyType = 0) {
		
		$responseArray['flightSearchData'] = array();

		$searchDataArray = json_decode($searchDataJSON, 1);

		$this->_AresponseFareTypes = $searchDataArray['faretype'];
		$this->_Aairlines 		   = $searchDataArray['airlines'];
		$this->_Astops 		   	   = $searchDataArray['stops'];

		if(is_array($searchDataArray)) {

			foreach($searchDataArray['data'] as $key => $val) {

				$this->flightTotalFare = $this->totalFare = array();

				foreach($this->_AresponseFareTypes as $ftkey=>$ftval) {
					
					if(isset($val['responseArray'][$ftval])) {

						### assign values for use in new sum value
						$this->flightTotalFare[$ftval] = $this->totalFare['newTotalFare'.$ftval] = $val['newTotalFare'.$ftval];
						$this->newflightTotalFare[$ftval] = $val['responseArray'][$ftval]['base_fare'] + $val['responseArray'][$ftval]['tax'];
						$responseArray['flightSearchData']['airlineData'][$key] = $this->_formAirlineData($val['responseArray'][$ftval], $val['duration'], $key, $ftkey);
						$responseArray['flightSearchData']['airlineData'][$key]['fareInfo'] = array_values($responseArray['flightSearchData']['airlineData'][$key]['fareInfo']);

						### build fare info array for each flight
						//$responseArray['flightSearchData']['airlineData'][$key]['fareInfo'] = $this->fareInfoArray[$key];
						//$responseArray['flightSearchData']['airlineData'][$key]['fareInfo'] = $this->fareInfoArray[$key];
						
						$responseArray['flightSearchData']['fareType'] 	     = $this->_formFareTypeData();

						### no need to form the below array as it is need only one in the response
						if($journeyType == 0) {
							
							$responseArray['flightSearchData']['stops'] 	     = $this->_formStopsData();
							$responseArray['flightSearchData']['airlines'] 	     = $this->_formAirlineDetails($searchDataArray['airlines']);
							$responseArray['flightSearchData']['sectorMain']     = $sectorInfo['origin'].'-'.$sectorInfo['destination'];
							$responseArray['flightSearchData']['departureTime']  = $this->_formDepatureTimeDetails();
						}
					}
					
				}

				//incrementting unique id
				$this->IuniqueId++;

			}
		}
		foreach ($responseArray['flightSearchData'] as $key => $value) 
		{
			$responseArray['flightSearchData'][$key] = array_values($responseArray['flightSearchData'][$key]);
		
		}		
		
		return $responseArray;
	}

    /*@desc forms airline data array
    * @param array|$dataArray
    * @param string|$duration
    * @return array|$responeArray
    */
	protected function _formAirlineData($dataArray, $duration, $key, $fareTypeKey) {

		$responeArray =  array();

		if(is_array($dataArray)) {

			### assign value to class member for assigning in array with multiple faretype in single fareInfo key
			### since array is looped with per fare type and need response to the returned in single fareInfo array 
			### stored in fareInfoArray class member

			$this->fareInfoArray[$key][$fareTypeKey] = $this->_getFareInfo($dataArray);
			if($this->_InputData['travelMode'] == 'I' && $this->_InputData['tripType'] == 'R')
			{
				$responeArray['sectorInfo'] 		 = $this->_getInternationalSectorInfo($dataArray);
				$responeArray['viaInfo']['O']		 = $this->_getInternationalViaInfo($dataArray['via_flights']['O']);
				$responeArray['viaInfo']['R']		 = $this->_getInternationalViaInfo($dataArray['via_flights']['R']);
			}
			else
			{
				$responeArray['sectorInfo'] 			 = $this->_getSectorInfo($dataArray, $duration);
				$responeArray['viaInfo']    			 = $this->_getViaInfo($dataArray);
			}
			$responeArray['fareInfo'] 				 = $this->fareInfoArray[$key];
			$responeArray['segmentLowestFare']  	 = max($this->totalFare);
			$responeArray['fareTypeCode']  	 		 = array_column($this->fareInfoArray[$key], 'fareTypeCode');
			$responeArray['uniqueId']  	 		 	 = $this->IuniqueId.'_'.$responeArray['sectorInfo']['airlineCode'];
			
		} 

		return $responeArray;
	}

    /*@desc forms airline sector information
    * @param array|$dataArray
    * @param string|$dataArray
    * @return array|$responeArray
    */
	protected function _getSectorInfo($dataArray, $duration) {

		$responeArray = array();

		if(is_array($dataArray)) {

			$durationTS = str_replace(array('h','m'), '', $duration);

			$responeArray['originAirportCode'] 		= $dataArray['origin_airport_code'];
			$responeArray['destinationAirportCode'] = $dataArray['dest_airport_code'];
			$responeArray['originAirport'] 			= $dataArray['origin_airport_name'];
			$responeArray['departureAirport'] 		= $dataArray['dest_airport_name'];
			$responeArray['departureDate'] 			= $dataArray['date_departure'];
			$responeArray['departureTime'] 			= $dataArray['time_departure'];
			$responeArray['arrivalDate'] 			= isset($dataArray['via_flights']['O'][0]['arrival_date']) ? $dataArray['via_flights']['O'][count($dataArray['via_flights']['O']) - 1]['arrival_date'] : $dataArray['via_flights']['R'][count($dataArray['via_flights']['R']) - 1]['arrival_date'];
			$responeArray['arrivalTime'] 			= $dataArray['time_arrival'];
			//$responeArray['duration'] 			= vsprintf("%02d:%02d", explode(' ', $durationTS));
			$responeArray['duration'] 				= $duration;
			$responeArray['airlineCode'] 			= isset($dataArray['via_flights']['O'][0]['airline_code']) ? $dataArray['via_flights']['O'][0]['airline_code'] : $dataArray['via_flights']['R'][0]['airline_code'];
			$responeArray['flightNumber'] 			= isset($dataArray['via_flights']['O'][0]['flight_number']) ? $dataArray['via_flights']['O'][0]['flight_number'] : $dataArray['via_flights']['R'][0]['flight_number'];
			$responeArray['airlineImage'] 			= 'https://www.cleartrip.com/images/logos/air-logos/'.$responeArray['airlineCode'].'.png';
			$responeArray['stops'] 			    	= $dataArray['stops'];
			$responeArray['stopsText'] 			= self::FLIGHT_STOP[$dataArray['stops']];
			$responeArray['cancellation_fee']			= $dataArray['cancellation_fee'];
			$responeArray['durationTimeString'] 	= strtotime(vsprintf("%02d:%02d", explode(' ', $durationTS)));
			$responeArray['departureTimeString'] 	= strtotime($dataArray['time_departure']);
		}

		return $responeArray;
	}

    /*@desc forms airline sector information
    * @param array|$dataArray
    * @return array|$responeArray
    */
	protected function _getViaInfo($dataArray) {

		$responeArray = array();

		if(is_array($dataArray)) {

			$viaFligthArray = isset($dataArray['via_flights']['R']) ? $dataArray['via_flights']['R'] : $dataArray['via_flights']['O'];

			foreach($viaFligthArray as $key=>$val) {

				$totalTime = str_replace(array('h','m'), '', $val['total_time']);

				$responeArray[$key]['originAirportCode'] 		= $val['origin_airport_code'];
				$responeArray[$key]['destinationAirportCode'] 	= $val['dest_airport_code'];
				$responeArray[$key]['originAirport'] 			= $val['origin_airport_name'];
				$responeArray[$key]['originAirportName'] 		= $val['origin_airport_details']['airport_name'];
				$responeArray[$key]['departureAirport'] 		= $val['dest_airport_name'];
				$responeArray[$key]['destinationAirportName'] 	= $val['dest_airport_details']['airport_name'];
				$responeArray[$key]['departureDate'] 			= $val['departure_date'];
				$responeArray[$key]['departureTime'] 			= $val['time_departure'];
				$responeArray[$key]['_comment'] 				= '';
				$responeArray[$key]['airlineCode'] 				= $val['airline_code'];
				$responeArray[$key]['durationTime'] 			= vsprintf("%02d:%02d", explode(' ', $totalTime));
				$responeArray[$key]['durationTimeString'] 		= strtotime($responeArray[$key]['durationTime']);
				$responeArray[$key]['layoverTime'] 				= $val['layover_time'];
				$responeArray[$key]['layoverTimeString'] 		= strtotime($val['layover_time']);
				$responeArray[$key]['flightNumber'] 			= $val['flight_number'];
				$responeArray[$key]['arrivalDate'] 				= $val['arrival_date'];
				$responeArray[$key]['arrivalTime'] 				= $val['time_arrival'];
				$responeArray[$key]['airlineImage'] 			= 'https://www.cleartrip.com/images/logos/air-logos/'.$val['airline_code'].'.png';
				$responeArray[$key]['baggage_allowance']		= $val['baggage_allowance'];
				$responeArray[$key]['fare_basic_code']			= $val['fare_basic_code'];
				$responeArray[$key]['cancellation_fee']		= $dataArray['cancellation_fee'];
				$responeArray[$key]['arrivalTerminal']			= $val['arrival_terminal'];
				$responeArray[$key]['departureTerminal']		= $val['departure_terminal'];
				fileWrite('key:-'.$key.'---'.$responeArray[$key]['flightNumber'], 'FlightNumberDuplicate','a+');

			}

		}

		return $responeArray;
	}


	/*@desc forms airline sector information for International Round Trip
    * @param array|$dataArray
    * @return array|$responseArray
    * @author: Ranjith Kumar 
    */
	protected function _getInternationalSectorInfo($dataArray) {

		$responseArray = array();

		if(is_array($dataArray)) {

			$onwardDurationTS = str_replace(array('h','m'), '', $dataArray['onwardtotalTravelTime']);
			$returnDurationTS = str_replace(array('h','m'), '', $dataArray['returntotalTravelTime']);
			$onwardViaCount = count($dataArray['via_flights']['O'])-1;
			$returnViaCount = count($dataArray['via_flights']['R'])-1;

			$responseArray['originAirportCode'] 		= $dataArray['origin_airport_code'];
			$responseArray['destinationAirportCode'] = $dataArray['dest_airport_code'];
			$responseArray['originAirport'] 			= $dataArray['origin_airport_name'];
			$responseArray['departureAirport'] 		= $dataArray['dest_airport_name'];
			$responseArray['departureDate'] 			= $dataArray['date_departure'];
			$responseArray['departureTime'] 			= $dataArray['time_departure'];
			$responseArray['arrivalTime'] 			= $dataArray['time_arrival'];
			$responseArray['arrivalDate']			= $dataArray['via_flights']['O'][$onwardViaCount]['arrival_date'];
			$responseArray['returnDepartureDate'] 	= $dataArray['return_date_departure'];
			$responseArray['returnDepartureTime'] 	= $dataArray['return_time_departure'];
			$responseArray['returnArrivalTime'] 		= $dataArray['return_time_arrival'];
			$responseArray['returnArrivalDate']		= $dataArray['via_flights']['R'][$returnViaCount]['arrival_date'];
			$responseArray['totalTravelTime'] 	= $dataArray['onwardtotalTravelTime'];
			$responseArray['duration'] 	= $dataArray['onwardtotalTravelTime'];
			$responseArray['returntotalTravelTime']		= $dataArray['returntotalTravelTime'];
			$responseArray['airlineCode'] 		= $dataArray['via_flights']['O'][0]['airline_code'];
			$responseArray['returnAirlineCode']		= $dataArray['via_flights']['R'][0]['airline_code'];
			$responseArray['flightNumber'] 	= $dataArray['via_flights']['O'][0]['flight_number'];
			$responseArray['returnFlightNumber'] 	= $dataArray['via_flights']['R'][0]['flight_number'];
			$responseArray['airlineImage'] 	= 'https://www.cleartrip.com/images/logos/air-logos/'.$responseArray['airlineCode'].'.png';
			$responseArray['returnAirlineImage'] 	= 'https://www.cleartrip.com/images/logos/air-logos/'.$responseArray['returnAirlineCode'].'.png';
			$responseArray['stops']			= $dataArray['stops'];
			$responseArray['returnStops']			= $dataArray['return_stops'];
			$responseArray['stopsText'] 		= self::FLIGHT_STOP[$dataArray['stops']];
			$responseArray['returnStopsText']		= self::FLIGHT_STOP[$dataArray['return_stops']];
			$responseArray['durationTmeString'] 	= strtotime(vsprintf("%02d:%02d", explode(' ', $onwardDurationTS)));
			$responseArray['returnDurationTimeString'] 	= strtotime(vsprintf("%02d:%02d", explode(' ', $returnDurationTS)));
			$responseArray['cancellation_fee']			= $dataArray['cancellation_fee'];
			$responseArray['departureTimeString'] 	= strtotime($dataArray['time_departure']);
		}

		return $responseArray;
	}

    /*@desc forms airline via information for international round trip
    * @param array|$dataArray
    * @return array|$responseArray
    * @author: Ranjith Kumar
    */
	protected function _getInternationalViaInfo($dataArray) {

		$responseArray = array();

		if(is_array($dataArray)) {
			foreach($dataArray as $key=>$val) {

				$totalTime = str_replace(array('h','m'), '', $val['travel_time']);
				$layoverTime = str_replace(array('h', 'm'), '', $val['layover_time']);
				$responseArray[$key]['originAirportCode'] 		= $val['origin_airport_code'];
				$responseArray[$key]['destinationAirportCode'] 	= $val['dest_airport_code'];
				$responseArray[$key]['originAirport'] 			= $val['origin_airport_name'];
				$responseArray[$key]['originAirportName'] 		= $val['origin_airport_details']['airport_name'];
				$responseArray[$key]['destinationAirport'] 		= $val['dest_airport_name'];
				$responseArray[$key]['destinationAirportName'] 	= $val['dest_airport_details']['airport_name'];
				$responseArray[$key]['departureDate'] 			= $val['departure_date'];
				$responseArray[$key]['departureTime'] 			= $val['time_departure'];
				$responseArray[$key]['_comment'] 				= '';
				$responseArray[$key]['airlineCode'] 			= $val['airline_code'];
				$responseArray[$key]['durationTime'] 			= vsprintf("%02d:%02d", explode(' ', $totalTime));
				$responseArray[$key]['durationTimeString'] 		= strtotime($responseArray[$key]['durationTime']);
				$responseArray[$key]['layoverTime'] 			= vsprintf("%02d:%02d", explode(' ', $totalTime));
				$responseArray[$key]['layoverTimeString'] 		= strtotime($responseArray[$key]['layoverTime']);
				$responseArray[$key]['flightNumber'] 			= $val['flight_number'];
				$responseArray[$key]['arrivalDate'] 			= $val['arrival_date'];
				$responseArray[$key]['arrivalTime'] 			= $val['time_arrival'];
				$responseArray[$key]['airlineImage'] 			= 'https://www.cleartrip.com/images/logos/air-logos/'.$val['airline_code'].'.png';
				$responseArray[$key]['baggage_allowance']		= $val['baggage_allowance'];
				$responseArray[$key]['fare_basic_code']			= $val['fare_basic_code'];
				$responseArray[$key]['cancellation_fee']		= $dataArray['cancellation_fee'];
				$responseArray[$key]['arrivalTerminal'] 		= $val['arrival_terminal'];
				$responseArray[$key]['departureTerminal'] 		= $val['departure_terminal'];
			}

		}

		return $responseArray;
	}



    /*@desc forms fare information
    * @param array|$dataArray
    * @return array|$responeArray
    */
	protected function _getFareInfo($dataArray, $name) {

		$responeArray = array();

		if(is_array($dataArray)) {

			$fareTypeCode	= isset($dataArray['via_flights']['O'][0]['faretype_code']) ? $dataArray['via_flights']['O'][0]['faretype_code'] : $dataArray['via_flights']['R'][0]['faretype_code'];
			$viaFlightInfo = isset($dataArray['via_flights']['O']) ? $dataArray['via_flights']['O'] : $dataArray['via_flights']['R'];
			$responeArray['name'] 		  	= strtr(isset($dataArray['via_flights']['O'][0]['faretypename']) ? $dataArray['via_flights']['O'][0]['faretypename'] : $dataArray['via_flights']['R'][0]['faretypename'], array('fare' => '', 'Fare' => ''));
			$responeArray['fareTypeCode']	= $fareTypeCode;
			$responeArray['seats']			= $dataArray['seats'];
			//$responeArray['totalAmount']    = $this->_getTotalFare($dataArray);
			fileWrite(print_r($this->flightTotalFare,1), 'FlightTotalFare','a+');
			$responeArray['totalAmount']    = $this->flightTotalFare[$responeArray['fareTypeCode']];
			$responeArray['newTotalAmount'] = $this->newflightTotalFare[$responeArray['fareTypeCode']];
			$responeArray['passengerFare']  = $this->_getPassengerFare($dataArray['passenger_fare'], $viaFlightInfo);
			$responeArray['discountedTotalAmount'] = $responeArray['passengerFare']['discountedTotalAmount'];
			$responeArray['totalDiscount'] = $responeArray['passengerFare']['totalDiscount'];
			unset($responeArray['passengerFare']['discountedTotalAmount']);
			unset($responeArray['passengerFare']['totalDiscount']);
		}

		return $responeArray;
	}

    /*@desc forms total fare information based on fare type
    * @param array|$dataArray
    * @return int|$totalAmount
    */
	protected function _getTotalFare($dataArray) {
		fileWrite(print_r($this->flightTotalFare,1), 'FlightTotalFare','a+');
		$totalAmount = array();
		//corporate fare
		if($dataArray['fareTypeCode'] == 'CF') {
			$totalAmount['CF']  = $this->flightTotalFare['newTotalFareCF'];
		} 

		//refudnable fare
		if($dataArray['fareTypeCode'] == 'R') {
			$totalAmount['R']  = $this->flightTotalFare['newTotalFareR'];
		} 

		//roundtrip fare
		if($dataArray['fareTypeCode'] == 'RT'){
			$totalAmount['RT']  = $this->flightTotalFare['newTotalFareRT'];
		} 

		//Hand-Baggae
		if($dataArray['fareTypeCode'] == 'HB'){
			$totalAmount['HB']  = $this->flightTotalFare['newTotalFareHB'];
		}

		//SME Fare
		if($dataArray['fareTypeCode'] == 'SM'){
			$totalAmount['SM']  = $this->totalFare['newTotalFareSM'];
		}

		return $totalAmount;
	}

    /*@desc forms passenger fare information
    * @param array|$dataArray
    * @param array|$viaInfo
    * @return array|$returnArray
    */
	protected function _getPassengerFare($dataArray, $viaInfo) {

		$passTypeArray = array('ADT' => 'adult', 'CHD' => 'child', 'CNN' => 'child','INF' => 'infant','INFT' => 'infant');

		$returnArray = array();

		if(is_array($dataArray)) {
			$returnArray['discountedTotalAmount'] = 0;
			foreach($dataArray as $key=>$val) {
				$returnArray[$key]['passengerType'] 	= $val['passenger_type'];
				$returnArray[$key]['baseFare'] 			= $val['base_fare'];
				$returnArray[$key]['tax'] 				= $val['tax'];
				$returnArray[$key]['fareBasisCode'] 	= $viaInfo[0]['fare_basic_code'][$passTypeArray[$val['passenger_type']]];
				$returnArray[$key]['taxBreakUpDetails'] = $val['taxBreakUpDetails'];
				$temp = 0;
				$temp += $val['base_fare'];
				foreach($val['taxBreakUpDetails'] as $taxKey=>$taxValue)
				{
					if($taxValue['taxCode'] == 'YQ')
					{
						$temp += $taxValue['taxAmount'];
					}
				}
				$returnArray[$key]['discountAmountPer'.$val['passenger_type']] = round(($temp * 2.25 ) / 100);
				$returnArray[$key]['discountAmount'] = $returnArray[$key]['discountAmountPer'.$val['passenger_type']] * $this->_InputData['passengers'][$passTypeArray[$val['passenger_type']]];
				$returnArray[$key]['discountedFarePer'.$val['passenger_type']] = ($val['base_fare']+$val['tax'])-$returnArray[$key]['discountAmountPer'.$val['passenger_type']];
				$returnArray[$key]['discountedFare'] = $returnArray[$key]['discountedFarePer'.$val['passenger_type']] * $this->_InputData['passengers'][$passTypeArray[$val['passenger_type']]];

				$returnArray['discountedTotalAmount'] += $returnArray[$key]['discountedFare']; 
				$returnArray['totalDiscount'] += $returnArray[$key]['discountAmount'];
			}
		}
		

		return $returnArray;
	}

    /*@desc forms fare type array
    * @param 
    * @return array|$returnArray
    */
	protected function _formFareTypeData() {

		$returnArray = array();

		if(is_array($this->_AresponseFareTypes)) {
			foreach($this->_AresponseFareTypes as $res) {
				$returnArray[] = constant('self::FARETYPE_'.$res);
			}
						
		}

		return $returnArray;
	}

    /*@desc forms stops data information
    * @param 
    * @return array|$returnArray
    */
	protected function _formStopsData() {

		$returnArray = array();

		if(is_array($this->_Astops)) {
			foreach ($this->_Astops as $res) {
				$returnArray[] = constant('self::STOPS_'.$res);
			}
		}

		return $returnArray;
	}

    /*@desc forms airline details array
    * @param array|$data
    * @return array|$returnArray
    */
	protected function _formAirlineDetails($data) {

		$returnArray = array();

		if(is_array($data)) {
			foreach ($data as $res) {
				$returnArray[] = array('text' => $res['airline_name'], 'code' => $res['airline_code'], 'selected' => false, 'value' => $res['airline_code']);
			}
		}

		return $returnArray;
	}

    /*@desc provides departure time and other details
    * @param 
    * @return array|$returnArray
    */
	protected function _formDepatureTimeDetails() {

		$returnArray = array();

		$returnArray[] = array('text' => 'Before 10AM', 
							   'icon' => 'md-partly-sunny', 
							   value => array(strtotime('00:00'), strtotime('10:00')), 'selected' => false);
		$returnArray[] = array('text' => '10AM - 3PM', 
							   'icon' => 'ios-sunny', 
							   value => array(strtotime('10:00'), strtotime('15:00')), 'selected' => false);
		$returnArray[] = array('text' => '3PM - 8PM', 
							   'icon' => 'md-partly-sunny', 
							   value => array(strtotime('15:00'), strtotime('20:00')), 'selected' => false);
		$returnArray[] = array('text' => 'After 8PM', 
							   'icon' => 'ios-moon', 
							    value => array(strtotime('20:00'),strtotime('23:59')), 'selected' => false);


		return $returnArray;
	}

	public function __destruct() {
		self::clearObject('common');
		self::clearObject('commonQuery');

	}
}