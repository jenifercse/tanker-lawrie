<?php

/* * **********************************************************************
 * @Class Name	: class.resendOTP.php
 * @Created on	: 23-07-2018 
 * @Created By	: Deepak Pande
 * @Description	: update password 
 * ************************************************************************ */
class resendOTP extends serviceTemplate
{

	public $_Aresponse;
	public $_Sstatus;

	public function __construct() {
        
    }

    /**
     * @Description :This function is default function whenever the following class is invoke
     * @param :
     * @return :
     */
    public function _invokeMember(){
        
    	$this->_resendOTP();
    }

    /**
     * @Description :This function is define for r
     * @param :
     * @return :
     */

    public function _resendOTP(){

    	$input = $this->_InputData;

    	$this->_OuserAuth = new userAuth();

    	$empNumber = $this->_getEmployeeNumber();

    	$this->_OuserAuth->_generateOTP($input['employeeId'],$empNumber,$input['fcmKey'],$input['corporateId']);

    	$this->_resendOTPResponse();

    	return TRUE;
    }

    /**
     * @Description :This function is define for r
     * @param :
     * @return :
     */

    public function _getEmployeeNumber(){

    	$this->_OcommonDBO = new commonDBO();

    	$result = $this->_OcommonDBO->_select('dm_employee','mobile_no','employee_id',$this->_InputData['employeeId'])[0]['mobile_no'];
    	return $result;



    }

    /**
     * @Description :This function is define for r
     * @param :
     * @return :
     */

    public function _resendOTPResponse(){

    	$this->_Aresponse = 'OTP Resend Successfully';
    	$this->_Sstatus = TRUE;

    }
}