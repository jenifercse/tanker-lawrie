<?php
/* * **********************************************************************
 * @Class Name	: serviceEncryptDecrypt
 * @Created on	: 2018-07-18
 * @Created By	: Deepak Pande
 * @Description	: This class in use for service request & response encryption & decryption
 * ************************************************************************ */

class serviceEncryptDecrypt 
{
	
	public function __construct()
	{
		# code...
	}

	public function _serviceDataEncrypt($input){
		return base64_encode(openssl_encrypt(json_encode($input),'aes-256-cbc',ENCRYTION_MOBILE_KEY,TRUE,ENCRYTION_MOBILE_KEY_VI));
	}

	public function _serviceDataDecrypt($input){
		return json_decode(openssl_decrypt(base64_decode($input),'aes-256-cbc',ENCRYTION_MOBILE_KEY,TRUE,ENCRYTION_MOBILE_KEY_VI),1); 
	}
}