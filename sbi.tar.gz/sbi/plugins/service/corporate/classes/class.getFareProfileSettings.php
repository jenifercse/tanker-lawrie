<?php
pluginFileRequire('misc/corporate/harinim/classes/class.commonQuery.php');
pluginFileRequire('admin/corporate/harinim/classes/class.manageApplicationSettings.php');
/* ******************************************************************************
 * @class			: getFareProfileSettings 
 * @author			: Ranjith Kumar
 * @created date	: Feb 21,2019
 * @Description		: Mobile Service for getting Fare Profile Settings
 * **************************************************************************** */
class getFareProfileSettings extends serviceTemplate implements iConfig
{
	public function __construct()
	{
		$this->_OcommonQuery = self::getObject('commonQuery');
		$this->_OmanageApp = self::getObject('manageApplicationSettings');
	}
/* ******************************************************************************
 * @function		: _invokeMember 
 * @author			: Ranjith Kumar
 * @created date	: Feb 21,2019
 * @Description		: To get the data from the json file
 * @params 			: -
 * @return 			: -
 * **************************************************************************** */
	public function _invokeMember()
	{
		$response['FareProfileSettings'] = $this->_OcommonQuery->_setFareSettingArrayForBackEnd($this->_InputData['configuration'],$this->_InputData['corporate_id'],$this->_InputData['group_id'],$this->_InputData['trip_type']);
		$this->_assignresponse($response);
	}


/* ******************************************************************************
 * @function		: _assignresponse 
 * @author			: Ranjith Kumar
 * @created date	: Feb 21,2019
 * @Description		: To send the response for the service
 * @params 			: Array -Response array
 * @return 			: -
 * **************************************************************************** */
	public function _assignresponse($response)
	{
	    $this->_Oresponse = $response;
	}
}

?>