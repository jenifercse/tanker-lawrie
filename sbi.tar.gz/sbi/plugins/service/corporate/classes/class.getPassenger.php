<?php
/* * **************************************************************************
 * @File             : class.getPassenger.php
 * @Description      : This file is used to Get the Passenger List of a approver
 * @Tables Affected  : dm_employee,dm_travel_mode,dm_travel_class
 * @Author           : M Muruganandham
 * @Created Date     : 03/12/2018
 * @Modified Date    : 
 * ****************************************************************************/
fileRequire("./lib/common/commonMethods.php");
pluginFileRequire('common/', 'interface/commonConstants.php');
pluginFileRequire('/airDomestic/corporate/harinim/classesTpl/class.tpl.airDomestic.flightRequestDisplayTpl.php');

class getPassenger extends serviceTemplate implements iConfig{
    public function __construct() {
        $this->_AfinalData=array();
        $this->_Oemployee = new employee();
        $this->_OgetPermission = new getPermission();
        $this->_OcommonDBO = new commonDBO();
        $this->_OflightRequestDisplayTpl = new flightRequestDisplayTpl();
    }

    /*  @desc   : function invokes business logic
     *  @param  :
     *  @return :
     */
    public function _invokeMember() {
        
        /*validate request details*/
        $this-> _validateInputs();
        if($this->_BvalidateInputDetail) {
        
	        /*To get the passenger list*/        
	        $this->_passengerList();

	         /*set response files*/
	        $this->_setResposeData();
    	}   
    	else {
    	    /*set error msg*/  
        	$this->_setErrorMsg();   
        }
        
    }
     /*  @desc   : validate service inputs
     *  @param  :
     *  @return :
     */
    public function _validateInputs() {
    	
    	if(!empty($this->_InputData) && isset($this->_InputData)) {
             if((!empty($this->_InputData['employee_code']) && isset($this->_InputData['employee_code'])) && (!empty($this->_InputData['loginemployeeId']) && isset($this->_InputData['loginemployeeId']))){
                 $this->_BvalidateInputDetail=true;
             }
         }
        
    }
     /*
    * @Description  Function used to get Array of passenger List
    * @param int|$this->_IinputData
    * @return array|$finalResponse
    * @date|12.12.2018 
    * @author|M.Muruganandham
    */ 
    public function _passengerList($input){

    	$input = $this->_InputData ;
    	$factEmployeeDetailsData =$this->_Oemployee->_getLoginEmployeeOtherDetails($input['loginemployeeId']);
    	$factEmployeeDetailsData['employee_id']=$input['loginemployeeId'];
    	$permissionsData = $this->_OgetPermission->_getDataAccessPermission($factEmployeeDetailsData);
    	$input['permissions'] = $permissionsData;
    	$employeeData = $this->_OflightRequestDisplayTpl->_getPermissionDetails($input,$factEmployeeDetailsData['r_corporate_id']);
        $employeeData= $this->_OflightRequestDisplayTpl->_AserviceResponse['employee'];
        filewrite('OUTPUT--> '.print_r(json_encode($employeeData),1),'IO_VALUES','a+');

        foreach($employeeData as $key=>$value)
        {
            $tempData = $this->_Oemployee->_getEmployeeDetailsInfo($value['employee_id']);
            $tempData['band'] = $this->_Oemployee->_getBandDetails($factEmployeeDetailsData['r_corporate_id'],'',$tempData['r_band_id'])[0]['band_name'];
            $tempData = array_merge($value ,$tempData);
            unset($tempData['login_status']);
            unset($tempData['r_designation_id']);
            unset($tempData['r_branch_id']);
            unset($tempData['r_billto_id']);
            unset($tempData['r_user_type_id']);
            unset($tempData['r_level_id']);
            unset($tempData['r_department_id']);
            
            $finalArray[] = $tempData;
        }
            $this->_AfinalData = $finalArray;
        fileWrite(print_r($this->_AfinalData,1),"getPassenger","w+");


        // $this->_AfinalData = $employeeData;

	}
	 /*  @desc   :  set final response for mobile service 
     *  @param  :
     *  @return :
     */
     private function _setResposeData() {
             if(!empty($this->_AfinalData) && isset($this->_AfinalData)){
             $this->_Oresponse= $this->_AfinalData;
             // assign reponse data
             $this->_Sstatus = true; //assign response code
         }
       else {
           $this->_Oresponse='data not found'; //error msg 
       }
     }        
     /*  @desc   : if input data not correct through the error msg
     *  @param  :
     *  @return :
     */ 
    public function _setErrorMsg() {
         $this->_Oresponse='Requested data incorrect'; //error message in response
    }  

}