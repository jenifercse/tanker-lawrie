<?php
fileRequire('common/commonEncryptDecrypt.php');
fileRequire('plugins/service/corporate/classes/class.userAuth.php');
/* * **********************************************************************
 * @Class Name  : class.verifyOTP.php
 * @Created on  : 19-07-2018 
 * @Created By  : Deepak Pande
 * @Description : this file is use for OTP verification
 * ************************************************************************ */

class verifyOTP extends serviceTemplate
{

    public $_Oresponse;
    public $_Sstatus;
    function __construct()
    {

        //object creation
        $this->_OcommonDBO = new commonDBO();

    }

   /**
     * @function : _invokeMember
     * @author : Deepak Pande
     * @created date : 2018-09-10
     * @description : invoke the business logic
     */
    public function _invokeMember(){

        $this->_validateUserOtp();
    }


    // public function _invokeMember(){
    //     /*get emp id from dm_employee table*/
    //            // $this->_getEmpId();
    //            /*validate otp*/
    //     $this->_validateUserOtp();
    // }

    /**
     * @function : _getEmpId
     * @author : Puroskhan.M
     * @created date : 10-09-2018 
     * @description : validate user otp number
     */
    /*public funtion _getEmpId() {
    if(empty($this->_InputData['emailId']) && !isset($this->_InputData['emailId'])) {   
      $sql="SELECT employee_id FROM dm_employee WHERE email_id='".$this->_InputData."'";
      $this->_InputData['employeeId'] = $this->_OcommonDBO->_getResult($sql)[0];
      }
    }*/

   /**
     * @function : _validateUserOtp
     * @author : Deepak Pande
     * @created date : 19-07-2018 
     * @description : validate user otp number
     */
    public function _validateUserOtp(){

        //assign the input
        $input  = $this->_InputData;

        //query to retieve data
        $sql = "SELECT 
                    *
                FROM 
                    employee_otp_details eop
                WHERE 
                    eop.r_employee_id = " .$input['employeeId'] . "
                AND 
                    eop.otp_key = " . $input['otpKey']. " 
                AND  
                    eop.fcm_key = "."'".$input['fcmKey']."'";

        //calling query execution funciton 
        $result = $this->_OcommonDBO->_getResult($sql)[0];
        count($result) > 0 ? $this->_isOTPActive($result['created_date']) : $this->_otpVerificationResponse('N','Enter Correct OTP');
    }

   /**
     * @function : _isOTPActive
     * @author :Deepak Pande
     * @created date : 19-07-2018 
     * @description : confirm OTP activate or not 
     */
    public function _isOTPActive($otpDate) {
        
        $this->_OcommonArrayFunctions = new commonArrayFunctions();
        $sql = "SELECT TIMEDIFF( " . "'" . $otpDate . "'".",". "'" . $this->_OcommonArrayFunctions->_getCurrentDateAndTime() . "') AS TIME_DIFF";
        $result = $this->_OcommonDBO->_getResult($sql)[0]['TIME_DIFF'];
        $time = explode(':', $result);
        $result =  ($time[0]*60) + ($time[1]) + ($time[2]/60);
        $result <= OTP_ACTIVE_TIME ? $this->_otpVerificationResponse('Y','Your OTP verify') : $this->_otpVerificationResponse('N','Your OTP validity time expires');
    }

   /**
     * @function : _otpVerificationResponse
     * @author : Deepak Pande
     * @created date : 19-07-2018 
     * @description : to verify the user response 
     */
    public function _otpVerificationResponse($otpActiveStatus,$message){
        $this->_Sstatus = $this->_Oresponse['status'] = ($otpActiveStatus == 'Y') ? TRUE : FALSE;

        if($this->_InputData['otp'] == 'N' && $this->_Sstatus ==true)
        {
            $sql = "select da.login_password from dm_account da inner join fact_employee as fe on da.account_id = fe.r_account_id inner join dm_employee de on de.employee_id = fe.r_employee_id where de.email_id = '". $this->_InputData['loginEmail'] ."'";
            $result = $this->_OcommonDBO->_getResult($sql)[0]['login_password'];
            $_OcommonED = new commonEncryptDecrypt();
            $pass = $_OcommonED->_decryptData($result);

            $_OuserAuth = new userAuth();
            $_OuserAuth->OTP_STATUS = false;
            $_OuserAuth->_InputData['loginEmail'] = $this->_InputData['loginEmail'];
            $_OuserAuth->_InputData['password'] = $pass;
            $_OuserAuth->_invokeMember();
        }

        $this->_Oresponse['message'] = $message;
        $this->_Oresponse['userAuth'] = $_OuserAuth->_Oresponse;

        return TRUE;
    }


}