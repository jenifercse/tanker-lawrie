<?php 
/* 
 * @Class Name      :   class.duplicateBookingCheck.php
 * @Description     :   This file is used get check whether the employee has previous booking on the same date
 * @Author          :   Ranjith Kumar
 * @Created Date    :   27 Apr, 2019
 * @Modified Date   :   --
 * @Modified By     :   --
 */
pluginFileRequire('plugins/airDomestic/corporate/harinim','classes/class.commonFlightSearchDetails.php');
fileRequire('plugins/admin/corporate/harinim/classes/class.location.php');
class duplicateBookingCheck extends serviceTemplate implements iConfig 
{   
    public function _invokeMember() 
    {
        $this->_duplicateCheck();        
    }

    public function _duplicateCheck()
    {
        $_OcommonFSD = new commonFlightSearchDetails();
        $originCode = $_OcommonFSD->_getCityCodeAirportId($this->_InputData['origin']);
        $destCode = $_OcommonFSD->_getCityCodeAirportId($this->_InputData['destination']);
        $_OCFSRI = new commonFlightSearchRequestInsert();
        $_OCFSRI->_IinputData['passenger']['ADT'] = $this->_InputData['employeeIds'];
        $_OCFSRI->_IinputData['airRequestDetails'][0]['requestTableData']['r_origin_airport_id']['cityId'] = $originCode;
        $_OCFSRI->_IinputData['airRequestDetails'][0]['requestTableData']['r_destination_airport_id']['cityId'] = $destCode;
        $_OCFSRI->_IinputData['airRequestDetails'][0]['requestTableData']['onward_date'] = $this->_InputData['travelDate'];
        $duplicateCheck = $_OCFSRI->_checkDuplicateBooking();
        fileWrite(print_r($_OCFSRI->_AfinalResponse,1),"duplicateCheckBookingService");
        if($duplicateCheck)
        {
            $this->_assignResponse($_OCFSRI->_AfinalResponse);
        }
        else
        {
            $this->_Oresponse['message'] = 'Error while checking';
            $this->_Sstatus = false;
        }
    }

    public function _assignResponse($response)
    {
        if(!empty($response) && $response != '')
        {
            $this->_Oresponse = $response;
            $this->_Sstatus = false;
        }
        else
        {
            $this->_Sstatus = true;
            $this->_Oresponse['FLAG'] = 'SUCCESS';
        }
        
    }
}
?>