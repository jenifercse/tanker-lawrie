<?php

/* *
 * @Class Name      :   class.myBookings.php
 * @Description     :   This file is used for giving my booking details 
 * @Author          :   puroskhan.m
 * @Created Date    :   24/08/2018
 * @Modified Date   :   --
 * @Modified By     :   --
 * */
class myBookingList extends serviceTemplate implements iConfig
{
    /*  @desc   : function invokes business logic
     *  @param  :
     *  @return :
     */
     public function __construct() {
          /* variables declaration and obj creation*/  
          $this->_BidentifyUser=true;
          $this->_Aresult=array();
          $this->_Oresponse = array();
          $this->_AfinalData=array();
          $this->_InputData=array();
          $this->_Sstatus='';
          $this->_OcommonDBO = self::getObject('commonDBO');
     }
     
     /*  @desc   : function invokes business logic
     *  @param  :
     *  @return :
     */
     public function _invokeMember(){
         
         /*identify the user */
         $this->_identifyUser();
         
         if($this->_BidentifyUser) {
         /* get user level permission*/
         $this->_setPermissionforuser();
         
         /*get  particular user details*/
         $this->_getBookingDetails();
         
         /*array array formation*/
         $this->_responseArrayFormation();
         }
     }
    
    /*  @desc   : to check the user available or not
     *  @param  :
     *  @return :
     */
     public function _identifyUser() {
         /*obj creation */
          $this->_Oemployee = self::getObject('employee');
          /*get employee realated details*/
          $sql='SELECT email_id FROM dm_employee WHERE employee_id ='.$this->_InputData['employee_id'];
          $_Aresult=$this->_OcommonDBO->_getResult($sql);
          $empMailId=trim($_Aresult[0]['email_id']);/*get employee email id*/
          $employeeDetailsArray = $this->_Oemployee->_checkAccountExist($empMailId, 2);
          $empCount=count($employeeDetailsArray);
          if($empCount > 0) {
               $this->_BidentifyUser=true;
          }
          else {
              $this->_Oresponse['message']='employee not availabe';
              $this->_Oresponse['status'] = 1;
          }
     }
     
     /*  @desc   : get booking details based on request input
     *  @param  :
     *  @return :
     */
     public function _getBookingDetails(){
         /*obj creation*/
         $this->_OlistDisplay=self::getObject('listDisplay');
         /*my booking sql query*/
         // $packageCondition = " WHERE (dmp.booking_type = '".CORPORATE_BOOKING_PACKAGE_TYPE."' OR dmp.booking_type = '".CORPORATE_BOOKING_MOBILE_AIR_PACKAGE_TYPE."' ) AND ( dmp.package_type = '0' OR dmp.package_type = '".CORPORATE_BOOKING_AIR_PACKAGE_TYPE."' OR  dmp.package_type = '".CORPORATE_BOOKING_MOBILE_AIR_PACKAGE_TYPE."' )  AND IF(fai.r_via_flight_id != '', fai.itinerary_status = " . SELECTED_ITINERARY . ","."( od.r_ticket_status_id = ".REQUESTED." or od.r_ticket_status_id = ".CANCEL_REQUEST .")".") ";
         // /*my booking sql query*/
         // $this->_OlistDisplay->_ccheckCondition = $packageCondition;
         /*get inputs*/

         if($this->_InputData['action'] == 'BOOK')
         {
            $this->_OlistDisplay->_MobileStatus = 'Y';
            $sqlmain=$this->_OlistDisplay->_getBookingsList('MYBOOKINGS','','returnQuery','NODATERANGE');
         }
         elseif($this->_InputData['action'] == 'CANCEL')
         {
            $this->_OlistDisplay->_MobileStatus = 'Y';
            $sqlmain=$this->_OlistDisplay->_getBookingsList('CANCELBOOKINGS','','returnQuery','NODATERANGE');
         }
         
         if(isset($this->_InputData['filter_wise']) && !empty($this->_InputData['filter_wise']))
         {
             $searchType=trim($this->_InputData['filter_wise']);
             switch ($searchType)
             {
                 case 'pnr':
                     $sqlCondition='AND pvd.pnr="'.$this->_InputData['filter_key'].'" ';
                     break;
                 case 'date':
                      $sqlCondition='AND od.created_date BETWEEN "'.$this->_InputData['date']['start'].' 00:00:00"'.' AND "'.$this->_InputData['date']['end'].' 23:59:59" ';
                      break;
                 case 'request_id':
                     $sqlCondition='AND bh.order_id='.preg_replace("/[^0-9]/", "", $this->_InputData['filter_key'] );  
                     break;
             }
         }
        $sqlmain .= $sqlCondition;
        $sqlmain .= ' GROUP BY bh.order_id ORDER BY bh.order_id DESC ';
        if(isset($this->_InputData['toOffset']) && !empty($this->_InputData['toOffset'])){
            $sqlmain .= ' LIMIT '.$this->_InputData['toOffset'];
        }
        if(isset($this->_InputData['fromOffset']) && !empty($this->_InputData['fromOffset']))
        {
            $sqlmain .= ' OFFSET '.$this->_InputData['fromOffset'];
        }

        /*main query excution*/
        $this->_Aresult=$this->_OcommonDBO->_getResult($sqlmain);
        unset($_SESSION);
     }
     
     /*  @desc   : this function user to get employee permission levels
     *  @param   :
     *  @return  :
     */
     public function _setPermissionforuser(){
         /*obj creation*/
          $this->_OgetPermission=self::getObject('getPermission');
         session_start();
         $sqlForEmpLevel="SELECT r_level_id FROM fact_employee WHERE r_employee_id=".$this->_InputData['employee_id']." AND r_corporate_id=".$this->_InputData['corporate_id'];
         $empLevelDeatils=$this->_OcommonDBO->_getResult($sqlForEmpLevel);
         $sqlForEmpAgency="SELECT   agency_id FROM agency_corporate_mapping WHERE corporate_id =".$this->_InputData['corporate_id'];
         $empAgencyDeatils=$this->_OcommonDBO->_getResult($sqlForEmpAgency);
         $_SESSION['agencyId']    = $empAgencyDeatils[0]['agency_id'];
         $_SESSION['corporateId'] = $this->_InputData['corporate_id'];
         $_SESSION['employeeId']  = $this->_InputData['employee_id'];
         $_SESSION['levelId']     = $empLevelDeatils[0]['r_level_id'];
         $permissionsData         = $this->_OgetPermission->_getDataAccessPermission();
         $_SESSION['permissions'] = $permissionsData;
     }
     
     /*  @desc   : this function user to get e
     *  @param   :
     *  @return  :
     */
     public function _responseArrayFormation(){
         if(!empty($this->_Aresult)) { 
             /*Array formation Start*/
             $temp=array();
             $arrIndex=0;
             foreach ($this->_Aresult as $key=>$value)
             {
                 $cityDetailsFrom=$this->_getCityNames($value['sector_from']);
                 $cityDetailsTo=$this->_getCityNames($value['sector_to']);
                 $onwardReturnDate=$this->_onwardReturnDates($value['order_id']);
                 $temp[$arrIndex]['trip_type']=$value['trip_type'];
                 $temp[$arrIndex]['package_id']=$value['package_id'];
                 $temp[$arrIndex]['request_id']=$value['order_id'];
                 $temp[$arrIndex]['origin']=$cityDetailsFrom[0]['city_name'];
                 $temp[$arrIndex]['origin_code']=$value['sector_from'];
                 $temp[$arrIndex]['destination']=$cityDetailsTo[0]['city_name'];
                 $temp[$arrIndex]['destinations_code']=$value['sector_to'];
                 $temp[$arrIndex]['origin_departure_date']=$onwardReturnDate[0]['onward_depature_date'];
                 $temp[$arrIndex]['return_departure_date']=$onwardReturnDate[0]['return_depature_date'];
                 $temp[$arrIndex]['airline_code']=$value['airline_code'];
                 $temp[$arrIndex]['flight_no']=$value['flight_no'];
                 $temp[$arrIndex]['status_value']=$value['status_value'];
                 $temp[$arrIndex]['pax_name']['title']=$value['title'];
                 $temp[$arrIndex]['pax_name']['first_name']=$value['first_name'];
                 $temp[$arrIndex]['pax_name']['last_name']=$value['last_name'];
                 $temp[$arrIndex]['ticket_status_code']=$value['booking_status'];
                 $temp[$arrIndex]['ticket_status_value']=$value['status_value'];
                 $temp[$arrIndex]['travel_mode']=$value['travel_mode'];
                $arrIndex++; 
             }//foreach ($this->_Aresult as $key=>$value)
             $this->_AfinalData=$temp;
             $this->_Oresponse=$this->_AfinalData;
           //$this->_Oresponse['message'] = 'my booking details';//success message
             $this->_Sstatus = true; //assign response code
             unset($temp);
             unset($this->_Aresult);

             
         }//if(!empty($this->_Aresult))
         else
         {
             $this->_Oresponse['message']='data not available';
             $this->_Oresponse['status'] = 1;
         }
     }
     
     /*  @desc   : this function user get sector details
     *  @param   :$sectorCode | String 
     *  @return  :$cityDetails| Array
     */
     public function _getCityNames($sectorCode){
         $sql="SELECT city_name,airport_desc 
               FROM dm_airport 
               WHERE airport_code='".trim($sectorCode)."'";
          $cityDetails=$this->_OcommonDBO->_getResult($sql);
          return $cityDetails;
     }
     
     /*  @desc   : this function user get sector details
     *  @param   :$orderId | String 
     *  @return  :onward and return date| Array
     */
     public function _onwardReturnDates($orderId){
         $sql="SELECT onward_depature_date,onward_arrival_date,return_depature_date,return_arrival_date
                 FROM booking_history
                 WHERE order_id=".trim($orderId);
           $cityDetails=$this->_OcommonDBO->_getResult($sql);
           return $cityDetails;
     }

     
}//class end



?>