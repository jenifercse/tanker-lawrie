<?php
/* * ****************************************************************************************
 * @File             : class.serviceTemplate.php
 * @Description      : This file as parent abstract class for the webservice files
 * 
 * @Author           : Taslim
 * @Created Date     : 08/08/2018
 * @Modified Date    : 
  /* * **************************************************************************************/

abstract class serviceTemplate {
	
	abstract public function _invokeMember();

    /*@desc send service response
    * @param 
    * @return
    */
	public function _getServiceResponse(){
		### call flight search functions and return response
        $this->_Aresponse = $this->_Oresponse;
        unset($this->_Oresponse);
	}

    /*@desc apply B2C customziation add corporate id & agency id
    * @param 
    * @return
    */
	public function _applyCustomization($appType) {

		if($appType == 'B2C') {
			$this->_InputData['corporateId'] = B2C_CORPORATE_ID;
			$this->_InputData['agencyId']    = B2C_AGENCY_ID;
		}

	}

    /*@desc check and create class object if not exists, if exists return already existing object
    * @param string|$className
    * @return object|$this->$name
    */
	final public function getObject($className) {

		$name = 'O_'.$className;

		if(!isset($this->$name)) {
			$this->setObject($name, $className);
		} 

		return $this->$name;
	}

	final public function setObject($name, $className) {
		$this->$name = new $className;
	}

    /*@desc clear class object 
    * @param string|$className
    * @return 
    */
	final public function clearObject($className) {

		$name = 'O_'.$className;

		if(isset($this->$name)) {
			unset($this->$name);
		}
	}
}
