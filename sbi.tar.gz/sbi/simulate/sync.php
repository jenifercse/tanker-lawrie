<?php
if($_REQUEST['method'] == 'registeragency') {
    $responseArray = array('status' => true, 'UID' => $_REQUEST['frontend_agencyid']);
} else {
    $responseArray = array('status' => false, 'errordesc' => 'Invalid method called', 'UID' => '');
}
$responseJSON = json_encode($responseArray);

header('Content-Type: application/json');
echo $responseJSON;
exit;
?>
