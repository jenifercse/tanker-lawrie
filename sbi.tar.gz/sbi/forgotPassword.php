<?php
/* * *****************************************************************************
 * @author      	Mercy Chrysolite
 * @created date	2016-06-16
 * @Disc                User ......... 
 * **************************************************************************** */
$applicationPath = rtrim(dirname(__FILE__), "/\\") . DIRECTORY_SEPARATOR;
require_once "common/auto_load.php";
require_once "common/include_header.php";
fileRequire("lib/system/pluginFileRequire.php");
fileRequire('common/auto_load.php');
fileRequire("lib/system/decryptValues.php");
fileRequire("lib/system/fileWrite.php");
fileRequire("classes/class.common.php");

class forgotPassword{
    
    
    private $_OdataBase;
    public $_IinputData;
     
    public function __construct(){
       $this->_IinputData = $this->_getRequestData();
       $this->_OdataBase = $this->_getConnection();
    }
    
    public function _checkRequest(){
    
    	pluginFileRequire('default/',"classes/class.employee.php");
    	$objLogin = new employee();
    	$user = explode("$$",base64_decode($this->_IinputData['user']));
        $this->_IinputData['showEmail'] = $user[4] ? $user[4] : 'N';
    	$employee = $objLogin->_getEmployeeInfo(0,$user[0]);
        return $employee;
    }
    
    public function _updatePassword(){
    
    	pluginFileRequire('default/',"classes/class.employee.php");
    	$objLogin = new employee();
    	$user = explode("$$",base64_decode($this->_IinputData['user']));
    	$employee = $objLogin->_getEmployeeInfo(0,$user[0]);
        
        return $employee;
    }
    
    public function _getResponse(){
        
        if(isset($this->_IinputData['ajaxMethodName'])){
            pluginFileRequire('default/',"classAjax/class.ajax.".$this->_IinputData['ajaxMethodName'].".php");
            $ajaxObject = new $this->_IinputData['ajaxMethodName'];

            //Set obejct for ajax class varibales 
            $ajaxObject->_Oconnection = $this->_OdataBase->_Oconnection;
            $ajaxObject->_IinputData = isset($this->_IinputData['inputData']) ? $this->_IinputData['inputData'] : $this->_IinputData;
        
            //Calling default ajax method
            $ajaxObject->_callAjaxFunction();
            
        }else{
             pluginFileRequire('default/',"classAjax/class.ajax.ajaxFileUpload.php");
            $ajaxObject = new ajaxFileUpload();

            //Set obejct for ajax class varibales 
            $ajaxObject->_Oconnection = $this->_OdataBase->_Oconnection;
            $ajaxObject->_IinputData = $this->_IinputData['inputData'];
            $ajaxObject->_Afile = $this->_getFileUploadData();
             //Calling default fileupload method
            $ajaxObject->_callAjaxUploadFile();
        }
        $this->_displayResponse($ajaxObject->_Aresponse);
    }
    
    //To get the connection object
    private function _getConnection(){
         return dataBase::_createDBO();
    }
    
    
    //To get request level data during post/get
    private function _getRequestData(){        
        //sanitize the input
        $_OauthToken = new authToken();  
        $requestDetails['user'] = $_OauthToken->_purifyInputData($_GET['user']);     
        return $requestDetails;
    }    
    
    //Method to return file upload contents
    private function _getFileUploadData(){
        return $_FILES;
    }   
    
    
    private function _displayResponse($result=array()){
        //Display the response content
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode($result);
    }
}

//Initialize the class
$ajaxObj = new forgotPassword();

$user = $ajaxObj->_checkRequest();
 $_Ocommon = new common();
 
$randElement =$_Ocommon->_generateRandomString(7,'NUMBERS');
//generate the random token for forgot password.
$user['forgotPwdCsrf'] = 'forgotPwd_'.$randElement;

//set the token into the session
$_SESSION['csrf_token']['forgotPwd'] = $user['forgotPwdCsrf'];

if(is_array($user)){
    $user['user'] = $ajaxObj->_IinputData['user'];
    $user['showEmail'] = $ajaxObj->_IinputData['showEmail'];
} 
else{
    $user['error'] = true;
}
$twig = init();
$temp = $twig->render('forgotPassword.tpl',$user);
echo $temp;
?>