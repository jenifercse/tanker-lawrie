<?php

/* * *****************************************************************************
 * @class		baseModule phpfunction 
 * @author      	Jk Thirumal
 * @desc 		This class acts as base class in the framework, generate datas related to module
 * @created date	2015-oct-08
 * **************************************************************************** */
require_once "classes/class.fileHandler.php";

class baseModule {

    //values get from wrapper.php
    var $_IinputData = array();
    var $_OobjResponse;
    var $_Oconnection;
    var $_Osmarty;
    var $_SdivName;
    var $_SmoduleName;
    var $_IcorporateGroupId;
    var $_SerrorMsg;
    var $_IinputCount;
    var $_SstdTemplateName;
    var $_ImoduleId;
    var $_StemplateNameArray;
    var $_StemplateType;
    var $_classTplName;
    var $_SdisplayName;
    var $_IpackagInputCount;
    var $_SdisplayMode;
    var $_StemplateDisplay;
    var $_StemplateName;
    var $_AviewConstants = array();
    var $_Saction;
    var $_SrequestLogId;

    function __construct() {
        $this->db = new commonDBO();
        $this->_SmoduleName = '';
        $this->_IcorporateGroupId = 0;
        $this->_SerrorMsg = '';
        $this->_IinputCount = 0;
        $this->_SstdTemplateName = '';
        $this->_ImoduleId = 0;
        $this->_StemplateNameArray = array();
        $this->_SdisplayMode = '';
        $this->_StemplateType = array();
        $this->_SclassName = array();
        $this->_classTplName = array();
        $this->_SdisplayName = array();
        $this->_StemplateDisplay = '';
        $this->_StemplateName = '';
        $this->_IpackagInputCount = 0;
        $this->_BOverRidePlugin = false;
        $this->_AtwigOutputArray = array();
        $this->_AapplicationError[] = 'base module error';
        $this->_Saction = '';
        $this->_SrequestLogId = '';
    }

    function _getModuleData() {

        $_OFileHandler = new fileHandler();

        global $CFG;

        $moduleFilePath = APP_BASE_PATH . 'lib/system/moduleDetails/' . $this->_SmoduleName . '_' . $_SESSION['groupId'];
        if (!file_exists($moduleFilePath)) {
            $sql = "SELECT DISTINCT
                        td.template_id,
                        td.template_name,
                        td.template_type,
                        td.class_tpl_name,
                        mgm.module_group_id,
                        mgm.group_id,
                        mgm.module_id as mapping_module_id,
                        mgm.template_id,
                        mgm.display_order,
                        mgm.display_status,
                        md.module_id,
                        md.module_name,
                        mgsm.group_id,
                        mgsm.module_id,
                        mgsm.std_tpl_id,
                        mgsm.class_name,
                        mgm.display_name,
                        sd.std_tpl_id,
                        sd.std_tpl_name  
                FROM 
                        core_template_details td, 
                        core_std_tpl_details sd, 
                        core_module_group_mapping mgm, 
                        core_module_group_stdtpl_mapping mgsm, 
                        core_module_details md
                WHERE 
                        md.module_name = '" . $this->_SmoduleName . "' 
                        AND mgm.group_id = '" . $_SESSION['groupId'] . "'
                        AND mgsm.group_id = mgm.group_id
                        AND md.module_id = mgsm.module_id 
                        AND md.module_id = mgm.module_id 
                        AND sd.std_tpl_id = mgsm.std_tpl_id 
                        AND td.template_id = mgm.template_id 
                        AND mgm.display_status = 'Y' 
                ORDER BY 
                        mgm.display_order";

        fileWrite($sql, 'baseModule','a+');
        $approval = array();

        fileWrite($sql, 'baseModule', 'a+');

            $result = $this->db->_getResult($sql);

            $modleDataJSON = json_encode($result);
            
            $fileLocation = APP_BASE_PATH . 'lib/system/moduleDetails/' . $this->_SmoduleName . '_' . $_SESSION['groupId'];
            
            $_OFileHandler->fileCreate($fileLocation, 'w');
            $_OFileHandler->writeContent($modleDataJSON);
            
        } else {
            $resultJSON = $_OFileHandler->readContent($moduleFilePath);
            $result     = json_decode($resultJSON, 1);
        }

        $rowCount = count($result);
        
        if ($rowCount > 0) {

            for ($i = 0; $i < $rowCount; $i++) {

                if ($i == 0) {
                    $this->_SstdTemplateName = $result[$i]['std_tpl_name'];
                    $this->_ImoduleId = $result[$i]['module_id'];
                }
                $templateNameView = substr($result[$i]['template_name'], 0, strlen($result[$i]['template_name']) - 4);
                $twigPath = isset($this->_StemplatePackageName[$result[$i]['r_template_id']]) ? $this->_StemplatePackageName[$result[$i]['r_template_id']] . "/twig" : "";
                $this->_StemplateNameArray[$i] = $twigPath . $result[$i]['template_name'];
                $this->_StemplateType[$i] = $result[$i]['template_type'];
                $this->_SclassName[$i] = $result[$i]['class_name'];
                $this->_classTplName[$i] = $result[$i]['class_tpl_name'];
                $this->_SdisplayName[$i] = $result[$i]['display_name'];
                $templateId[$i] = $result[$i]['template_id'];
            }
        }
        $this->_insertUserActions();
    }

    /*
     * Function : _insertUserActions()
     * Description : Track the user actions on agency auto front end
     */

    function _insertUserActions(){
        
        global $CFG;
        //insert the user ip address info        
        //set remote address
        $remoteAddress = $_SERVER['REMOTE_ADDR'];
        
        //find and insert the remote address info.
        $userRemoteAddressInfo = $this->db->_select('dm_user_remote_address','*','ip_address',$remoteAddress);
        if(!$userRemoteAddressInfo){        
            $this->_IremoteAddressId = $this->db->_insert('dm_user_remote_address',array('ip_address' => $remoteAddress));
        }
        else{
            $this->_IremoteAddressId = $userRemoteAddressInfo[0]['user_remote_address_id'];
        }              

        //Insert client access order id        
        //find and insert the user order info.
        if($_SESSION['order_id']){            
            //set order id.
            $orderId = $_SESSION['order_id'];
            $userOrderInfo = $this->db->_select('dm_user_order','*','r_order_id',$orderId);
            if(!$userOrderInfo){        
                $this->_IuserOrderId = $this->db->_insert('dm_user_remote_address',array('r_order_id' => $orderId));
            }
            else{
                $this->_IuserOrderId = $userOrderInfo[0]['user_order_id'];
            }
        }

        //insert dm_user_actions
        if(isset($this->_Saction) && $this->_Saction != ''){
            $userActionInfo = $this->db->_select('dm_user_actions','*','action_name',$this->_Saction);
            if(!$userActionInfo){
                $this->_IrequestDetailsId = $this->db->_insert('dm_user_actions',array('action_name' => $this->_Saction));
            }
            else{
                $this->_IrequestDetailsId = $userActionInfo[0]['request_details_id'];
            }
        }

        //Insert all user actions data to track
        $factUserActionInfo['r_account_id'] = $_SESSION['accountId'];
        $factUserActionInfo['r_user_type_id'] =  $_SESSION['userTypeId'];
        if(isset($this->_Saction) && $this->_Saction != ''){
            $factUserActionInfo['r_module_id'] = $this->_IrequestDetailsId;
            $factUserActionInfo['type'] = 1; //0-module, 1-action
        }
        elseif (isset($this->_SmoduleName) && $this->_SmoduleName != '') {
            $factUserActionInfo['r_module_id'] = $this->_ImoduleId;
            $factUserActionInfo['type'] = 0; //0-module, 1-action
        }
        $factUserActionInfo['r_corporate_id'] = $_SESSION['corporateId'];
        $factUserActionInfo['r_agency_id'] = $_SESSION['agencyId'];
        $factUserActionInfo['accesstime'] = $CFG['created_date'];
        $factUserActionInfo['r_user_remote_address_id'] = $this->_IremoteAddressId;
        $factUserActionInfo['r_user_order_id'] = $this->_IuserOrderId;
        if(isset($this->_SrequestLogId) && $this->_SrequestLogId != ''){
            $factUserActionInfo['r_user_request_log_id'] = $this->_SrequestLogId;
        }
            $this->db->_insert('fact_user_actions',$factUserActionInfo);
    }

    function _getPackageName() {

        $sql = "SELECT DISTINCT
                            mpm.r_module_id,
                            mpm.r_group_id,
                            mpm.package_name,
                            mpm.package_type,
                            mpm.r_template_id
                        FROM
                            module_package_mapping mpm,
                            core_module_details md
                        WHERE 
                            md.module_name = '" . $this->_SmoduleName . "' 
                            AND md.module_id = mpm.r_module_id
                            AND mpm.r_group_id=  '" . $_SESSION['groupId'] . "'
                            AND if(mpm.r_corporate_id!=0,mpm.r_corporate_id = " . $_SESSION['corporateId'] . ", mpm.r_corporate_id=0)";

        if ($result = $this->db->_getResult($sql)) {
            $rowCount = count($result);
            if ($rowCount > 0) {
                $approval = array();
                $this->_IpackagInputCount = $rowCount;
                for ($i = 0; $i < $rowCount; $i++) {
                    if ($result[$i]['package_type'] == "T") {
                        $this->_StemplatePackageName[$result[$i]['r_template_id']] = $result[$i]['package_name'];
                    } else {
                        $this->_ImoduleId[$i] = $result[$i]['module_id'];
                        $this->_IgroupId[$i] = $result[$i]['group_id'];
                        $this->_SpackageName = $result[$i]['package_name'];
                    }
                }
            }
        }

        //assign override plugin name form session if package name is not already set from module package mapping table
        if (!isset($this->_SpackageName) || empty($this->_SpackageName)) {
            $this->_getOverridePackageName();
        }
    }

    /*
     * Description : get the override package name from application settings
     */

    public function _getOverridePackageName() {

        ### add condtion to check one level name space override
        if (trim(DEFAULT_PACKAGE_NAME, '/') != OVERRIDE_PACKAGE_NAME) {
            $this->_BOverRidePlugin = true;
            $this->_SoverRidePackageName = OVERRIDE_PACKAGE_NAME;
            $this->_SoverRidePluginPathName = PLUGIN_NAME . '/' . OVERRIDE_PACKAGE_NAME;
        }

        ### add condtion to check multi level name space override exists 
        if ($this->_BOverRidePlugin && $this->getOverRidePluginMultiple()) {

            $this->_AoverRidePluginPathName = $this->_AoverRidePackageName;
           
            ### append the plugin name for use in override package name array
            array_walk($this->_AoverRidePluginPathName, function(&$value, &$key) {
              $value = PLUGIN_NAME . $value;
            });
        }
    }

    /**
     * @Description : This function get the multiple override package name for the override plugin name
     * @Param       : 
     * @return      : bool|$result
     * */
    private function getOverRidePluginMultiple() {

        return false;
    }

    /**
     * @Description : This function traverses through the defined namespace and find the file which exists and loads
     * @Param       : string|$_SSubModulePath
     * @Param       : string|$classestplName
     * @return      : bool|$result
     * */
    public function checkFileExistsinOverRidePluginMultiple($_SSubModulePath, $classestplName, $classNameWithPath) {

        $returnValue = false;

        ### loop through the namespace and find the override package name as per priority
        foreach($this->_AoverRidePluginPathName as $pluginkey=>$pluginNameSpace) {
            
            if (pluginFileRequireBasic($_SSubModulePath . $pluginNameSpace . '/', "classesTpl/class.tpl." . $classNameWithPath . ".php")) {
               
                ### replace with the multi-plugin package name and plugin path for namespace based file overriding
                $this->_SoverRidePackageName    = $this->_AoverRidePackageName[$pluginkey];
                $this->_SoverRidePluginPathName = $pluginNameSpace;
                $returnValue = true;
                
                break;
            } 
        }

        return $returnValue;
    }

    function _displayModule() {
        $this->_AtwigOutputArray['templateNameArray'] = $this->_StemplateNameArray;
        $this->_StemplateDisplay = $this->_Otwig->render($this->_StemplateName, $this->_AtwigOutputArray);
    }

    /**
     * @Description : This function will return all the constants mapped for a particular view templateid
     * @Author      : J Thirumal
     * @Created_date: 18-04-2016
     * @Param       : Template Id
     * @return      : array
     * */
    function _getDisplayTemplate($tempId = '') {

        $sql = "SELECT  
                        constant_name 
                    FROM 
                        component_template ct ,
                        view_constant_mapping cvm 
                    WHERE 
                        ct.temp_id=cvm.r_temp_id AND
                        ct.temp_id=" . $tempId;

        if (DB::isError($result = $this->db->_getResult($sql))) {

            $this->_SerrorMsg = $result->getMessage();
            return FALSE;
        }

        $approval = array();

        if ($result->numRows() > 0) {

            while ($row = $result->fetchRow(DB_FETCHMODE_ASSOC)) {

                $this->_AviewConstants[] = $row['constant_name'];
            }
        } else {
            return 0;
        }
    }

    function __destruct() {
        global $CFG;
        /* Mysql close */
        //$this->_Oconnection->disconnect();
        unset($CFG);
        unset($this->_Oconnection);
        unset($this->_Osmarty);
        unset($this->_OobjResponse);
        unset($GLOBALS['custom']);
        //commented for php 7.2
        //unset($this);
        /* Force PHP to clean the circular reference */
        $cleaned = gc_collect_cycles();
        //session_write_close();
        /* Display how many zvals have been freed by the circular reference garbage collector */
    }

}
