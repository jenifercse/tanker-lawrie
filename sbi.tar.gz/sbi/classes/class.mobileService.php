<?php
/* * **********************************************************************
 * @Class Name    : mobileService
 * @Created on    : 2018-05-18
 * @Created By    : Deepak Pande
 * @Description    : This class holds get the function from the webserivce request data
 * ************************************************************************ */

fileRequire('lib/JWT/autoload.php');
use \Firebase\JWT\JWT;

class mobileService
{
    
    function __construct()
    {
        
    }
    
    public function _getServiceResponse($inputData)
    {
        
        $O_request = new $inputData['module'];
        
    }
    
    public function _generateServiceAccessCredentials($corporateId)
    {
        $serviceCredential['userName'] = SERVICE_AUTH_USERNAME . $corporateId;
        $serviceCredential['password'] = base64_encode(md5($serviceCredential['userName'], SERVICE_AUTH_KEY));
        return $serviceCredential;
    }
    
    public function _verifyServiceAccessCredentials($userName, $password)
    {
        if (base64_encode(md5($userName, SERVICE_AUTH_KEY)) == $password) {
            $corporateId = preg_replace("/[^0-9]/", "", $userName);
            return $corporateId;
        } else {
            return 'Invalid Details';
        }
    }
    
    public function _verifyToken($tokenId)
    {
        
        try {
            
            $secretKey        = base64_decode(SERVICE_SECRET_KEY);
            JWT::$leeway      = 10;
            $DecodedDataArray = JWT::decode($tokenId, $secretKey, array(
                SERVICE_ALGORITHM
            ));
            return 'SUCCESS';
        }
        catch (Exception $e) {
            
            return 'UNAUTHORIZED_REQUEST' . $e;
        }
    }
    
    public function _returnFinalResponse($data, $status = false, $code = 1, $jwtToken)
    {
        if ($status) {
            return json_encode(array(
                "status" => true,
                "data" => $data,
                "jwtToken" => $jwtToken
            ));
        } else {
            return json_encode(array(
                "status" => false,
                "data" => array(
                    "code" => $code,
                    "msg" => $data
                ),
                "jwtToken" => $jwtToken
            ));
        }
    }
    
    
    /*function _generateToken($userName,$password){
    
    }*/
    
    public function _generateToken($fcmKey)
    {
        
        $this->_ScredentialsVerficationStatus = $this->_verifyServiceAccessCredentials($userName, $password);
        
        if ($this->_ScredentialsVerficationStatus != 'FAILED') {
            $data      = array(
                'fcmToken' => $fcmKey,
                'rng' => rand(1, 100)
            );
            $secretKey = base64_decode(SERVICE_SECRET_KEY);
            $jwt       = JWT::encode($data, //Data to be encoded in the JWT
                $secretKey, // The signing key
                SERVICE_ALGORITHM);
            
            return $jwt;
            
        } else {
            return 'UNAUTHORIZED_REQUEST';
        }
        
    }
    
}
?>