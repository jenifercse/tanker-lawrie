<?php
/* * *****************************************************************************
 * @class		twig functions common file
 * @author      	Taslim
 * @created date	2016-05-31
 * **************************************************************************** */

class customtwig {

    public function __construct() {
        
    }

    public function createMenu($givenArray, $template, $stringVal = "", $parentSubMenu = 'N', $count, $menuorder = 1, $child = false) {
        
        global $CFG;
        
        $menu = $givenArray;
        $checkReference = $template;
        $initialMenu = $stringVal;
        $initialSubMenu = $parentSubMenu;
        $mainClass = "";
        $hrefattr = '';

        if (empty($count)) {
            $count = 0;
        }

        if ($count == 0)
            $mainClass = "nav navbar-nav";
        else
            $mainClass = "dropdown-menu ";

        $stringVal.="<ul class='" . $mainClass . "'>";

        //if the home icon no need set the corporate id on config, Otherwise its how based class available
        if ($mainClass == "nav navbar-nav" && !in_array($_SESSION['corporateId'],$CFG['HOME_ICON_HIDE'])) {
            $stringVal.='<li class="home-icon">
                        <a href="javascript:;" ng-click="loadHomePage();">
                            <i class="fa fa-home"></i>
                        </a>
                    </li>';
        }

        foreach ($menu as $key => $value) {

            $count++;
            
            $quickLinSelected = array_flip($_SESSION['quickLinkArray']);
            
            if(in_array($value['submenu_id'], $_SESSION['quickLinkArray'])) {
                $quickLinkClass = "quick-link-add added infi-88-quicklink";
            } else {
                $quickLinkClass = "quick-link-add infi-88-quicklink";
            }

            if (isset($value['menu_name']))
                $link = $value['menu_name'];

            if (isset($value['submenu_name']))
                $link = $value['submenu_name'];

            $additionalClassMenu = "";
            $additionalClass = "";
            $menuLinkAttr = '';

            if (isset($value['menu_link'])) {
                $onclick = isset($value['menu_link']) && !empty($value['menu_link']) ? $value['menu_link'] : '';
                $moduleAction = isset($value['routing_name']) && !empty($value['routing_name']) ? ' href="#/' . $value['routing_name'] . '" ui-sref="/' . $value['routing_name'] . '" ui-sref-opts="{reload: true, inherit:false}" ' : ' ng-click= "' . $onclick . '" ';
            }
            if (isset($value['submenuArray']) && !empty($value['submenuArray'])) {
                $menuLinkAttr = ' class="dropdown-toggle" data-toggle="dropdown" ';
                $additionalClass = " caret";
                $additionalClassMenu = "dropdown";
                $hrefattr = 'data-toggle="dropdown"';
            }

            if (isset($value['submenu_link'])) {
                $onclick = isset($value['submenu_link']) && !empty($value['submenu_link']) ? $value['submenu_link'] : '';
                $moduleAction = isset($value['routing_name']) && !empty($value['routing_name']) ? ' href="#/' . $value['routing_name'] . '" ui-sref="/' . $value['routing_name'] . '" ui-sref-opts="{reload: true, inherit:false}" ' : ' ng-click= "' . $onclick . '" ';
            }
            
            if (isset($value['menu_link'])) {
                if ($onclick == 'NULL')
                    $stringVal.='<li class="' . $additionalClassMenu . '"><a  title=" ' . $link . '"' . $menuLinkAttr . ' tabindex="' . $count . '" >' . $link . '<span class=' . $additionalClass . '></span></a>';
                else
                    $stringVal.='<li class="' . $additionalClassMenu . '"><a style="cursor:pointer;" ' . $moduleAction . '  $link ' . $menuLinkAttr . ' tabindex="' . $count . '"> ' . $link . ' <span class=' . $additionalClass . '></span></a>';
            }

            if (isset($value['submenu_link'])) {

                //for mobile view hide the personal booking using by css class -> no-menu-needed
                 if($value['submenu_name'] == 'Personal Booking') {
                    
                   if ($onclick == 'NULL')
                            $stringVal.='<li class="no-menu-needed ' . $additionalClassMenu . '"><a tabindex="' . $count . '" ' . $hrefattr . '> ' . $link . '<span id="ql_span_'.$value['submenu_id'].'" ng-click="menuaddquicklink('.$value['submenu_id'].');" class="'.$quickLinkClass.'"></span></a>';
                        else
                            $stringVal.='<li class="no-menu-needed ' . $additionalClassMenu . '"><a style="cursor:pointer;" ' . $moduleAction . ' style="cursor:pointer;" tabindex="' . $count . '" ' . $hrefattr . '> ' . $link . '<span id="ql_span_'.$value['submenu_id'].'" ng-click="menuaddquicklink('.$value['submenu_id'].');" class="'.$quickLinkClass.'"></span></a>';
                    }

                  else{
                        if ($onclick == 'NULL')
                            $stringVal.='<li class="' . $additionalClassMenu . '"><a tabindex="' . $count . '" ' . $hrefattr . '> ' . $link . '<span id="ql_span_'.$value['submenu_id'].'" ng-click="menuaddquicklink('.$value['submenu_id'].');" class="'.$quickLinkClass.'"></span></a>';
                        else
                            $stringVal.='<li class="' . $additionalClassMenu . '"><a style="cursor:pointer;" ' . $moduleAction . ' style="cursor:pointer;" tabindex="' . $count . '" ' . $hrefattr . '> ' . $link . '<span id="ql_span_'.$value['submenu_id'].'" ng-click="menuaddquicklink('.$value['submenu_id'].');" class="'.$quickLinkClass.'"></span></a>';
                   }
            
            }

            if (isset($value['submenuArray']) && is_array($value['submenuArray'])) {
                $parentSubmenu = 'N';
                if (isset($value['parentSubmenu']) && $value['parentSubmenu'] == 'Y') {
                    $parentSubmenu = 'Y';
                }

                $stringVal .= $this->createMenu($value['submenuArray'], $template, '', $parentSubmenu, 2, $count, true);
            }

            $stringVal.="</li>";
        }

        $stringVal.="</ul>";

        if ($checkReference == "Y") {
            return $stringVal;
        }
    }

    public function createQuickLinkMenu($menuArray) {

        //create quick link menu html and push into array
        $this->buildQuickLinkMenu($menuArray);

        $str = '';
        
        $count   = count($this->_AoutputStr);
        $divisor = round($count / 5);
        
        $clearDivValue          = $divisor;
        $clearDivValueNextValue = $divisor+1;
        

        if (is_array($menuArray)) {

            $str .= "<div class='added-links'>";
            $i = 1;
            foreach ($this->_AoutputStr as $key => $menu) {

                if ($i % $clearDivValue == 0 && $menu['level'] == 1) {
                    $str .= "</div>";
                    //incrementing since main level menu should not come at bottom so that it appear in next column
                    $i++;
                }

                if ($i % $clearDivValue == 1 || $i == $clearDivValueNextValue) {
                    $str .= "<div class='link-column'>";
                }

                $str .= $menu['html'];

                if ($i % $clearDivValue == 0 && $menu['level'] != 1) {
                    $str .= "</div>";
                }

                $i++;
            }

            $str .= "</div>";
            $str .= "<div class='clearfix'></div>";
            $str .= "<div class='text-center'><button type='button' ng-click='saveQuickLinks(" . $_SESSION['userId'] . ");' class='btn custom-btn custom-btn-blue'>Apply</button></div>";
            $str .= "</div>";
        }

        return $str;
    }

    public function buildQuickLinkMenu($menuArray) {

        foreach ($menuArray as $mainkey => $mainval) {
            $this->_AoutputStr[] = array("html" => "<p><span class='main-menu-tle'>" . $mainval['menu_name'] . "</span></p>", "level" => 1);
            $this->buildQuickLinkSubMenu($mainval['submenuArray']);
        }
    }

    public function buildQuickLinkSubMenu($menuArray) {

        if (is_array($menuArray)) {
            foreach ($menuArray as $key => $val) {
                if ($val['parentSubmenu'] == "Y") {
                    $this->_AoutputStr[] = array("html" => "<label class='sub-menu-tle'><span></span><i class='fa fa-caret-down'></i>" . $val['submenu_name'] . "</label>", "level" => 2);
                    $this->buildQuickLinkSubMenu($val['submenuArray']);
                } else {
                    if (in_array($val['submenu_id'], $_SESSION['quickLinkArray'])) {
                        $checked = "checked='checked'";
                        $labelClass = "class='active'";
                    } else {
                        $checked = "";
                        $labelClass = "";
                    }

                    $this->_AoutputStr[] = array("html" => "<label id='lbl_cb_".$val['submenu_id']."' " . $labelClass . "><span></span><input id='cb_" . $val['submenu_id'] . "' class='ql_cb' data-menuname='" . $val['submenu_name'] . "' data-id='".$val['submenu_id']."' data-routingname='" . $val['routing_name'] . "' type='checkbox' " . $checked . " ng-click='toggleQuickLink(" . $_SESSION['userId'] . ", " . $val['submenu_id'] . ");'>" . $val['submenu_name'] . "</label>", "level" => 3);
                }
            }
        }
    }
    
    public function _dynamicQuickLink($selectedArray) {
        
        $str = '';
        
        foreach($selectedArray as $res) {
            $str .= '<li id="ql_list_'.$res['menu_id'].'"><a href="#/' . $res['routing_name'] . '" ui-sref="/' . $res['routing_name'] . '" ui-sref-opts="{reload: true, inherit:false}" >'.$res['menu_name'].'</a></li>';
        }
        
        return $str;
    }

    public function createGrid($params) {

        $class = '';

        if (!isset($params['records']) || count($params['records']) == 0) {
            return;
        }

        $statusClass = array("Y" => "Active", "N" => "Inactive");
        $statusIcon = array("Y" => "infi-16-widgettick", "N" => "infi-24-close");

        $statusFunction = isset($params['status']) && !empty($params['status']) ? $params['status'] : '';
        $viewFunction = isset($params['view']) && !empty($params['view']) ? $params['view'] : '';
        $editFunction = isset($params['edit']) && !empty($params['edit']) ? $params['edit'] : '';
        $deleteFunction = isset($params['delete']) && !empty($params['delete']) ? $params['delete'] : '';

        $retval = '';
        $blockSort = array('status', 'view', 'edit', 'delete');

        //build table header
        $retval .='<thead><tr>';

        foreach ($params['header'] as $key => $val) {
            if (in_array($key, $blockSort)) {
                $class = "no-sort";
            }
            if (isset($params['styleHeader'][$key])) {
                $style = $params['styleHeader'][$key];
                $retval .= '<th class=' . $class . ' style=' . $style . '>' . $val . '</th>';
            } else {
                $retval .= '<th class=' . $class . ' >' . $val . '</th>';
            }
            $headerFields[] = $key;
        }

        $retval .='</tr></thead>';

        $retval .= '<tbody>';

        if (isset($params['records'])) {
            foreach ($params['records'] as $key => $val) {
                $retval .= '<tr>';

                if (isset($statusFunction) && !empty($statusFunction)) {
                    $statusfn = "toggleStatus('" . $statusFunction . "','" . $val[$params['pk_name']] . "')";
                }

                foreach ($val as $k => $v) {
                    if ($k != $params['pk_name']) {

                        if (!in_array($k, $headerFields))
                            continue;

                        switch ($k) {
                            case 'status':
                                $retval .= '<td align=left>';
                                $retval .= '<a href="javascript:;" title="' . $statusClass[$v] . '" ng-click="' . $statusfn . '">
                                                <i class="' . $statusIcon[$v] . '" id="status' . $val[$params['pk_name']] . '"></i>
                                            </a>';
                                $retval .= '</td>';
                                break;

                            default:
                                $retval .= '<td>' . $v . '</td>';
                                break;
                        }
                    }
                }

                if (isset($viewFunction) && !empty($viewFunction)) {
                    $fn = str_replace('{edit_id}', $val[$params['pk_name']], $viewFunction);
                    $retval .= '<td align=left>';
                    $retval .= '<a href="javascript:;" title="view" ng-click="' . $fn . '">
                                    <i class="infi-25-view"></i>
                                </a>';
                    $retval .= '</td>';
                }

                if (isset($editFunction) && !empty($editFunction)) {
                    $fn = str_replace('{edit_id}', $val[$params['pk_name']], $editFunction);
                    $retval .= '<td align=left>';
                    $retval .= '<a href="javascript:;" title="Edit" ng-click="' . $fn . '">
                                    <i class="infi-13-edit"></i>
                                </a>';
                    $retval .= '</td>';
                }

                if (isset($deleteFunction) && !empty($deleteFunction)) {
                    $fn = str_replace('{edit_id}', $val[$params['pk_name']], $deleteFunction);
                    $retval .= '<td align=left>';
                    $retval .= '<a href="javascript:;" title="Delete" ng-click="' . $fn . '">
                                    <i class="infi-23-delete"></i>
                                </a>';
                    $retval .= '</td>';
                }

                if (isset($params['action'])) {
                    $retval .= '<td align=center>';
                    foreach ($params['action'] as $res) {
                        $retval .= str_replace(array('{edit_id}'), $val[$params['pk_name']], $res);
                    }
                    $retval .= '</td>';
                }
                $retval .= '</tr>';
            }
        }
        $retval .= '</tbody>';

        echo $retval;
    }

    public function printArray($Inputarray) {
        echo '<pre>';
        print_r($Inputarray);
    }

    public function dumpVariable($Inputarray) {
        echo '<pre>';
        var_dump($Inputarray);
    }

    /*

     * Function Name :createQueryBox
     * Param : array
     * Description: Used Create tab heading
     * Author:SELVAKUMAR
     *      */

    public function createQueryBox($data) {
        $retVal = '';
        $content = '';
        $retVal .= '<ul class="nav nav-tabs custom-tab">';
        if (isset($data) && $data != '') {
            foreach ($data as $key => $value) {
                $retVal .= '<li><a ';
                if ($key == '1') {
                    $retVal .= 'class="active" ';
                }
                $retVal .='id="tabhead' . $key . '" rel="' . $key . '" href="javascript:;">' . $value . '</a></li>';
            }
        }
        $retVal .= '</ul>';
        echo $retVal;
    }

    public function createCorporateMenu($menuObject) {
        $_Stitle = json_decode($menuObject->subMenu);
        $_Sapplicationname = json_decode($menuObject->mainMenu);
        $_Slink = json_decode($menuObject->submenuOnClick);
        $_SimgClass = json_decode($menuObject->submenuOnClass);
        $_Iapplicationid = json_decode($menuObject->applicationId);
        $_SmapSubmenuId = json_decode($menuObject->subMenuId);
        $corporateMenu .= '<ul>';
        $homePageWrapper = "wrapperscript('showhomepageimages','')";
        $corporateMenu .= '<li><a href="javascript:;" id="applicationid0" class="home" ng-click="' . $homePageWrapper . '"><i class="fa fa-home"></i></a></li>';
        $count = 1;
        $countloop = 1;

        foreach ($_Iapplicationid as $key => $value) {
            $corporateMenu .= '<li><a href="javascript:;" id="applicationid' . $count . '" >' . $_Sapplicationname[$key] . '</a>';
            if ($_Stitle[$key] != '') {
                $corporateMenu .= '<ul class="submenu">';
                $subcount = 1;
                foreach ($_Stitle[$key] as $subKey => $subValue) {
                    $corporateMenu .= '<li><a href="javascript:;" id="submenuviewid' . $countloop . $subcount . '"';
                    if ($_SmapSubmenuId[$key][$subKey] == 0) {
                        $corporateMenu .= ' ng-click="' . $_Slink[$key][$subKey] . '"';
                    }
                    $corporateMenu .= '>';
                    $corporateMenu .='<i class="';
                    if ($_SimgClass[$key][$subKey] != '') {
                        $corporateMenu .= $_SimgClass[$key][$subKey];
                    } else {
                        $corporateMenu .= 'fa fa-user';
                    }
                    $corporateMenu .= '"></i>&nbsp' . $_Stitle[$key][$subKey] . '</a>';

                    if ($_SmapSubmenuId[$key][$subKey] != 0) {
                        $corporateMenu .= '<ul class="submenuchild">';
                        $mapsubcount = 1;
                        foreach ($_SmapSubmenuId[$key][$subKey] as $subChildKey => $value) {
                            $corporateMenu .= '<li><a href="javascript:;" ng-click="' . $_SmapSubmenuId[$key][$subKey][$subChildKey]->link . '">' . $_SmapSubmenuId[$key][$subKey][$subChildKey]->title . '</a></li>';
                            $mapsubcount = $count + 1;
                        }
                        $corporateMenu .= '</ul>';
                    }
                    $corporateMenu .= '</li>';
                    $subcount ++;
                }
                $corporateMenu .= '</ul>';
            }
            $corporateMenu .= '</li>';
            $count ++;
            $countloop ++;
        }
        $corporateMenu .= '</ul>';
        return $corporateMenu;
    }

    /*  
        method to create the back end menu functionality for back end
    */


    public function createMenuBackEnd($menu, $template, $stringVal = "", $parentSubMenu = 'N', $count, $menuorder=1, $child = false) {
        $checkReference = $template;
        $initialMenu    = $stringVal;
        $initialSubMenu = $parentSubMenu;
        $mainClass      = "";
        $hrefattr       = '';
        
        if (empty($count)) {
            $count = 0;
        }

        if ($count == 0)
            $mainClass = "nav navbar-nav custom-nav";
        
        else
            $mainClass = "dropdown-menu ";
        
        $stringVal.="<ul class='" . $mainClass . "'>";

        if ($mainClass == "nav navbar-nav custom-nav") {
            $homelink='wrapperScript("advOfflineBookingRequest","")';
            $stringVal.="<li class='home-icon'>
                        <a href='javascript:;' class='ng-scope' data-ng-click=".$homelink.">
                            <i class='fa fa-home' ></i>
                        </a>
                    </li>";
            /*$stringVal.='<li class="home-icon">
                        <a href="javascript:;" onclick="location.reload();">
                            <i class="fa fa-home"></i>
                        </a>
                    </li>';*/
        }

        foreach ($menu as $key => $value) {
            $count++;

            if (isset($value['menu_name']))
                $link = $value['menu_name'];

            if (isset($value['submenu_name']))
                $link = $value['submenu_name'];

            $additionalClassMenu = "";
            $additionalClass = "";
            $menuLinkAttr    = '';
            
            $linkIconClass = strtolower($link);
            $linkIconClass = preg_replace('/\s+/', '', $linkIconClass);
            
            if (isset($value['menu_link'])) {
                $onclick    = isset($value['menu_link']) && !empty($value['menu_link']) ? $value['menu_link'] : '';
                $moduleAction = 'ng-click="'.$onclick.'"';
            }
            if (isset($value['submenuArray']) && !empty($value['submenuArray'])) {
                $menuLinkAttr = ' class="dropdown-toggle '.$linkIconClass.'" data-toggle="dropdown" ';
                $additionalClass = " caret";
                $additionalClassMenu = "dropdown";
                $hrefattr = 'data-toggle="dropdown"';
            }

            if (isset($value['submenu_link'])) {
                $onclick      = isset($value['submenu_link']) && !empty($value['submenu_link']) ? $value['submenu_link'] : '';
                $moduleAction = 'ng-click="'.$onclick.'"';
            }

            if (isset($value['menu_link'])) {
                if ($onclick == 'NULL')
                {
                    $stringVal.='<li class="' . $additionalClassMenu .'"><a  title="' . $link . '" ' . $menuLinkAttr . ' tabindex="' . $count . '" >' . $link . '<span class=' . $additionalClass . '></span></a>';
                    $_SESSION['MENU_LINK'] = $link;
                }
                else
                {
                    $stringVal.='<li class="' . $additionalClassMenu . '"><a '.$moduleAction .'  title="' . $link . '" ' . $menuLinkAttr . ' tabindex="' . $count . '"> ' .$link. '<span class=' . $additionalClass . '></span></a>';
                }
            }

            if (isset($value['submenu_link'])) {
                if ($onclick == 'NULL')
                {
                    $stringVal.='<li class="' . $additionalClassMenu . '"><a tabindex="' . $count . '" '.$hrefattr.'> ' . $link. ' </a>';
                    $_SESSION['SUB_MENU_LINK'] = $link;
                }
                else
                {
                    if(isset($_SESSION['SUB_MENU_LINK']))
                    {
                        $sessionMenuLink = $_SESSION['MENU_LINK'];
                        $sessionSubMenuLink = $_SESSION['SUB_MENU_LINK'];
                        $breadCrumLink = "advCommonBreadCrums('".$sessionMenuLink."','".$sessionSubMenuLink."','".$link."'";
                        $stringVal.='<li class="'.$additionalClass.'"><a href="javascript:;" class = "quicklink-visible" tabindex="'.$count.'" '.$moduleAction.' onclick="'.$breadCrumLink.'"> '.$link .' <span class="quick-link infi-icon_9_quicklink"></span></a>';
                    }
                    else
                    {
                        $sessionMenuLink = $_SESSION['MENU_LINK'];
                        $breadCrumLink = "advCommonBreadCrums('".$sessionMenuLink."','".$link."')";  
                        $stringVal.='<li class="'.$additionalClass.'"><a href="javascript:;" class = "quicklink-visible" tabindex="'.$count.'" '.$moduleAction.' onclick="'.$breadCrumLink.'"> '.$link.' <span class="quick-link infi-icon_9_quicklink"></span></a>';
                    }
                }
            }

            if (isset($value['submenuArray']) && is_array($value['submenuArray'])) {
                $parentSubmenu = 'N';
                if (isset($value['parentSubmenu']) && $value['parentSubmenu'] == 'Y') {
                    $parentSubmenu = 'Y';
                }

                $stringVal .= $this->createMenu($value['submenuArray'], $template, '', $parentSubmenu, 2, $count, true);
                unset($_SESSION['SUB_MENU_LINK']);
            }

            $stringVal.="</li>";
        }

        $stringVal.="</ul>";
        
        if ($checkReference == "Y") {
            filewrite('second'.$stringVal, 'menu');
            return $stringVal;
        }
    }   

}

?>