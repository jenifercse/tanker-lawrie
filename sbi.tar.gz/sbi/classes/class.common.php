<?php

$currentFileDirPath = rtrim(dirname(__FILE__), "/\\");
$applicationPath = substr($currentFileDirPath, 0, strrpos($currentFileDirPath, DIRECTORY_SEPARATOR)) . DIRECTORY_SEPARATOR;

set_include_path($applicationPath);
//Require Files
require_once "config/config.inc.php";
require_once "config/config.commonConfig.php";
require_once "lib/system/fileRequire.php";
require_once "classes/class.baseModule.php";
require_once 'common/commonEncryptDecrypt.php';
class common {

    function _executeQuery($sql) {
        $resultArray = array();
        if (DB::isError($result = $this->_Oconnection->query($sql))) {
            fileWrite($sql, 'SqlError', 'a+');
            return false;
        }
        if ($result->numRows() > 0) {
            while ($row = $result->fetchRow(DB_FETCHMODE_ASSOC)) {
                $resultArray[] = $row;
            }
        }
        return $resultArray;
    }

    function multiArrayEncrypt($formvalue) {
        foreach ($formvalue as $key => $value) {
            if (is_array($value)) {
                $formvalue[$key] = $this->multiArrayEncrypt($value);
            } else {

                if (!$this->encriptCheck($key))
                    $formvalue[$key] = $this->decryptData($value);
            }
        }
        return $formvalue;
    }

    function encriptCheck($key) {
        global $CFG;
        $fieldArray = array();
        for ($i = 0; $i < count($fieldArray); $i++) {
            if ($fieldArray[$i] === $key) {
                return true;
            }
        }
        return false;
    }

    function decryptData($data) {

        if (empty($data)) {
            return $data;
        }

        $data = base64_decode($data);

        if (strlen($data) == 1) {
            return $data;
        }

        // kal6be8ai3 
        $data = substr($data, 0, substr($data, -1)) . substr($data, substr($data, -1) + 4);
        $data = substr($data, 0, strlen($data) - 1);
        return $data;
    }

    //function to encode a particular value
    function valueEncoder($idValue) {
        $encodedId = bin2hex($this->Encode($idValue));
        return $encodedId;
    }

    //Functin to decode a value
    function valueDecoder($encodedId) {
        $val = $this->hex2bin($encodedId);
        $decodedId = $this->Encode($val);
        return $decodedId;
    }

    //Encoder function	
    function Encode($data) {
        global $CFG;
        $pwd = $CFG['site']['encrypt_key'];
        $pwd_length = strlen($pwd);
        $j = $a = $x = 0;
        $Zcrypt = "";
        for ($i = 0; $i < 256; $i++) {
            $key[$i] = ord(substr($pwd, ($i % $pwd_length) + 1, 1));
            $counter[$i] = $i;
        }
        for ($i = 0; $i < 256; $i++) {
            $x = ($x + $counter[$i] + $key[$i]) % 256;
            $temp_swap = $counter[$i];
            $counter[$i] = $counter[$x];
            $counter[$x] = $temp_swap;
        }
        for ($i = 0; $i < strlen($data); $i++) {
            $a = ($a + 1) % 256;
            $j = ($j + $counter[$a]) % 256;
            $temp = $counter[$a];
            $counter[$a] = $counter[$j];
            $counter[$j] = $temp;
            $k = $counter[(($counter[$a] + $counter[$j]) % 256)];
            $Zcipher = ord(substr($data, $i, 1)) ^ $k;
            $Zcrypt .= chr($Zcipher);
        }
        return $Zcrypt;
    }

    function hex2bin($hexdata) {
        $bindata = "";
        for ($i = 0; $i < strlen($hexdata); $i+=2) {
            $bindata.=chr(hexdec(substr($hexdata, $i, 2)));
        }
        return $bindata;
    }

    function getIPAddress() {

        if (array_key_exists('HTTP_X_FORWARDED_FOR', $_SERVER)) {
            $ipAddress = array_pop(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']));
        } else {
            $ipAddress = $_SERVER['REMOTE_ADDR'];
        }
        return $ipAddress;
    }    

    /*
    * @Function Name   : _corporateCitySearch
    * @Description     : This method is used to call service to get hotel city list
    */

    function _corporateCitySearch() {
        switch ($this->_Smode) {
            case 'hotel':
                $url = $this->_url;
                break;
            case 'bus':
                $url = $this->_url;
                break;
            case 'train':
                $url = "http://preprodaws.atyourprice.net/AllWebServices2.0/webSearch2.1/webServiceSearch.php";
                break;
            case 'air':
                $url = SERVICE_AGENCY_URL;
                break;
        }

        $agent = SERVICE_AGENCY_ID;
        $data = array("data" => $this->_Adata, "mode" => $this->_Smode, 'agencyId' => SERVICE_AGENCY_ID,'requestId' => date('hdmy'));

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_USERAGENT, $agent);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
        curl_setopt($ch, CURLOPT_REFERER, $reffer);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file_path);
        curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie_file_path);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Authorization: ' . SERVICE_AGENCY_AUTHKEY . ''
        ));

        $content = curl_exec($ch);

        //$content = array("city_name"=>"Chennai", "airport_code"=>"MAA"); 
        return $content;
    }

    public static function _checkClassExistsInNameSpace($class, $travelMode = 'misc', $namespace = false) {
        
        //set default class name initially for false case handling
        $O_classObjectName = '\\' . $class;

        $travelMode = $travelMode . '/';

        if (defined('DEFAULT_PACKAGE_NAME') && defined('OVERRIDE_PACKAGE_NAME') && trim(DEFAULT_PACKAGE_NAME, '/') != OVERRIDE_PACKAGE_NAME) {
            //include class file from namespace
            if (pluginFileRequireByTravelMode("classes/class." . $class . ".php", false, $namespace)) {
                
                $O_classObjectName = !$namespace ? \OVERRIDE_PACKAGE_NAME . '\\' . $class : $namespace .'\\'.$class;
            } else if (pluginFileRequireByTravelMode("classes/class." . $class . ".php", true)) {
                
                $O_classObject = new $O_classObjectName;
            }

        }

        $O_classObject = new $O_classObjectName;
        return $O_classObject;
    }
    /**
    * function used for international flight search array formattion
    * @param 
    * @param  $data,$corporateFareCall,$amountCorporateFlow,$nonRefundableFlag
    * @param int $key
    * @return array
    * @author Baskar.V.P
    */
    public function _internationalSearchArrayFormation($data,$corporateFareCall,$amountCorporateFlow,$nonRefundableFlag,$lowFareLogicPlay,$bookingClass) {
        $responseKey = SERVICE_AGENCY_RESPONSEKEY;
        $mergedResponse = $this->_searchArrayFormation($data,$corporateFareCall,$amountCorporateFlow,$nonRefundableFlag,$lowFareLogicPlay,$bookingClass);
        $basedConvertData['data'] = base64_encode($this->aesEncryption($responseKey, base64_encode(gzencode(($mergedResponse)))));
        $basedConvertData['status_code'] = 200;
        return $basedConvertData;
    }

    /**
    * Function used for international flight search array formattion
    * @param 
    * @param  $data,$corporateFareCall,$amountCorporateFlow,$nonRefundableFlag
    * @param int $key
    * @return array
    * @author Vijaykeerthi R
    */
    public function _searchArrayFormation($data,$corporateFareCall,$amountCorporateFlow,$nonRefundableFlag,$lowFareLogicPlay,$bookingClass) {
        $convertedData = $this->responseArrayConversion($data);
        // to call function for array merging
        $mergedResponse = $this->arrayMergeInternationalData($convertedData,$corporateFareCall,$amountCorporateFlow,$nonRefundableFlag,$lowFareLogicPlay,$bookingClass);
        if($corporateFareCall == 'YES' || $lowFareLogicPlay == 'Y'){
            $mergedResponse = $this->_corporateFareRetailFareChecking($mergedResponse,$corporateFareCall);
        }

        return $mergedResponse;
    }

    /**
      @function name : encryption
      @function desc : decryption  data
      @parameter     : ..... (string),jsonString(json)
     * */
    public function aesDecryption($passphrase, $jsonString) {
        $jsondata = json_decode($jsonString, true);
        try {
            $salt = hex2bin($jsondata["s"]);
            $iv = hex2bin($jsondata["iv"]);
        } catch (Exception $e) {
            return null;
        }
        $ct = base64_decode($jsondata["ct"]);
        $concatedPassphrase = $passphrase . $salt;
        $md5 = array();
        $md5[0] = md5($concatedPassphrase, true);
        $result = $md5[0];
        for ($i = 1; $i < 3; $i++) {
            $md5[$i] = md5($md5[$i - 1] . $concatedPassphrase, true);
            $result .= $md5[$i];
        }
        $key = substr($result, 0, 32);
        $data = openssl_decrypt($ct, 'aes-256-cbc', $key, true, $iv);
        return json_decode($data, true);
    }
    /**
    * function used for  json   data
    * @param ......
    * @param  ...
    * @param int $key
    * @return array
    * @author Baskar.V.P
    */
    public function aesEncryption($passphrase, $value) {
        $salt = openssl_random_pseudo_bytes(8);
        $salted = '';
        $dx = '';
        while (strlen($salted) < 48) {
            $dx = md5($dx . $passphrase . $salt, true);
            $salted .= $dx;
        }
        $key = substr($salted, 0, 32);
        $iv = substr($salted, 32, 16);
        $encrypted_data = openssl_encrypt(json_encode($value), 'aes-256-cbc', $key, true, $iv);
        $data = array("ct" => base64_encode($encrypted_data), "iv" => bin2hex($iv), "s" => bin2hex($salt));
        return json_encode($data);
    }

   /**
    * function used for resoponse array conversion method
    * @param 
    * @param  $decodedData,$corporateFareCall,$amountCorporateFlow,$nonRefundableFlag
    * @param int $key
    * @return array
    * @author Baskar.V.P
    */
    public function responseArrayConversion($data){
        
        $responseKey = SERVICE_AGENCY_RESPONSEKEY;        
        if(is_array($data) && count($data) > 0){
            foreach ($data as $key => $value){
                //decode response data
                $decodeData = json_decode($value, 1);
                $basedConvertData[$key] = gzdecode(base64_decode($this->aesDecryption($responseKey, base64_decode($decodeData['data']))));
            }
        }
        else{
            //decode response data
            $decodeData = json_decode($data, 1);
            $basedConvertData = gzdecode(base64_decode($this->aesDecryption($responseKey, base64_decode($decodeData['data'])))); 
        }
        return $basedConvertData;
    }

    /**
    * function used array merging the reponse once the respone from web service
    * @param 
    * @param  $decodedData,$corporateFareCall,$amountCorporateFlow,$nonRefundableFlag
    * @param int $key
    * @return array
    * @author Baskar.V.P
    */

    public function arrayMergeInternationalData($decodedData,$corporateFareCall,$amountCorporateFlow,$nonRefundableFlag,$lowFareLogicPlay,$bookingClass) {
    	global $CFG;
        $finalResponse = array();
        $tripType = '';
        foreach ($decodedData as $key => $value) {
            $decodRes = json_decode($value, 1);
            if ($decodRes[0] != 'EMPTY') {
                // to remove non refundable fare based on corporate settings
                if($nonRefundableFlag == 'NO'){
                foreach ($decodRes as $decodReskey => $decodResvalue) {
                    if($decodResvalue['via_flights'][0]['faretype_code']== 'NR'){
                        unset($decodRes[$decodReskey]);
                        }
                    }
                } 
                foreach ($decodRes as $decodReskey => $decodResvalue) {
                    $finalResponse["faretype"][] = $decodResvalue['via_flights'][0]['faretype_code'];
                    $finalResponse["airlines"][$decodReskey]['airline_code'] = $decodResvalue['via_flights'][0]['airline_code'];
                    $finalResponse["airlines"][$decodReskey]['airline_name'] = $decodResvalue['via_flights'][0]['airline_name'];
                    $finalResponse["stops"][] = $decodResvalue['stops'];
                    if ($tripType == '') {
                        $tripType = $decodResvalue['trip_type'];
                    }
                    foreach ($decodResvalue['via_flights'] as $key => $value) {
                        $decodResvalue['via_flights'][$key]['trip_type'] ? $decodResvalue['via_flights'][$key]['trip_type'] : 'R';
                    }
                    $viaFlights = array();
                    foreach ($decodResvalue['via_flights'] as $vk => $vv) {
                        $viaFlights[$vv['trip_type']][] = $vv;
                        $decodRes[$decodReskey][$vv['trip_type']]['totalTravelTime'] = $viaFlights[$vv['trip_type']][count($viaFlights[$vv['trip_type']]) - 1]['travel_time'];
                        $decodResTota = $viaFlights[$vv['trip_type']][count($viaFlights[$vv['trip_type']]) - 1]['total_time'];
                        $fromDate = $viaFlights[$vv['trip_type']][0]['departure_date'];
                        $fromTime = $viaFlights[$vv['trip_type']][0]['time_departure'];
                        $toDate = $viaFlights[$vv['trip_type']][count($viaFlights[$vv['trip_type']]) - 1]['arrival_date'];
                        $toDateTime = $viaFlights[$vv['trip_type']][count($viaFlights[$vv['trip_type']]) - 1]['time_arrival'];

                        $dateTime = $fromDate . ' ' . $fromTime;
                        $returDateTime = $toDate . ' ' . $toDateTime;
                        if ($vv['trip_type'] == 'R') {
                            $decodResvalue['returntotalTravelTime'] = $viaFlights[$vv['trip_type']][count($viaFlights[$vv['trip_type']]) - 1]['total_time'] ;//$this->totalTravelTime($dateTime, $returDateTime);
                             $decodResvalue['returntotalTravelTime'] = $this->convertTimeFromGMT($viaFlights[$vv['trip_type']]); //$this->totalTravelTime($dateTime, $returDateTime);
                             $viaFlights[$viaFlights[$vv['trip_type']]][count($viaFlights[$vv['trip_type']])-1]["total_time"]= $decodResvalue['returntotalTravelTime'];
                        } else {
                            $decodResvalue['onwardtotalTravelTime'] = $viaFlights[$vv['trip_type']][count($viaFlights[$vv['trip_type']]) - 1]['total_time']; //$this->totalTravelTime($dateTime, $returDateTime);
                             $decodResvalue['onwardtotalTravelTime'] = $this->convertTimeFromGMT($viaFlights[$vv['trip_type']]); //$this->totalTravelTime($dateTime, $returDateTime);
                             $viaFlights[$viaFlights[$vv['trip_type']]][count($viaFlights[$vv['trip_type']])-1]["total_time"]= $decodResvalue['onwardtotalTravelTime'];
                        }
                        $decodResvalue[$decodResvalue][$decodReskey][$vv['trip_type']]['totalTravelTime'] = $this->totalTravelTime($dateTime, $returDateTime);
                    }
                    $decodResvalue['via_flights'] = $viaFlights;
                    $resulDiff = $this->dayDifference($fromDate, $toDate);
                    $decodResvalue['daysDifference'] = $resulDiff->days;
                    $onwardflightnumberkey = "";
                    foreach ($decodResvalue['via_flights']['O'] as $ok => $ov) {
                        $onwardflightnumberkey = $onwardflightnumberkey . $ov['airline_code'] . $ov['flight_number'];
                        if($ok != 0){
                            $decodResvalue['connectingDataArrayO'][$ok]= $ov['airline_code'].'-'.$ov['flight_number'];
                        }
                    }
                    $reslValueOnward = array_unique($decodResvalue['connectingDataArrayO']);
                    $decodResvalue['connectingDataO'] = implode(' / ',$reslValueOnward);
                    $returnflightnumberkey = "";
                    foreach ($decodResvalue['via_flights']['R'] as $rk => $rv) {
                        $returnflightnumberkey = $returnflightnumberkey . $rv['airline_code'] . $rv['flight_number'];
                        if($rk != 0){
                            $decodResvalue['connectingDataArrayR'][$rk]= $rv['airline_code'].'-'.$rv['flight_number'];
                        }
                    }
                    
                    $decodResvalue['classShow'] = $decodResvalue['via_flights']['O'][0]['cabin_class'] ? strtolower($decodResvalue['via_flights']['O'][0]['cabin_class']) : strtolower($decodResvalue['via_flights']['R'][0]['cabin_class']);


                    $reslValueReturn = array_unique($decodResvalue['connectingDataArrayR']);
                    $decodResvalue['connectingDataR'] = implode(' / ',$reslValueReturn);

                    $groupingCode = base64_encode($onwardflightnumberkey . $returnflightnumberkey . $decodResvalue['time_departure'] . $decodResvalue['time_arrival'] . $decodResvalue['return_time_departure'] . $decodResvalue['return_time_arrival'] . $decodResvalue['date_departure'] . $decodResvalue['return_date_departure']);
                    //Check for the code already exist
                    if(array_search($groupingCode, $groupingCodes)==FALSE){
                        $groupingCodes[] = $groupingCode;
                    }
                    $key = array_search($groupingCode, $groupingCodes);

                    $fareCode = $decodResvalue['via_flights']['O'][0]['faretype_code'] ? $decodResvalue['via_flights']['O'][0]['faretype_code'] : $decodResvalue['via_flights']['R'][0]['faretype_code'];
                  
                    //IOCL LOGIC PLAYS
                    // start
                    foreach($decodResvalue['passenger_fare'] as $paxFareKey => $paxFareValue){
                        $totalAmount = $paxFareValue['base_fare'] + $paxFareValue['tax'];
                    }
                    $fareCompare = $finalResponse['data'][$key]['responseArray'][$fareCode]['base_fare'] + $finalResponse['data'][$key]['responseArray'][$fareCode]['tax'];
                    if($fareCompare == 0 || $bookingClass == 'B'){
                            if(($corporateFareCall == 'YES' || $lowFareLogicPlay == 'Y') && in_array($finalResponse["airlines"][$decodReskey]['airline_code'], $CFG['LCC_AIRLINES']) && in_array($fareCode,$CFG['FARE_CODE']))
                            {
                                $amountCorporateFlowFinal = (int)$amountCorporateFlow;
                            }
                            else
                            {
                                $amountCorporateFlowFinal = 0 ;
                            }
                            $decodResvalue['amountCal'] = $amountCorporateFlowFinal;
                            $finalResponse["data"][$key]['responseArray'][$fareCode] = $decodResvalue;
                            //assigning value for 250 for ongc corporate
                            $finalResponse["data"][$key]['sortArray'][$fareCode."_newTotalFare"] = 0;
                            $finalResponse["data"][$key]['newTotalFare'.$fareCode] = 0;
                            $finalResponse["data"][$key]['finalTotalAmount'] = 0;
                            foreach($decodResvalue['passenger_fare'] as $paxFareKey => $paxFareValue){
                                $finalResponse["data"][$key]['finalTotalAmount'] =  $paxFareValue['base_fare'] + $paxFareValue['tax'];
                                $totalAmount = $paxFareValue['base_fare'] + $paxFareValue['tax'] + $amountCorporateFlowFinal;
                                $finalResponse["data"][$key]['sortArray'][$fareCode."_newTotalFare"] += $totalAmount;
                                $finalResponse["data"][$key]['newTotalFare'.$fareCode] += $totalAmount;
                            }                  
                            /* SETTING CORPORATE VS REFUNDABLE FARE END */
                            $countVariable = $decodResvalue['via_flights']['O'] ? count($decodResvalue['via_flights']['O']) -1 : count($decodResvalue['via_flights']['R']) - 1; 
                            $finalResponse["data"][$key]['time_arrival'] = $decodResvalue['via_flights']['O'][$countVariable]['time_arrival'] ? $decodResvalue['via_flights']['O'][$countVariable]['time_arrival'] : $decodResvalue['via_flights']['R'][$countVariable]['time_arrival'] ;
                            $finalResponse["data"][$key]['uniqid'] = false;
                            $finalResponse["data"][$key]['time_departure'] = $decodResvalue['time_departure'];
                            $finalResponse["data"][$key]['duration'] = $decodResvalue['onwardtotalTravelTime'];
                            $finalResponse["data"][$key]['classShow'] = $decodResvalue['classShow'];
                    }else{
                        if($totalAmount < $fareCompare){
                            if(($corporateFareCall == 'YES' || $lowFareLogicPlay == 'Y') && in_array($finalResponse["airlines"][$decodReskey]['airline_code'], $CFG['LCC_AIRLINES']) && in_array($fareCode,$CFG['FARE_CODE']))
                            {
                                $amountCorporateFlowFinal = (int)$amountCorporateFlow;
                            }
                            else
                            {
                                $amountCorporateFlowFinal = 0 ;
                            }
                            $decodResvalue['amountCal'] = $amountCorporateFlowFinal;
                            $finalResponse["data"][$key]['responseArray'][$fareCode] = $decodResvalue;
                            //assigning value for 250 for ongc corporate
                            $finalResponse["data"][$key]['sortArray'][$fareCode."_newTotalFare"] = 0;
                            $finalResponse["data"][$key]['newTotalFare'.$fareCode] = 0;
                            $finalResponse["data"][$key]['finalTotalAmount'] = 0;
                            foreach($decodResvalue['passenger_fare'] as $paxFareKey => $paxFareValue){
                                $finalResponse["data"][$key]['finalTotalAmount'] =  $paxFareValue['base_fare'] + $paxFareValue['tax'];
                                $totalAmount = $paxFareValue['base_fare'] + $paxFareValue['tax'] + $amountCorporateFlowFinal;
                                $finalResponse["data"][$key]['sortArray'][$fareCode."_newTotalFare"] += $totalAmount;
                                $finalResponse["data"][$key]['newTotalFare'.$fareCode] += $totalAmount;
                            }                  
                            /* SETTING CORPORATE VS REFUNDABLE FARE END */
                            $countVariable = $decodResvalue['via_flights']['O'] ? count($decodResvalue['via_flights']['O']) -1 : count($decodResvalue['via_flights']['R']) - 1; 
                            $finalResponse["data"][$key]['time_arrival'] = $decodResvalue['via_flights']['O'][$countVariable]['time_arrival'] ? $decodResvalue['via_flights']['O'][$countVariable]['time_arrival'] : $decodResvalue['via_flights']['R'][$countVariable]['time_arrival'] ;
                            $finalResponse["data"][$key]['uniqid'] = false;
                            $finalResponse["data"][$key]['time_departure'] = $decodResvalue['time_departure'];
                            $finalResponse["data"][$key]['duration'] = $decodResvalue['onwardtotalTravelTime'];
                            $finalResponse["data"][$key]['classShow'] = $decodResvalue['classShow'];
                        }
                    }



                    /* SETTING CORPORATE VS REFUNDABLE FARE */
                    // settings data finally to finalResponse
                    // if($corporateFareCall == 'YES' && in_array($finalResponse["airlines"][$decodReskey]['airline_code'], $CFG['LCC_AIRLINES']) && in_array($fareCode,$CFG['FARE_CODE']))
                    // {
                    //     $amountCorporateFlowFinal = (int)$amountCorporateFlow;
                    // }elseif($amountCorporateFlow !=0 && in_array($finalResponse["airlines"][$decodReskey]['airline_code'], $CFG['ALL_AIRLINES']) && in_array($fareCode,$CFG['FARE_CODE']))
                    //     {
                    //         $amountCorporateFlowFinal =  (int)$amountCorporateFlowFinal;
                    //     }else{
                    //             $amountCorporateFlowFinal = 0 ;
                    //     }
                    // $decodResvalue['amountCal'] = $amountCorporateFlowFinal;
                    // $finalResponse["data"][$key]['responseArray'][$fareCode] = $decodResvalue;
                    // //assigning value for 250 for ongc corporate
                    // $finalResponse["data"][$key]['sortArray'][$fareCode."_newTotalFare"] = 0;
                    // $finalResponse["data"][$key]['newTotalFare'.$fareCode] = 0;
                    // $finalResponse["data"][$key]['finalTotalAmount'] = 0;
                    // foreach($decodResvalue['passenger_fare'] as $paxFareKey => $paxFareValue){
                    //     $finalResponse["data"][$key]['finalTotalAmount'] =  $paxFareValue['base_fare'] + $paxFareValue['tax'];
                    //     $totalAmount = $paxFareValue['base_fare'] + $paxFareValue['tax'] + $amountCorporateFlowFinal;
                    //     $finalResponse["data"][$key]['sortArray'][$fareCode."_newTotalFare"] += $totalAmount;
                    //     $finalResponse["data"][$key]['newTotalFare'.$fareCode] += $totalAmount;
                    // }                  
                    // /* SETTING CORPORATE VS REFUNDABLE FARE END */
                    // $countVariable = $decodResvalue['via_flights']['O'] ? count($decodResvalue['via_flights']['O']) -1 : count($decodResvalue['via_flights']['R']) - 1; 
                    // $finalResponse["data"][$key]['time_arrival'] = $decodResvalue['via_flights']['O'][$countVariable]['time_arrival'] ? $decodResvalue['via_flights']['O'][$countVariable]['time_arrival'] : $decodResvalue['via_flights']['R'][$countVariable]['time_arrival'] ;
                    // $finalResponse["data"][$key]['uniqid'] = false;
                    // $finalResponse["data"][$key]['time_departure'] = $decodResvalue['time_departure'];
                    // $finalResponse["data"][$key]['duration'] = isset($decodResvalue['onwardtotalTravelTime']) ? $decodResvalue['onwardtotalTravelTime'] : $decodResvalue['returntotalTravelTime'];
                }
            }
        }
        // assigning fare type for the flght response
        if (count($finalResponse["faretype"]) != 0) {
            $finalResponse["faretype"] = array_values(array_unique($finalResponse["faretype"]));
        }
        // assigning airline for the flght response
        if (count($finalResponse["airlines"]) != 0) {
            $finalResponse["airlines"] = array_values(array_map("unserialize", array_unique(array_map("serialize", $finalResponse["airlines"]))));
        }
        // assigning stops for the flght response
        if (count($finalResponse["stops"]) != 0) {
            $finalResponse["stops"] = array_values(array_unique($finalResponse["stops"]));
        }
        // return value if count > 0 true means return flight response esle return empty
        return (count($finalResponse) != 0) ? json_encode($finalResponse) : json_encode(array("EMPTY"));
    }
    
    /**
    * function used to check day difference for the particular from and to date
    * @param 
    * @param array $otp
    * @param int $key
    * @return array
    * @author Baskar.V.P
    */
    public function dayDifference($fromDate, $toDate) {
        $from = date_create($fromDate);
        $to = date_create($toDate);
        $diff = date_diff($to, $from);
        return $diff;
    }
    /**
    * function used to check OTP 
    * @param 
    * @param array $otp
    * @param int $key
    * @return array
    * @author Baskar.V.P
    */
    
    public function totalTravelTime($fromDate, $toDate) {
        $dateDiff = intval((strtotime($toDate) - strtotime($fromDate)) / 60);
        $hours = intval($dateDiff / 60);
        $minutes = $dateDiff % 60;
        return $hours . 'h' . ' ' . $minutes . 'm';
    }

    /**
    * function used to check OTP 
    * @param 
    * @param array $otp
    * @param int $key
    * @return array
    * @author Baskar.V.P
    */

    public function _setOtp() {
        require_once 'classes/class.commonDBO.php';
        require_once 'lib/common/commonMethods.php';
        require_once 'classes/class.framework.php';
        fileRequire("lib/system/twiginit.php");
        $this->_Otwig = init($applicationPath);
        $this->_OcommonDBO = new commonDBO();
        $rand =$this->_generateRandomString(5);
        $tableName = 'database_access_key';
        $cur_time = date("Y-m-d H:i:s");
        // before insert checking for present or not
        $field = array('start_date_time', 'end_date_time');
        $sqlData = "SELECT * FROM database_access_key ORDER BY database_access_key_id DESC LIMIT 1";
        $resultSelected = $this->_OcommonDBO->_getResult($sqlData)[0];
        if ((strtotime($resultSelected['start_date_time']) <= strtotime($cur_time)) && (strtotime($cur_time) <= strtotime($resultSelected['end_date_time']))) {
            return true;
        } else {
            // end date and time
            $duration = '+10 minutes';
            $enddate = date('Y-m-d H:i:s', strtotime($duration, strtotime($cur_time)));
            $insertArray ['otp'] = $rand;
            $insertArray ['start_date_time'] = $cur_time;
            $insertArray ['end_date_time'] = $enddate;
            $insertValue = $this->_OcommonDBO->_insert($tableName, $insertArray);
            $this->_OcommonMethods = new commonMethods();
            $this->_AtwigOutputArray['otp'] = $rand;
            $this->_AtwigOutputArray['startTime'] = $insertArray ['start_date_time'];
            $this->_AtwigOutputArray['endTime'] = $insertArray ['end_date_time'];
            $this->_AtwigOutputArray['hostName'] = $_SERVER['HTTP_HOST'];
            $_Stemplate = $this->_Otwig->render('otpEmail.tpl', $this->_AtwigOutputArray);
            $from = 'support@atyourprice.in';
            $sendMail = $this->_OcommonMethods->_sendMail($mail, $from, 'OTP For Adminer', $_Stemplate);
            return false;
        }
    }
        
    /**
    * function used to check OTP 
    * @param 
    * @param array $otp
    * @param int $key
    * @return array
    * @author Baskar.V.P
    */

    public function _checkOtp($otp) {
        require_once 'classes/class.commonDBO.php';
        require_once 'classes/class.framework.php';
        fileRequire("lib/system/twiginit.php");
        $this->_OcommonDBO = new commonDBO();
        $field = array('otp');
        $result = $this->_OcommonDBO->_select('database_access_key', $field, 'otp', $otp)[0];
        return $result == '' ? false : true;
    }

    /*
     * @description     :  set http response code in response header
     * @params          :  int|$statusCode
     * @returnType      :  
     */

    public static function _setHeaderResponseCode($statusCode) {

        if ($statusCode != '') {
            http_response_code($statusCode);
            
            switch ($statusCode) {
                //forbidden custom error
                case 403 : 
                    echo file_get_contents(APPLICATION_BASE_PATH.'view/common/html/common/forbidden.html');
                    break;
                
                default :
                    
            }
        }
    }

    /*
     * @description     :  create js file to store csrf token
     * @params          :  string|$csrfToken
     * @returnType      :  bool|$returnValue
     */

    public static function _createCSRFFile($csrfToken = '') {

        $returnValue = false;

        if ($csrfToken != '') {
            $csrfContent = "localStorage.xctaa ='" . $csrfToken . "'";
            $filename   = APPLICATION_BASE_PATH . 'lib/script/angular/config/' . INDEXNAME . '/xctaa.txt';
            $fh = fopen($filename, 'w');
            $returnValue = fwrite($fh, $csrfContent);
        }

        return $returnValue;
    }

    /*
     * @description     :  function to compare time difference
     * @params          :  string|$datePast
     * @params          :  string|$dateFuture
     * @params          :  string|$diffUnit
     * @returnType      :  string|$returnValue
     */

    public function compareTimeDiff($datePast, $dateFuture, $diffUnit = 'i') {

        $returnValue = false;

        if ($datePast != '' && $dateFuture != '') {
            $datetime1 = new DateTime(strtotime($datePast));
            $datetime2 = new DateTime(strtotime($dateFuture));
            $interval = $datetime1->diff($datetime2);
            $returnValue = $interval->format('%R%' . $diffUnit);
        }
        return $returnValue;
    }
    
    /**
     * Ajax encryption for request data will be done
     * @param json $jsonData Data to be posted over the request
     * @return string
     * @author Vijaykeerthi R
     */
    public function doAjaxEncryption($jsonData) {
        
        return $data = (AJAXENCYPT == 'Y') ? base64_encode(gzcompress($this->aesEncryption(AJAXENCYPTSALT, $jsonData), 9)) : $jsonData;
    }
    
    /**
     * Ajax decryption for response data will be done
     * @param type $encryptedData
     * @return type
     * @author Vijaykeerthi R
     */
    public function doAjaxDecryption($encryptedData) {
        
        return (AJAXENCYPT=='Y')?$this->aesDecryption(AJAXENCYPTSALT,base64_decode($encryptedData)):$encryptedData;
    }

    /**
     * Convers date string into valid date
     * @param string $date Date Ymd format
     * @return string
     */
    public function _convertSAPDate($date) {
        
        $Year = substr($date, 0,4);
        $month = substr($date, 4,2);
        $dateNo = substr($date, 6,2);
        $strDate = $Year.'-'.$month.'-'.$dateNo;
        
        return $strDate;
    }
    
    /**
     * Convers date string into valid time
     * @param string $time Time His format
     * @return string
     */
    public function _convertSAPTime($time) {
        $hr = substr($time, 0,2);
        $min = substr($time, 2,2);
        //$sec = substr($time, 4,2);
        $strTime = $hr.':'.$min.':'.$sec;
        
        return $strTime;
    }
    /**
    * function used to compare corporate vs retail fare checking
    * @param 
    * @param array $requestDetails
    * @param int $key
    * @return array
    * @author Baskar.V.P
    */
    public function _corporateFareRetailFareChecking($response,$corporateFareCall){
       $convertedResponse = json_decode($response,1);
       foreach($convertedResponse['data'] as $key => $value){
            if(count($convertedResponse['data'][$key]['sortArray'])>1){
                //asort to sort the array based on order of the array
                asort( $convertedResponse['data'][$key]['sortArray']); 
                $explodeValue = array_keys($convertedResponse['data'][$key]['sortArray']);
                // removing the first key of the array to avoid removing array from the corresponding index 
                $foundValue =$explodeValue[0];
                unset($explodeValue[0]);

                // function to explode the array value and finding key in a array to to remove that particular key
                foreach ($explodeValue as $inerkey => $value) {
                    $implodeStr = explode("_",$value)[0];
                    // removing the array from the data respone array 
                    unset($convertedResponse['data'][$key]['responseArray'][$implodeStr]) ;
                    unset($convertedResponse['data'][$key]['newTotalFare'.$implodeStr]);
                }
                if($corporateFareCall != 'YES'){
                    $convertedResponse['data'][$key]['responseArray'][explode("_",$foundValue)[0]]['amountCal'] = 0;
                }
            }
        }
       return (count($convertedResponse) != 0) ? json_encode($convertedResponse) : json_encode(array("EMPTY"));
    }
    
    
    /*@desc  Function used to form the array formation for the response.
    * @param $data,$inputData,$requestData,$itineraryInfo | array
    * @return $response | array
    * @author Karthika.M
    */
    public function _mealBaggageArrayFormation($data,$inputData,$requestData,$itineraryInfo){
        
        global $CFG;        
        //object creation
        $this->_OssrDetails = new ssrResponseDetails();        
        
        //set inputs
        $responseKey = SERVICE_AGENCY_RESPONSEKEY;
        $orderId = explode(":",$inputData)[1];
        $flightKey = explode(":",$inputData)[2];
        
        //decrypted the response array.
        foreach($data as $value){            
            $statusCode[] = json_decode($value,1)['status_code'];
        }
        
        //decrypt the encrypted response.
        $basedConvertData = $this->responseArrayConversion($data);  
        fileWrite("REQUEST DATA-->".print_r(json_encode($requestData,1),1),"MealBaggageLog_".$orderId,"a+"); 
        fileWrite("statusCode--->".print_r($statusCode,1),"MealBaggageLog_".$orderId,"a+");  
        fileWrite("FIRST RESPONSE DATA-->".print_r($basedConvertData,1),"MealBaggageLog_".$orderId,"a+"); 
        
        //set parameters.
        $getData['data'] = $data;
        $getData['inputData'] = $inputData;
        $getData['requestData'] = $requestData;
        $getData['itineraryInfo'] = $itineraryInfo;
        $getData['basedConvertData'] = $basedConvertData;
        
        //checking the status code.
        if(!in_array(0,$statusCode) || $getData['basedConvertData'][0] == 'EMPTY'){
            $mealBaggageDetails = array();
            $response['status_code'] = 1;
            $response['message'] = $basedConvertData;
        }
        else{ 
            //if response is success, forming the array with respect to the response,           
            $mealBaggageDetails = $this->_OssrDetails->_formingMealBaggageArray($getData);
            $response['status_code'] = (count($mealBaggageDetails) > 0) ? 0 :1;
        }       
        //finally set the meal baggage info based on the array count.
        $mealBaggageDetails = (count($mealBaggageDetails) > 0) ? json_encode($mealBaggageDetails) : json_encode(array("EMPTY"));       
        fileWrite("FINAL RESPONSE DATA-->".print_r($mealBaggageDetails,1),"MealBaggageLog_".$orderId,"a+");  
                
        //forming the response array.(encrypt the array)
        $response['data'] = base64_encode($this->aesEncryption($responseKey, base64_encode(gzencode(($mealBaggageDetails)))));        
        
        //get the key of error response.
        $messageKey = array_search(1,$statusCode);        
        if($messageKey || $messageKey == 0){
            //set the message in response.
            $response['message'] = $basedConvertData[$messageKey];
        }
        //set the ssr settings info from the config.
        $response['SSR_SETTINGS'] = json_decode($CFG['SSR_SETTINGS'],true);
        fileWrite("RESPONSE".print_r($response,1),"MealBaggageLog_".$orderId,"a+");
        return $response;
    }

    public function _getWebservicesResult($encrypt, $appType='web'){

        //set flag and inputs
        $encryptData   = $encrypt['data'];
        $corporateFlag = $encrypt['corporateFlag'];

        //service calling for meal and baggage only.
        if ($encrypt['serviceType'] == 'MEAL_BAGGAGE') {

            //set the inputs
            $requestType = $encrypt['serviceType'];
            $requestData = $encrypt['requestData'];
            $inputData = $encrypt['serviceInput'];
            $itineraryInfo = $encrypt['itineraryInfo'];
            $encryptData = json_decode($encrypt['data'], 1);
        } 
        else if ($encrypt['serviceType'] == 'VENDOR_HOTEL' || $encrypt['serviceType'] == 'HOTELSEARCH') {
            //set the inputs
            $requestType = $encrypt['serviceType'];
        }

        //set flag for fare type.
        $nonRefundableFlag = $encrypt['nonRefundableFare'];

        //multicurl initialization
        $mh = curl_multi_init();
        $ch = array();
        $url = array();
        $result = array();

        foreach ($encryptData as $key => $value) {

            if ($key != "airline_code" || $requestType == 'MEAL_BAGGAGE' || $requestType == 'HOTELSEARCH' ):
                
                $mode = ($encrypt['serviceType'] == 'VENDOR_HOTEL' || $encrypt['serviceType'] == 'HOTELSEARCH' )? 'hotel' : 'air';

                //set airline code
                $url[$key] = SERVICE_AGENCY_URL;
                if($itineraryInfo['viaInfo'][$key]['service_provider_id'] == "TP") { 

                    $data['agencyCode'] = SERVICE_AGENCY_ID; 
                    $data['serviceName'] = sprintf("GETSSRAVAILABILITY_TRAVELPORT_AIR_RF_V%s",$itineraryInfo['viaInfo'][$key]['operating_airline_code']);
                    $url[$key] = SERVICE_AGENCY_URL_2T; 
                }
            
                //set data
                $data = array("data" => $encryptData[$key], "mode" => $mode, 'agencyId' => SERVICE_AGENCY_ID, 'requestId'=>strtotime("now"));

                $ch[$key]  = curl_init();
                curl_setopt($ch[$key], CURLOPT_URL, $url[$key]);
                curl_setopt($ch[$key], CURLOPT_USERAGENT, $agent);
                curl_setopt($ch[$key], CURLOPT_POSTFIELDS, $data);
                curl_setopt($ch[$key], CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch[$key], CURLOPT_FOLLOWLOCATION, 1);
                curl_setopt($ch[$key], CURLOPT_ENCODING, 'gzip');
                curl_setopt($ch[$key], CURLOPT_REFERER, $reffer);
                curl_setopt($ch[$key], CURLOPT_SSL_VERIFYPEER, 0);
                curl_setopt($ch[$key], CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch[$key], CURLOPT_HEADER, 0);
                curl_setopt($ch[$key], CURLOPT_HTTPHEADER, array(
                    'Requestauthorization: ' . SERVICE_AGENCY_AUTHKEY
                ));
                curl_multi_add_handle($mh, $ch[$key]);
            endif;
        }
        $running = null;

        do {
            curl_multi_exec($mh, $running);
            curl_multi_select($mh);
        } while ($running > 0);
        // get content and remove handles
        foreach ($ch as $a => $c) {
            $result[$a] = curl_multi_getcontent($c);
            $error[$a] = curl_error($c);
            curl_multi_remove_handle($mh, $c);
        }
        curl_multi_close($mh);

        //array formation with respect to the response for corresponding service
        if ($requestType == 'MEAL_BAGGAGE') {
            $_Jcontent = $this->_mealBaggageArrayFormation($result, $inputData, $requestData, $itineraryInfo);
        } else if ($requestType == 'VENDOR_HOTEL') {
            $_Jcontent = $result;

        } else if($appType =='mobile') {
            $_Jcontent = $this->_searchArrayFormation($result, $corporateFlag, CORPORATEFARELOW, $nonRefundableFlag);
        }
        else if($requestType == 'HOTELSEARCH'){
            $_Jcontent = $result; //$this->_setHotelResponeData($result);
        }
         else {
            $_Jcontent = $this->_internationalSearchArrayFormation($result, $corporateFlag, CORPORATEFARELOW, $nonRefundableFlag);
        }
        return $_Jcontent;
    }

	/**
     * @function    : _insertMobileLogDetails
     * @description : this function used to compress and insert mobiles service details in mobile_search_log table
     * @param       : $insertValues | Array
     * @return      : $insertedId | int
     * @author      : puroskhan.m
     */
    public function _insertMobileLogDetails($insertValues){
        $sql="INSERT INTO mobile_search_log
                (order_id,
                package_id,
                request_details,
                response_details,
                created_date)
                VALUES
                   ('"
                     .$insertValues['order_id']."',
                    ".$insertValues['package_id'].",
                    "."COMPRESS('".$insertValues['request_details']."'),
                    "."COMPRESS('".$insertValues['response_details']."'),
                    "."now())";
           $this->_OcommonDBO = new commonDBO();
           $insertedId = $this->_OcommonDBO->_executeQuery($sql);
           return $insertedId;
    }
    
    /**
    * @Description : Function to generate ....
    * @param type $length
    * @return type
    */
    public function _generateRandomString($length = 8,$type='STRING'){
        if($type == 'STRING'){  
           $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*"; 
        }  
        else{ 
           $chars = 1234567890;
        }    
        $requiredVal = substr(str_shuffle($chars),0,$length);
        return $requiredVal;
    }
   
    /**
    * @Description : Function used to remove the lf cf characters from the string ....
    * @param string $string
    * @return string 
    */
    public function _removeLFCFCharacters($string){        
        $search = array("\r\n","\n","\r"," ");
        $replace = '';        
        return str_replace($search,$replace,$string);
    }
       
       /**
        * @Description : Function to generate encrypted string 
        * @param ----
        * @return type | String
        */
       public function _generateEncryptionString($length = 8) {
           $mixedString=$this->_generateRandomString($length);
           $encryptData=commonEncryptDecrypt::_encryptData($mixedString);
           return $encryptData;
       }

       /**
        * function used to call sap service sync
        *
        * @param array $_Adata
        * @param string $_SserviceName
        * @return array
        */
        public function _sapSyncService($_Adata, $_SserviceName){

            $_Asapsyncdata = array("data" => $_Adata, "serviceName" => $_SserviceName, "mode" => "SAP", 'agencyCode' => SERVICE_AGENCY_ID, 'requestId' => date('hdmy'));

            fileWrite(print_r($_Asapsyncdata,1),'SAP_SYNC','a+');

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, SERVICE_AGENCY_SAP_URL);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $_Asapsyncdata);
            curl_setopt($ch, CURLOPT_USERAGENT, SERVICE_AGENCY_ID);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
            curl_setopt($ch, CURLOPT_REFERER, $reffer);
            curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file_path);
            curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie_file_path);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Authorization: ' . SERVICE_AGENCY_AUTHKEY . ''
            ));

            $content = curl_exec($ch);
            fileWrite(print_r($content,1),'SAP_SYNC','a+');
            return $content;
        }   

        public function convertTimeFromGMT($tempViaFlightArray,$type="string"){
            $startGMT = $tempViaFlightArray[0]["origin_airport_details"]["offset"];
            $endGMT = $tempViaFlightArray[count($tempViaFlightArray)-1]["dest_airport_details"]["offset"];

            $startDateTime = $tempViaFlightArray[0]["departure_date"]." ".$tempViaFlightArray[0]["time_departure"];
            $endDateTime = $tempViaFlightArray[count($tempViaFlightArray)-1]["arrival_date"]." ".$tempViaFlightArray[count($tempViaFlightArray)-1]["time_arrival"];
            

            $startGMT = explode(":",str_replace("-","",str_replace("+","",$startGMT)));
            $endGMT   = explode(":",str_replace("-","",str_replace("+","",$endGMT)));
            $STime    = (strtotime($startDateTime)-(3600*($startGMT[0]+($startGMT[1]/60))));
            $ETime    = (strtotime($endDateTime)-(3600*($endGMT[0]+($endGMT[1]/60))));
            $start_date  = new \DateTime(date("Y-m-d H:i:s",$ETime));
            $since_start = $start_date->diff(new \DateTime(date("Y-m-d H:i:s",$STime)));
            $hours = ($since_start->days * 24) + $since_start->h;
            if($type == "string")
            {
                return $hours."h ".$since_start->i."m";
            }
            else
            {
                return array($hours,$since_start->i);
            }
        }    
}
?>