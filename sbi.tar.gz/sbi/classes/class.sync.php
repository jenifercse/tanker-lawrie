<?php
/************************************************************************
 * @Class Name  : sync
 * @Created on  : 2017-02-06
 * @Created By  : Taslim
 * @Description : This agencySync class is used to communicate with backend tool.
 * ************************************************************************ */
fileRequire('lib/common/commonMethods.php');
pluginFileRequire('misc/corporate/harinim/', 'classesTpl/class.tpl.misc.commonServicesTpl.php');
class sync{

    public function __construct(){

        $this->objCommon = new commonMethods();
        $this->_Oairline = new airline();
        $this->_OflightItinerary = new flightItinerary();
        $this->db = new commonDBO();
        $this->_OcreditnoteDetails = new creditnoteDetails();
        $this->_OcommonServices = new commonServicesTpl();
        $this->_OcommonDbo = new commonDBO();        
        $this->_Opackage   = new package();
        $this->_Oemployee   = new employee();  
        $this->_OsendToApproval = common::_checkClassExistsInNameSpace('sendToApproval');
        $this->_OsendSms = new sendSms();
        $this->_errorHandlingObj = new errorHandling(); 
    }

   /*
    * @FunctionName    :  _pushAgencyCorporateDetails
    * @Description     :  find content type
    * @param           :  int|$agencyId
    * @return          :  array|$responseArray
    */
    public function _pushAgencyCorporateDetails($agencyId){

        $_Oagency = new agency();
        $_Ocorporate = new corporate();
        $fieldsArray = array('agency_name', 'agency_backend_url');
        if($agencyId != ''){
            $agencyListArray = $_Oagency->_getAgencyList($fieldsArray, $agencyId);
            $agencyBackendUrl = $agencyListArray[0]['agency_backend_url'];
            $requestType = 'json';
            $postData = array();
            $agencyList = $_Ocorporate->_getCorporateDetails($agencyId);
            $postJSON = $this->objCommon->_encodeArrayToJSON($agencyList);
            $response = $this->objCommon->_curlRequest($agencyBackendUrl, 'POST', $postJSON, $requestType);
            $responseArray = $this->objCommon->_decodeJSONToArray($response);
            return $responseArray;
        }else{
            $responseArray = array('status' => 0, 'message' => 'Unable to make request - invalid agency id');
        }
    }

    /*
     * @FunctionName    :   _detectServiceDataType()
     * @Description     :   find content type
     * @param           :   
     * @return          :   string|$contentType
     */
    public function _detectServiceDataType(){

        if (!isset($_SERVER["CONTENT_TYPE"])){
            $requestHeaders = apache_request_headers();
            $contentType = $requestHeaders['Content-Type'];
        }else{
            $contentType = $_SERVER["CONTENT_TYPE"];
        }
        $contentType = $this->_detectHeaderType($contentType);
        return $contentType;
    }

    /*
     * @FunctionName    :   _detectHeaderType()
     * @Description     :   read the http header to detech header type
     * @param           :   array|$header
     * @return          :   array|$type
     */
    private function _detectHeaderType($header){

        switch($header){

            case 'application/json':
                $type = 'JSON';
                break;
            case 'text/xml':
            case 'application/xml':
                $type = 'XML';
                break;
            default:
                $type = 'JSON';
        }
        return $type;
    }

    /*
     * @FunctionName    :   airBookingFullfilment()
     * @Description     :   This function is get the full filment details of the booking request
     * @param           :   $request array
     */    
    public function airBookingFullfilment($request){

        pluginFileRequire('common/', 'classes/class.bookingDetailsSync.php');
        fileWrite($request,"syncRequestFromBackend");
        fileWrite(print_r($request,true),"syncRequestFromBackendSet","a+");
        $this->_ObookingDetailsSync = common::_checkClassExistsInNameSpace('bookingDetailsSync');
        $response = $this->_ObookingDetailsSync->_updateFullfilmentData($request);
        return $response;
    }    
    
    /*
     * Updates SAP Request id after fulfillment
     * @param array $request SAP Request details
     * @return array
     */
    public function updateSAPRequestId($request){
        pluginFileRequire('common/', 'classes/class.bookingDetailsSync.php');
        $this->_ObookingDetailsSync = new bookingDetailsSync();
        $response = $this->_ObookingDetailsSync->_updateSAPDetails($request);        
        return $response;
    }
    
    /*
     * Cancellation migration queue for balmer for previous booking from the SAP
     * @param $requestData array
     * @return array sync data
     */
    public function cancellationMigrationQueue($requestData){

        $agencySyncData = $this->_getAgencyDetails($requestData['corporateId']);
        $agencyUrl = $agencySyncData[0]['agency_backend_url'];
        $agencyUname = $agencySyncData[0]['agency_username'];
        $agencyPwd = $agencySyncData[0]['agency_password'];
        $agencyToken = $agencySyncData[0]['sync_token'];
        $tokenValidity = $agencySyncData[0]['token_validity'];
        $agencyId = $agencySyncData[0]['agency_id'];
        //get temporary token
        $response = $this->objCommon->_callTokenSyncMethod($agencyUrl, $agencyUname, $agencyPwd, $agencyToken, $tokenValidity, $agencyId);
        $requestMethod = 'cancellationMigrationQueue';
        $request = json_encode($requestData);
        $response = $this->objCommon->_callSyncMethod($agencyUrl, $requestMethod, $request, $packageId=0, $response['serviceToken']);
        $responseArray = (array) json_decode($response, 1);
        return $responseArray;
    }
    /*
     * used to validate the corporate sync gst details from web service
     * @param array $syncDetails
     * @return boolean
     * @author sivaprakash
     */
    private function _validateCorporateGSTSyncDetails($syncDetails) {
        
        $this->_SerrorMessage = '';
    // check corporate id not empty    
        $syncDetails['corporateId'] != 0 ? '' : $this->_SerrorMessage .= 'Corporate id is empty, ';
    // check corporate id not empty    
        !empty($syncDetails['processType']) ? '' : $this->_SerrorMessage .= 'process type is empty, ';
    // check corporate id not empty    
        $syncDetails['processValue'] != 0 ? '' : $this->_SerrorMessage .= 'process value is empty, ';        
        
    // validate corporate gst details of array records
        foreach ($syncDetails['gstInfo'] as $key => $value) {
        //validate gstStateId
            $value['gstStateId'] != 0 ? '' : $this->_SerrorMessage .= 'GST state id is empty, ';
        //validate gstNumber
            !empty($value['gstNumber']) ? '' : $this->_SerrorMessage .= 'GST number is empty, ';
        //validate gstCompanyName
            !empty($value['gstCompanyName']) ? '' : $this->_SerrorMessage .= 'GST company name is empty, ';
        //validate gstEmail
            !empty($value['gstEmail']) ? '' : $this->_SerrorMessage .= 'GST email id is empty, ';
        //validate gstMobileNumber
            $value['gstMobileNumber'] != 0 ? '' : $this->_SerrorMessage .= 'GST mobile number is empty, ';
        //validate gstAddress
            !empty($value['gstAddress']) ? '' : $this->_SerrorMessage .= 'GST address is empty, ';
        //validate defaultGST
            !empty($value['defaultGST']) ? '' : $this->_SerrorMessage .= 'Default GST is empty, ';
        //validate gstId
            $value['gstId'] != 0 ? '' : $this->_SerrorMessage .= 'GST Id is empty, ';
        }
        
        return !empty($this->_SerrorMessage) ? FALSE : TRUE;
    }
    /**
     * Inserts corporate  GST informations and cost center code info
     * @param array GST data of a corporate
     * @return array
     */
    public function corporateGSTDetails($requestData){
        
        //set request data.
        $request = $requestData['data'];

        //Get GST state master id
        $_OgstCostCenter = new gstCostCenter();
        $response = $_OgstCostCenter->_corporateGSTAndCostCenterDetails($request);        
        return $response;
    }

    /**
     * Inserts corporate  GST informations and cost center code info
     * @param array GST data of a corporate
     * @return array
     */
    public function corporateCostCenterDetails($requestData){
        //Get GST state master id
        $_OgstCostCenter = new gstCostCenter();
        $response = $_OgstCostCenter->_insertAndUpdateCostCentrCodeData($requestData['data']);
        return $response;
    }

   /*
    * @FunctionName    :   airCancellationFullfilment()
    * @Description     :   This function is get the full filment details of the booking request cancellation
    * @param           :   $request array
    */
    public function airCancellationFullfilment($request){
        
        fileWrite("airCancellationFullfilment".print_r($request,1),"airCancellationFullfilment","a+");
        pluginFileRequire('common/', 'classes/class.cancellation.php');
        pluginFileRequire('common/', 'classes/class.creditnoteDetails.php');
        pluginFileRequire('common/', 'classes/class.orderDetails.php');
        
        $this->_Ocancellation = new cancellation();
        $this->_OorderDetails = new orderDetails();
        
        //validating the air cancellation fulfillment details.
        $validationStatus = $this->_validateReq($request,'airCancellationFullfilment');
        fileWrite("validationStatus ".print_r($validationStatus,1),'airCancellationFullfilment','a+');
        
        if($validationStatus['status'] == 0){
            return $validationStatus;
        }         
        else{
            //checking the via flight info in cancellation request array.
            $cancellationViaFlightStatus = $this->_checkCancellationViaFlightInfo($request);            
            if($cancellationViaFlightStatus['status'] == 0){                
              return  $cancellationViaFlightStatus;
            }
        }

        $checkCreditNoteExits = $this->_Ocancellation->_isCreditNoteExist($request['cancellationId']);
        
        /*update passenger_via_details table booking status*/
        foreach ($request['cancellationInfo'] as $res){

            //Get via_flight_id for the sync id
            $viaFlightResult = $this->_Ocancellation->_fetchViaFlightIdSync($res['syncItineraryId']);
            if(is_array($viaFlightResult) && count($viaFlightResult) > 0) {
                $res['itineraryId'] = $viaFlightResult[0]['via_flight_id'];
            }
            //Get passenger_id for the sync id
            $passengerResult = $this->_Ocancellation->_fetchPassengerIdSync($res['syncPassengerId']);
            if(is_array($passengerResult) && count($passengerResult) > 0) {
                $res['passengerId'] = $passengerResult[0]['passenger_id'];
            }
            fileWrite(print_r($res,1),"airCancellationFullfilment","a+");

            //update passenger_via_details status
            $this->_Ocancellation->_updatePassegerViaDetailCancelStatus($res);

            //update cancellation_details status cancel_status
            $this->_Ocancellation->_updateCancellaionDetailStatus($res);        

            //get pnr with respect to the passenger_id and via_flight_id.
            $pnrInfo = $this->_OflightItinerary->_getPaxViaInfo('',$res['passengerId'],'',$res['itineraryId'])[0]['pnr'];

            //get the refund array with respect to the pax and itinerary.
            $cancelInfo[$res['passengerId']][$res['itineraryId']]['refundAmount'] = $res['refundAmount'];
            $cancelInfo[$res['passengerId']][$res['itineraryId']]['cancellationCharges'] = $res['penalityAmount'];
            $cancelInfo[$res['passengerId']][$res['itineraryId']]['pnr'] = $pnrInfo;
        }

        //set sync cancellation id.
        $_IsyncCancellationId = $request['syncCancellationId'];
        fileWrite("AFTER".print_r($request,1),"airCancellationFullfilment","a+");
        if($request['cancellationId'] != ''){
            $_IcancellationID = $request['cancellationId'];
            if(!$this->_Ocancellation->_fetchSyncCancellationId($_IsyncCancellationId)){
                $this->db->_update('trans_cancellation', array('sync_cancellation_id' => $_IsyncCancellationId), 'cancellation_id', $_IcancellationID);
            }
        }
        else{
            $_AcancellationId = $this->_Ocancellation->_fetchSyncCancellationId($_IsyncCancellationId);
            $_IcancellationID = $_AcancellationId[0]['cancellation_id'];
        }
        fileWrite($_IcancellationID.'--'.$_IsyncCancellationId,"airCancellationFullfilment","a+");

        /* get & update creditnote details id */
        $_AcanDetails = $this->_Ocancellation->_fetchPassengerId($_IcancellationID);
        fileWrite("_AcanDetails".print_r($_AcanDetails,1),"airCancellationFullfilment","a+");
        if(!$checkCreditNoteExits){
            $this->_OcreditnoteDetails->_IrCancellationDetailsId = 0;
            $this->_OcreditnoteDetails->_ScreditnoteDate = date('Y-m-d H:i:s');
            $this->_OcreditnoteDetails->_IsyncCreditnoteId = $request['syncCreditNoteId'];
            $this->_OcreditnoteDetails->_IrCancellationId = $_IcancellationID;
            $this->_OcreditnoteDetails->_insertCreditnoteDetails();
        }
        else{
            $this->_OcreditnoteDetails->_SupdatedDate = date('Y-m-d H:i:s');
            $this->_OcreditnoteDetails->_IsyncCreditnoteId = $request['syncCreditNoteId'];
            $this->_OcreditnoteDetails->_IrCancellationId = $_IcancellationID;
            $this->_OcreditnoteDetails->_updateCreditnoteDetails();
        }
        /* get & update order_details status */
        $this->_OorderDetails->_IsyncOrderId = $request['syncOrderId'];
        $_AorderDetails = $this->_OorderDetails->_selectOrderDetails();
        $_IorderId = $_AorderDetails[0]['order_id'];

        /* update order details */
        $this->_OorderDetails->_SrTicketStatusId = $this->_Ocancellation->_checkPartialCancellation($_IorderId);
        $this->_OorderDetails->_IsyncOrderId = $request['syncOrderId'];
        $this->_OorderDetails->_updateOrderDetails();

        /* update trans_cancellation agent_email_id */
        if (isset($request['agentId']) && !empty($request['agentId'])) {
            $cancelArray = array('agent_id' => $request['agentId'], 'cancellation_id' => $_IsyncCancellationId);
            if($request['cancellationId'] != ''){  
                $cancelArray['trans_cancellation_id'] = $_IcancellationID;
            }
            fileWrite("cancelArray".print_r($cancelArray,1),"airCancellationFullfilment","a+");
            $this->_Ocancellation->_updateSyncCancellaionMaster($cancelArray);
        }
        if($checkCreditNoteExits || OVERRIDE_PACKAGE_NAME != 'iocl'){
            //Get the package id for the input booking id
            $bookingPersonDetails=$this->_Opackage->_getBookingPersonInfo($_IorderId);
            $packageId = $bookingPersonDetails[0]['r_package_id'];
            //Getting the  Setting Array
            $settingArray=$this->_OsendSms->_smsEnableStatusCheck($packageId);
            
            // condition to check internal scenarion for email & sms block
            $blockSMSEMAIL = true;
            $explodeEmail = explode(',', BLOCK_EMAIL_BALMER);
            fileWrite('cancellatio sync Refund sms'.print_r($explodeEmail,1),'BLOCKEMAIL','a+');
            fileWrite('cancellatio sync Refund sms'.print_r($cancelArray['agent_id'],1),'BLOCKEMAIL','a+');
            if(in_array($cancelArray['agent_id'], $explodeEmail)){
                fileWrite('cancellatioRefund sms true ' .print_r($cancelArray['agent_id'],1),'BLOCKEMAIL','a+');
                $blockSMSEMAIL = false;
            }
            fileWrite('cancellatio sync Refund sms'.print_r($blockSMSEMAIL,1),'BLOCKEMAIL','a+');
            
            //used to send the refund sms to pax.
            $settingArray['SMS_Trigger']['Refund']== 'Y' && $blockSMSEMAIL ? $this->_senCancellRefundAmountSMS($cancelInfo,$_IorderId) :'';
            
            //send the cancellation fulfillment success message with refund amount to passenger
            $mailResponse = $blockSMSEMAIL ?  $this->_sendRefundAmountMailToPax($cancelInfo,$_IorderId) : '' ;           
                fileRequire('plugins/service/corporate/classes/class.notification.php');
                $notification = new notification();
                $notification->_sendNotification('CANCELLATION',$_IorderId,$packageId,$cancelInfo);
            fileWrite("FINALRESPONSE ".print_R($mailResponse,1),'cancelRefundAmountMail','a+');
        }
        return array('response' => 'SUCCESS', 'data' => '');        
    }    
    
   /*
    * @FunctionName    :   sendCancellationRequest()
    * @Description     :   This function is send the cancellation raised request for the bookings and get the cancellation fee
    * @param           :   $request array
    */
    public function sendCancellationRequest($requestData){
        $this->_Opackage = new package();
        $corporateDetails = $this->_Opackage->_getCorporateAdminDetails($requestData['orderId'])[0];
        $requestData['corporateId'] = $corporateDetails['r_corporate_id'];
        $requestData['syncCorporateId'] = $corporateDetails['sync_corporate_id'];
        $agencySyncData = $this->_getAgencyDetails($requestData['corporateId']);
        $agencyUrl = $agencySyncData[0]['agency_backend_url'];
        $agencyUname = $agencySyncData[0]['agency_username'];
        $agencyPwd = $agencySyncData[0]['agency_password'];
        $agencyToken = $agencySyncData[0]['sync_token'];
        $tokenValidity = $agencySyncData[0]['token_validity'];
        $agencyId = $agencySyncData[0]['agency_id'];
        //get temporary token
        $response = $this->objCommon->_callTokenSyncMethod($agencyUrl, $agencyUname, $agencyPwd, $agencyToken, $tokenValidity, $agencyId);
        $requestMethod = 'airCancellation';
        $request = json_encode($requestData);
        $response = $this->objCommon->_callSyncMethod($agencyUrl, $requestMethod, $request, $packageId, $response['serviceToken']);
        $responseArray = (array) json_decode($response, 1);
        return $responseArray;
    }
    
  

   /*
    * @FunctionName    :   _getAgencyDetails()
    * @Description     :   This function is get the agency details like sync url 
    * @param           :   $corporateId , $agencyId
    */
    public function _getAgencyDetails($corporateId = '', $agencyId = ''){
        if($agencyId != ''){
            
        }else{
            if($corporateId == 0){
                $corporateId = $_SESSION['corporateId'];
            }
        }
        $sql = "SELECT agency_id, agency_backend_url, agency_username, agency_password, sync_token, token_validity FROM dm_agency a 
                INNER JOIN agency_corporate_mapping m ON a.dm_agency_id = m.agency_id 
                WHERE ";
        $sql .= $corporateId ? " m.corporate_id = " . $corporateId . " AND " : '';
        $sql .= $agencyId ? " agency_id = " . $agencyId . " AND " : '';
        $sql .= " status='Y' ";
        $result = $this->db->_getResult($sql);
        return $result;
    }

   /*
    * @FunctionName    :   _corporateRegistrationSync()
    * @Description     :   This function is used to sync the corporate registration in the backend and get the sync isd and update
    * @param           :   $corporateDetails array , $agencyId
    */
    public function _corporateRegistrationSync($corporateDetails,$agencyId){
        $responseArray = $this->_getdata($corporateDetails, 'corporateRegistration', $agencyId);
        if($responseArray['status'] == 'SUCCESS'){
            //update values to corresponding tables
            $corporateId = array_column($corporateDetails, 'corporateId')[0];
            $this->_updateCorporateSyncDetails($responseArray, $corporateId);
        }else{
            fileWrite('Response Status:' . $responseArray['status'], 'syncResponse', 'a+');
        }
        return $responseArray;
    }

   /*
    * @FunctionName    :   _updateCorporateSyncDetails()
    * @Description     :   This function is used to update corporate details
    * @param           :   $response,$corporateId
    */
    public function _updateCorporateSyncDetails($response,$corporateId){
        $syncId = array_column($response, 'sync_corporate_id')[0];
        $sql = " UPDATE agency_corporate_mapping SET sync_corporate_id = " . $syncId . " WHERE corporate_id = " . $corporateId . " ";
        $result = $this->db->_getResult($sql);
    }

   /*
    * @FunctionName    :   _checkCorporateAvailableBalance()
    * @Description     :   This function is get the corporate availabel balance
    * @param           :   $corporateId
    */
    public function _checkCorporateAvailableBalance($corporateId){
        $responseArray = $this->_getdata($corporateId, 'corporateAvailableBalance');
            $corporateBalance = array_column($responseArray,'availableBalance')[0];
            $_SESSION['corporateBalance'] = $corporateBalance;
            if(($corporateBalance!='') && ($corporateBalance <= 50000)){
                $this->_sendCorporateBalanceMail($corporateId['corporateAvailableBalance']['requestInfo']['corporateId'],$corporateBalance);
            }
        return $corporateBalance;
    }

   /*
    * @FunctionName    :   _getTranscationSystemDiscountFee()
    * @Description     :   This function is get the corporate based transcation fee,system,discount fee details
    * @param           :   $feeArray
    */
    public function _getTranscationSystemDiscountFee($feeArray,$method){
        $responseArray = $this->_getdata($feeArray,$method);
        return $responseArray;
    }

   /*
    * @FunctionName    :   _getMarkUpMarkdownFee()
    * @Description     :   This function is get mark up and mark down fare for the corporate based fare type
    * @param           :   $feeArray
    */
    public function _getMarkUpMarkdownFee($feeArray){
        $responseArray = $this->_getdata($feeArray,'markUpMarkDown');
        return $responseArray;
    }

   /*
    * @FunctionName    :   _employeeSyncDetails()
    * @Description     :   This function is sync the newly created employee details and edit the employee details for update
    * @param           :   $employeeData array
    */
    public function _employeeSyncDetails($employeeData){
        $agencyId = $this->db->_select('agency_corporate_mapping', 'agency_id', 'corporate_id', $employeeData['data']['corporateId'])[0]['agency_id'];
        $responseArray = $this->_getdata($employeeData, 'employeeDetail', $agencyId);
        return $responseArray;
    }

   /*
    * @FunctionName    :   _getFinanceCharge()
    * @Description     :   This function is used to get the finance charge
    * @param           :   $input|array,$method|string
    */
    public function _getFinanceCharge($input,$method){
        $responseArray = $this->_getdata($input,$method);
        return $responseArray;
    }

   /*
    * @FunctionName    :   _getdata()
    * @Description     :   This function is get the input from all sync methods and return the processed data to the called function
    * @param           :   $input array, $method, $agencyId
    */
    public function _getdata($input,$method,$agencyId = ''){

        $request = json_encode($input);
        if($agencyId != ''){
            $agencySyncData = $this->_getAgencyDetails('', $agencyId);
        }else{
            $agencySyncData = $this->_getAgencyDetails();
        }
        $agencyUrl = $agencySyncData[0]['agency_backend_url'];
        $agencyUname = $agencySyncData[0]['agency_username'];
        $agencyPwd = $agencySyncData[0]['agency_password'];
        $agencyToken = $agencySyncData[0]['sync_token'];
        $tokenValidity = $agencySyncData[0]['token_validity'];
        $agencyId = $agencySyncData[0]['agency_id'];
        $response = $this->objCommon->_callTokenSyncMethod($agencyUrl, $agencyUname, $agencyPwd, $agencyToken, $tokenValidity, $agencyId);
        $requestMethod = $method;
        $response = $this->objCommon->_callSyncMethod($agencyUrl, $requestMethod, $request, $packageId, $response['serviceToken']);
        $responseArray = (array) json_decode($response, 1);
        return $responseArray;
    }

   /*
    * @FunctionName    :   _getCancellationCharge()
    * @Description     :   This function is get get the cancellation charges for the boooking request raised for cancellation
    * @param           :   $orderId, $orderDetails array
    */
    public function _getCancellationCharge($orderId, $orderDetails,$cancellationDetails){

        $_ArequestInput = array();

        //get air booking details
        $airBookingRequestDetails = $this->_getAirBookingRequest($orderId);
        $airItinerayDetails = $this->_getAirBookingItinearay($orderId);

        //get corporate info
        $this->_Opackage = new package();
        $corporateDetails = $this->_Opackage->_getCorporateAdminDetails($orderId)[0];

        //get Booking mode
        $bookingMode = $this->db->_select('booking_history','booking_type','order_id',$orderId)[0]['booking_type'];

        $_ArequestInput['corporateId'] = $corporateDetails['r_corporate_id'];
        $_ArequestInput['syncCorporateId'] = ($bookingMode == 1) ? $corporateDetails['sync_corporate_id'] : $corporateDetails['sync_personal_id'];
        $_ArequestInput['agencyId'] = $corporateDetails['agency_id'];
        $_ArequestInput['numberOfPax'] = $airBookingRequestDetails[0]['num_passenger'];
        $_ArequestInput['tripType'] = $airBookingRequestDetails[0]['trip_type'] == 0 ? 'ONEWAY' : 'ROUNDTRIP';
        $_ArequestInput['cancelledNumberOfPax'] = $orderDetails['cancelledNumberOfPax'];
        $_ArequestInput['classType'] = $this->_Oairline->_getTravelClassName($airBookingRequestDetails[0]['r_travel_class_id'])[0]['class_name'];
        $_ArequestInput['travelType'] = $airBookingRequestDetails[0]['travel_type'] == 'D' ? 'DO' : '';
        $_ArequestInput['modeType'] = 'air';
         $cutomFieldValue  =  $airBookingRequestDetails[0]['customize_fields'] ? json_decode($airBookingRequestDetails[0]['customize_fields'],1) : 'N';
        if($cutomFieldValue  == 'N'){
            $cutomFieldValue = '';
        }else{
            if($cutomFieldValue['LTCEnable'] == 'Y'){
                $cutomFieldValue = 'LTC';
            }else if($cutomFieldValue['defenseFare'] == 'Y'){
                $cutomFieldValue = 'DEFENCE';
            }
            else {
                 $cutomFieldValue = '';
            }
        }
        $_ArequestInput['customizedFare'] = $cutomFieldValue;
        $_ArequestInput['baseFare'] = 0;
        $_ArequestInput['tax'] = 0;
        $i = 0;
        foreach($airItinerayDetails as $res){
            $splitDetailsArray = $this->_OflightItinerary->_getSplitupForViaFareId($res['r_via_fare_id'], 1);
            $_ArequestInput['flightInfo'][$i]['airlineCode'] = $res['airline_code'];
            $_ArequestInput['flightInfo'][$i]['basefare'] = $splitDetailsArray['baseFare'];
            $_ArequestInput['flightInfo'][$i]['tax'] = $splitDetailsArray['tax'];
            $_ArequestInput['flightInfo'][$i]['yQ'] = $splitDetailsArray['YQ'];
            $_ArequestInput['flightInfo'][$i]['tripType'] = $res['trip_type'] == 0 ? 'ONWARD' : 'RETURN';
            $_ArequestInput['flightInfo'][$i]['fareType'] = $splitDetailsArray['baseFare'] ? $this->db->_select('dm_fare_type', 'fare_type_code', 'fare_type_id', $res['r_fare_type_id'])[0]['fare_type_code'] : 'null';
            $_ArequestInput['baseFare'] += $splitDetailsArray['baseFare'];
            $_ArequestInput['tax'] += $splitDetailsArray['tax'];
            $i++;
        }
        $_ArequestInput['cancellationInfo'] = $cancellationDetails;
        $request['cancellationFee'] = $_ArequestInput;
        $request = json_encode($request);
        $agencySyncData = $this->_getAgencyDetails();
        $agencyId = $agencySyncData[0]['agency_id'];
        $agencyUrl = $agencySyncData[0]['agency_backend_url'];
        $agencyUname = $agencySyncData[0]['agency_username'];
        $agencyPwd = $agencySyncData[0]['agency_password'];
        $agencyToken = $agencySyncData[0]['sync_token'];
        $tokenValidity = $agencySyncData[0]['token_validity'];
        $response = $this->objCommon->_callTokenSyncMethod($agencyUrl, $agencyUname, $agencyPwd, $agencyToken, $tokenValidity, $agencyId);
        $requestMethod = 'cancellationFee';
        $response = $this->objCommon->_callSyncMethod($agencyUrl, $requestMethod, $request, $packageId, $response['serviceToken']);
        $responseArray = (array) json_decode($response, 1);
        return $responseArray;
    }

   /*
    * @FunctionName    :   _getAirBookingRequest()
    * @Description     :   This function is get the air booking request info.
    * @param           :   $orderId
    */
    public function _getAirBookingRequest($orderId){
        $sql = "SELECT a.* from fact_booking_details f INNER JOIN air_request_details a ON f.r_request_id = a.air_request_id
                WHERE f.r_order_id = " . $orderId . "";
        $result = $this->db->_getResult($sql);
        return $result;
    }

   /*
    * @FunctionName    :   _getAirBookingItinearay()
    * @Description     :   This function is get the air booking itinerary info.
    * @param           :   $orderId
    */
    public function _getAirBookingItinearay($orderId){

        $sql = "select * from fact_air_itinerary f JOIN air_booking_details a ON f.r_air_booking_details_id  = a.air_booking_details_id
                INNER JOIN via_flight_details v ON f.r_via_flight_id = v.via_flight_id
                INNER JOIN dm_airline da ON v.r_airline_id  = da.airline_id
                WHERE a.r_order_id = " . $orderId . "";
        $result = $this->db->_getResult($sql);
        return $result;
    }

   /*
    * @FunctionName    :   agencyRegistration()
    * @Description     :  The function update agency details to db
    * @param           :   array|$request
    * @response        :   array|$returnArray
    */   
    public function agencyRegistration($request){
        
        ## create necessary object
        $_OAgency = new agency();
        
        $syncAgencyDetails = $request['agencyDetails'];
        if(count($syncAgencyDetails) > 0){
            $i = 0;
            foreach ($syncAgencyDetails as $key => $data){

                //validate if agency already exists
                $agencyExists = $_OAgency->_checkAgencyExists($data['agencyName']);

                if ($agencyExists['status'] == 0){
                    
                    //prepare inserting array into dm_agency
                    $insertArray = array();
                    $insertArray['agency_name'] = $data['agencyName'];
                    $insertArray['agency_address'] = $data['agencyAddress'];
                    $insertArray['agency_mobile'] = $data['agencyMobile'];
                    $insertArray['agency_backend_url'] = $data['agencyBackEndUrl'];
                    $insertArray['agency_backend_uid'] = 0;
                    $insertArray['agency_username'] = $data['agency_username'];
                    $insertArray['agency_password'] = $data['agency_password'];
                    $insertArray['service_tax_number'] = $data['service_tax_number'];
                    $insertArray['service_tax_category'] = $data['service_tax_category'];
                    $insertArray['pan_number'] = $data['pan_number'];
                    $insertArray['gst'] = $data['GST'];
                    $insertArray['gst_state_id'] = $data['gst_state_id'];
                    $insertArray['sac'] = $data['SAC'];

                    //insert data into dm_agency
                    $this->_AAgencyinsertId[$i] = $this->db->_insert('dm_agency', $insertArray);

                    $agencyMappingArray = array('agency_id' => $this->_AAgencyinsertId[$i],
                        'sync_agency_id' => $data['sync_agency_id'],
                        'status' => 'N',
                        'deleteStatus' => 'N');

                    $agencyCorporateMappingId = $_OAgency->_agencyCorporateMapping($agencyMappingArray);
                    $returnArray[] = array('status' => 1, 'agency_id' => $this->_AAgencyinsertId, 'message' => 'sync completed');
                }else{
                    $message = $agencyExists['status'] == 1 ? 'agency already exists' : 'agency name not passed';
                    $returnArray[] = array('status' => 0, 'message' => $message);
                }
                $i++;
            }
        }else{
            $returnArray[] = array('status' => 0, 'message' => 'required parameters not passed');
        }
        return $returnArray;
    }

   /* @FunctionName    :   corporateRegistrationSyncDetails()
    * @Description     :   This function sync corporate registration details from backend to frontend application
    * @param           :   array|$request
    * @response        :   array|$returnArray
    */
    public function corporateRegistrationSyncDetails($request){
        
        //set the data
        $syncCorporateDataArray = $request['corporateRegistration'];
        
        //corporate registration.
        if(count($syncCorporateDataArray) > 0){
            
            //looping the corporate info
            foreach($syncCorporateDataArray as $key => $val){
                
                //insert the new corporate info.
                if(!isset($val['corporateDetails']['parentSyncCorporateId']) || $val['corporateDetails']['parentSyncCorporateId'] == 0){
                    $returnArray = $this->insertCorporateInfo($val);                
                } 
                else{                    
                    //insert the corporate details with respect to the parent corporate id
                   $returnArray = $this->_insertCorporateInfoByParentId($val);
                }
            }
        } 
        else{            
            $returnArray[] = $this->_errorHandlingObj->_setErrorMsg($request,'corporate Registration Sync Error','Required parameters not passed in corporate registration sync');
        }
        return $returnArray;
    }
    
    /*
    * @functionName    : insertCorporateInfo()
    * @description     : insert the corporate details.(New corporate)
    */
    public function insertCorporateInfo($val){
        
        $_Ocorporate = new corporate();
        $_OAgency = new agency();
        
        //check the corporate already exist or not.
        $corporateExists = $_Ocorporate->_checkCorporateAlreadyExists($val['corporateDetails']['company_name']);
       
        //if it is new corporate
        if($corporateExists['status'] == 0){
            
            //insert into dm_corporate
            $corporateId = $_Ocorporate->_insertCorporate($val['corporateDetails']);

            //update the details in dm_corporate.
            $corporateInfo['admin_account_id'] = $_Ocorporate->_getCorporateAdminAccountId($val['corporateDetails']['admin_emailid'],$corporateId,$val['corporateDetails'])['account_id'];
            $corporateInfo['created_by'] = $_Ocorporate->_getCorporateAdminAccountId($val['corporateDetails']['created_by'],$corporateId,$val['corporateDetails'])['account_id'];
            $corporateInfo['approved_by'] = $_Ocorporate->_getCorporateAdminAccountId($val['corporateDetails']['approved_by'],$corporateId,$val['corporateDetails'])['account_id'];
            
            //update the corporate by and approved by details in the corporate data
            $corporateUpdated = $this->db->_update('dm_corporate',$corporateInfo,'corporate_id',$corporateId);                    
          
            //insert the corporate details and agency_corporate_mapping info
            if($corporateId != false){     
                        
                //insert the corporate header logo
                $corporateLogoInfo['image_path'] = $val['corporateDetails']['corporate_logo'];
                $corporateLogoInfo['r_corporate_id'] = $corporateId;
                $corporateLogoId = $this->db->_insert('dm_corporate_logo',$corporateLogoInfo);
                        
                //insert into corporate_details
                $corporateRegisterId = $_Ocorporate->_insertCorporateDetails($corporateId, $val['corporateDetails']);
                if($corporateRegisterId > 0){       
                            
                    //get agency id
                    $agencyData = $this->db->_select('dm_agency','*','sync_agency_id',$val['corporateDetails']['sync_agency_id']);   

                    if($agencyData){
                        
                        //set inputs
                        $agencyId = $agencyData[0]['dm_agency_id'];
                        
                        //insert agency_corporate_mapping
                        $agencyMappingArray = array('agency_id' => $agencyId,'corporate_id' => $corporateId,'status' => 'Y','deleteStatus' => 'N');
                               
                        //set the input based on the booking mode.
                        if($val['corporateDetails']['bookingType'] == 'Personal'){
                            $agencyMappingArray['sync_personal_id'] = $val['corporateDetails']['corporate_id'];
                            $agencyMappingArray['sync_email_id'] = $val['corporateDetails']['sync_corporate_email_id'];
                            $agencyMappingArray['sync_password'] = $val['corporateDetails']['sync_corporate_password'];
                        }
                        else{
                            $agencyMappingArray['sync_corporate_id'] = $val['corporateDetails']['corporate_id'];
                            $agencyMappingArray['sync_corporate_email_id'] = $val['corporateDetails']['sync_corporate_email_id'];
                            $agencyMappingArray['sync_corporate_password'] = $val['corporateDetails']['sync_corporate_password'];
                        }                                
                                
                        //get agency_corporate_mapping info.
                        $agencyCorporateMappingId = $_OAgency->_agencyCorporateMapping($agencyMappingArray,$corporateId,$agencyId);
                        if($agencyCorporateMappingId){
                            
                            //corporate details insertion//payment mode,embedded link
                            $bookingLink = $_Ocorporate->_corporateSettingsInsertion($val['corporateDetails'],$corporateId);
                            
                            //set the array
                            $returnArray[] = array('status' => 1, 'corporate_id' => $corporateId,'booking_link' => $bookingLink, 'message' => 'sync completed');
                        } 
                        else{
                            $returnArray[] = $this->_errorHandlingObj->_setErrorMsg($request,'Corporate Registration Sync Error','corporate mapping not done for the corporate id '.$corporateId);
                        }
                    } 
                    else{
                        $returnArray[] = $this->_errorHandlingObj->_setErrorMsg($request,'Corporate Registration Sync Error','agency not registered');
                    }
                } 
                else{
                    $returnArray[] = $this->_errorHandlingObj->_setErrorMsg($request,'Corporate Registration Sync Error','corporate registration not done');
                }
            } 
            else{
                $returnArray[] = $this->_errorHandlingObj->_setErrorMsg($request,'Corporate Registration Sync Error','corporate name already exists');
            }
        } 
        else{
            $responseMsg = $corporateExists['status'] == 1 ? 'corporate already exists' : 'corporate name not passed in corporate registration sync';
            $returnArray[] = $this->_errorHandlingObj->_setErrorMsg($request,'corporate Registration Sync Error',$responseMsg);
        }
        return $returnArray;
    }
    
    /*
    * @functionName    : _insertCorporateInfoByParentId()
    * @description     : insert the corporate details info with respect to the parent sync corporate id.
    */
    public function _insertCorporateInfoByParentId($val){
        
        ## create necessary object
        $_Ocorporate = new corporate();
        $_OAgency = new agency();
        
        //check the parent corporate exist or not.
        $parentCorporateIdExist =  $this->db->_select('dm_corporate','*','corporate_id',$val['corporateDetails']['parentSyncCorporateId'])[0]['corporate_id'];
        if($parentCorporateIdExist && $parentCorporateIdExist != 0){
            
            //get the agency corporate mapping info for the parent corporate id.
            $agencyCorporateMappingId = $this->db->_select('agency_corporate_mapping','agency_corporate_mapping_id','corporate_id',$val['corporateDetails']['parentSyncCorporateId'])[0]['agency_corporate_mapping_id'];
            if($agencyCorporateMappingId){                 

                //set the inputs based on the flag.
                if($val['corporateDetails']['bookingType'] == 'Personal'){
                    $agencyMappingArray['sync_personal_id'] = $val['corporateDetails']['corporate_id'];
                    $agencyMappingArray['sync_email_id'] = $val['corporateDetails']['sync_corporate_email_id'];
                    $agencyMappingArray['sync_password'] = $val['corporateDetails']['sync_corporate_password'];
                    $dmCorporateDetails['personal_booking_enable'] = 'Y';
                }
                else{
                    $agencyMappingArray['sync_corporate_id'] = $val['corporateDetails']['corporate_id'];
                    $agencyMappingArray['sync_corporate_email_id'] = $val['corporateDetails']['sync_corporate_email_id'];
                    $agencyMappingArray['sync_corporate_password'] = $val['corporateDetails']['sync_corporate_password'];
                    $dmCorporateDetails['corporate_booking_enable'] = 'Y';
                }
                
                //set corporate id
                $corporateId = $val['corporateDetails']['parentSyncCorporateId'];

                //update the details in dm_corporate.
                $dmCorporateDetails['admin_account_id'] = $_Ocorporate->_getCorporateAdminAccountId($val['corporateDetails']['admin_emailid'],$corporateId,$val['corporateDetails'])['account_id'];
                $dmCorporateDetails['created_by'] = $_Ocorporate->_getCorporateAdminAccountId($val['corporateDetails']['created_by'],$corporateId,$val['corporateDetails'])['account_id'];
                $dmCorporateDetails['approved_by'] = $_Ocorporate->_getCorporateAdminAccountId($val['corporateDetails']['approved_by'],$corporateId,$val['corporateDetails'])['account_id'];
                $corporateIdInfo = $this->db->_update('dm_corporate',$dmCorporateDetails,'corporate_id',$corporateId);
                
                fileWrite($corporateIdInfo,"corporateId","a+");
                
                //update the agency_corporate_mapping
                $_OAgency->_agencyCorporateMapping($agencyMappingArray, '', '', $agencyCorporateMappingId);

                //corporate details insertion//payment mode,embedded link
                $bookingLink = $_Ocorporate->_corporateSettingsInsertion($val['corporateDetails'],$corporateId);
                
                $returnArray[] = array('status' => 1, 'corporate_id' => $val['corporateDetails']['parentSyncCorporateId'],'booking_link' => $bookingLink, 'message' => 'sync completed');
            }
            else{
                $returnArray[] = $this->_errorHandlingObj->_setErrorMsg($request,'Corporate Registration Sync Error','Agency corporate mapping not exist for the Parent Corporate id '.$corporateId);
            }
        }
        else{
            $returnArray[] = $this->_errorHandlingObj->_setErrorMsg($request,'Corporate Registration Sync Error','Parent Corporate Sync Id does not exist '.$corporateId);
        }
        return $returnArray;
    }

    /*
    * @FunctionName    :   addCorporateAppSettings()
    * @Description     :   This function is to over write the app setting data
    * @param           :   int|corporateId,personalBookingFlag
    */
    
    public function addCorporateAppSettings($corporateId,$personalBookingFlag){

        $_OauthToken = new authToken();
        $filePath = $_OauthToken->_purifyInputData(APP_BASE_PATH . 'appSettings/' . PLUGIN_NAME . 'corporate' . $corporateId . '.json');
        $fileContents = json_decode(file_get_contents($filePath),1);
                                    
        foreach ($fileContents as $k => $v) {
            if($personalBookingFlag == 'N'){
                $fileContents['settings']['PERSONAL_BOOKING'] = 'NO';
            }
            else{
                $fileContents['settings']['PERSONAL_BOOKING'] = 'YES';
            }
        }
        $fileName = fopen($filePath,'w');
        $f = fwrite($fileName,json_encode($fileContents));
        fclose($fileName);
    }
    /*
    * @FunctionName    :   corporateRegistrationSyncDetails()
    * @Description     :   This function sync corporate registration details from backend to frontend application
    * @param           :   array|$request
    * @response        :   array|$returnArray
    */
    public function getFareProfileSettings($request){
        
        fileWrite('REQUEST : '.print_r($request,true),"syncFPS","a+");       
        //object creation.
        $O_commonQuery = new commonQuery();
        //set inputs
        $fareProfileSettings = $request['fareProfileSettings'];        
        if(count($fareProfileSettings) > 0 && $fareProfileSettings['corporate_id'] != ''){
            //get the fare profile settings info.
            $dataArray = $O_commonQuery->_setFareSettingArrayForBackEnd($fareProfileSettings['request_configuration'],$request);
            if(count($dataArray) > 0){
                $returnArray[] = array('status' => 1, 'fareSetting' => $dataArray, 'message' => 'details sent successfully');
            } 
            else{
                $returnArray[] = array('status' => 0, 'message' => 'fare profile settings not available');
            }
        } 
        else{
            $this->_errorHandlingObj->_errorHandlingFlow(json_encode($fareProfileSettings),'Fare Profile Settings Error - Back End Request','required data does not exist','Y');
            $returnArray[] = array('status' => 0, 'corporate_id' => 0, 'message' => 'required data does not exist');
        }
        fileWrite('RESPONSE : '.print_r($returnArray,true),"syncFPS","a+");
        return $returnArray;
    }

    /**
     * Send SMS
     * @param array $request Request details
     * @return array
     */
    public function sendSMS($request) {
        
        $syncData = $request['smsDetails'];
        
        $message    = $syncData['message'];
        $mobileNo   = $syncData['mobile_no'];
        $syncCorpoarteId = $syncData['corporate_id'];
        $syncAgencyId   = $syncData['agency_id'];
        
        $result = $this->_getSMSCredentials($syncCorpoarteId,$syncAgencyId);

        //Prepare url with message
        $url = $result['url'] . "?Id=" . $result['username'] . "&Pwd=" . $result['password'] . "&PhNo=" . '91' . $mobileNo . "&text=" . urlencode($message);
        fileWrite("url " . $url, 'messageSms', 'a+');
        
        //send SMS
        $this->_OcommonMethods = new commonMethods();
        $serviceReponse = $this->_OcommonMethods->_readExternalWebservice($url);
        
        if (trim($serviceReponse, " ") == 'Message Submitted') {
            $response = array('response' => 'SUCCESS', 'data' => 1, 'message' => 'Message sent successfully');
        } else {
            $response = array('response' => 'FAIL', 'data' => 0, 'message' => 'Message not sent');
        }
        
        return $response;
    }
    
    /**
     * Get SMS credentials for corporates
     * @param int $syncCorpoarteId Sync corporate id
     * @param int $syncAgencyId Sync agency id
     * @return array
     */
    public function _getSMSCredentials($syncCorpoarteId,$syncAgencyId) {
        
        $sql = "SELECT 
                    sud.url,
                    sud.username,
                    sud.password 
                FROM 
                     sms_url_details sud JOIN agency_corporate_mapping acm 
                WHERE 
                     sud.r_corporate_id=acm.corporate_id 
                     AND acm.sync_agency_id = " . $syncAgencyId ." 
                     AND acm.sync_corporate_id = " . $syncCorpoarteId;

        $result = $this->_OcommonDBO->_getResult($sql)[0];
        
        return $result;
    }
    
    /**
     * Create offline cancellation
     * @param array $request array of cancellatoin input
     * @return array
     */
    public function putOfflineCancellation($request){
        
        fileWrite("request Data".print_r($request,1),"offlineRES","a+");  
        $cancelDetails = $request['data']['cancelDetails'];
        
        //get cancel pax and itinerary info with respect to the trip typ.
        $cancelPaxInfo = array_column($cancelDetails['passengerItineraryDetails'],'syncPassengerId');
        $cancelItineraryInfo = array_column($cancelDetails['passengerItineraryDetails'],'syncItineraryId');
        $cancelTripInfo = array_column($cancelDetails['passengerItineraryDetails'],'trip');
        
        $cancelPaxId = implode(',',$cancelPaxInfo);
        $cancelItineraryId = implode(',',$cancelItineraryInfo);
        $cancelTrip = implode(',',$cancelTripInfo);
        
        //get order details.
        $alreadyCancelBooking = array();
        $orderDetails = $this->_getOrderPNRDetails('',$cancelDetails['orderId'],$cancelDetails['corporateId'],$cancelPaxId,$cancelItineraryId);
        
        foreach($orderDetails as $value) {
            ($value['r_booking_status_id'] != NOTHING_REQUESTED) ? $alreadyCancelBooking[] = $value['r_passenger_id'].'-'.$value['r_via_flight_id'] : '';
        }
        
        //if itineray already cancel meanss
        if(count($alreadyCancelBooking) > 0){
            $response = array('response' => 'FAILED','data' => '','alreadyCancelBooking' => $alreadyCancelBooking,'message' => 'Cancellation already in process');
        }
        // else if($orderDetails[0]['date_depature'] < date("Y-m-d H:i:s")){ // Departure date already passed
        //     $response = array('response' => 'FAILED', 'data' => '', 'message' => 'Cancellation not Possible. Flight already departed.');
        // }  
        // else if($orderDetails[0]['date_depature'] < date("Y-m-d H:i:s", strtotime('+2 hours'))){ // Departure date time about to come with in 2Hrs
        //     $response = array('response' => 'FAILED', 'data' => '', 'message' => 'Cancellation not Possible. Within 2Hrs to departure, flight can not be cancelled.');
        // }
        else{
            try{                
                //initiate cancellation
                $input = array('pnr' => $cancelDetails['pnr'], 'order_id' => $orderDetails[0]['r_order_id'], 'cancelReason' => $cancelDetails['cancellationRemarks'],'passenger_id' => $cancelPaxInfo,'tripType' => $cancelTripInfo);
                $this->_OcommonServices->_SagentEmailId = $cancelDetails['agentEmail'];
                $cancelresponse = $this->_OcommonServices->_onlineCancellationProcess($input,'Offline');
                fileWrite("offlineRES".print_r($cancelresponse,1),"offlineRES","a+"); 
                //error is there,
                if($cancelresponse['errorStatus'] == 'Y'){
                    $message = $cancelresponse['message'];
                    $response = 'FAILED';
                    $_ArequestData = array();
                }        
                else{
                    //forming the sync details.
                    $this->_Ocancellation = new cancellation();
                    $_ArequestData = $this->_Ocancellation->_getCancellationSyncReqInfo($this->_OcommonServices->_cancellationId);        
                    $_ArequestData['cancellationRemarks'] = $cancelDetails['cancellationRemarks'];      
                    $_ArequestData['employeeRemarks'] = $cancelDetails['employeeRemarks'];       
                    $_ArequestData['approverDetails'] = $cancelDetails['approverDetails'];      
                    $_ArequestData['corporateId'] = $cancelDetails['corporateId'];      
                    $_ArequestData['agentEmail'] = $cancelDetails['agentEmail'];      
                    $_ArequestData['syncCorporateId'] = $this->db->_select('agency_corporate_mapping','sync_corporate_id','corporate_id',$cancelDetails['corporateId'])[0]['sync_corporate_id'];
                    $message = 'Cancellation done successfully';
                    $response = 'SUCCESS';
                }
            } 
            catch(Exception $ex){
                $message = $ex->getMessage();
                $response = 'FAILED';
                $_ArequestData = array();
            }
            //set the response array.
            $response = array('response' => $response, 'data' => $_ArequestData, 'message' => $message);
        }        
        fileWrite("final Offline Response".print_r($response,1),"offlineRES","a+"); 
        return $response;
    }
    
    /**
     * Gets order details of a particular PNR
     * @param string $pnr PNR
     * @param int $orderId Order id
     * @param int $corpoarteId Corporate id
     * @return array
     */
    public function _getOrderPNRDetails($pnr = '',$orderId,$corpoarteId,$passengerId = '',$viaFlightId = ''){
        
        $sqlItinerary = "SELECT 
                            pvd.r_order_id,
                            pvd.r_booking_status_id,
                            CONCAT(vfd.departure_date,' ',vfd.time_departure) AS date_depature,
                            pvd.r_passenger_id,pvd.r_via_flight_id
                        FROM 
                            passenger_via_details pvd 
                            INNER JOIN passenger_details pd ON pvd.r_passenger_id = pd.passenger_id 
                            INNER JOIN fact_booking_details fbd ON fbd.r_order_id=pvd.r_order_id 
                            INNER JOIN via_flight_details vfd ON vfd.via_flight_id = pvd.r_via_flight_id 
                        WHERE 
                            fbd.r_corporate_id = ".$corpoarteId." AND fbd.r_order_id=".$orderId;
        
        ($pnr != '') ?  $sqlItinerary .= " AND pvd.pnr = '".$pnr."'" : "";
        ($passengerId != '') ?  $sqlItinerary .= " AND pvd.r_passenger_id IN (".$passengerId.")" : "";
        ($viaFlightId != '') ?  $sqlItinerary .= " AND pvd.r_via_flight_id IN (".$viaFlightId.")" : "";        
        $result = $this->db->_getResult($sqlItinerary);
        
        return $result;
    }

    /**
     * Sync corporate details
     * @param type $request
     */
    public function syncCorporateDetails($request) {

        $syncCorporateArray = $request['corporateRegistration'];
        $_Ocorporate = new corporate();
        $_OAgency = new agency();
        $_OAppSettings = new applicationSettings();
        $_OcorporateSetting = new corporateSettings();
        foreach ($syncCorporateArray as $key => $val) {
            $corporateName = $_Ocorporate->_getCorporateName($val['corporateDetails']['sync_corporate_id']);
            $exitCorporateNameArr = $_Ocorporate->_checkCorporateExists($corporateName);
            if (isset($exitCorporateNameArr[0]['corporate_id'])) {
                $updateSyncCorporateDetailsArr = array('corporate_credit_limit' => $val['corporateDetails']['corporate_credit_limit'],
                    'total_available_balance' => $val['corporateDetails']['total_available_balance']);
                $approveSyncArr = array('approved_date' => $val['corporateDetails']['approved_date'], 'status' => 'Y');
                $updateSyncDetails = $this->db->_update('corporate_details', $updateSyncCorporateDetailsArr, 'r_corporate_id', $exitCorporateNameArr[0]['corporate_id']);
                $approveDateDetails = $this->db->_update('dm_corporate', $approveSyncArr, 'corporate_id', $exitCorporateNameArr[0]['corporate_id']);
                $_OcorporateSetting->_deleteCorporatePaymentOptions($exitCorporateNameArr[0]['corporate_id']);
                $_Ocorporate->_paymentTypeMappingDetails($exitCorporateNameArr[0]['corporate_id'], $val['paymentCode']);
            }
        }
        
        return TRUE;
    }

    public function _getCorporateSyncId($corporateId) {
        return $this->db->_select('agency_corporate_mapping', 'sync_corporate_id', 'corporate_id', $corporateId)[0]['sync_corporate_id'];
    }


    /**
     * @Description     :   TO push ... updated to in AGencyAUto to AYP 
     * @param           :   string|$emailId
     * @param           :   int|$corporateId
     * @param           :   int|$syncCorporateId
     * @param           :   string|--------
     * @param           :   int|$agencyId
     * @response        :   array|$response
     */
    public function _syncUpdatedPassword($emailId, $corporateId, $syncCorporateId, $hashword, $agencyId) {


        if ($emailId != '' && $corporateId != '' && $syncCorporateId != '' && $hashword != '' && $agencyId != '') {

            $requestArray = array();
            $requestArray['method'] = 'updateLoginPassword';
            $requestArray['data']['emailId'] = $emailId;
            $requestArray['data']['corporateId'] = $corporateId;
            $requestArray['data']['sync_corporateId'] = $syncCorporateId;
            $requestArray['data']['password'] = $hashword;
            $requestArray['data']['agencyId'] = $agencyId;

            $agencySyncData = $this->_getAgencyDetails();

            $agencyId = $agencySyncData[0]['agency_id'];
            $agencyUrl = $agencySyncData[0]['agency_backend_url'];
            $agencyUname = $agencySyncData[0]['agency_username'];
            $agencyPwd = $agencySyncData[0]['agency_password'];
            $agencyToken = $agencySyncData[0]['sync_token'];
            $tokenValidity = $agencySyncData[0]['token_validity'];

            $response = $this->objCommon->_callTokenSyncMethod($agencyUrl, $agencyUname, $agencyPwd, $agencyToken, $tokenValidity, $agencyId);

            $requestMethod = 'updateLoginPassword';
            $request = json_encode($requestArray);
            $response = $this->objCommon->_callSyncMethod($agencyUrl, $requestMethod, $request, $packageId, $response['serviceToken']);
        }
    }

    /**
     * Edit invoice details
     * @param array $allData Booking details input data
     * @return array
     */
    public function airEditInvoice($allData) {

        $requestData = $allData['data'];

        if (!is_array($requestData) || empty($requestData)) {
            $response = array('response' => 'FAILED', 'data' => $requestData, 'message' => 'Details not found');
            return $response;
        }

        $syncOrderId = $requestData['order_id'];
        $syncInvoiceId = $requestData['invoice_id'];
        $syncCorporateId = $requestData['corporate_id'];
        $totalAmount = $requestData['totalAmount'];
        $transactionFee = $requestData['transactionFee'];
        $discountAmount = $requestData['discountAmount'];
        $systemUsageFee = $requestData['systemUsageFee'];
        $financeCharge = $requestData['finance_charge'];
        $servicTax = $requestData['service_tax'];
        $billtoAddress = $requestData['billto_address'];

        //Passenger information
        $passengerInfo = $requestData['passengerInfo'];
        //Fare information
        $fareInfo = $requestData['fareInfo'];
        //Fare information
        $passViaInfo = $requestData['passengerViaInfo'];

        //Get via flight ids
        $viaIds = array_column($fareInfo, 'itinerayId');

        $_Oinvoice = new invoice();
        //Get existing data
        $oldData = $_Oinvoice->_getInvoiceData($syncOrderId, $viaIds);
        //insert new and old data for future reference
        $_Oinvoice->_logEditInvoice($oldData, $requestData);

        //Update order total fares/coprorate id
        $orderId = $_Oinvoice->_updateInvOrderFare($syncInvoiceId, $totalAmount, $syncCorporateId, $billtoAddress);

        //Update processing fees/charges
        $_Oinvoice->_pushBookingFeeMapping($orderId, 'transactionFee', $transactionFee); //Change Transaction fee
        $_Oinvoice->_pushBookingFeeMapping($orderId, 'discountAmount', $discountAmount); //Change discount fee
        $_Oinvoice->_pushBookingFeeMapping($orderId, 'systemUsageFee', $systemUsageFee); //Change system usage fee
        $_Oinvoice->_pushBookingFeeMapping($orderId, 'finance_charge', $financeCharge); //Change finance charge
        //Update flght fare
        foreach ($fareInfo as $key => $viaFlight) {

            $_Oinvoice->_updateInvFilightFare($viaFlight);
        }

        //Update passenger info
        foreach ($passengerInfo as $key => $passDetail) {

            $_Oinvoice->_updateInvPassengerDetails($passDetail);
        }

        //Update passenger via info
        foreach ($passViaInfo as $key => $passViaDetail) {

            $_Oinvoice->_updateInvPassengerViaDetails($passViaDetail);
        }

        $response = array('response' => 'SUCCESS', 'data' => '', 'message' => 'Details updated successfully');

        return $response;
    }

    /*
     * @FunctionName    :   airEditItinerary()
     * @Description     :   This function is update the itinerary
     * @param           :   $request array
     */

    public function airEditItinerary($request) {

        pluginFileRequire('common/', 'classes/class.bookingDetailsSync.php');

        $this->_ObookingDetailsSync = new bookingDetailsSync();
        $result = $this->_ObookingDetailsSync->_updateItinerary($request);

        if ($result) {
            $response = array('response' => 'SUCCESS', 'data' => '', 'message' => 'Itinerary updated successfully');
        } else {
            $response = array('response' => 'FAIL', 'data' => '', 'message' => 'Params not set');
        }

        return $response;
    }

    /*
     * @Description     :   To update edit credit note values on related tables
     * @param           :   array|$request -> Edit values will come as array
     * @response        :   array|$response
     */

    public function airCancellationFulfillment($request) {
        //Check is array and array is empty
        if (is_array($request) && !empty($request)) {
            $updateArray['comments'] = $request['data']['cancel_reason'];
            $this->db->_update('trans_cancellation', $updateArray, 'sync_cancellation_id', $request['data']['syncCancellationId'], '=');
            foreach ($request['data']['cancellationInfo'] AS $key => $item) {
                $sql = "SELECT passenger_id FROM passenger_details WHERE sync_passenger_id = " . $item['syncPassengerId'];
                $result = $this->_Oconnection->query($sql);
                //Check row count for update record id
                if ($result->rowCount() >= 1) {
                    $r_passenger_id = $result[0]['passenger_id'];
                } else {
                    $r_passenger_id = 0;
                }
                //Unset already assigned data
                unset($updateArray);
                $updateArray['penalty_charge'] = $request['data']['penalityAmount'];
                $updateArray['refund_amount'] = $request['data']['refundAmount'];
                $this->db->_update('cancellation_details', $updateArray, 'r_passenger_id', $r_passenger_id, '=');
            }
        } else {
            $response = array('response' => 'FAIL', 'data' => '', 'message' => 'Array empty (or) Not an array');
            return $response;
        }
    }
    


    /**
     * this function will act as common to get the data for all travel modes
     * @param type $requestarray
     * @param type $orderId
     * @return type
     * @Author :- Vishwa Raj
     */
    public function _requestInfo($requestarray, $orderId){
        
        $requestarray['requestInfo']['packageId'] = $this->db->_select('fact_booking_details', 'r_package_id', 'r_order_id', $orderId)[0]['r_package_id'];
        $requestarray['requestInfo']['orderId'] = $orderId;

        $requestarray['requestInfo']['requestPersonEmail'] = $this->db->_select('dm_package', 'requested_by', 'package_id', $requestarray['requestInfo']['packageId'])[0]['requested_by'];
        $requestarray['requestInfo']['packageDateTime'] = $this->db->_select('dm_package', 'created_date', 'package_id', $requestarray['requestInfo']['packageId'])[0]['created_date'];

        $requestarray['requestInfo']['travelPurpose'] = $this->db->_select('order_details', 'travel_purpose', 'order_id', $orderId)[0]['travel_purpose'];
        $requestarray['requestInfo']['currencyCode'] = strtoupper($this->db->_select('currency_master', 'currency_symbol', 'currency_id', 1)[0]['currency_symbol']);

        $requestarray['requestInfo']['totalAmount'] = $this->db->_select('order_details', 'total_amount', 'order_id', $orderId)[0]['total_amount'];
        $requestarray['requestInfo']['numberOfPax'] = $this->db->_select('booking_history', 'no_of_passenger', 'order_id', $orderId)[0]['no_of_passenger'];

        $requestarray['requestInfo']['paymentType'] = $this->db->_select('dm_payment_type', 'payment_type_code', 'payment_type_id', $this->db->_select('payment_details', 'r_payment_type_id', 'r_order_id', $orderId)[0]['r_payment_type_id'])[0]['payment_type_code'];
        $requestarray['requestInfo']['tralveModeCode'] = $this->db->_select('dm_travel_mode', 'travel_mode_code', 'travel_mode_id', $this->db->_select('order_details', 'r_travel_mode_id', 'order_id', $orderId)[0]['r_travel_mode_id'])[0]['travel_mode_code'];

        $requestarray['requestInfo']['billToAddress'] = $this->db->_select('dm_billto_mapping', 'billto_name', 'billto_id', $this->db->_select('order_details', 'r_billto_id', 'order_id', $orderId)[0]['r_billto_id'])[0]['billto_name'];
        return $requestarray;
    }
    
    /**
    * @Desc this function is used to add a promocode for  created corporate
    * @param Array $promocodeData
    * @Author :- Baskar V.P
    */
     public function promoCodeSync($requestData){
         
        fileWrite(" REQUEST".print_r($requestData,1),"syncREsPROMO","a+");
        
        // checking for value all present for promo code check
        if(isset($requestData) && isset($requestData['promoCodeDetails']) && count($requestData['promoCodeDetails']>0)){
            
            $syncCorporateDataArray = $requestData;
            $_OAgency = new agency();

            // setting action for the promcode check
            $action = $requestData['action'];

            // checking corporate id is exist or not for the corporate
            $syncCorporateId = $syncCorporateDataArray['promoCodeDetails'][0]['corporate_id'] ? $syncCorporateDataArray['promoCodeDetails'][0]['corporate_id'] : 0 ;

            $resultCorporateData = $this->db->_select("sync_corporate_details","*","sync_corporate_id",$syncCorporateId)[0];
            $corporateId = $resultCorporateData['r_corporate_id'];

            // switch case to handle action performance based on action it will work
            switch ($action) {
                case 'ADD':
                    //to edit the promocode
                    $promoCodeId = $this->_createPromoCode($corporateId,$syncCorporateDataArray,$resultCorporateData['booking_mode']);
                    break;

                case 'DELETE':
                    // to create the promocode
                    $this->_deletePromoCode($corporateId,$syncCorporateDataArray,$resultCorporateData['booking_mode']);
                    break;

                case 'EDIT':
                    // to delete the promocode
                    $this->_editPromoCode($corporateId,$syncCorporateDataArray,$resultCorporateData['booking_mode']);
                    break;
            }
            // return response after process completed from front end to back end
            $response = array('response' => 'SUCCESS', 'data' => $promoCodeId, 'message' => 'Details updated successfully');    
        }
        else{
            $responseMsg = 'Promocode details not set properly kindly check Urgent..';
            $this->_errorHandlingObj->_errorHandlingFlow(json_encode($requestData),'Promo Code Sycn error',$responseMsg,'Y');
            $response = array('response' => 'ERROR','message' => $responseMsg);
        }
        return $response;
    }
    
   /*
    *  This method is used to create the promocode from backend to front end
    */
    public function _createPromoCode ($corporateId,$insertData,$bookingMode){
        $_Ocorporate = new corporate();
        //insert into promotcode details
        $promoCodeId = $_Ocorporate->_insertPromoCode($corporateId, $insertData['promoCodeDetails']);
        if(count($promoCodeId) > 0) {
            $result = $_Ocorporate->_mapPromoCodeToCorporate($corporateId, $promoCodeId,$bookingMode);
        }
        return $promoCodeId;
    }
    
    /*
    *** This method is used to delete the promocode from backend to front end ***
    */
    public function _deletePromoCode($corporateId,$requestData){
        //object intialization 
        $_Oairline = new airline();
        $_OcorporateSettings = new corporateSettings();

        //to get airline result based on marketing airline
        $airlineResult = $_Oairline->_getAirlineCodeInfo($requestData['promoCodeDetails'][0]['marketing_airline']);

        // to get promocode result from database based on corporate,airline and promocode
        $promoCodeResult = $_OcorporateSettings->_getPromocodeDetails($corporateId, 0,'',$airlineResult[0]['airline_id'], $requestData['promoCodeDetails'][0]['promo_code'],$requestData['promoCodeDetails'][0]['booking_class']);

        if (count($promoCodeResult) > 0 && isset($promoCodeResult[0]['promo_code_id'])) {
            foreach ($promoCodeResult as $promoResult) {
                $reult = $_OcorporateSettings->_deletePromocodeDetails($corporateId,$promoResult['promo_code_id']);
            }
        }
        return $result;
    }
    
   /**
    * This method is used to edit the promocode from backend to front end
    */
    public function _editPromoCode($corporateId,$insertData,$bookingMode){
        //update query for promo code mapping update
        $_Ocorporate = new corporate();
        //update  promotcode details
        $promoCodeId = $_Ocorporate->_updatePromoCode($corporateId,$insertData,$bookingMode);
        return $result;
    }    
    
    /*
    * @Description  This method is used to update the agency details.
    * @param|array:$request
    * @return|array:$response
    * @author:Karthika.M
    */ 
    public function updateAgencyDetailSync($request){
        
        ## create necessary object
        $_OAgency = new agency();
        
        fileWrite("SyncUpdate".print_r($request,1),"SyncUpdate","a+");
    
        $syncAgencyDetails = $request['agencyDetails'];
        fileWrite("syncAgencyDetails".print_r($syncAgencyDetails,1),"SyncUpdate","a+");

        if(count($syncAgencyDetails) > 0){         
            
            foreach ($syncAgencyDetails as $key => $data){
                
                //prepare updating array
                $updateArray = array();                
                $data['agencyName'] ? $updateArray['agency_name'] = $data['agencyName']:'';
                $data['agencyAddress'] ? $updateArray['agency_address'] = $data['agencyAddress']:'';
                $data['agencyMobile'] ? $updateArray['agency_mobile'] = $data['agencyMobile']:'';
                $data['agencyBackEndUrl'] ? $updateArray['agency_backend_url'] = $data['agencyBackEndUrl']:'';
                $data['agency_username'] ? $updateArray['agency_username'] = $data['agency_username']:'';
                $data['agency_password'] ? $updateArray['agency_password'] = $data['agency_password']:'';
                $data['service_tax_number'] ? $updateArray['service_tax_number'] = $data['service_tax_number']:'';
                $data['service_tax_category'] ? $updateArray['service_tax_category'] = $data['service_tax_category']:'';
                $data['pan_number'] ? $updateArray['pan_number'] = $data['pan_number']:'';
                $data['agency_status'] ? $updateArray['agency_status'] = $data['agency_status']:'';
                $data['GST'] ? $updateArray['gst'] = $data['GST'] : '';
                $data['gst_state_id'] ? $updateArray['gst_state_id'] = $data['gst_state_id']:'';
                $data['SAC'] ? $updateArray['sac'] = $data['SAC']:'';

                fileWrite("updateArray ".print_r($updateArray,1),"SyncUpdate","a+");
                 
                //get the agency id with respect to the sync agency id.
                $agencyId = $this->db->_select('agency_corporate_mapping','agency_id','sync_agency_id',$data['sync_agency_id'])[0]['agency_id'];
                fileWrite("agencyId ".$agencyId,"SyncUpdate","a+");
                
                //insert data into dm_agency
                $agencyUpdatedId[] = $this->db->_update('dm_agency', $updateArray,'dm_agency_id',$agencyId);
                fileWrite("agencyUpdatedId ".print_r($agencyUpdatedId,1),"SyncUpdate","a+");

                //update the agency_corporate_mapping.
                $data['sync_agency_reference'] ? $agencyCorporateMappingArray['sync_agency_reference'] = $data['sync_agency_reference'] : '';
                $data['status'] ? $agencyCorporateMappingArray['status'] = $data['agency_status'] :'';
                fileWrite("agencyCorporateMappingArray ".print_r($agencyCorporateMappingArray,1),"SyncUpdate","a+");
                if(count($agencyCorporateMappingArray) > 0){
                    $agencyCorporateMappingId[] = $this->db->_update('agency_corporate_mapping', $agencyCorporateMappingArray,'sync_agency_id',$data['sync_agency_id']);
                }
                $returnArray[] = array('status' => 1, 'agency_id' => $agencyId, 'message' => 'Updated successfully');
            }
        } 
        else {
            $returnArray[] = array('status' => 0, 'message' => 'required parameters not passed');
        }
        return $returnArray;
    }
    
    
    /*
    * @Description  This method is used to update the corporate details.
    * @param|array:$request
    * @return|array:$response
    * @author:Karthika.M
    */ 
    public function updateCorporateDetailSync($request){
        
        //set inputs
        $syncCorporateDataArray = $request['corporateRegistration'];        
        
        if(count($syncCorporateDataArray) > 0){
            
            ## create necessary object
            $_Ocorporate = new corporate();
            $_OAgency = new agency();
            
            //looping the corporate info
            foreach ($syncCorporateDataArray as $key => $val){
                
                $corporateDetails = $val['corporateDetails'];
                
                //get corporate id with respect to the sync_corporate_id and sync_agency_id.
                $corporateId = $_Ocorporate->_getCorporateIdInfo($corporateDetails['sync_agency_id'],$corporateDetails['corporate_id'],$corporateDetails['bookingType'])[0]['corporate_id'];
                if($corporateId != ''){

                //get the employee info
                $empId  = $this->db->_select("dm_employee","employee_id","email_id",$corporateDetails['admin_emailid'])[0]['employee_id'];
                    
                    //update dm_booking_link table
                    if($corporateDetails['embeddedLink'] == 'Y'){
                        $bookingLink['userLink'] = $_Ocorporate->_insertEmbeddedLink($corporateDetails,$corporateId,4);
                    }
                    else{
                        $_Ocorporate->_changeBookingLinkStatus('employee_id',$empId,4,'N');
                    }
                   
                    if($corporateDetails['embeddedCorporateAdminLink'] == 'Y'){
                        $bookingLink['adminLink'] = $_Ocorporate->_insertEmbeddedLink($corporateDetails,$corporateId,2);
                    }   
                    else{
                        $_Ocorporate->_changeBookingLinkStatus('employee_id',$empId,2,'N');
                    }                  
                    
                    //update the corporate header logo
                    $corporateLogoInfo['image_path'] = $corporateDetails['corporate_logo'];
                    $corporateLogoId = $this->db->_update('dm_corporate_logo',$corporateLogoInfo,'r_corporate_id',$corporateId);
                    
                    //update the corporate details in to dm_corporate.                  
                    $corporateDetails['company_name'] ? $corporateArray['corporate_name'] = trim($corporateDetails['company_name']):'';
                    $corporateDetails['admin_emailid'] ? $corporateArray['admin_account_id'] = $_Ocorporate->_getCorporateAdminAccountId($corporateDetails['admin_emailid'],$corporateId)['account_id']:'';
                    $corporateDetails['status'] ? $corporateArray['status'] = trim($corporateDetails['status']):'';
               
                    //set the embedded link flag. 
                    $corporateArray['embedded_link'] = 'N';
                    if($corporateDetails['embeddedLink'] == 'Y' || $corporateDetails['embeddedCorporateAdminLink'] == 'Y'){
                        $corporateArray['embedded_link'] = 'Y';
                    }

                    //set the booking type enabled for the corporate.
                    if($corporateDetails['bookingType'] == 'Corporate'){
                        $corporateArray['corporate_booking_enable'] = 'Y';
                    }
                    else{
                        $corporateArray['personal_booking_enable'] = 'Y';
                    }
                    
                    $updatedCorporateId[] = $this->db->_update('dm_corporate',$corporateArray,'corporate_id',$corporateId);
                    
                    //update the corporate details into corporate_details
                    $corporateDetailsUpdatedId[] = $_Ocorporate->_updateCorporateDetails($corporateId,$corporateDetails);

                    //get agency info
                    $agencyIdExist = $this->db->_select('dm_agency','*','sync_agency_id',$corporateDetails['sync_agency_id']); 
                    if($agencyIdExist){            
                        
                        //get agency id
                        $agencyData = $_OAgency->_checkCorporateSyncIdExists('',$corporateDetails['corporate_id'],$agencyIdExist[0]['dm_agency_id'], false);
                        fileWrite("agencyData ".print_r($agencyData,1),"SyncUpdate","a+");
                        
                        //set agency details.
                        $agencyId        = $agencyData['data']['agency_id'];
                        $agencyMappingId = $agencyData['data']['agency_corporate_mapping_id'];

                        //update corporate details in agency_corporate_mapping
                        if($corporateDetails['bookingType'] == 'Corporate'){
                            $corporateDetails['sync_corporate_email_id'] ? $agencyMappingArray['sync_corporate_email_id'] = $corporateDetails['sync_corporate_email_id']:'';
                            $corporateDetails['sync_corporate_password'] ? $agencyMappingArray['sync_corporate_password'] = $corporateDetails['sync_corporate_password']:'';
                        }
                        else{
                            $corporateDetails['sync_corporate_email_id'] ? $agencyMappingArray['sync_email_id'] = $corporateDetails['sync_corporate_email_id']:'';
                            $corporateDetails['sync_corporate_password'] ? $agencyMappingArray['sync_password'] = $corporateDetails['sync_corporate_password']:'';
                        }
                        $corporateDetails['status'] ? $agencyMappingArray['status'] = $corporateDetails['status']:'';
                        
                        //calling function for updating the agency_corporate_mapping.
                        count($agencyMappingArray) > 0 ? $agencyCorporateMappingId[] = $_OAgency->_agencyCorporateMapping($agencyMappingArray,'', '', $agencyMappingId):'';
                        
                        //set the booking mode.
                        $bookingMode = $corporateDetails['bookingType'] == 'Corporate' ? '1' : '0';
                        
                        //update the payment code
                        if(count($corporateDetails['paymentCode']) > 0){                            
                            
                            //delete the data in payment_type_mapping with respect to the corporate id and insert the payment code details.
                            $_Ocorporate->_deletePaymentBasedBookingMode($corporateId,$bookingMode);
                            
                            //insert the payment_type_mapping table with respect to the corporate id,
                            $_Ocorporate->_paymentTypeMappingDetails($corporateId,$corporateDetails['paymentCode'],$bookingMode);
                        }  
                        
                        //update sync corporate details.
                        $_Ocorporate->_updateSyncCorporateDetails($corporateDetails,$corporateId,$bookingMode);                        
                    } 
                    else{
                        $returnArray[] = $this->_errorHandlingObj->_setErrorMsg($request,'Corporate details updation sync','agency not registered');
                    }                    
                    $returnArray[] = array('status' => 1, 'corporate_id' => $corporateId, 'booking_link' => $bookingLink, 'message' => 'corporate details updated successfully');
                } 
                else{
                    $returnArray[] = $this->_errorHandlingObj->_setErrorMsg($request,'Corporate details updation sync','corporate id not exist in mapping');
                }
            } 
        } 
        else{
            $returnArray[] = $this->_errorHandlingObj->_setErrorMsg($request,'Corporate details updation sync','required parameters not passed in corporate updation sync');
        }
        return $returnArray;
    }    
    
    
    /*
    * @Description  This method is used to resend the mail to passenger from backend.
    * @param|array:$requestData
    * @date: 02-11-2017
    * @return|array:$response
    * @author:Karthika.M
    */ 
    public function resendEticket($requestData){
        
        fileWrite(print_r($requestData,1),"resendResponse"); 
        
        //declare the object.
        $this->_ObookingDetailsSync = common::_checkClassExistsInNameSpace('bookingDetailsSync'); 
        $this->_OsendSms   = new sendSms();
        
        //calling the function.
        $mailResponse = $this->_ObookingDetailsSync->_sendEticketToPassenger($requestData['orderId'], $requestData['reciepientEmail']);   
        
        //to get package id if package id is not available in requestData
        if($requestData['packageId'] != '' && $requestData['packageId'] != 0){
            $packageId = $requestData['packageId'];
        }
        else{
            $packageId = $this->_OcommonDbo->_select('fact_booking_details',array('r_package_id'),'r_order_id',$requestData['orderId'])[0]['r_package_id'];
        }   
        $settingsSMSArray = $this->_OsendSms->_smsEnableStatusCheck($packageId);
        $settingsSMSArray['SMS_Trigger']['Booking'] == 'Y' ? $this->_OsendSms->_smsDetailsFormation($requestData['orderId'],'BOOKING',$cancellationAmount,$settingsSMSArray) : '';
        
        //set response
        if(!in_array($mailResponse,0)){
            $response = array('status' => 1, 'message' => 'Mail sent successfully');                   
        }
        else{
           $response = array('status' => 0, 'message' => 'Mail not sent');    
        }       
        fileWrite(print_r($response,1),"resendResponse","a+");     
        return $response;
    } 
   
    
    /*
    * @Description  function used to send refund amount details to all passenger while auto cancellation.
    * @param|array:$cancelInfo
    * @date: 16-11-2017
    * @return|array:$response
    * @author:Karthika.M
    */ 
    public function _sendRefundAmountMailToPax($cancelInfo,$_IorderId){
        
        //declare the object. 
        $this->_ObookingDetailsSync = common::_checkClassExistsInNameSpace('bookingDetailsSync'); 
        //calling the function.
        $response  = $this->_ObookingDetailsSync->_sendRefundAmountToPax($cancelInfo,$_IorderId);
        return $response;
    }

    /**
    * @Description function used to send refund amount details to all passenger while auto cancellation for balmer lawrie.
    * @param|array,int:$cancelInfo,$orderId
    * @return|array:$mailResponse
    */ 
    public function _senCancellRefundAmountSMS($cancelInfo,$orderId){        
        fileWrite("--------SMS-- " .print_r($cancelInfo,1),"cancelRefundAmountSMS","a+");
        $bookingType = $this->_OcommonDbo->_select("booking_history","booking_type","order_id",$orderId)[0]['booking_type'];        
        //looping the cancelInfo.
        if($bookingType == 1){
            foreach($cancelInfo as $paxId => $paxCancelInfo){            
                $totalRefundAmount = 0; $totalCancellationCharges= 0; 
                $pnrInfo = array();
                foreach($paxCancelInfo as $itineraryId => $refundAmountInfo){        
                    $totalRefundAmount += $refundAmountInfo['refundAmount'];
                    $totalCancellationCharges += $refundAmountInfo['cancellationCharges'];
                    $pnrInfo[] = $refundAmountInfo['pnr'];
                    //get trip type
                    $tripType[] = $this->_OcommonDbo->_select('via_flight_details','trip_type','via_flight_id',$itineraryId)[0]['trip_type'];
                }            
                //get trip type
                $tripType = array_unique($tripType);
                $tripType = array_values($tripType);            
                $mailResponse[] =  $this->_OsendSms->_smsDetailsFormation($orderId,'CANCEL',$totalRefundAmount,'',$paxId,implode(",",$tripType));
            }   
        }
        else{
            $totalRefundAmount = 0; $totalCancellationCharges= 0; 
            $pnrInfo = array();
            foreach($cancelInfo as $paxId => $paxCancelInfo){
                foreach($paxCancelInfo as $itineraryId => $refundAmountInfo){        
                    $totalRefundAmount += $refundAmountInfo['refundAmount'];
                    $totalCancellationCharges += $refundAmountInfo['cancellationCharges'];
                    $pnrInfo[] = $refundAmountInfo['pnr'];
                    //get trip type
                    $tripType[] = $this->_OcommonDbo->_select('via_flight_details','trip_type','via_flight_id',$itineraryId)[0]['trip_type'];
                }            
                //get trip type
                $tripType = array_unique($tripType);
                $tripType = array_values($tripType);
            }
            $paxId = implode(",",array_keys($cancelInfo));
            $mailResponse[] =  $this->_OsendSms->_smsDetailsFormation($orderId,'CANCEL',$totalRefundAmount,'',$paxId,implode(",",$tripType));
        }
        
        return $mailResponse;
    } 

   /*
    * @FunctionName    :   checkAutomationStatus()
    * @Description     :   This function is used to get automation status 
    * @param           :   $request array
    */
    public function _checkAutomationStatus($requestData){
        fileWrite('sycn'.print_r($requestData,1),'automation','a+');
        $this->_Opackage = new package();
        $corporateDetails = $this->_Opackage->_getCorporateAdminDetails($requestData['orderId'])[0];
        $requestData['corporateId'] = $corporateDetails['r_corporate_id'];
        $requestData['syncCorporateId'] = $corporateDetails['sync_corporate_id'];
        $agencySyncData = $this->_getAgencyDetails($requestData['corporateId']);
        $agencyUrl = $agencySyncData[0]['agency_backend_url'];
        $agencyUname = $agencySyncData[0]['agency_username'];
        $agencyPwd = $agencySyncData[0]['agency_password'];
        $agencyToken = $agencySyncData[0]['sync_token'];
        $tokenValidity = $agencySyncData[0]['token_validity'];
        $agencyId = $agencySyncData[0]['agency_id'];
        //get temporary token
        $response = $this->objCommon->_callTokenSyncMethod($agencyUrl, $agencyUname, $agencyPwd, $agencyToken, $tokenValidity, $agencyId);
        $requestMethod = 'checkAutomationStatus';
        $request = json_encode($requestData);
        $response = $this->objCommon->_callSyncMethod($agencyUrl, $requestMethod, $request, $packageId, $response['serviceToken']);
        $responseArray = (array) json_decode($response, 1);
        return $responseArray;
    }
    
   /*
    * @FunctionName   _validateReq()
    * @Description    This function is used to validate the json with respect to the schema.
    * @param          $request|array,$methodName |string
    * @author         Karthika.M
    */
    public function _validateReq($request,$methodName){
        return jsonSchemaValidator::_checkJSONSchema($request,$methodName); 
    }
    
   /*
    * @FunctionName   _checkCancellationViaFlightInfo()
    * @Description    This function is used to validate the request data
    * @param          $request|array
    * @author         Karthika.M
    */
    public function _checkCancellationViaFlightInfo($request){
        
        //looping the cancellation info
        if(isset($request['cancellationInfo']) && count($request['cancellationInfo']) > 0){
            
            foreach($request['cancellationInfo'] as $key => $res){
                
                //Get via_flight_id for the sync id
                $viaFlightResult = $this->_Ocancellation->_fetchViaFlightIdSync($res['syncItineraryId']);
                
                $res['itineraryId'] = $viaFlightResult[0]['via_flight_id'];
                
                //Get passenger_id for the sync id
                $passengerResult = $this->_Ocancellation->_fetchPassengerIdSync($res['syncPassengerId']);
                
                $res['passengerId'] = $passengerResult[0]['passenger_id'];
                $data[] = $res;
            }
            
            //set itinerary info.
            $itineraryInfo = array_column($data,'itineraryId');
            //set passenger info.
            $passengerInfo = array_column($data,'passengerId');
            
            //check the itinerary info.
            if(count($itineraryInfo) == 0 || (count(array_filter($itineraryInfo)) != count($itineraryInfo))){
                //send error mail
                return $this->_errorHandlingObj->_setErrorMsg($request,'air cancellation fullfilment sync error','itinerary id not found for this sync itinerary id');
            }
            //check the passenger info.
            if(count($passengerInfo) == 0 || (count(array_filter($passengerInfo)) != count($passengerInfo))){
                 //send error mail
                return $this->_errorHandlingObj->_setErrorMsg($request,'air cancellation fullfilment sync error','passenger id not found for this sync passenger id');
            }
            
            
        }
        else{
            //send error mail
            return $this->_errorHandlingObj->_setErrorMsg($request,'air cancellation fullfilment sync error','cancellation info not found');
        }
        
        return array('status' => 1,'response' => 'success');
    }

    //sync function to update the corporate status
    public function syncCorporateStatusUpdate($request){

        $corporate = new corporate();
        $returnData = $corporate->updateStatus($request);
        if(isset($returnData) && !empty($returnData)){
           $response = array('status' => 1, 'message' => 'Status Update successfully'); 
        }
        else{
            $response = array('status' => 0, 'message' => 'Status not update successfully');
        }
        return $response;
    }
     /*
    * @Description  function used to send multiple employee details based on search.
    * @param|array:$requestData
    * @date: 27-7-2018
    * @return|array:$result
    * @author:Banupriyanka.S
    */ 
    public function getEmployeeDetails($requestData){
        $final = array();
        $this->_Oemployee   = new employee();
        $employeeData = $this->_Oemployee->_getEmployeeDetails($requestData['corporate_id'],$requestData['employeeCode']);
        if(empty($requestData['employeeCode']) || $requestData['employeeCode']==''){
            $final['errorStatus']['msg'] = 'Fail';
            $final['errorStatus']['description'] = 'Employee code is Empty';
        }
        else if(empty($employeeData) || $employeeData=='EMPTY' || $employeeData=='ERROR'){
            $final['errorStatus']['msg'] = 'Fail';
            $final['errorStatus']['description'] = 'Employee code does not exist';
        }
        else if(isset($employeeData) && !empty($employeeData)){
            $final['errorStatus']['msg'] = 'Success';
            $final['errorStatus']['description'] = '';
        }
        foreach($employeeData as $key => $val){
            $resultArray = $this->_Oemployee->_getEmployeeOtherDetails($val['employee_id'])[$val['employee_id']][0];
            $row['Department'] = $resultArray['department_name'];
            $row['Position'] = $resultArray['designation_name'];
            $row['Band'] = $resultArray['band_name'];
            $row['branch'] = $resultArray['branch_name'];
            $row['Title'] = $val['title'];
            $row['FirstName'] = $val['first_name'];
            $row['LastName'] = $val['last_name'];
            $row['MobileNumber'] = $val['mobile_no'];
            $row['EmployeeCode'] = $val['employee_code'];
            $row['EmailID'] = $val['email_id'];
            $row['AadharNo'] = $val['aadhaar_no'];
            $row['DOB'] = $val['date_of_birth'];
            $row['CostCenterCode'] = $val['cost_center_code'];
            $finalArray[$key] = $row;
        }
        $final['EmployeeDetails'] = $finalArray;
        return $result = $final;
    }
    
    /*
    * @Description  function used to send sms/mail to passenger and approver, if automation is failed.
    * @param|array:$requestData
    * @date: 30-8-2018
    * @return|array:$response
    * @author:Karthika.M
    */ 
    public function sendAutomationFailureSMS($requestData){
        
        //object declaration.
        $O_commonQuery = new commonQuery();
        
        fileWrite("requestData: ".print_r($requestData,1),"sendAutomationFailureSMS","a+");

        //update automation failure status
        $updateStatus['r_ticket_status_id'] = AUTOMATION_FAILURE;
        $this->db->_update('order_details',$updateStatus,'order_id',$requestData['orderId']);
        //get automation retry count
        $automationRetryCount = $this->db->_select('automation_retry_status', 'automation_retry_count','r_order_id', $requestData['orderId']);
        if(!$automationRetryCount){
            //get fare profile settings info.
            $settingsSMSArray = $O_commonQuery->_getSettingsDisplayData($requestData['packageId'],'SMS/Email');
            
            //approver message is enabled.
            if($settingsSMSArray['SMS_Trigger']['Ticketing_failure'] == 'Y'){
            
                //form the sms info for passenger and approver.
                $smsInfo = $this->_OsendToApproval->_formApproverPaxSMSInfo($requestData['orderId']);   
                if(count($smsInfo) > 0){
                    
                    //get message format.
                    $this->_OsendSms->_sendMessageFormation($smsInfo,'TICKETFAILURESMS','',$requestData['orderId']); 

                    //send Mail to passenge and approver.
                    $mailId = array_column($smsInfo,'email_id');               
                    if(count($mailId) > 0){
                        $mailResponse = $this->_OsendSms->_sendAutomationFailureMail($requestData['orderId'],$smsInfo);
                    }                
                    //set response.
                    $response = array('status' => 1,"response" => $mailResponse); 
                }        
                else{
                    $response = array('status' => 0, 'message' => 'SMS details not exist for the order id.');
                }
            }
            else{
                $response = array('status' => 0, 'message' => 'Settings not enabled.'); 
            }
        }
        else{
            $response = array('status' => 0, 'message' => 'Already mail get triggered'); 
        }
        return $response;       
    }
    
    /*
    * @FunctionName    :   _getFinanceCharge()
    * @Description     :   This function is used to get the finance charge
    * @param           :   $input|array,$method|string
    */
    public function _retryAutomation($input,$method,$agencyId){
        $responseArray = $this->_getdata($input,$method,$agencyId);
        return $responseArray;
    }
    
    /*
    * @FunctionName    :   _getSyncToken()
    * @Description     :   This function is get the sync token for the agency id
    * @param           :   $agencyId
    */
    public function _getSyncToken($agencyId = ''){        
        if($agencyId != ''){
            $agencySyncData = $this->_getAgencyDetails('', $agencyId);
        }else{
            $agencySyncData = $this->_getAgencyDetails();
        }
        
        $agencyUrl = $agencySyncData[0]['agency_backend_url'];
        $agencyUname = $agencySyncData[0]['agency_username'];
        $agencyPwd = $agencySyncData[0]['agency_password'];
        $agencyToken = $agencySyncData[0]['sync_token'];
        $tokenValidity = $agencySyncData[0]['token_validity'];
        $agencyId = $agencySyncData[0]['agency_id'];
        $response = $this->objCommon->_callTokenSyncMethod($agencyUrl,$agencyUname,$agencyPwd,$agencyToken,$tokenValidity,$agencyId);
        if(count($response) == 0){
            return array('status' => 'FAILURE','serviceToken' => '');
        }        
        return $response;
    }

    /*
    * @FunctionName    :   insertPSinvoice()
    * @Description     :   This function is get the sync details insertion (power suite details )
    * @param           :   request details
    * @auther          :  Puroskhan.M
    */
    public function insertPSinvoice($requestData) {

        $response=array();
        if(count($requestData) > 0 && array_key_exists('powerSuiteDetails', $requestData)) {
           $_Oinvoice=new invoice();
           $response= $_Oinvoice->_insertPSinvoiceData($requestData);
        }
        else { 
            $response='no data found';
        }
        return $response;
    }
    
    /**
     * function used to initiate sync function for employee family details
     *
     * @param array $requestData
     * @return array
     */
    public function sapEmployeeDependentInfo($requestData = array()){

        $_Osaptossbt = new saptossbt();

        return count($requestData) > 0 ? $_Osaptossbt->_employeeDependent($requestData) : array('uidNumber'=>$requestData['uidNumber'],'status'=>'N','responseMessage'=>'Failure to insert or update the record');
    }

    /**
     * function used to initiate sync function for employee master details
     *
     * @param array $requestData
     * @return array
     */
    public function sapEmployeeMaster($requestData = array()){

        $_Osaptossbt = new saptossbt();
        return count($requestData) > 0 ? $_Osaptossbt->_sapEmployeeMaster($requestData) : array('uidNumber'=>$requestData['uidNumber'],'status'=>'N','responseMessage'=>'Failure to insert or update the record');
    }    
    /*
    * @FunctionName    :   insertPaymentGateway()
    * @Description     :   This function is used to insert the pg charges details with respect to the payment type and agency.
    * @param           :   request details
    * @auther          :   Karthika.M
    */
    public function insertPaymentGateway($requestData){
        $_Opayment = new payment();
        return $_Opayment->_insertPGchargesDetails($requestData);        
    }


    /*
    * @FunctionName    :   syncPgStatusUpdate()
    * @Description     :   This function is used to update the pg charges status details with respect to the payment type and agency.
    * @param           :   request details
    * @auther          :   Muruganandham M
    */
    public function syncPgStatusUpdate ($requestData){
        $_Opayment = new payment();
        return $_Opayment->_syncPgStatusUpdate($requestData);       
    }
    
    /*
    * @FunctionName    :   updatePaymentGateway()
    * @Description     :   This function is used to update the pg charges details with respect to the payment type and agency.
    * @param           :   request details
    * @auther          :   Karthika.M
    */
    public function updatePaymentGateway($requestData){
        $_Opayment = new payment();
        return $_Opayment->_updatePGchargesDetails($requestData);        
    }    

    /**
     * function used to initiate sync function for employee transfer out details
     *
     * @param array $requestData
     * @return array
     */
    public function sapEmployeeTransferInfo($requestData = array()){

        $_Osaptossbt = new saptossbt();

        return count($requestData) > 0 ? $_Osaptossbt->_employeeTransferOut($requestData) : array('uidNumber'=>$requestData['uidNumber'],'status'=>'N','responseMessage'=>'Failure to insert or update the record');
    }

    /**
     * function used to initiate sync function for employee ticket booking lock
     *
     * @param array $requestData
     * @return array
     */
    public function sapEmployeeTicketBookingLockInfo($requestData = array()){

        $_Osaptossbt = new saptossbt();

        return count($requestData) > 0 ? $_Osaptossbt->_employeeTicketBookingLock($requestData) : array('uidNumber'=>$requestData['uidNumber'],'status'=>'N','responseMessage'=>'Failure to insert or update the record');
    }
    
    /**
    * Miscellaneous payment for additional payment
    * @param  array $request request details
    * @return array
    * @author Rajesh U
    */
    public function miscellaneousPayment($request){
        if(!empty($request)){
            
            $orderExit = $this->db->_select('order_details','*','order_id',$request[0]['orderId'])[0];
            if(!empty($orderExit)){
                $this->_Opayment = new payment();
                $_additionalPaymentLinkId = $this->_Opayment->_insertAdditionalPayment($request);
                $AdditionPaymentUrl = $this->_Opayment->_additionalPaymentLinkUrl($request,$_additionalPaymentLinkId);
                if(!empty($AdditionPaymentUrl)){
                    $response = array('status' => 'SUCCESS','message' => 'Mail send successfully');
                }
                else{
                    $response = array('status' => 'FAILURE','message' => 'order not exit');
                }
            }
            else{
                $response = array('status' => 'FAILURE','message' => 'order not exit');
            }
        }
        else{
          $response = array('status' => 'FAILURE','message' => 'No Data Found');
        }
        return $response;
    } 

    /**
     * function used to initiate sync function for employee ticket booking lock
     *
     * @param array $requestData
     * @return array
     */
    public function sapEmployeeApproverInfo($requestData){

        $_Osaptossbt = new saptossbt();

        return count($requestData) > 0 ? $_Osaptossbt->_sapEmployeeApproverInfo($requestData) : array('uidNumber'=>$requestData['uidNumber'],'status'=>'N','responseMessage'=>'Failure to insert or update the record');
    }

    public function sapsyncresponse($requestData){
      $_Ossbttosap =   new ssbtToSAP();
      $sapInserResponse = $_Ossbttosap->updateSAPResponse($requestData,'sapsyncresponse');
        return array('status' => 'Y', 'responseMessage' => 'Success');
    }

    public function sapTicketApprovalAcknowledge($requestData){
         $_Ossbttosap =   new ssbtToSAP();
        $sapInserResponse = $_Ossbttosap->updateSAPResponse($requestData,'sapServiceHandler');
        return array('status' => 'Y', 'responseMessage' => 'Success');
    }

    /*
    * get bill desk response Query API Transaction response
    * @param  array $request request details
    * @return array
    * @author puroskhan.m
    */
    public function checkPaymentStatus($requestData) {
       $_Opayment =  new payment();
       $returnDetails = $_Opayment->_getQueryAPIreponse($requestData);
       return $returnDetails;    
    } 

   /*
    * Function to update cancellation failure
    * @param  array $request request details
    * @return array
    * @author Muruganandham M
    */
    public function airCancellationFailure($request){
        $_Ocancellation = new cancellation();
        $result = $_Ocancellation->_airCancellationFailureUpdate($request['cancellationFailureInfo']);
        return $result;
    } 
      /*
    * @functionName    : _sendCorporateBalanceMail()
    * @description     : this method used to send Mail and sms for Low Corporate Balance
    * @author          : Muruganandham M
    */
    public function _sendCorporateBalanceMail($corporateId,$corporateBalance){
            fileWrite("corporateBalance".print_r($corporateId,1),"Muruga","a+");
         
         //get automation retry count
        $corporateName = $this->db->_select('dm_corporate','corporate_name','corporate_id',$corporateId)[0]['corporate_name'];
         $this->_AtwigOutputArray['message'] = " Dear Ms/Mr. Admin , <br/><br/> Your credit limit for <strong>".$corporateName."</strong> corporate is <strong>".$corporateBalance."</strong>. Please increase the deposit amount to avoid booking failure. <br/><br/>Regards,<br/>".EMAIL_SIGNATURE;
            $this->_AtwigOutputArray['host'] =  HOST_URL;
            $_Otwig = init();  
            $message = $_Otwig->render('mailLayout.tpl', $this->_AtwigOutputArray);
            $subject = "Low Corporate Balance";
            $_Omail = new commonMethods();
            $_Omail->_sendMail(CREDIT_LIMTI_MAIL, 'support@atyourprice.in', $subject, $message);
            $smsInfo = array();
            $smsInfo['corporateBalance'] = $corporateBalance;
            $smsInfo['mobile_no'] = CREDIT_LIMIT_SMS;
            $smsInfo['corporateName'] = $corporateName;
            $smsDetails[] = $smsInfo;
            $_OsendSms = new sendSms();
            $smsResponse = $_OsendSms->_sendMessageFormation($smsDetails,'CREDITLIMIT','',0,$corporateId);
        return true;
    }

    /*
    * Function to update Mail Settings
    * @param  array $request request details
    * @return array
    * @author Muruganandham M
    */
    public function agencyConfigSettings($request){
        $_Oagency = new agency();
        $result = $_Oagency->_updateAgencyMailSettings($request['agencyConfigSettings']);
        return $result;
    } 
}
?>