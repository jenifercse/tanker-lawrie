<?php
require_once "common/restrictDirectAccess.php";
/* * *********************************************************************
 * @class           class to load framework related files
 * @author          Taslim
 * @created Date    2017-07-08
 * ********************************************************************* */
fileRequire('lib/system/commonFunctions.php');
fileRequire("lib/system/authToken.php");
fileRequire("lib/common/commonMethods.php");

class framework extends authToken {
    /*
     * @description     : construction function of class
     * @param           : string|$applicationType
     */

    public function __construct($applicationType = 'corporate') {


        $this->_SApplicationType = $applicationType;
        $this->_AOutPutArray = array();

        $this->_OcommonFunc = new commonFunctions();
        $this->_OcommonMethods = new commonMethods();

        //$this->_OMenu = new listMenu();
        $this->_OMenu = common::_checkClassExistsInNameSpace('listMenu','misc');
    }

    /*
     * @description     : function to initialize framework
     * @param           : 
     * @return          : 
     */

    public function _init($pluginFolder, $logoPath) {
        /*
         * 
         * Check is user is logged in
         */
        // one more validation to check and set booking reject
        $this->_ILoggedIn = (isset($_SESSION['groupId']) && !empty($_SESSION['groupId'])) ? true : false;

        if($this->_ILoggedIn){
            $this->_ILoggedIn = (isset($_SESSION['approvalFlow']) && $_SESSION['approvalFlow'])  ? false : true;
        }
        /*
         * Set the application variable needed for twig template display
         * 
         */
        $this->S_PluginFolder = $S_PluginFolder;

        /* get css path */
        $this->_ScustomStyleCss = $this->_getApplicationCSSPath();

        /** create combined css file **/
        if(COMBINED_CSS_ENABLE){
            $css = $this->_OcommonMethods->loadCombinedCSS();
            $this->_combinedCssPath = substr($css,strpos($css, "/lib")+1);
        }

        /** to create combine js function **/
        if(COMBINED_JS_ENABLE){
            $js = $this->_OcommonMethods->loadCombinedJS();
            $this->_combinedJsPath = substr($js,strpos($js, "/lib")+1);
        }

        /** set last auth token in js localstorage varaible ***/
        $lastCSRFToken   = end($_SESSION['xctaa']);
        $this->_Sxctaa   = $lastCSRFToken['token'];

        if ($this->_ILoggedIn) {
            
            /**  set csrf token for application **/
            $this->_setAuthToken();

            /* get application menu from db */
            $this->_AmenuDisplay = $this->_getApplicationMenu();

            /* set the application menu to session so that it can be 
             * used while loading the menu 
             */
            $this->_setApplicationMenuInSession($this->_AmenuDisplay[0]);

            /* traverse through application menu array and find duplicate menus to display 
             * the duplicate menu with parent name in quicklink menu
             */
            $_AquickLinkMenu = $this->_checkAndFindQuickLinkMenu($this->_AmenuDisplay[1]);

            /*
             * Set quick link menu as permenant cookie to use in quick link menu throught the application
             */
            $this->_OcommonFunc->_setApplicationCookie('quickLinkDupMenu', json_encode($_AquickLinkMenu));

            /*
             * Save quick link array to session for loading quick links
             */
            $this->_OcommonFunc->_setSessionValue('quickLinkArray', $this->_OMenu->_loadSavedQuickLink());

            /*
             * assign default home page to be loaded by default after login
             */
            $loadMenuName = $this->_OcommonFunc->_checkLoadDefaultMenu($moduleName);

            /*
             * 
             *  query and get the corporate logo for corporate base logo
             */

            $this->S_logoPath = $this->_getLogo();

            /*
             * assign values to class variable to assign to twig template array
             */
            $this->_SmoduleName = $loadMenuName['name'];

            /*
             * assign value in session in varaible to set as 
             * hid{{footerLogoImageLink}}den vairalbe and use in js menu loader to load the defualt state
             * during initial page load based on corporate this settings is based
             * on applicaiton menu settings
             */
            $this->_OcommonFunc->_setSessionValue('employeeUpdateConfirmed', $loadMenuName['status']);
            
            /**** get fare profile settings ****/
            $this->_getFareProfileSettingsValue();
            
            /*** set footer logo based on fare profile settings ***/
            $this->_setFooterLogo();
             
        }
    }

    /*
     * @description     : function to get css file path to be loaded in application
     * @param           : 
     * @return          : string|$customStyleCss
     */

    public function _getApplicationCSSPath() {
        $customStyleCss = file_exists(APP_CSS_PATH . 'custom-style_' . $_SESSION['corporateId'] . '.css') ? 'custom-style_' . $_SESSION['corporateId'] . '.css' : 'custom-style.css';

        return $customStyleCss;
    }

    /*
     * @description     : function to get cpersona booking sync params
     * @param           : 
     * @return          : string|$menuSyncJSON
     */

    public function _getPersonalMenuSyncParams() {

        $menuSyncJSON = $this->_OcommonFunc->_menuSync();
        return $menuSyncJSON;
    }

    /*
     * @description     : function to get application menu from db
     * @param           : 
     * @return          : array|$_AmenuDisplay
     */

    public function _getApplicationMenu() {

        $_AmenuDisplay = $this->_OMenu->_constructMenu();
        return $_AmenuDisplay;
    }

    /*
     * @description     : function to set application menu from session to use while 
     *                    calling menu module
     * @param           : arrray|$_AapplicationMenu
     * @return          : 
     */

    private function _setApplicationMenuInSession($_AapplicationMenu) {

        $_SESSION['AmenuDisplay'] = serialize($_AapplicationMenu);
    }

    /*
     * @description     : function traverses through application menu and get duplicate 
     *                    menu to display in quick link with duplicate names
     * @param           : array|$_AapplicationMenu
     * @return          : array|$_AquickLinkMenu
     */

    private function _checkAndFindQuickLinkMenu($_AapplicationMenu) {

        $_AquickLinkMenu = $this->_OMenu->_processDuplicateQuickLInks($_AapplicationMenu);
        return $_AquickLinkMenu;
    }

    /*
     * @description     : function to get logo for corporate
     * @param           : 
     * @param           : 
     * @return          : string|$logoPath
     */

    public function _getLogo() {


        if($this->_SApplicationType != 'corporate'){
            $response['logoPath']   = 'lib/images/personalLogoDefault.jpg';
        }else{
            $response['logoPath']   = 'lib/images/LogoDefault.jpg';
        }
        $response['footerPath'] = 'lib/images/sabre_logo.png';

        if (isset($_SESSION['userId'])) {

            $db = new commonDBO();
            $coporateId = $_SESSION['corporateId'];

            $sql = "SELECT image_path, footer_logo FROM dm_corporate_logo WHERE r_corporate_id = " . $coporateId . " AND `status` = 'Y'";
            $result = $this->_OMenu->db->_getResult($sql);
            if (isset($result[0]['image_path']) && !empty($result[0]['image_path'])) {
                $filePath = 'lib/images/' . $result[0]['image_path'];
                if($result[0]['image_path'] != ''){
                    $response['logoPath'] = $result[0]['image_path'];
                } 
                else{
                    $response['logoPath'] = 'lib/images/header-logo.png';
                }
            }
            if (isset($result[0]['footer_logo']) && !empty($result[0]['footer_logo'])) {
                $footerLogo = 'lib/images/' . $result[0]['footer_logo'];

                if (file_exists($footerLogo)) {
                    $response['footerPath'] = $footerLogo;
                }
            }
        }

        return $response;
    }

    /*
     * @description     : function set valeus to output array to be passed to twig render function
     * @param           : string|$name
     * @param           : mixed|$value
     * @return          : 
     */

    private function _setValues($name, $value) {

        if (isset($value)) {
            $this->_AOutPutArray[$name] = $value;
        }
    }

    /*
     * @description     : assings output vlaues to array
     * @param           : boolen|$login
     * @return          : 
     */

    private function _assignOutPutValues($login = false) {

        global $CFG;

        /*  set global config variable * */
        $this->_setValues('CFG', $CFG);

        /*  set captcha in forgot password * */
        $this->_setValues('forgotpwdcaptchapath', $this->_OcommonFunc->_getCapchaCodeURL("fpwd"));
       
        /*  set captcha in login * */
        $this->_setValues('logincaptchapath', $this->_OcommonFunc->_getCapchaCodeURL("login"));

        /*  set plugin folder name * */
        $this->_setValues('pluginFolder', $this->S_PluginFolder);

        /*  set gulp application set flag form config.commonConfig.php * */
        $this->_setValues('gulp_include_flag', GULP_INCLUDE_FLAG);

        /* asign combined css path name */
        $this->_setValues('combinedCSSPath', $this->_combinedCssPath);

        /* asign combined js path name */
        $this->_setValues('combinedJSPath', $this->_combinedJsPath);

        /*  set combined CSS enable flag */
        $this->_setValues('combinedCssFlag', COMBINED_CSS_ENABLE);

        /*  set combined JS enable flag */
        $this->_setValues('combinedJsFlag', COMBINED_JS_ENABLE);

        /*  set css file path * */
        $this->_setValues('customStyleCss', $this->_ScustomStyleCss);

        /** Set application INDEX NAME FOR IDENTIFICATION * */
        $this->_setValues('applicationIndexName', INDEXNAME);

        /** Set product Logo **/
        $this->_setValues('logoPathCorporate', defined('PRODUCTLOGO') ? PRODUCTLOGO : '');

        /** Set cross site script name in to twig * */
        $this->_setValues('XCTAA', $this->_Sxctaa);

        /**  to set versionig for js **/
        $this->_setValues('JS_VERSION',md5(JS_VERSIONING));
        
        $this->_setValues('IP_ADDR', $_SERVER['REMOTE_ADDR']);

        if ($login) {
            /*  set login name * */
            $this->_setValues('loginName', $_SESSION['userName']);

            /*  set last login Time * */
            $this->_setValues('lastLoginTime', $_SESSION['lastLoginTime']);

            /*  set corporateBalance * */
            $this->_setValues('corporateBalance', $_SESSION['corporateBalance']);

            /*  set applicaton logo Path * */
            $this->_setValues('logoPath', $this->S_logoPath['logoPath']);

            /*  set applicaton logo Path * */

            $this->_setValues('footerPath', $this->S_logoPath['footerPath']);

            /*  set user group id * */
            $this->_setValues('userGroupID', $_SESSION['groupId']);

            /*  set corporate list array * */
            $this->_setValues('corporateList', $_SESSION['corporateList']);


            /*  set language in session * */
            $this->_setValues('languages', $_SESSION['languages']);

            /*  set plugin name */
            $this->_setValues('PLUGINNAME', $this->_SApplicationType);

            /*  set perosnal booking sync menu in form hidden field */
            $this->_setValues('menuSyncJSON', $this->_getPersonalMenuSyncParams());

            /*  set default module to be loaded */
            $this->_setValues('defaultModuleName', $this->_SmoduleName);

            /*  set application quick link menu */
            $this->_setValues('quickmenu', $this->_AmenuDisplay[0]);

            /* set corporate id */
            $this->_setValues('corporateId', $_SESSION['corporateId']);
            
            /* set corporate name */
            $this->_setValues('corporateName', $_SESSION['corporateName']);

            /* set sso login flag */
            $this->_setValues('ssoBalmer', $_SESSION['hideMenu']);
            
            /*  set selected quick links */
            $this->_setValues('selectedquicklink', $this->_OMenu->_getQuickLinkMenuDetails());
            
            /*  set footer logo details * */
            $this->_setValues('footerLogoEnabled', $this->_SfooterLogoEnabled);
            $this->_setValues('footerLogoContent', $this->_SfooterLogoContent);
            $this->_setValues('footerLogoImageLink', $this->_SfooterLogoImageLink);

            /* set corporate code for HTML */
            $this->_setValues('corporateCode', $_SESSION['corporateCode']);
            
            /*** set GULP ENABLE/DISABLE value from fare profile settings  ****/
            //$this->_setValues('gulp_include_flag', $this->_AfareProfileSettingsInfo['Gulp_Enabled']['status'] == 'Y' ? false : false);

            /* SET wsauth type for use in menu display in template  */
            $wsAuthType = $_COOKIE['wsAuthType'];
            $this->_setValues('wsAuthType', $wsAuthType);
           

        }
    }

    /*
     * @description     : function loads twig array and to assing to twig render function 
     *                    menu to display in quick link with duplicate names
     * @param           : 
     * @return          : 
     */

    public function _assignResponse() {

        $this->_SdisplayPage = '';
        if (APPLICATION_MAINTENANCE) {
            $this->_SdisplayPage = 'common/maintenance.html';
        } else if (!isset($_SESSION['groupId']) || empty($_SESSION['groupId']) || $_SESSION['approvalFlow']) {
            $this->_SdisplayPage = 'base/index.tpl';
            $this->_assignOutPutValues(false);
        } else {
            $this->_SdisplayPage = 'base/mainPage.tpl';
            $this->_assignOutPutValues(true);
        }
    }

    /*
     * @description     : function render twig template and sends response back
     *                    menu to display in quick link with duplicate names
     * @param           : 
     * @return          : 
     */

    public function _getResponse() {
        
        ### return response headers
        $this->_addResponseHeader();
        $this->_OTwig->display($this->_SdisplayPage, $this->_AOutPutArray);
    }

    public function __destruct() {
        
    }
     /*
     * @description     : get fare profile setting in class object
     * @param           : 
     * @return          : 
     */
    private function _getFareProfileSettingsValue() {
        
         $this->_OcommonQuery             = new commonQuery();   
         $this->_AfareProfileSettingsInfo = $this->_OcommonQuery->_getSettingsDisplayData('','General_configurations');
         
    }
    
    
    //get the footer logo content based on corporate based on fare profile settings.
    public function _setFooterLogo(){
             
        //get settings info for the corporate.        
        $fareProfileSettingsInfo    = $this->_OcommonQuery->_getSettingsDisplayData(0,'General_configurations');
        $this->_SfooterLogoEnabled    =  $this->_AfareProfileSettingsInfo['Hyperlink_Small_Image_If_Required']['status'];
        $this->_SfooterLogoContent    =  str_replace("_"," ",$fareProfileSettingsInfo['Footer_write_Up']['textBoxValue']);
        $this->_SfooterLogoImageLink  =  $this->_AfareProfileSettingsInfo['Corporate_Logo']['textBoxValue'];
    }

}
