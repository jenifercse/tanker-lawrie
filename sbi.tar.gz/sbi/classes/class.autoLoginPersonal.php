<?php

/* * *****************************************************************************
 * @class		auto Login class file
 * @author      	Taslim
 * @created date	2016-04-09
 * **************************************************************************** */
//fileRequire("lib/system/xajaxCall.php");
fileRequire('lib/system/authToken.php');
fileRequire('classes/class.commonDBO.php');
fileRequire('misc/corporate/harinim/classes/class.login.php');
fileRequire('admin/corporate/harinim/classes/class.employee.php');
fileRequire('admin/corporate/harinim/classes/class.agency.php');
fileRequire('misc/corporate/harinim/classes/class.listMenu.php');
require_once 'classes/class.common.php';
class checkWSAutoLogin extends login {

    public function __construct() {

        parent::__construct();

        $this->db                      = new commonDBO();
        $this->_Oemployee              = new employee();
        $this->_OAgency                = new agency();
        $this->_Oemployee->_OcommonDBO = $this->db;
        $this->_OAgency->db            = $this->db;
    }

    /*
     * @description     : compare authorization key
     * @param           : string|$authKey
     * @param           : int|$aypAccountId
     * @param           : string|$aypEmailId
     * @param           : int|$aypCorporateId
     * @return          : boolean|$returnValue
     */

    public function _autoLoginFromPersonal($authKey, $aypAccountId, $aypEmailId, $aypAgencyId, $aypCorporateId, $agencyId, $aypUserType, $salutation, $firstName, $lastName, $mobileNo, $mappingData, $wsAuthType) {

        //array('usertype','usertypeId', 'groupId', level_id)
        //define user type array for use in queries
        $this->_AuserType = array('CA' => array('CA', 2, 2, 5),
                                  'CT' => array('TA', 2, 2, 5),
                                  'CU' => array('CU', 4, 4, 2),
                                  'NU' => array('NU', 5, 5, 0));

        if ($this->_generateAuthKey($aypAccountId, $aypEmailId, $aypCorporateId, $wsAuthType)) {

            if (strcmp($authKey, $this->_SaypAuthKey) == 0) {

                $employeeInfo = $this->_checkUserExists($aypEmailId, $mappingData['corporate_id']);

                if (!$employeeInfo) {

                    //insert employee into dm_employee table
                    $employeeEmailId = $this->_insertEmployeeMapping($aypCorporateId, $aypEmailId, $aypUserType, $salutation, $firstName, $lastName, $mobileNo, $mappingData);

                    if ($employeeEmailId) {

                        $this->_Arows['details']['title']               = $salutation;
                        $this->_Arows['details']['first_name']          = $firstName;
                        $this->_Arows['details']['last_name']           = $lastName;
                        $this->_Arows['details']['account_id']          = $this->IaccountId;
                        $this->_Arows['details']['corporate_id']        = $mappingData['corporate_id'];
                        $this->_Arows['details']['agency_id']           = $mappingData['agency_id'];
                        $this->_Arows['details']['sync_corporate_id']   = $mappingData['sync_corporate_id'];
                        $this->_Arows['details']['user_type']           = $this->_AuserType[$aypUserType][0];
                        $this->_Arows['details']['user_type_id']        = $this->_AuserType[$aypUserType][1];
                        $this->_Arows['details']['r_employee_id']       = $this->_IemployeeId;
                        $this->_Arows['details']['fact_employee_id']    = $employeeEmailId;
                        $this->_Arows['details']['r_level_id']          = $this->_AuserType[$aypUserType][3];
                        $this->_Arows['details']['group_id']            = $this->_AuserType[$aypUserType][2];
                        $this->_Arows['details']['email_id']            = $aypEmailId;
                        $this->_Arows['details']['mobile_no']           = $mobileNo;
                        $this->_Arows['valid'] = true;
                        $returnValue = true;

                        $this->_setUserSession();
                        $this->_setMenuState();

                        //if user is valid set uniqueauthorization token for the user
                        $autoToken = new authToken();
                        $autoToken->_setAuthToken();
                    } else {
                        $returnValue = false;
                    }
                } else {
                    
                    $this->_IinputData['loginEmail'] = $aypEmailId;
                    $result = $this->_validateUserCredentials($aypAgencyId, $aypCorporateId, $agencyId);
                    if ($result['valid']) {
                        $employeeEmailId = $employeeInfo[0]['email_id'];
                        $this->_setUserSession();
                        $this->_setMenuState();
                        //if user is valid set uniqueauthorization token for the user
                        $autoToken = new authToken();
                        $autoToken->_setAuthToken();
                        $returnValue = true;
                    } else {
                        $returnValue = false;
                        fileWrite('User not exist in corporate/agency:' . $this->_SerrorAlert . $aypEmailId, 'sso_request', 'a+');
                    }
                }
            } else {
                $returnValue = false;
            }
        } else {
            $returnValue = false;
        }
        return $returnValue;
    }

    /*
     * @description     : set state menu json file for router redirection 
     * @param           : 
     * @return          : 
     */

    private function _setMenuState() {

        $this->_listMenu = new listMenu();
        $menuListArray = $this->_listMenu->_getMenuDetails($this->_Arows['details']['group_id']);
        $stateCreation = $this->_listMenu->_createStateFile($menuListArray, $this->_Arows['details']['group_id']);
    }

    /*
     * @description     : insert employee mapping into tables
     * @param           : string|$emailId
     * @param           : string|$salutation
     * @param           : string|$firstName
     * @param           : string|$lastName
     * @return          : mixed|$factEmployeeId
     */

    private function _insertEmployeeMapping($aypCorporateId, $emailId, $aypUserType, $salutation, $firstName, $lastName, $mobileNo, $mappingData) {
         $_Ocommon=new common();

        //KOTAK_CORPORATE_ID
        $factEmployeeId = false;

        $insertArray = array();
        $insertArray['email_id'] = $emailId;
        $insertArray['title'] = $salutation;
        $insertArray['first_name'] = $firstName;
        $insertArray['last_name'] = $lastName;
        $insertArray['mobile_no'] = $mobileNo;

        $this->_IemployeeId = $this->_Oemployee->_insertEmployee($insertArray);

        $insertAccArray = array();
        $insertAccArray['login_password'] =  $_Ocommon->_generateEncryptionString();
        $insertAccArray['transaction_password'] = $_Ocommon->_generateEncryptionString();
        $insertAccArray['r_user_type_id'] = $this->_AuserType[$aypUserType][1];

        $this->IaccountId = $this->_Oemployee->_insertAccount($insertAccArray);

        $factArray = array();
        $factArray['r_employee_id'] = $this->_IemployeeId;
        $factArray['r_account_id'] = $this->IaccountId;
        $factArray['r_user_type_id'] = $this->_AuserType[$aypUserType][1];
        $factArray['r_corporate_id'] = $mappingData['corporate_id'];
        $factArray['r_level_id'] = $this->_AuserType[$aypUserType][3];

        if ($this->_IemployeeId && $this->IaccountId) {
            $factEmployeeId = $this->_Oemployee->_insertEployeeFactInfo($factArray);
        } else {
            $this->_errorMsg[] = 'Unable to insert new employee info';
        }

        return $factEmployeeId;
    }

    /*
     * @description     : check if user exists in db
     * @param           : string|$emailId
     * @return          : array|$result
     */

    private function _checkUserExists($emailID, $corporateId) {

        $sql = "SELECT de.email_id FROM dm_employee de INNER JOIN fact_employee fe ON de.employee_id = fe.r_employee_id
                WHERE de.email_id = '" . $emailID . "' AND de.status = 'Y'";

        $result = $this->db->_getResult($sql);

        return $result;
    }

    /*
     * @description     : geneate authorization key
     * @param           : int|$aypAccountId
     * @param           : string|$aypEmailId
     * @param           : int|$aypCorporateId
     * @return          : boolean|$aypAuthKey
     */

    private function _generateAuthKey($aypAccountId, $aypEmailId, $aypCorporateId, $wsAuthType = 1) {

        /* key generate algorithim
          md5(email_id+corporate_id+account_id+'infiniti'+current date) */

        $currentDate = date('Y-m-d');
        

        if ($aypEmailId != '' && $aypCorporateId != '') {

            switch ($wsAuthType) {

                case 1: /* WS AUTH TYPE = 1 FOR ATYOURPRICE SSO */
                case 3: /* WS AUTH TYPE = 3 FOR AGENCYAUTOFRONTEND SSO */
                    $this->_SaypAuthKey = md5($aypEmailId . $aypCorporateId . $aypAccountId . AYP_AUTOLOGIN_SALT . $currentDate);
                    break;

                case 2: /* WS AUTH TYPE = 2 FOR L&T SSO */
                case 4:
                    $this->_SaypAuthKey = md5($aypEmailId . $aypCorporateId . $aypAccountId . AYP_AUTOLOGIN_SALT . $currentDate);
                    break;

                default:
                    $this->_SaypAuthKey = md5($aypEmailId . $aypCorporateId . $aypAccountId . AYP_AUTOLOGIN_SALT . $currentDate);
            }

            $aypAuthKey = true;
        } else {
            $this->_errorMsg[] = 'Parameters not specified correctly';
            $aypAuthKey = false;
        }

        return $aypAuthKey;
    }

    public function _setApplicationMenu($wsAuthType, $menuDetails, $moduleEncoded) {

        if ($wsAuthType == 1) {
            $menuDetailsJson = trim(base64_encode(gzcompress($menuDetails, 9)));
            setcookie('corporateMenu',$menuDetailsJson,time() + (86400 * 30),PRODUCT_ROOT_NAME,DOCUMENT_ROOT,TRUE,TRUE);
            setcookie('encodedModuleName',$moduleEncoded,time() + (86400 * 30),PRODUCT_ROOT_NAME,DOCUMENT_ROOT,TRUE,TRUE);
        } 
        else{
            setcookie('encodedModuleName',$moduleEncoded,time() + (86400 * 30),PRODUCT_ROOT_NAME,DOCUMENT_ROOT,TRUE,TRUE);
        }
        setcookie('wsAuthType',$wsAuthType,time() + (86400 * 30),PRODUCT_ROOT_NAME,DOCUMENT_ROOT,TRUE,TRUE);
    }

    /*
     * @description     : redirect page
     * @param           : string|$pageName
     * @return          : 
     */

    public function _redirectPage($pageName = 'index.php') {

        header("Location:" . $this->_rootWebPath . "/" . $pageName);
    }

    /*
    * @description     : check sync mapping exist for external corporate or agency id
    * @param           : int|$syncAgencyId
    * @param           : int|$syncCorporateId
    * @return          : boolean|$returnValue
    */
    public function _checkCorporateAgencySyncMappingExists($syncAgencyId,$syncCorporateId,$agencyId,$syncPersonalId){
        
        $returnValue = array('response' => false, 'data' => '');

        if($syncAgencyId != '' || $syncCorporateId != ''){
            $returnValue = $this->_OAgency->_checkCorporateSyncIdExists($syncAgencyId,$syncCorporateId,$agencyId,'',$syncPersonalId);
        }
        return $returnValue;
    }

    public function _setModuleData($wsAuthType, $formValues){
        
        $_OauthToken = new authToken();
        $jsonEndCodedStateData = false;
        $stateData = array();
        
        //purify the json.
        $formValues = $_OauthToken->_purifyInputData($formValues);        
        $formValues = json_decode($formValues, 1); 
        switch ($wsAuthType) {

            /* authtype of sso of balmer corporate */
            case 4:
                if ($formValues['triptype'] == '0') {
                    $count = 0;
                } else if ($formValues['triptype'] == '1') {
                    $count = 0;
                } else if ($formValues['triptype'] == '2') {
                    $count = $formValues['count'];
                }

                $cabinClassArray = explode(":", $formValues['travelClass']);

                //assign and form request table data
                $stateData['masterInfo']['requestTableData']['trip_type'] = $formValues['triptype'];
                $stateData['masterInfo']['requestTableData']['adult_count'] = $formValues['adult'];
                $stateData['masterInfo']['requestTableData']['child_count'] = $formValues['child'];
                $stateData['masterInfo']['requestTableData']['infant_count'] = $formValues['infant'];
                $stateData['masterInfo']['requestTableData']['num_passenger'] = $formValues['num_passenger'];
                $stateData['masterInfo']['requestTableData']['r_travel_class_id'] = $cabinClassArray[0];
                $stateData['masterInfo']['requestTableData']['travel_type'] = $formValues['travelMode'];
                $stateData['masterInfo']['requestTableData']['return_date'] = $formValues['travelMode'] == 'D' ? $formValues['endDate'] : $formValues['iendDate'] ;

                $stateData['masterInfo']['requestTableData']['r_origin_airport_id'] = $formValues['origin0']['cityId'];
                $stateData['masterInfo']['requestTableData']['r_destination_airport_id'] = $formValues['depTo0']['cityId'];
                $stateData['masterInfo']['requestTableData']['onward_date'] = $formValues['onwardDate0'];

                $stateData['masterInfo']['oldCabinClass'] = $formValues['travelClass'];
                $stateData['masterInfo']['cabinClass'][0] = $cabinClassArray[0];
                $stateData['masterInfo']['cabinClass'][1] = $cabinClassArray[1];
                $stateData['masterInfo']['currency_name'] = '';
                $stateData['masterInfo']['r_travel_mode_id'] = $formValues['r_travel_mode_id'];
                $stateData['masterInfo']['onwardTimeStart'] = '';
                $stateData['masterInfo']['onwardTimeEnd'] = '';


                $stateData['hotelRequestDetails']['guest_details'] = array();
                $stateData['hotelRequestDetails']['room_details'] = array();

                $stateData['travelModeType'] = $formValues['r_travel_mode_id'];
                $stateData['packageType']    = $formValues['packageType'];
                $stateData['triptype']       = $formValues['triptype'];

                for ($i = 0; $i <= $count; $i++) {
                    $stateData['airRequestDetails'][$i]['requestTableData'] = array('r_origin_airport_id'      => $formValues['travelMode'] == 'D' ? $formValues['origin'.$i]['cityId'] : $this->_getCityCodeAirportId($formValues['iorigin'.$i]['cityCode']), 
                                                                                    'r_destination_airport_id' => $formValues['travelMode'] == 'D' ? $formValues['destination'.$i]['cityId'] : $this->_getCityCodeAirportId($formValues['idestination'.$i]['cityCode']) , 
                                                                                    'onward_date'              => $formValues['travelMode'] == 'D' ? $formValues['onwardDate'.$i]: $formValues['ionwardDate'.$i]);
                    
                    $stateData['airRequestDetails'][$i]['originCode']      = $formValues['travelMode'] == 'D' ? $formValues['origin'.$i]['cityCode'] : $formValues['iorigin'.$i]['cityCode'] ;
                    $stateData['airRequestDetails'][$i]['destinationCode'] = $formValues['travelMode'] == 'D' ? $formValues['destination'.$i]['cityCode'] : $formValues['idestination'.$i]['cityCode'];
                    $stateData['airRequestDetails'][$i]['originCity']      = $formValues['travelMode'] == 'D' ? $formValues['origin'.$i]['cityName'] : $formValues['iorigin'.$i]['cityName'] ;
                    $stateData['airRequestDetails'][$i]['destinationCity'] = $formValues['travelMode'] == 'D' ? $formValues['destination'.$i]['cityName'] : $formValues['idestination'.$i]['cityName'];
                    
                    
                    $stateData['showRequestDetails'][$i]['sectorFrom']     =$formValues['travelMode'] == 'D'  ? $formValues['origin'.$i]['cityName'] : $formValues['iorigin'.$i]['cityName'];
                    $stateData['showRequestDetails'][$i]['sectorTo']       = $formValues['travelMode'] == 'D' ? $formValues['destination'.$i]['cityName'] : $formValues['idestination'.$i]['cityName'];
                    $stateData['showRequestDetails'][$i]['startDate']      = $formValues['travelMode'] == 'D' ? $formValues['onwardDate'.$i] : $formValues['ionwardDate'.$i] ;
                    
                    //if trip is roundtrip end date is present
                    if(isset($formValues['endDate']) && !empty($formValues['endDate']) || isset($formValues['iendDate']) && !empty($formValues['iendDate'])) {
                        $stateData['showRequestDetails'][$i]['endDate']  =$formValues['travelMode'] == 'D' ? $formValues['endDate'] : $formValues['iendDate'] ;
                    }
                  
                }
                $stateData['passengerFirstName'] = $formValues['first_name'];
                $stateData['passengerLastName']  = $formValues['last_name'];
                
                break;

            default:
        }

        $jsonEndCodedStateData = json_encode($stateData);

        return $jsonEndCodedStateData;
    }
    
    public function _getCityCodeAirportId($cityCode, $dataArray) {
        
        $dmAirporatId = '';
// check city code airport id exist 
        $dmAirporatId = $this->db->_select('dm_airport', array('airport_id'), 'airport_code', $cityCode)[0]['airport_id'];
// return existing airport id or return last inserted airport id
        return $dmAirporatId ? $dmAirporatId : $this->db->_insert('dm_airport', array('airport_code'=> $dataArray['cityCode'], 'airport_desc'=> $dataArray['airport_desc']));
    }

}