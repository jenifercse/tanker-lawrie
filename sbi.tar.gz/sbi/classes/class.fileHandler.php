<?php

/* * *****************************************************************************
 * @class		Class to handle file operations
 * @author      	Taslim
 * @desc 		This class acts as class to handle file operations
 * @created date	2018-March-28
 * **************************************************************************** */

class fileHandler {

    public function __construct() {}

    /*
     * @description     : create a file in given location
     * @param           : string|$fileLocation
     * @param           : string|$mode
     * @return          : filePointer
     */

    public function fileCreate($fileLocation, $mode = 'r') {

        if ($fileLocation != '') {
            $this->fp = fopen($fileLocation, $mode);
        }
        
        return $this->fp;
    }

    /*
     * @description     : write content to a file
     * @param           : string|$fp
     * @param           : string|$content
     * @return          : 
     */

    public function writeContent($content, $fp = '') {

        if($content != '') {
            $fp = isset($fp) && !empty($fp) ? $fp : $this->fp;
            fwrite($fp, $content);
        }
    }
    
    public function readContent($filename, $mode='r') {
       
       $content = '';
      
       if(file_exists($filename)) {
            $this->fp = fopen($filename, $mode);
            $content  = fread($this->fp, filesize($filename));
       }
       
       return $content;
    }

    /*
     * @description     : function to close a file
     * @param           : string|$fp
     * @return          : 
     */

    public function fileclose($fp='') {
        
        $fp = isset($fp) && !empty($fp) ? $fp : $this->fp;
        
        fclose($fp);
    }
    
    public function __destruct() {
        $this->fileclose($this->fp);
    }

}