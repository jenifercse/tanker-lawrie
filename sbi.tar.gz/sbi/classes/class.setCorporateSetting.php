<?php
/* * **********************************************************************
 * @Class Name	: setCorporateSettings
 * @Created on	: 2017-05-22
 * @Created By	: Taslim
 * @Description	: This class holds get the corporate settings from the webservice request data
 * ************************************************************************ */
fileRequire('classes/class.baseModule.php');
fileRequire('classes/class.commonDBO.php');

class setCorporateSetting{    

    public function __construct(){
        $this->_ODBC                = new commonDBO();
        $this->_Ologin              = new login();
        $this->_OBaseModule         = new baseModule();
    }
    
    public function _getCorporateCustomization($dataArray,$requestArray){

        $returnValue = false;

        if(isset($dataArray['bookingType'])){

            //set booking type
            $booking_type = lcfirst($dataArray['bookingType'])."/";

            //booking related sync
            if(isset($requestArray['syncOrderId'])){

                //object creation
                $_Ocorporate = new corporate();

                //get corporate id
                $corporateId = $_Ocorporate->_getOrderCorporateId($requestArray['syncOrderId']);                
            }
            else{
                //settings related sync
                $corporateId = $this->_ODBC->_select('sync_corporate_details','*','sync_corporate_id',$requestArray['corporateId'])[0]['r_corporate_id'];
            }
        }
        else{   
            //get corporate id with respect to the SAP id
            $corporateId = $this->_ODBC->_select('agency_corporate_mapping','*','SAP_id',$requestArray['corporateName'])[0]['corporate_id'];

            //set booking type.
            $booking_type = "corporate/" ;
        }     

        //set the override plugin name
        if($corporateId != '' && $booking_type != ''){

            //set the application settings value in session
            $userApplicationSettings = $this->_Ologin->_getCorporateAppSettings($corporateId,$booking_type);

            //set the override package name
            if(isset($userApplicationSettings['OVERRIDE_PLUGIN_NAME'])){
                define('OVERRIDE_PACKAGE_NAME', array_search('YES', $userApplicationSettings['OVERRIDE_PLUGIN_NAME']));
            } 
            else{
                define('OVERRIDE_PACKAGE_NAME', 'harinim');
            }

            //set package name constants for customization
            if(OVERRIDE_PACKAGE_NAME != 'harinim'){                
                define('DEFAULT_PACKAGE_NAME','harinim');
            }

            //set plugin name
            define('PLUGIN_NAME', $dataArray['bookingType'].'/');

            if(isset($userApplicationSettings['OVERRIDE_PLUGIN_NAME'])){               
                $overRidePackageName =  OVERRIDE_PACKAGE_NAME;               
                if(trim(DEFAULT_PACKAGE_NAME,'/') != $overRidePackageName){
                    $this->_BOverRidePlugin          = true;
                    $this->_SoverRidePackageName     = $overRidePackageName;
                    $this->_SoverRidePluginPathName  = PLUGIN_NAME.'/'.$overRidePackageName;
                }
            }

            if($this->_BOverRidePlugin && pluginFileRequireByTravelMode("classes/class.sync.php")){
                $returnValue = $this->_SoverRidePackageName.'\\sync';
            } 
            else{
                fileRequire('classes/class.sync.php');
            }   
        }
        else{
            //override package name should be default package name in case of not overriden package name
            define('OVERRIDE_PACKAGE_NAME', 'harinim');
        }       
        return $returnValue;
    }
    
    /*
    * @Description  Function used to set the override plugin name based on the corporate id
    * @param int|$corporateId
    * @return string|OVERRIDE_PACKAGE_NAME
    * @date|19.12.2017
    * @author|Karthika.M
    */
    public function _getCorporatePluginName($corporateId,$bookingType = 'corporate'){

        if($corporateId != ''){

            //set the application settings value in session
            $userApplicationSettings = $this->_Ologin->_getCorporateAppSettings($corporateId,$bookingType.'/'); 

            //set application settings in session
            $_SESSION['userApplicationSettings'] = $userApplicationSettings;
            
            //set override package name.
            if(isset($userApplicationSettings['OVERRIDE_PLUGIN_NAME'])){
                define('OVERRIDE_PACKAGE_NAME', array_search('YES', $userApplicationSettings['OVERRIDE_PLUGIN_NAME']));
            } 
            else{
                define('OVERRIDE_PACKAGE_NAME', 'harinim');
            }
            
            //set package name constants for customization
            if(OVERRIDE_PACKAGE_NAME != 'harinim'){                
                define('DEFAULT_PACKAGE_NAME','harinim');
            }

            //set plugin name
            define('PLUGIN_NAME', $dataArray['bookingType'].'/');
        } 
        else{
            //override package name should be default package name in case of not overriden package name
            define('OVERRIDE_PACKAGE_NAME', 'harinim');
        }
        return OVERRIDE_PACKAGE_NAME;
    }
}
?>