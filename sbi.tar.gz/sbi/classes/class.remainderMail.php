<?php
/****************************************************************************
 * @File             : class.remainderMail.php
 * @Description      : This file is used to send remainder mail based on settings
 * @dimensionTables  : remainder_mail_settings,dm_mail_log
 * @Author           : Lakshmi.S
 * @Created Date     : 01/08/2017
 * @Modified Date     : 
 *****************************************************************************/
class remainderMail{

    private $_OcommonDBO; 
    public function __construct(){
        $this->_OlistDisplay = new listDisplay();
        $this->_Oemployee = new employee();
        $this->_Opassenger = new passenger();        
        //$this->_OhotelReq = new hotelRequest();
        $this->_OcommonDBO = new commonDBO();
        $this->_OmailLog = new mailLog();
        $this->_OcommonMethods = new commonMethods();
        $this->_OsendSms=new sendSms();
        $this->_OcommonQuery=new commonQuery();
        $this->_Otwig = init();        
    }

          
    /*@author          :   A.kaviyarasan
    * @functionName    :   _remainderEmail()
    * @description     :   used to store  reminder mail details in mail_log and remainder_mail_settings
    * return value     : 
    */ 
    public function _remainderEmail($orderId){ 
        
        //getting the orderID,agecnyId,corporateId from booking history
        $orderdetail = $this->_OcommonDBO->_select('booking_history',array('order_id','r_agency_id','package_id','r_corporate_id'),'sync_order_id',$orderId);
        
        //getting the travel_mode and employeeID from fact_booking_details
        $travelModeId=$this->_OcommonDBO->_select('fact_booking_details', array('travel_mode','r_employee_id'), 'r_order_id', $orderdetail[0]['order_id']);
        
        //getting the travel mode name from dm_travel_mode 
        $travelMode=$this->_OcommonDBO->_select('dm_travel_mode', 'travel_mode', 'travel_mode_id', $travelModeId[0]['travel_mode']);
        
        //getting the travelMode without any spaces 
        $travleModeName = preg_replace('/\s+/','',$travelMode[0]['travel_mode']);
        
        //dynamically get the class  Name
        $classname = 'common'.$travleModeName.'ItineraryDisplay';
        
        //creatin the Object for that class dynamically
        $this->objClass = new $classname();
        
        //dynamic method name based on travel mode name        
        $methodName = '_get'.$travleModeName.'ItineraryInfo';
        $orderdetail[0]['orderId']=$orderdetail[0]['order_id'];
        
        //call the class function to initiate the call_user_func with parameter     
        $this->_AtwigOutputArray = call_user_func( array($this->objClass, $methodName), $orderdetail[0]);
        $tplName = lcfirst($travleModeName).'MailItinerary.tpl';
        filewrite('tpl name=>'.$tplName,'settingArray','a+');
        
        //looping the itinerary Info for getting the trip type and plays the logic
        foreach($this->_AtwigOutputArray['itineraryInfo'] as $key => $val){
            
            //Based on  trip type Form Sql Statement
            $val['trip_type'] == 1? $deparuteDate ='return_depature_date as depatureDate':$deparuteDate='onward_depature_date as  depatureDate';
            
            //geting the depature date from booking_history
            $deparuteDate = $this->_OcommonDBO->_select('booking_history',$deparuteDate,'order_id',$val['order_id'])[0]['depatureDate']; 
            $val['depature_date_format'] = $deparuteDate;
            
            //insert the values to the remender_mail_settings table
            $val['packageId'] = $orderdetail[0]['package_id'];
            filewrite(print_r($val,1),'settingArray','a+');
            
            $result = $this->_insertRemainderMailSettings($val);
            
            //checking the result is true or not
            if($result){
                
                //looping the pax Info for sending the mail for all passenger
                foreach($this->_AtwigOutputArray['paxInfo'] as $key => $value){
                    
                    if(!empty($value['email_id'])){
                        
                        //forming the insertion details
                        $insertdetails['r_agency_id']   =$orderdetail[0]['r_agency_id'];
                        $insertdetails['r_corporate_id'] =$orderdetail[0]['r_corporate_id'];        
                        $insertdetails['r_employee_id']  =$travelModeId[0]['r_employee_id'];
                        $insertdetails['r_order_id']     =$val['order_id'];
                        $insertdetails['mail_from']     ='support@atyourprice.in';
                        $insertdetails['mail_type']     =3;
                        $insertdetails['mail_to']       =$value['email_id'];
                        $insertdetails['trip_type']     = $val['trip_type'];
                        $insertdetails['mail_subject']  ='Reminder Mail For Your Travel';
                        $renderingData=$this->_AtwigOutputArray;
                        
                        //forming the message array
                        $renderingData['message']="Dear  ".$value['paxName'].",
                             You have a Travel On  ".$val['depature_date_format']."  from  ".$val['airport_origin_desc']."  to ".$val['airport_dest_desc']."\n"
                                ." Happy Journey";

                        $renderingData['itineraryInfo'] = '';
                        $renderingData['itineraryInfo'][0] = $val;
                        
                        //rendiring the template with appropriate passenger detail
                        $response = $this->_Otwig->render($tplName,$renderingData);
                        filewrite(print_r($response,1),'responseforremainder','a+');
                        $insertdetails['mail_contents']=$response;
                        $this->_insertMailLog($insertdetails);
                    }
                }
            }
        }            
    }    
    
    public function _remainderMailData_24HRS_PRIOR_DEPART($input){
        fileWrite(print_r($input, 1), "REMAINDERMAIL", "a+");
        $insertValues = array();
        $departureDate = $input['flightSearchData']['selectedOnwardFlight']['via_flights'][0]['departure_date'];
        $departureTime = $input['flightSearchData']['selectedOnwardFlight']['via_flights'][0]['time_departure'];
        $departureDateTime = $departureDate . " " . $departureTime;
        fileWrite("In departuredatetime" . $departureDateTime, "REMAINDERMAIL", "a+");
        $remainderDateTime = date_create(date("Y-m-d H:i:s", strtotime($departureDateTime)));
        fileWrite("In remainderDateTime" . print_r($remainderDateTime, true), "REMAINDERMAIL", "a+");
        date_sub($remainderDateTime, date_interval_create_from_date_string('24 hours'));
        fileWrite("In remainderDateTime after" . print_r($remainderDateTime, true), "REMAINDERMAIL", "a+");
        $finalRemainderDateTime = date_format($remainderDateTime, 'Y-m-d H:i:s');
        fileWrite("In remainderDateTime after" . $finalRemainderDateTime, "REMAINDERMAIL", "a+");
        $insertValues['r_order_id'] = $input['factBookingDetails']['r_order_id'];
        $insertValues['mail_date'] = $finalRemainderDateTime;
        $insertValues['mail_count'] = 1;
        $insertValues['email_id'] = $input['approverEmailId'];
        $insertValues['created_date'] = date('Y-m-d H:i:s');
        fileWrite("In insert input" . print_r($insertValues, true), "REMAINDERMAIL", "a+");
        $this->_OcommonDBO->_insert('remainder_mail_settings', $insertValues);
    }

    /*
    * @functionName    :   _insertRemainderMailSettings()
    * @description     :   used to insert the remainder mail settings 
    * @param           :   
    * @return          :   query executed array
    */
    public function _insertRemainderMailSettings($input){
        $SettingArray = $this->_OcommonQuery->_getSettingsDisplayData($input['packageId'],'SMS/Email');
        filewrite(print_r($SettingArray,1),'settingArray','a+');
        $remaindermail = $SettingArray['Remainder_Mail'];
        return false;
    }

    /*
    * @functionName    :   _makeTime()
    * @description     :   used to make the make the time wioith difference for storing it into the remainder_mail_settings table 
    * @param           :   take the time to make the difference
    * @return          :  return the altered time
    */
    public function _makeTime($datewithtime, $hours){
        $remainderDateTime = date_create(date("Y-m-d H:i:s", strtotime($datewithtime)));
        date_sub($remainderDateTime, date_interval_create_from_date_string($hours));
        $finalRemainderDateTime = date_format($remainderDateTime, 'Y-m-d H:i:s');
        return $finalRemainderDateTime;
    }

    public function _insertMailLog($input){
        $sql = "INSERT INTO mail_log SET
                    r_agency_id       = '" . $input['r_agency_id'] . "',
                    r_corporate_id    = '" . $input['r_corporate_id'] . "',
                    r_employee_id     = '" . $input['r_employee_id'] . "',
                    r_order_id       = '" . $input['r_order_id'] . "',
                    mail_from        ='" . $input['mail_from'] . "',
                    mail_type        = '" . $input['mail_type'] . "',
                    mail_to          = '" . $input['mail_to'] . "',
                    trip_type        = '" . $input['trip_type'] . "',
                    mail_subject     = '" . $input['mail_subject'] . "', 
                    mail_contents    = COMPRESS('" . $input['mail_contents'] . "'),
                    status           = '" . $input['status'] . "'";
        $this->_OcommonDBO->_executeQuery($sql);
    }

    /* @autor          :   A.kaviayrasan
    * @functionName    :   _checkRemainderMailSettings()
    * @description     :   used to get the remainder mail's from the remainder_mail_settings table from now date  
    * @return          :   query executed array
    */
    public function _checkRemainderMailSettings(){

        //forming sql statement for getting the email's Information
        $sql = " SELECT r_order_id,mail_count,trip_type,mail_sent_count,time_interval,mail_status,mail_date
                FROM remainder_mail_settings WHERE mail_status='Y' AND mail_date <= now()";
        $result = $this->_OcommonDBO->_getResult($sql);
        
        //looping the Email ID's Information 
        foreach ($result as $value){            
            $mailDetails = $this->_OmailLog->_getMailDetails($value['r_order_id'], $value['trip_type'])[0];            
            $mailStatus = $this->_OcommonMethods->_sendMail($mailDetails['mail_to'], $mailDetails['mail_from'], $mailDetails['mail_subject'], $mailDetails['mail_contents'],'','',BALMER_MAIL_REQUEST_BCC_PASSENGER);
            if($mailStatus){
                $this->_updateRemainderMailSettings($value);
            }
        }
    }

    /* @autor          :   A.kaviayrasan
    * @functionName    :   _updateRemainderMailSettings()
    * @description     :   Update Remainder_mail_settings table status and mail_sent_count for particular OrderId and Trip Type    
    * @return          :   query executed array
    */
    public function _updateRemainderMailSettings($value){
        
        $updateArray['mail_sent_count'] = $value['mail_sent_count'] + 1;
        if($updateArray['mail_sent_count'] == $value['mail_count']){
            $updateArray['mail_status'] = 'N';
        }
        $sql = 'UPDATE remainder_mail_settings ';
        if(!empty($updateArray['mail_status'])){
            $sql .="SET mail_status = '" . $updateArray['mail_status'] . "',";
        }
        if(!empty($value['r_order_id'])){
            $sql .="mail_sent_count = " . $updateArray['mail_sent_count'] . " where r_order_id=" . $value['r_order_id'] . " and trip_type=" . $value['trip_type'];
        }
        $result = $this->_OcommonDBO->_executeQuery($sql);
    }
    

    public function _departureDateRemainderMail($remainderMailSettingsData){
        
        $sqlOrderDetails = "SELECT order_id,departure_date,time_departure FROM order_details od,approval_tracking at,air_booking_details abd,fact_air_itinerary fai,via_flight_details vfd
                            WHERE od.order_id = at.r_order_id
                                AND abd.r_order_id = od.order_id
                                AND fai.r_air_booking_details_id = abd.air_booking_details_id
                                AND vfd.via_flight_id = fai.r_via_flight_id
                                AND vfd.segment_order = 1
                                AND vfd.trip_type = 0
                                AND od.r_ticket_status_id = ".SEND_FOR_APPROVAL." 
                                AND at.approval_level =  od.approval_level 
                                AND at.approval_view_status = 'N' ";

        $result = $this->_OcommonDBO->_getResult($sqlOrderDetails);
        foreach($result as $orderDetails){
            $todayDate = strtotime(date("Y-m-d H:i:s"));
            $departureDate = strtotime($orderDetails['departure_date'] . " " . $orderDetails['time_departure']);
            $timeDifference = round(abs($todayDate - $departureDate) / 60, 2);
            if($timeDifference > $remainderMailSettingsData['time_interval']){
                
            }
        }
    }

    /*
    * @Description  This method used to send remainder approval mail.
    * @param int|$corporateId
    * @date|22.02.2018 
    * @author|Karthika.M
    */ 
    public function _sendApprovalRemainderMail($corporateId){       
        
        global $CFG;
        
        $mailResponse = array();
        
        //object declaration.
        $this->_OapprovalTracking = common::_checkClassExistsInNameSpace('approvalTracking'); 
        
        //get hours.
        if(isset($CFG['approval_remainder_mail'][$corporateId]) && count($CFG['approval_remainder_mail'][$corporateId]) > 0){
            
            //array to string.
            $remainderHours = implode(',',$CFG['approval_remainder_mail'][$corporateId]);
            
            //get not approved bookings info.
            $notApprovedBooking = $this->_OapprovalTracking->_getNotApprovedBooking($corporateId,$remainderHours);
            
            //send remainder approval mail.
            if($notApprovedBooking && count($notApprovedBooking) > 0){             
                foreach($notApprovedBooking as $key => $value){           
                    //send mail to approver
                    $mailResponse['approverMail'] = $this->_formRemainderApprovalInput($value);
                    //send mail to passenger
                    $mailResponse['paxMail'] = $this->_formRemainderPassengerInput($value);                    
                }
            }
        }        
        return $mailResponse;
    }
    
    /*
    * @Description  This method used to form mail input.
    * @param int|$corporateId
    * @date|22.02.2018 
    * @author|Karthika.M
    */ 
    public function _formRemainderApprovalInput($value){
        
        //object declaration.
        $this->_OsendToApproval = new sendToApproval();
        
        //form input
        $mailInput['employee_id'][0] = $value['approver_id'];
        $mailInput['package_id'] = $value['packageId'];
        $mailInput['order_id'] = $value['orderId'];
        $mailInput['packageType'] = $this->_OcommonDBO->_select('dm_package','*','package_id',$value['packageId'])[0]['package_type'];
        $mailInput['status'] = 'Y';
        $mailInput['subject'] = "Request For Approval - Booking ID ".$value['orderId'];
        $mailInput['multicityStatus'] = 'N';
        
        //assign the twig value to approval process class.
        $this->_OsendToApproval->_Otwig = $this->_Otwig;    
        return $this->_OsendToApproval->_sendMailContent($mailInput);       
    }
    
    /*
    * @Description  This method used to form mail input for sending mail to pax.
    * @param array|$value
    * @date|28.03.2018 
    * @author|Karthika.M
    */ 
    public function _formRemainderPassengerInput($value){    
        
        //object declaration.
        $this->_OapprovalProcess = new approvalProcess();
        
        //send the remainder mail to pax for the booking not approved by approver.
        $passengerInfo = $this->_OcommonDBO->_select('passenger_details','*','r_order_id',$value['orderId']);
        $paxInfo = array_column($passengerInfo,'email_id');
        
        //form input
        $mailInput['email_id'] = $paxInfo;
        $mailInput['package_id'] = $value['packageId'];
        $mailInput['order_id'] = $value['orderId'];
        $mailInput['packageType'] = $this->_OcommonDBO->_select('dm_package','*','package_id',$value['packageId'])[0]['package_type'];
        $mailInput['status'] = 'N';
        $mailInput['subject'] = "Approval is pending for the Booking ID ".$value['orderId'];
        $mailInput['multicityStatus'] = 'N';
        
        //assign the twig value to approval process class.
        $this->_OapprovalProcess->_Otwig = $this->_Otwig;    
        return $this->_OapprovalProcess->_sendMailContent($mailInput);  
    }

     /*
    * @Description  This method used to send remainder trip approval mail.
    * @param int|$corporateId
    * @date|17.03.2018 
    * @author|Rajesh U
    */ 
    public function _sendTripApprovalRemainderMail($corporateId){       
        
        global $CFG;
        
        $mailResponse = array();
        
        //object declaration.
        $this->_OapprovalTracking = common::_checkClassExistsInNameSpace('approvalTracking'); 

        //get hours.
        if(isset($CFG['approval_remainder_mail'][$corporateId]) && count($CFG['approval_remainder_mail'][$corporateId]) > 0){
            
            //array to string.
            $remainderHours = implode(',',$CFG['approval_remainder_mail'][$corporateId]);
            
            //get not approved bookings info.
            $notApprovedBooking = $this->_OapprovalTracking->_getNotApprovedTrip($corporateId,$remainderHours);
            
            //send remainder approval mail.
            if($notApprovedBooking && count($notApprovedBooking) > 0){             
                foreach($notApprovedBooking as $key => $value){           
                    //send mail to approver
                    $mailResponse['approverMail'] = $this->_formTripRemainderApprovalInput($value);
                    //send mail to passenger
                    $mailResponse['paxMail'] = $this->_formTripRemainderPassengerInput($value);                    
                }
            }
        }        
        return $mailResponse;
    }

     /*
    * @Description  This method used to form mail input for sending mail to pax.
    * @param array|$value
    * @date|17.05.2019 
    * @author|Rajesh U
    */ 
    public function _formTripRemainderApprovalInput($value){    
        
        $buttonStatus = $value['approval_type'] == 'IA' ? 'N' : 'Y';
        return $this->_formTripRemainderMailInput($value['approver_id'],$value['trip_request_details_id'],$value['approval_tracking_id'],$value['userName'],$buttonStatus);
        
    }

     /*
    * @Description  This method used to form mail input for sending mail to pax.
    * @param array|$value
    * @date|17.05.2019 
    * @author|Rajesh U
    */ 
    public function _formTripRemainderPassengerInput($value){    
        
        return $this->_formTripRemainderMailInput($value['employee_id'],$value['trip_request_details_id'],$value['approval_tracking_id'],$value['userName'],'N');
    }



    /* 
 * @Function Name             : _formTripRemainderMailInput
 * @Description               : this function used to form trip approver info
 * @Author                    : Rajesh U
 * @Created Date              : 17/05/2019
 */

 public function _formTripRemainderMailInput($employeeApproverId,$tripDetailsId,$approvalTrackingId,$userName  = '',$buttonStatus){

    $this->_OtripCreation = common::_checkClassExistsInNameSpace('tripCreation');


    $tripDetails = $this->_OtripCreation->_mailInputFormation($tripDetailsId)[0];
    
    $mailInput['tripRequest'] =  $tripDetails;

    $mailInput['buttonStatus'] = $buttonStatus;

    $mailInput['employeeName'] = $userName != '' ? $userName : $_SESSION['userName'];

    $subject = "Request for Trip Approval - Trip Id " .$tripDetailsId;

    $approverInfo = $this->_OcommonDBO->_select('dm_employee','*','employee_id',$employeeApproverId)[0];
    
    $approverMailId = $approverInfo['email_id'];

    $mailInput['approverName'] = $approverInfo['title']." ".$approverInfo['first_name']." ".$approverInfo['last_name'];

    $mailInput['ticketRequest'] = $this->_getTripOrderInfo($tripDetailsId);
    $mailInput['link'] = $this->_OtripCreation->_formApproveAndRejectLinkForMail($tripDetails,$approverMailId,$approvalTrackingId);

    return $this->_OtripCreation->_sendTripMail($approverMailId,$mailInput,$subject);

    filewrite(print_r($mailInput,1),'MAIL','a+');

 }

public function _getTripOrderInfo($tripId){

    $orderId = $this->_OcommonDBO->_select('fact_trip_order_details','r_order_id','r_trip_request_details_id',$tripId);
    $approvalType = $this->_OcommonDBO->_select('trip_request_details','approval_type','trip_request_details_id',$tripId)[0]['approval_type'];
    $orderInfo = implode(",", array_column($orderId,'r_order_id'));
    if(!empty($orderId)){
    $sql = "SELECT vfd.*,od.* FROM fact_booking_details fbd
            INNER JOIN order_details od ON od.order_id = fbd.r_order_id 
            INNER JOIN passenger_via_details pvd ON pvd.r_order_id = fbd.r_order_id
            INNER JOIN via_flight_details vfd ON vfd.via_flight_id = pvd.r_via_flight_id 
            WHERE fbd.r_order_id IN (" . $orderInfo . ") ";
                if($approvalType == 0){
                    $sql .= " AND od.r_ticket_status_id = " . SEND_FOR_APPROVAL;
                }else{
                    $sql .= " AND od.approval_status = " . POST_FACTO_SEND_FOR_APPROVAL;
                }
    $result = $this->_OcommonDBO->_getResult($sql);
    $arrayCount = count($result);
        foreach ($result as $key => $value) {
            $mailInfo[$key]['fromCity']     = $result[$key]['r_origin_airport_id'] ? $this->_OcommonDBO->_select('dm_airport','city_name','airport_id',$result[$key]['r_origin_airport_id'])[0]['city_name']: '';
            $mailInfo[$key]['toCity']   = $result[$key]['r_destination_airport_id'] ? $this->_OcommonDBO->_select('dm_airport','city_name','airport_id',$result[$key]['r_destination_airport_id'])[0]['city_name'] : '';
            $mailInfo[$key]['fromDate']     = $result[$key]['departure_date'];
            $mailInfo[$key]['toDate']   = $result[$key]['arrival_date'];
            $mailInfo[$key]['fromTime']     = $result[$key]['time_departure'];
            $mailInfo[$key]['toTime']   = $result[$key]['time_arrival'];
        }
    }
    return $mailInfo;


}


}
?>