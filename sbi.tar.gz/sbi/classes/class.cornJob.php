<?php

/* * **********************************************************************
 * @Class Name	: cornJob
 * @Created on	: 2017-05-11
 * @Created By	: Sivaprakash.M
 * @Description	: This cornJob class is used to process the action need to be done by the functions
 * ************************************************************************ */
filerequire('lib/common/commonMethods.php');

class cornJob {

    public function __construct() {
        $this->db = new commonDBO();
        $this->_AapprovalProcess = new approvalProcess();
        $this->objCommon = new commonMethods();
        $this->_Ppromocode = new promoCode();
        $this->responseMessage = '';
    }

    /*
     * @functionName    :   promoCodeUpdationAndMailExpiryDetails()
     * @param           :   $dataArray | array
     * @description     :   get the list of promocode expiry details details 
     * @return          :   $responseMessage | string
     */

    public function checkPromocodeExpiry() {
        $this->promoCodeUpdationAndMailExpiryDetails();
        return $this->promoCodeUpdationAndMailExpiryDetails(array('interval' => DEFAULT_DAYS_LIMIT));
    }

    /*
     * @functionName    :   promoCodeUpdationAndMailExpiryDetails()
     * @param           :   $dataArray | array
     * @description     :   get the list of promocode expiry details details 
     * @return          :   $responseMessage | string
     */

    public function promoCodeUpdationAndMailExpiryDetails($dataArray = '') {

        $inputData['promoCodeCheckValidityDate'][0] = ($dataArray['interval'] != '' || $dataArray['interval'] != 0) ? date('Y-m-d', strtotime('+' . $dataArray['interval'] . ' days')) : date('Y-m-d');
        $inputData['promoCodeCheckValidityDate'][1] = ($dataArray['interval'] != '' || $dataArray['interval'] != 0) ? '=' : '<';

        $result = $this->_Ppromocode->_getPromoCodeAndAirlineDetails($inputData);

        $this->responseMessage = 'No promocode has been expired';

        if (count($result) > 0 && !empty($result)) {
            if (($dataArray['interval'] != '' || $dataArray['interval'] != 0)) {// to intimate than the promocode is going to be expired
                $promoCodeExpiryDetails = array();
                $result = array_unique(array_column($result, 'promo_code_value'));

                foreach ($result as $key => $value) {
                    $promoCodeExpiryDetails[$value] = implode(', ', array_column($this->db->_getResult('SELECT corporate_name FROM dm_corporate WHERE corporate_id ' . "IN (" . implode(',', array_column($this->db->_getResult("SELECT pcm.r_corporate_id FROM promo_code_mapping pcm INNER JOIN dm_promo_code dmp ON pcm.r_promo_code_id = dmp.promo_code_id WHERE dmp.promo_code_value = '$value' "), 'r_corporate_id')) . ")"), 'corporate_name'));
                }
                // to intimate than the promocode is going to be expired  details  
                $this->_AtwigOutputArray['colortheme'] = BOOKING_MAIL_THEME;
                $this->_AtwigOutputArray['promocodeExipry'] = $promoCodeExpiryDetails;
                $this->_AtwigOutputArray['promocodeExipryDate'] = $inputData['promoCodeCheckValidityDate'][0];
                // to intimate than the promocode is going to be expired details for mail content   
                $mailDisplayContent = $this->_Otwig->render('promoCodeExpiryInformation.tpl', $this->_AtwigOutputArray);
                $subject = " Corporate Promocode Expiry Details From AgencyAutoFrontEnd Portal ";

                $this->responseMessage = $this->objCommon->_sendMail(PROMOCODE_EXPIRY_DETAILS_MAIL_INFO, 'support@atyourprice.in', $subject, $mailDisplayContent);
            } else {// to update the expired promocode 
                $statusChangePromoCodeIds = implode(',', array_column($result, 'r_promo_code_id'));
                // update expired promocode status
                $promo_code_mapping_update = $this->db->_update('promo_code_mapping', array('search_status' => 'N', 'status' => 'N'), 'r_promo_code_id', "(" . $statusChangePromoCodeIds . ")", 'IN');
                $dm_promo_code_update = $this->db->_update('dm_promo_code', array('fare_check' => 'N', 'status' => 'N'), 'promo_code_id', "(" . $statusChangePromoCodeIds . ")", 'IN');

                (!empty($promo_code_mapping_update) || !empty($dm_promo_code_update)) ? $this->responseMessage = 'Update Successfully' : '';
            }
        }
        return $this->responseMessage;
    }

    /**
     * used to auto generate cancellation for the booking which has status in send for approval
     * departure date and departure time is less then 3hrs from current date and time
     * @param type $inputData array
     * @return type string
     */
    public function _autoCancellationBookingsByTimePrior($inputData) {

        $autoCancellationOrderData = array();

        $sql = " SELECT 
                        order_id, trip_type as tripType, travel_mode
                FROM 
                        auto_cancellation_booking
                WHERE 
                        cancellation_time <= NOW() AND status = 'Y' ";

        $autoCancellationOrderData = $this->db->_getResult($sql);

        return $this->responseMessage = (count($autoCancellationOrderData) > 0 && !empty($autoCancellationOrderData[0])) ? $this->_raiseAutoCancellation($autoCancellationOrderData) : 'No booking to be raised for cancellation';
    }

    /**
     * used to auto cancellation for booking in time prior
     * @param type $autocancellationDetails array
     * @return type string
     */
    public function _raiseAutoCancellation($autocancellationDetails) {

        $result = $orderArray = array();

        foreach ($autocancellationDetails as $key => $value) {

            //get the travel mode name without hite spaces preg_replace
            $travleModeName = preg_replace('/\s+/', '', $value['travel_mode']);

            //dynamic method name based on travel maode name        
            $methodName = '_raise' . $travleModeName . 'CancelRequest';

            //call the class function to initiate the call_user_func with parameter for automate cancellation
            $result[] = call_user_func(array($this->_AapprovalProcess, $methodName), $value);
            // assign orderid 
            $orderArray[$key] = $value['order_id'];
        }
        // update status in auto_cancellation_booking for automated cancelled bookings
        count($orderArray) > 0 ? $this->db->_update('auto_cancellation_booking', array('status' => 'N', 'updated_date' => date('Y-m-d H:i:s')), 'order_id', '(' . implode(',', $orderArray) . ')', 'IN') : FALSE;

        return count($result) > 0 ? 'Booking has automated for cancellation' : FALSE;
    }

    /*
     * @author          :A.kaviyarasan
     * @Description     :This function will check and send the reamindermail and remainderMsg if setting is available 
     * 
     */

    public function _RemainderMailandMsg() {
        fileWrite('CRONCHECK', 'croncheck');
        $this->_OreminderMail = new reminderMail();
        fileWrite('CRONCHECK', 'croncheck', 'a+');
        $this->_OreminderMail->_checkRemainderMailSettings();
        $this->_OsendSms = new sendSms();
        $this->_OsendSms->_getReminderMessageDetails();
    }

    /*
     * @author          :Deepak Pande
     * @Description     :This function will check the card expiry date
     * 
     */

    public function _checkCardExpiryDate() {
        fileWrite('inside---_checkCardExpiryDate', 'checkCard','a+');
        $this->_OpassThrough = new passThrough();
        $this->_OpassThrough->_checkFirstDateOfMonth();
    }



    /**
    * @Description : function used to send approval remainder mail to corresponding approver.
    * @author Karthika.M
    * @date 2018-02-22
    */
    public function _approvalRemainderMail(){
        
        global $CFG;
        
        //object declaration.
        $this->_OremainderMail = new remainderMail();
        
        //array initialization.
        $response = array();
        
        //looping config.
        foreach($CFG['approval_remainder_mail'] as $corporateId => $value){
            //send approval mail.
            $response[$corporateId] = $this->_OremainderMail->_sendApprovalRemainderMail($corporateId);
        }
        return $response;
    }

    /**
    * @Description : function used to send trip approval remainder mail to corresponding approver.
    * @author Rajesh.U
    * @date 2019-05-17
    */
    public function _tripApprovalRemainderMail(){
        
        global $CFG;
        
        //object declaration.
        $this->_OremainderMail = new remainderMail();
        
        //array initialization.
        $response = array();
        
        //looping config.
        foreach($CFG['approval_remainder_mail'] as $corporateId => $value){
            //send approval mail.
            $response[$corporateId] = $this->_OremainderMail->_sendTripApprovalRemainderMail($corporateId);
        }
        return $response;
    }

    /**
    * @Description : function used to sync the unsync data to the sap
    * @author Rajesh.U
    * @date 2019-08-27
    */
    public function syncUnsyncDataToSAP(){
        //object declaration.
        $this->_OssbtToSAP = new ssbtToSAP();
       
        // calling function to sync the unsync details to sap

        $response = $this->_OssbtToSAP->_syncDataToSap();
       
        return $response;
    }

    /**
    * @Description : function used to sync the unsync data to the sap
    * @author Rajesh.U
    * @date 2019-08-27
    */
    public function sendMailTripData() {
        $this->_SdateTimeToday = date('Y-m-d H:i:s');
        $this->_OssbtToSAP = new ssbtToSAP();
        $this->_Oreport = new report();
        $this->_SprofilePath  = PROFILE_UPLOAD_PATH;
        // calling function to sync the unsync details to sap
        $response = $this->_OssbtToSAP->_getSapSyncData('N');
        $dataFound = false;
        if(is_array($response)){
            $dataFound = true;
            $headerValue = array_flip(array_change_key_case(array_flip(array_keys($response[0])),CASE_UPPER));
            $this->_Oreport->_AheaderData = $headerValue;
            
            //Send invalid profiles to the user
            $this->_filePath = "Trip_Data" . $this->_SdateTimeToday . ".xlsx" ;

            
            $this->_Oreport->_createCsvFile( $response, $this->_SprofilePath . $this->_filePath,2);

            $subject = 'LIST OF Data Not Pushed to SAP ';
            $msg = 'Please find the attachment containing trip data not updated to sap.';
            $this->_sendErrorEmail($subject,$msg,SAPUNSYNC_SEND_MAIL);
        }
    }
    
    /**
    * @Description : function used to expire the Time Based Approval action and request to next level approval
    * @author Rajesh.U
    * @date 2019-09-09
    */

    public function expireTimeApprovalAction(){

        $this->_OsendToApproval = new sendToApproval();

        $sql = "SELECT
                    apt.r_order_id,TIMESTAMPDIFF(HOUR,approve_sent_date,now()) as hours
                FROM
                    approval_tracking apt
                INNER JOIN order_details od ON apt.r_order_id = od.order_id
                AND od.approval_level = apt.approval_level
                WHERE
                    apt.approval_type IN ('TA') AND apt.approval_view_status = 'N' AND TIMESTAMPDIFF(HOUR,apt.approve_sent_date,now()) >= ".TIME_APPROVAL_EXPIRE_TIME;

        $expiredOrder = $this->db->_getResult($sql);

        $sendMailToNextLevel = $this->_OsendToApproval->_sendMailToNextLevel($expiredOrder);

        return $sendMailToNextLevel; 
    }

    /**
    * @Description : function used get not paid booking 
    * @author Rajesh.U
    * @date 2019-10-14
    */
    public function getUnsyncBookingDetails() {

        $this->_SdateTimeToday = date('Y-m-d H:i:s');
        $time = strtotime($this->_SdateTimeToday);
        $startTimeDiff = $time - (60 * 60);
        $endtimeDiff = $time - (ERROR_DIFF_TIME * 60);
        $startDate = date("Y-m-d H:i:s", $startTimeDiff);
        $endDate = date("Y-m-d H:i:s", $endtimeDiff);
        $this->_Oemployee = new employee();
        $this->_Oreport = new report();
        $this->_SprofilePath  = PROFILE_UPLOAD_PATH;
        // calling function to sync the unsync details to sap
        $response = $this->_Oemployee->_getUnsyncBooking($startDate,$endDate);
        $dataFound = false;
        if(is_array($response)){
            $dataFound = true;
            $headerValue = array_flip(array_change_key_case(array_flip(array_keys($response[0])),CASE_UPPER));
            $this->_Oreport->_AheaderData = $headerValue;
            
            //Send invalid profiles to the user
            $this->_filePath = "Unsync_Booking" . $this->_SdateTimeToday . ".xlsx" ;

            $this->_Oreport->_createCsvFile( $response, $this->_SprofilePath . $this->_filePath,2);
            $subject = 'LIST OF Data Not Sync To Backend';
            $msg = 'Please find the attachment containing Booking not sync to backend.';
            $this->_sendErrorEmail($subject,$msg,TOMAILID);
        }
    }

    /**
    * @Description : function used get automationmation failure booking 
    * @author Rajesh.U
    * @date 2019-10-14
    */
    public function getAutomationFailedBooking() {
        $this->_SdateTimeToday = date('Y-m-d H:i:s');
        $time = strtotime($this->_SdateTimeToday);
        $startTimeDiff = $time - (60 * 60);
        $endtimeDiff = $time - (ERROR_DIFF_TIME * 60);
        $startDate = date("Y-m-d H:i:s", $startTimeDiff);
        $endDate = date("Y-m-d H:i:s", $endtimeDiff);
        $this->_Oemployee = new employee();
        $this->_Oreport = new report();
        $this->_SprofilePath  = PROFILE_UPLOAD_PATH;
        // calling function to sync the unsync details to sap
        $response = $this->_Oemployee->_getAutomationFailedBooking($startDate,$endDate);
        $dataFound = false;
        if(is_array($response)){
            $dataFound = true;
            $headerValue = array_flip(array_change_key_case(array_flip(array_keys($response[0])),CASE_UPPER));
            $this->_Oreport->_AheaderData = $headerValue;
            
            //Send invalid profiles to the user
            $this->_filePath = "Automation_Failed_Booking" . $this->_SdateTimeToday . ".xlsx" ;

            $this->_Oreport->_createCsvFile( $response, $this->_SprofilePath . $this->_filePath,2);
            $subject = 'Automation Failed Booking';
            $msg = 'Please find the attachment containing automation failed booking.';
            $this->_sendErrorEmail($subject,$msg,TOMAILID);
        }
    }

    /**
     * Send unsync details to developer
     * @return boolean
     */
    public function _sendErrorEmail($subject,$msg,$ADMINEMAILS) {

        $this->_OcommonMethod = new commonMethods();

        //get the mail content.        
        $twigOutputArray['host'] = HOST_URL; 
        $twigOutputArray['msg'] = $msg;
        $twigOutputArray['mailSignature'] = EMAIL_SIGNATURE; 
        $this->_Otwig = init();  

        //render the tpl for mail content.
        $_SmailContent = $this->_Otwig->render('unSyncDataListMailer.tpl',$twigOutputArray);
        fileWrite($ADMINEMAILS,'ERRORMAILID','a+');
        $this->_OcommonMethod->_sendMail($ADMINEMAILS,'', $subject, $_SmailContent,$this->_SprofilePath . $this->_filePath,'','',$this->_filePath);
        return TRUE;
    }

    /**
     * Send daily report to developer
     * @return boolean
     */

    public function getDailyRequestCount(){

        $this->_Oreport = new report();

        $this->_Oreport->_dailyReportFomation();

        return TRUE;
    }
}
?>