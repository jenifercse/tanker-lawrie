<?php

/*
  @Module name 	:   class.module.commonModule.php
  @Created on 	:   18th May 2015
  @Author       :   Jkthirumal
  @Description  :   common module file to load all the class.tpl files mapped to the module and pass inputs to those files
 */

require_once "classes/class.baseModule.php";

class commonModule extends baseModule {

    //Connection object
    public $_Oconnection;
    //Result variable holds the output from each tpl
    public $_Aresult = array();
    //Response variable holds the response status
    public $_AresponseStatus = array("status" => "success", "status_code" => 1, "status_message" => "success");
    //Smarty object
    public $_Osmarty;
    public $_Otwig;
    public $_OobjResponse;
    public $_SpluginName;
    public $_SpackageName;
    public $_AserviceResponse = array();
    public $_SerrorMsg = '';
    public $_Stemplatetype;
    public $_Stemplatenamearray;
    // use this variable to write common application error so that error log are writted to application error log 
    public $_AapplicationError;
    public $_BclassOverride = false;

    /**
     * Constructor initalise the basemodule object and classtpl object
     */
    public function __construct() {
        parent::__construct();
        $this->_AapplicationError[] = 'common module error';
        $this->_AserviceResponse['status'] = array('status_code' => 0,
            'status_message' => 'success',
            'error_alert' => 'Response sent successfully');
    }

    /**
     * Called for including the template files based on the mapping from back end for the current module.
     */
    public function _setModuleData() {

        //ClassTpl length initialized
        $templateCount = 0;
        
        //set the application settings details to session
        $this->_setSettingsInSession();

        $templateCount = count($this->_StemplateType);
        
        for ($i = 0; $i < $templateCount; $i++) {

            $classestplName = $this->_classTplName[$i]; // misc.menu
            /** To check the module package is from common folder or from other folders 
                if it is common,it will come to normal instantiation. otherwise it will concatenate package name
                with the classestpl name and instantiate using namespace concept
             **/
                        
            /*if sub-modules are set redirect to sub-module path else look in main directory*/
            $_SclassPropertiesArray  = explode(".", $classestplName);
            $_IclassPropertiesCount  = count($_SclassPropertiesArray);
             
            if($_IclassPropertiesCount == 2) {
                 $classNameWithPath = $classestplName;
                 $_SSubModulePath   = $_SclassPropertiesArray[0].'/';
                 $classestplName    = $_SclassPropertiesArray[1];
            } else {
                $_SSubModulePath    = '';
                $classNameWithPath  = $classestplName;
            }

            /*this override will only work when entry is added in module_package_mapping table*/
            if ($this->_BclassOverride) {
                $className = '\\' . "$this->_SpackageName" . '\\' . $classestplName;
            } else {
                $className = $classestplName;
            }
            
            ### check multple plugin path settings exists and overide 
            ### the namespace which exists according to priority
            $this->checkFileExistsinOverRidePluginMultiple($_SSubModulePath, $classestplName, $classNameWithPath);
            
            /*$this->_SpluginPath based on module name given in path.xml file pluginname*/
            if ($this->_BOverRidePlugin && pluginFileRequireBasic($_SSubModulePath . $this->_SoverRidePluginPathName . '/', "classesTpl/class.tpl." . $classNameWithPath . ".php")) {
                fileWrite($_SSubModulePath . $this->_SoverRidePluginPathName . '/'. "classesTpl/class.tpl." . $classNameWithPath . ".php", 'IncludedModuelFile','a+');
                $className = $this->_SoverRidePackageName.'\\'.$classestplName;
                $this->_ObjClassTpl->_AbugTracking = &$this->_AbugTracking;
                $this->_ObjClassTpl = new $className;
                $this->_callTemplateFunction($i);
            } else if (pluginFileRequireBasic($_SSubModulePath . $this->_SpluginPath . '/'. "classesTpl/class.tpl." . $classNameWithPath . ".php")) {
                fileWrite($_SSubModulePath . $this->_SpluginPath . '/', "classesTpl/class.tpl." . $classNameWithPath . ".php", 'IncludedModuelFile', 'a+');
                $this->_ObjClassTpl->_AbugTracking = &$this->_AbugTracking;
                $this->_ObjClassTpl = new $className;
                $this->_callTemplateFunction($i);
            } else if (pluginFileRequireBasic($_SSubModulePath . $this->_SSecpluginPath . '/', "classesTpl/class.tpl." . $classNameWithPath . ".php")) {
                fileWrite($_SSubModulePath . $this->_SSecpluginPath . '/'. "classesTpl/class.tpl." . $classNameWithPath . ".php", 'IncludedModuelFile', 'a+');
                $this->_ObjClassTpl->_AbugTracking = &$this->_AbugTracking;
                $this->_ObjClassTpl = new $className;
                $this->_callTemplateFunction($i);
            } else {
                fileWrite('Files Not Included='.$classNameWithPath, 'IncludedModuelFile','a+');
                fileWrite($_SSubModulePath . $this->_SSecpluginPath . '/'. "classesTpl/class.tpl." . $classNameWithPath . ".php", 'IncludedModuelFile', 'a+');
                $this->_SerrorMsg = 'classtpl file not found';
            }
        }
    }

    /**
     * Common method for assigning the connection object,input values,result array and status array
     */
    public function _callTemplateFunction($classTplCount) {

        if ($this->_AresponseStatus['status_code'] == 1) {


            $this->_ObjClassTpl->_Oconnection   = $this->_Oconnection;
            $this->_ObjClassTpl->_Otwig         = $this->_Otwig;

            $this->_ObjClassTpl->_OobjResponse  = $this->_OobjResponse;
            $this->_ObjClassTpl->_Stemplatetype = $this->_Stemplatetype;
            $this->_ObjClassTpl->_AapplicationError  = $this->_AapplicationError;
            $this->_ObjClassTpl->_Stemplatenamearray = $this->_Stemplatenamearray;
            $this->_ObjClassTpl->_SmoduleName   = $this->_SmoduleName;
            $this->_ObjClassTpl->_SmoduleAction = isset($this->_SmoduleAction) && !empty($this->_SmoduleAction) ? $this->_SmoduleAction : '';
            $this->_ObjClassTpl->_IinputData    = &$this->_IinputData;
            $this->_ObjClassTpl->_Aresult       = &$this->_Aresult;
            $this->_ObjClassTpl->_AresponseStatus  = &$this->_AresponseStatus;
            $this->_ObjClassTpl->_AserviceResponse = &$this->_AserviceResponse;

            if (isset($this->_AModuleResponseData) && !empty($this->_AModuleResponseData)) {
                $this->_ObjClassTpl->_AModuleResponseData = $this->_AModuleResponseData;
            }

            $this->_ObjClassTpl->_getDisplayInfo();

            //assign to class variable for usage in-case of next tpl in loop for module mapping
            if (isset($this->_ObjClassTpl->_AModuleResponseData) && !empty($this->_ObjClassTpl->_AModuleResponseData)) {
                $this->_AModuleResponseData = $this->_ObjClassTpl->_AModuleResponseData;
                unset($this->_ObjClassTpl->_AModuleResponseData);
            }

            //assigning back twig template array to basemodule class 
            if (isset($this->_ObjClassTpl->_AtwigOutputArray)) {

                $this->_AtwigOutputArray = $this->_ObjClassTpl->_AtwigOutputArray;
            }

            //to display bootstap alert message
            if (isset($this->_ObjClassTpl->_ATwigAlertOutput)) {
                $this->_ATwigAlertOutput = $this->_ObjClassTpl->_ATwigAlertOutput;
                $this->_assignAlertMessage();
            }

            //override templatearray to be displayed in the output used for display result in templates
            if (isset($this->_ObjClassTpl->_AoverridetemplateNameArray) && !empty($this->_ObjClassTpl->_AoverridetemplateNameArray)) {
                $this->_StemplateNameArray = $this->_ObjClassTpl->_AoverridetemplateNameArray;
            }

            //for loading data table in wrapper script
            if (isset($this->_ObjClassTpl->_BLoadDataTable)) {
                $this->_BLoadDataTable = $this->_ObjClassTpl->_BLoadDataTable;
            }

            //for displaying popupcontent and displaying pop-up
            if (isset($this->_ObjClassTpl->_displayPopupArray) && count($this->_ObjClassTpl->_displayPopupArray) > 0) {
                $displayParams = $this->_ObjClassTpl->_displayPopupArray;
                $this->_displayPopUpView($displayParams);
            }
        }
    }

    private function _setSettingsInSession() {

        $applicationObj = new coreApplicationSettings();
        $applicationObj->_Oconnection = $this->_Oconnection;
        $settingsArray = $applicationObj->_fetchApplicationSettingsValue();

        $_SESSION['settings'] = $settingsArray;
    }

    /*
     * @Description assign alert message to bootstrap alert div to display as pop-up
     * @param 
     * @return
     */

    public function _assignAlertMessage() {
        if ($this->_ATwigAlertOutput['type'] == 0) { //danger bootstrap alert
            $twigOutputTemplate = 'default/fail.tpl';
        } else if ($this->_ATwigAlertOutput['type'] == 1) { //warning bootstrap alert
            $twigOutputTemplate = 'default/warning.tpl';
        } else if ($this->_ATwigAlertOutput['type'] == 2) { //information bootstrap alert
            $twigOutputTemplate = 'default/information.tpl';
        } else if ($this->_ATwigAlertOutput['type'] == 3) { //success bootstrap alert
            $twigOutputTemplate = 'default/success.tpl';
        }
        $this->_SBSAlertMsg = $this->_Otwig->render($twigOutputTemplate, $this->_ATwigAlertOutput);
    }

    /*
     * @Description display given content in the pop-up
     * @param array|$displayParams
     * @return
     */

    private function _displayPopUpView($displayParams) {
        $output = $this->_Otwig->render($displayParams['templateName'], $this->_AtwigOutputArray);
        $this->_OobjResponse->assign("{$displayParams['contentDiv']}", 'innerHTML', $output);
        $this->_OobjResponse->script("$('#{$displayParams['popUpDiv']}').modal('show');");
    }

    public function __destruct() {

        //for logging application errors
        if (ENABLE_APPLICATION_ERROR_LOG) {
            if(isset($this->_ObjClassTpl) && count($this->_ObjClassTpl->_AapplicationError) >0) {
               // error_log(print_r('class name:' . get_class($this->_ObjClassTpl) . '--' . print_r($this->_ObjClassTpl->_AapplicationError, 1), 1), 3, APPLICATION_BASE_PATH . 'QUERY_FILE/applicationError.log');
            }
            
            if(isset($this->_ObjClassTpl) && !empty($this->_ObjClassTpl)) {
                foreach ($this->_ObjClassTpl as $classObj) {
                    if (is_object($classObj) && !empty($classObj->_AapplicationError)) {
                       // error_log('class name:' . get_class($classObj) . '--' . print_r($classObj->_AapplicationError, 1), 3, APPLICATION_BASE_PATH . 'QUERY_FILE/applicationError.log');
                    }
                }
            }
        }
    }

}
