<?php
$currentFileDirPath = rtrim(dirname(__FILE__), "/\\");
$applicationPath = substr($currentFileDirPath, 0, strrpos($currentFileDirPath, DIRECTORY_SEPARATOR)) . DIRECTORY_SEPARATOR;

set_include_path($applicationPath);

//Require Files
require_once "config/config.inc.php";
require_once "common/auto_load.php";
require_once "common/include_header.php";

//Common Class object required files
require_once "lib/system/fileRequire.php";
fileRequire("lib/system/pluginFileRequire.php");
fileRequire('lib/system/authToken.php');
fileRequire("lib/system/decryptValues.php");
fileRequire("lib/system/fileWrite.php");
fileRequire('lib/common/commonMethods.php');
fileRequire('plugins/misc/corporate/loreal/classes/class.sync.php');

$db = new commonDBO();
$_OCommonMethods = new commonMethods();

fileRequire("plugins/misc/corporate/harinim/classes/class.cancellation.php");

//?CORPID=2&CANID=135

echo $cancelId = $_REQUEST['CANID'];
echo $_SESSION['corporateId'] = $_REQUEST['CORPID'];
$_SESSION['agencyId']    = 1;
$_SESSION['userApplicationSettings']['AUTOMATION_PROCESS'] = 'YES';
//exit();

$_OcancelDetailsSync = new cancellation();
$_OcancelDetailsSync->_SsendEmail = 'N';
echo $_OcancelDetailsSync->_intiateCancellationService($cancelId);