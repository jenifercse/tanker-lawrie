<?php
ini_set("display_errors", 0);
error_reporting(E_ERROR | E_PARSE);
$currentFileDirPath = rtrim(dirname(__FILE__), "/\\");
$applicationPath = substr($currentFileDirPath, 0, strrpos($currentFileDirPath, DIRECTORY_SEPARATOR)) . DIRECTORY_SEPARATOR;
set_include_path($applicationPath);

###include the corresponding files.
require_once 'common/include_header_service.php';
require_once "lib/system/authToken.php";
ini_set('max_execution_time', 100);

//object declaration
$_OauthToken = new authToken();

//set service type
$requestType   = ($_POST['serviceType']) ? $_OauthToken->_purifyInputData($_POST['serviceType']) : ''; 
        
###service calling for meal and baggage only.
if($requestType == 'MEAL_BAGGAGE'){
    //set the inputs
    $data          = $_OauthToken->_purifyInputData($_POST['data']);
    $requestData   = $_OauthToken->_sanitiseInputData($_POST['requestData']);
    $inputData     = $_OauthToken->_purifyInputData($_POST['serviceInput']);
    $itineraryInfo = $_OauthToken->_sanitiseInputData($_POST['itineraryInfo']);
    $orderId       = $itineraryInfo['order_id'];
    $encryptData   = json_decode($data,1);
}
else{
    ###set flag and inputs
    $encryptData   = $_OauthToken->_sanitiseInputData($_POST['data']);
    $corporateFlag = $_OauthToken->_purifyInputData($_POST['corporateFlag']);
    ###set flag for fare type.
    $nonRefundableFlag = $_OauthToken->_purifyInputData($_POST['nonRefundableFare']);
    $lowFareComparisonAmount = $_OauthToken->_purifyInputData($_POST['lowFareComparison']);
    $lowFareLogicPlay = $_OauthToken->_purifyInputData($_POST['lowFareLogicPlay']);
}
//set request id
if(INDEXNAME == 'personal'){
    $orderId = time();
}

$requestId = ($orderId) ? $orderId : date('hdmy');

###multicurl initialization
$mh     = curl_multi_init();
$ch     = array();
$url    = array();
$result = array();

foreach ($encryptData as $key => $value) {

    if ($key == "airline_code"){
        $airlineCode = $value;
    } 
    if ($key != "airline_code" || $requestType == 'MEAL_BAGGAGE'):

        $data = array("data" => $encryptData[$key], "mode" => 'air', 'agencyId' => SERVICE_AGENCY_ID,'requestId' => $requestId,'agencyCode'=>SERVICE_AGENCY_ID,'serviceName'=>'FLIGHTSEARCH_NDC_AIR_RF_V2T');
    
        //set airline code
        $url[$key] = $airlineCode == '2T' ? SERVICE_AGENCY_URL_2T : SERVICE_AGENCY_URL;
         
        if($itineraryInfo['service_provider_id'] == "TP") { 

            $data['agencyCode'] = SERVICE_AGENCY_ID; 
            $data['serviceName'] = sprintf("GETSSRAVAILABILITY_TRAVELPORT_AIR_RF_V%s",$itineraryInfo['viaInfo'][$key]['operating_airline_code']);
            $url[$key] = SERVICE_AGENCY_URL_2T; 
        }

        $ch[$key]  = curl_init();
        curl_setopt($ch[$key], CURLOPT_URL, $url[$key]);
        curl_setopt($ch[$key], CURLOPT_USERAGENT, $agent);
        curl_setopt($ch[$key], CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch[$key], CURLOPT_RETURNTRANSFER, 1);  
        curl_setopt($ch[$key], CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch[$key], CURLOPT_ENCODING, 'gzip');
        curl_setopt($ch[$key], CURLOPT_REFERER, $reffer);
        curl_setopt($ch[$key], CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch[$key], CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch[$key], CURLOPT_HEADER, 0);
        curl_setopt($ch[$key], CURLOPT_HTTPHEADER, array(
            'Authorization: ' . SERVICE_AGENCY_AUTHKEY
        ));
        curl_multi_add_handle($mh, $ch[$key]);
    endif;    
}

$running = null;

do {
    curl_multi_exec($mh, $running);
    curl_multi_select($mh);
} while ($running > 0);

// get content and remove handles
foreach ($ch as $a => $c) {
    $result[$a] = curl_multi_getcontent($c);
    $error[$a]  = curl_error($c);
    curl_multi_remove_handle($mh, $c);
}
curl_multi_close($mh);
$_Ocommon = new common;


//array formation with respect to the response for corresponding service
if ($requestType == 'MEAL_BAGGAGE') {
    $_Jcontent = $_Ocommon->_mealBaggageArrayFormation($result,$inputData,$requestData,$itineraryInfo);
} 
print_r(json_encode($_Jcontent));
exit;