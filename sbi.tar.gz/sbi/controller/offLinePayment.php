<?php

$currentFileDirPath = rtrim(dirname(__FILE__), "/\\");
$applicationPath = substr($currentFileDirPath, 0, strrpos($currentFileDirPath, DIRECTORY_SEPARATOR)) . DIRECTORY_SEPARATOR;

set_include_path($applicationPath);
require_once $applicationPath . "config/config.inc.php";
require_once "common/auto_load.php";
require_once "common/include_header.php";
require_once "common/include_database.php";
require_once "lib/system/pluginFileRequire.php";
fileRequire("lib/system/twiginit.php");
fileRequire("lib/common/commonMethods.php");
require_once 'lib/system/authToken.php';

/* $_REQUEST['applicationId'] = base64_encode('agencyAutoFE');
  $_REQUEST['packageId']     = base64_encode('2323');
  $_REQUEST['orderId']       = base64_encode('2386');
  $_REQUEST['paymentStatus'] = base64_encode('N');
  $_REQUEST['travelModeId']  = base64_encode('1');
  $_REQUEST['mailEmailId']   = base64_encode('testprocess@atyourprice.in'); */

  $_OauthToken = new authToken();

  //purify the input data
  $requestData['applicationId'] = $_OauthToken->_purifyInputData($_REQUEST['applicationId']);
  $requestData['packageId']     = $_OauthToken->_purifyInputData($_REQUEST['packageId']);
  $requestData['orderId']       = $_OauthToken->_purifyInputData($_REQUEST['orderId']);
  $requestData['paymentStatus'] = $_OauthToken->_purifyInputData($_REQUEST['paymentStatus']);
  $requestData['travelModeId']  = $_OauthToken->_purifyInputData($_REQUEST['travelModeId']);
  $requestData['mailEmailId']   = $_OauthToken->_purifyInputData($_REQUEST['mailEmailId']);
  $requestData['logId']         = $_OauthToken->_purifyInputData($_REQUEST['logId']);

  $applicationId = base64_decode($requestData['applicationId']);

if(count($requestData) > 0 && $applicationId == 'agencyAutoFE'){

    //receive all the request parameters
    $packageId = base64_decode($requestData['packageId']);
    $orderId = base64_decode($requestData['orderId']);
    $paymentStatus = base64_decode($requestData['paymentStatus']);
    $travelMode = base64_decode($requestData['travelModeId']);
    $mailEmailId = base64_decode($requestData['mailEmailId']);
    $logId = base64_decode($requestData['logId']);

    //check if valid user
    $O_login = new login();
    $O_login->_IinputData['loginEmail'] = $mailEmailId;
    $response = $O_login->mailLogin();

    //check payment details already updated
    $_OPayment = new payment();
    $updated = $_OPayment->_checkOrderPaymentUpdated($orderId);

    if ($response['status'] == 1) {

        if (!$updated) {
            //set user type for payment type restriction in payment module
            $_SESSION['LoginType'] = 'offLinePayment';

            $_AairRequestData = array('package_id' => $packageId,
                'contentIdData' => $packageId . ':' . $orderId,
                'paymentProcessType' => 'orderPayment',
                'buttonDisplay' => 'makePaymentListButton.tpl',
                'packageStatus' => 'Not Paid',
                'packageName' => DEFAULT_PLUGIN_FOLDER,
                'action' => 'offLinePayment',
                'moduleName' => 'displayAllItinerary',
                'classTpl' => 'itineraryDisplayTpl',
                'mailEmailId' => $mailEmailId,
                'logId' => $logId);

            $_AairRequestData['tplClassName'] = $_AairRequestData['moduleName'];

            $O_common = new commonMethods();
            $response = $O_common->_doModulePost($applicationPath, $_AairRequestData);
        } else {
            $response = array('status' => 0, 'message' => 'Payment details already updated');
        }
    }
} else {
    $response = array('status' => 0, 'message' => 'Invalid payment request');
}

//display the offline payment page
if ($response['status'] == 1) {
    echo $response['displayTpl'];
} else {
    $_Otwig = init();
    $A_headerOutPutArray = array('displayMessage' => true, 'message' => $response['message']);
    $A_headerOutPutArray['dynamicTemplateName']  = 'payment_failure.tpl';
    

    $_STemplateDisplay  = $twig->render('base/externalHeader.tpl', $A_headerOutPutArray);
    $_STemplateDisplay .= $twig->render('base/externalBody.tpl', $A_headerOutPutArray);
    $_STemplateDisplay .= $twig->render('base/externalFooter.tpl', $A_headerOutPutArray);
    
    echo $_STemplateDisplay;
    
    /*functon called if the process is offline payment then update in offline payment table payment is done*/
    $_OapplicationSettings = new applicationSettings();
    $_OapplicationSettings->_checkAndUpdateOfflinePayment();
}
exit;
?>