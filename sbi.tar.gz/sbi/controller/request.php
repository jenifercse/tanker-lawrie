<?php
/* * *****************************************************************************
 * @class		index.php
 * @author      	Mercy Chrysolite
 * @created date	2016-06-08
 * **************************************************************************** */
$currentFileDirPath = rtrim(dirname(__FILE__), "/\\");
$applicationPath = substr($currentFileDirPath, 0, strrpos($currentFileDirPath, DIRECTORY_SEPARATOR)) . DIRECTORY_SEPARATOR;

/** Set include path to include files * */
set_include_path($applicationPath);
define('APPLICATION_BASE_PATH', $applicationPath);
/* * * Include autoload for class file including ***** */
require_once "common/errorHandler.php";
require_once "common/auto_load.php";

/* * * Include framework file***** */
require_once "common/include_header.php";

require_once "classes/class.baseModule.php";

/* * * Include configuration file***** */
require_once "config/config.inc.php";

/* * ** Common, security required files****** */
fileRequire("lib/system/pluginFileRequire.php");
fileRequire('lib/system/authToken.php');
fileRequire("lib/system/decryptValues.php");
fileRequire("lib/system/fileWrite.php");
fileRequire("common/checkSessionTime.php");
fileRequire("lib/common/commonMethods.php");
pluginFileRequire('common/', "config/config.inc.php");

class ajaxCall extends authToken {
    /*     * ** define class variables ****** */

    private $_OdataBase;
    private $_IinputData;
    private $_AtwigTemplateArray;

    public function __construct() {

        /*         * ** call the parent construct for including header token method ****** */
        parent::__construct();

        /* To check the session timeout */
        checkSessionTime();

        /* assign request data to inputData variable */
        $this->_IinputData = $this->_getRequestData();

        /* assign database connection object */
        $this->_OdataBase  = $this->_getConnection();

        /* declare twig template array */
        $this->_AtwigTemplateArray = array();

        $this->_Ocommon = new common();
    }

    /*
     * @Description process the request from user
     * @param 
     * @return 
     */

    public function _getResponse(){
        //set action array
        $allowedAction = array('login','forgotPassword','resetPassword','changePassword','verifyOtp','resendOTP','validateData','updateMailandSendforgotPassword','captchacode','sessionSetup');
        
        //Decryption of ajax inputs
        isset($this->_IinputData['allData'])?$this->_IinputData = $this->_Ocommon->doAjaxDecryption($this->_IinputData['allData']):NULL;
    
        /* add condition to check session is active or wherether the request action*/
        $this->_BcheckCSRFToken = true;//$this->_validateRequestHeader();
        $sessionActive = $this->_checkSessionIsActive();        
        if(($sessionActive && $this->_BcheckCSRFToken) || in_array($this->_IinputData['inputData']['action'],$allowedAction) || $this->_IinputData['inputData']['requestType'] == 'requestFromMail'){
            /** check ajax method name is passed in input argument **/
            if (isset($this->_IinputData['ajaxMethodName'])) {
                if($_SESSION['employeeEmailId'] !=''){
                    $this->_updateUserLoginCredentials();
                }
                //add entry to application log
                $_SrequestLogId = $this->_insertApplicationRequestLog($this->_IinputData);
                /** include common reuqest class file and create object this file is used to handle all the ajax request and call the tpl files * */
                pluginFileRequire('common/', "classAjax/class.ajax.commonRequest.php");
                $ajaxObject = new commonRequest();

                /** assign db connection to commonrequest class * */
                $ajaxObject->_Oconnection = $this->_OdataBase->_Oconnection;

                //Insert user actions log
                $objBaseModule = new baseModule();
                $objBaseModule->_Saction = $this->_IinputData['inputData']['action'];
                $objBaseModule->_SrequestLogId = $_SrequestLogId;
                $objBaseModule->_insertUserActions();

                /** Get the package name from the input if not found set as package name as common * */
                $ajaxObject->_SpackageName = isset($this->_IinputData['packageName']) ? $this->_IinputData['packageName'] : DEFAULT_PLUGIN_FOLDER;

                /** create encryption object * */
                $objDecryptValues = new decryptValues($this->_OdataBase);

                //created dummy form elements for decryption
                $formValues = array();
                $formValues['encrypt'] = 'N';

                //Decrypting class tpl name
                $objDecryptValues->_decrypt($this->_IinputData['tplClassName'], $formValues);
        
                $ajaxObject->_StplClassName = $objDecryptValues->_SmoduleName;

                //Check for decoded classtpl name
                if ($ajaxObject->_StplClassName != '') {

                    //Assigning the input data
                    $ajaxObject->_IinputData = isset($this->_IinputData['inputData']) ? $this->_IinputData['inputData'] : $this->_IinputData;

                    //assign twig object
                    $ajaxObject->_Otwig = init();

                    //Calling default ajax method to include classTpl name dynamically
                    $ajaxObject->_callAjaxFunction();
                } else {
                    $ajaxObject->_Aresponse['error'] = 'class tpl name not found';
                }
            } else {
                //if ajaxmethod name is not given then it is file upload process file upload based on this
                //create object for file upload
                pluginFileRequire('common/', "classAjax/class.ajax.ajaxFileUpload.php");
                $ajaxObject = new ajaxFileUpload();

                //Set obejct for ajax class varibales 
                $ajaxObject->_Oconnection = $this->_OdataBase->_Oconnection;
                //Decrypt input values
                $decrypted = $this->_Ocommon->doAjaxDecryption($this->_IinputData['input']);
                $decoded = json_decode($decrypted,1);
                $this->_IinputData['input'] =  ($decoded==NULL)?$decrypted:$decoded;
                $ajaxObject->_IinputData = $this->_IinputData['input'];
                $ajaxObject->_Afile = $this->_getFileUploadData();
                //add entry to application log
                $_SrequestLogId = $this->_insertApplicationRequestLog($ajaxObject->_IinputData);

                //Insert user actions log
                $objBaseModule = new baseModule();
                $objBaseModule->_Saction = $ajaxObject->_IinputData['action'];
                $objBaseModule->_SrequestLogId = $_SrequestLogId;
                $objBaseModule->_insertUserActions();

                if ($ajaxObject->_IinputData['mode'] == 'logo') {
                    $fileInfoArray = array('name' => 'logoupload',
                        'storagePath' => LOGO_UPLOAD_PATH,
                        'tplClassFile' => 'applicationSettingsTpl',
                        'travelModeDir' => 'misc',
                        'allowedexts' => array('image/jpg', 'image/jpeg', 'image/png', 'image/gif'));
                    $ajaxObject->_callAjaxUploadFile($fileInfoArray);
                } else if ($ajaxObject->_IinputData['mode'] == 'profiles') {
                    $fileInfoArray = array('name' => 'profileupload',
                        'storagePath' => PROFILE_UPLOAD_PATH,
                        'tplClassFile' => 'uploadEmployeeProfileTpl',
                        'travelModeDir' => 'admin',
                        'allowedexts' => array('text/csv', 'application/octet-stream', 'application/csv', 'application/vnd.ms-excel', 'application/vnd.msexcel'));
                    $ajaxObject->_callAjaxUploadFile($fileInfoArray);
                } else if ($ajaxObject->_IinputData['mode'] == 'footerLogo') { //for dynamic application settings
                    $fileUpload = new commonMethods();
                    $fileInfoArray = array(
                        'name' => 'logoupload',
                        'flag' => $ajaxObject->_IinputData['action'] == "view" ? 2 : 1,
                        'storagePath' => Footer_LOGO_UPLOAD_PATH,
                        'tplClassFile' => 'applicationSettingsTpl',
                        'travelModeDir' => 'misc',
                        'fileUploadExtension' => $this->_IinputData['input']['extension'],
                        'usertypeId' => $this->_IinputData['input']['usertypeId'],
                        'allowedexts' => array('image/jpg', 'image/jpeg', 'image/png', 'image/gif'),
                        'agencyId' => $ajaxObject->_IinputData['agencyId'] ? $ajaxObject->_IinputData['agencyId'] : 0,
                        'corporateId' => $ajaxObject->_IinputData['corporateId'] ? $ajaxObject->_IinputData['corporateId'] : 0
                        );

                    $uploadDir = APP_BASE_PATH . 'userUpload/footerLogo/';
                    if (($fileInfoArray['flag'] != 2) || ($fileInfoArray['agencyId'] == 0) && ($fileInfoArray['corporateId']) == 0) {
                        $newFileName = 'footerlogo.jpg';
                    } else {
                        $newFileName = 'footerlogo' . $fileInfoArray['corporateId'] . '_' . $fileInfoArray['usertypeId'] . '.' . $this->_IinputData['input']['extension'];
                    }
                    $fileUpload->compressImage($ajaxObject->_Afile['uploadedFile1'], $newWidth = 90, $newHeight = 100, $uploadDir, $newFileName);
                    $ajaxObject->_Aresponse['newFileName'] = $newFileName;
                } else {
                    $fileInfoArray = array(
                        'name'         => 'passport_file_',
                        'storagePath'  => PASSPORT_COPY_UPLOAD_PATH,
                        'tplClassFile' => 'manageEmployeeProfileTpl',
                        'travelModeDir'=> 'admin',
                        'allowedexts'  => array('image/jpg', 'image/jpeg', 'image/png', 'image/gif')
                    );
                    $ajaxObject->_callAjaxUploadFile($fileInfoArray);
                }
            }


            if (!empty($ajaxObject->_AtwigTemplateArray)) {
                $ajaxObject->_Aresponse['responseTemplate'] = $this->_getTemplate($ajaxObject->_AtwigTemplateArray);
            }
            
            //set auth token in response for next request usage
            $ajaxObject->_Aresponse['xctaa'] = $this->_setAuthToken();
            
            //Check for encryption
            $returnResponse = $this->_Ocommon->doAjaxEncryption($ajaxObject->_Aresponse);
        } else if (!$this->_BcheckCSRFToken && $this->_OResponse['session_state']) {
            if(!$sessionActive) {
                fileWrite('session is not active' . print_r($_SESSION, 1), 'sessionActive');
            } else if(!$this->_BcheckCSRFToken) {
                common::_setHeaderResponseCode(403);    
            }
            
        } else {
            $this->_Stateresponse['session_state'] = false;
            //Check for encryption
            $returnResponse = $this->_Ocommon->doAjaxEncryption($this->_Stateresponse);
        }

        $this->_addResponseHeader('json');
        $this->_displayResponse($returnResponse);
        return $this->_displayResponse;
        
    }

    /*
     * @Description get the database connection object
     * @param 
     * @return 
     */

    private function _getConnection() {
        return dataBase::_createDBO();
    }

    /*
     * @Description get the template name
     * @param string|$templateArray
     * @return string|$this->_OobjModule->_SBSAlertMsg
     */

    private function _getTemplate($templateArray) {

        $twig = init();
        fileRequire("classes/class.commonModule.php");
        $this->_OobjModule = new commonModule();
        $this->_OobjModule->_Oconnection = $this->_OdataBase->_Oconnection;
        $this->_OobjModule->_Otwig = $twig;
        $this->_OobjModule->_ATwigAlertOutput = $templateArray;

        $this->_OobjModule->_assignAlertMessage();
        return $this->_OobjModule->_SBSAlertMsg;
    }

    /*
    * @Description get the request data
    * @param 
    * @return array|$_POST
    */
    private function _getRequestData(){
        //sanitize the request input data
        return $this->_sanitiseInputData($_POST);
    }

    /*
     * @Description get the request data
     * @param 
     * @return array|$_REQUEST
     */

    private function _getFileUploadData() {

        return $_FILES;
    }

    private function _displayResponse($result = array()) {
        
        ### return response headers
        $this->_addResponseHeader('json');
        echo json_encode($result);
    }



    public function __destruct() {
        $cleaned = gc_collect_cycles();
    }

}

/* Create object for this class and call the getresponse function */
$ajaxObj = new ajaxCall();
$ajaxObj->_getResponse();
?>
