<?php
/* * *********************************************************************************************************************************
 * @class		route.php
 * @author      	Taslim
 * @Description         This files works as gateway for angular routing request and will load the module data to the groupDiv1 div
 * @created date	2016-06-29
 * ********************************************************************************************************************************** */
$currentFileDirPath = rtrim(dirname(__FILE__), "/\\");
$applicationPath = substr($currentFileDirPath, 0, strrpos($currentFileDirPath, DIRECTORY_SEPARATOR)) . DIRECTORY_SEPARATOR;

set_include_path($applicationPath);

### Require Files
require_once "common/errorHandler.php";
require_once "config/config.inc.php";
require_once "lib/system/fileRequire.php";
require_once "classes/class.baseModule.php";

fileRequire("common/auto_load.php");
fileRequire("common/restrictDirectAccess.php");
fileRequire("classes/class.common.php");
fileRequire("lib/system/JsonPath.php");
fileRequire("lib/system/decryptValues.php");
fileRequire("lib/system/commonFunctions.php");
fileRequire("lib/system/authToken.php");
fileRequire("lib/common/commonMethods.php");
fileRequire("classes/class.dataBase.php");
fileRequire("lib/system/pluginFileRequire.php");
fileRequire("lib/system/twiginit.php");
fileRequire("common/checkSessionTime.php");

class route extends authToken {

    private $_OdataBase;
    private $_IinputData;
    private $_AtwigTemplateArray;
    protected $_OResponse;
    private $_SdivName;
    private $_BclassOverride = false;
    private $_SpluginPath;

    public function __construct() {

        //To check the session timeout
        global $CFG;

        parent::__construct();

        checkSessionTime();

        $this->_config = $CFG;
        $this->_IinputData = $this->_getRequestData();
        $this->_OdataBase = $this->_getConnection();
        $this->_OcommonFunctions = new commonFunctions();
        $this->_Ocommon          = new common();

        $this->_AtwigTemplateArray = array();
        $this->_ScustomerErrorMessage = " Functionality not activated for demo."; //customer error messages
        //Plugin name initialized based on the URL
        $this->_SpluginName = PLUGIN_NAME;
    }

    /*
     * @Description this function gets the input arguments and works as controller for routing in backend
     * @param 
     * @return 
     */

    public function _handleRequest() {

        $this->_BcheckCSRFToken = true;//$this->_validateRequestHeader();
        $sessionActive          = $this->_checkSessionIsActive();

        if ($this->_checkSessionIsActive() && $this->_BcheckCSRFToken) {

            $moduleName = isset($this->_IinputData['name']) && !empty($this->_IinputData['name']) ? $this->_IinputData['name'] : '';

            //input decryption
            $this->_IinputData['stateData'] = $this->_Ocommon->doAjaxDecryption($this->_IinputData['stateData']);
            

            $this->_updateUserLoginCredentials();
            //add entry to application log
            $this->_insertApplicationRequestLog($this->_IinputData);
            
            if (isset($this->_IinputData['stateData'])) {
                $formValue = json_decode($this->_IinputData['stateData'],1);
                $this->_IinputData['formValues'] = ($formValue==NULL)?$this->_IinputData['stateData']:$formValue;
            }
            
            $formValues = isset($this->_IinputData['formValues']) && !empty($this->_IinputData['formValues']) ? $this->_IinputData['formValues'] : array();
            //to override form encypring check in decrytpValues library
            
            $formValues['encrypt'] = 'N';

            $objDecryptValues = new decryptValues($this->_OdataBase);
            
            //Decrypt form values, module name
            $objDecryptValues->_decrypt($moduleName, $formValues);

            $this->_SmoduleName = $objDecryptValues->_SmoduleName;

            $this->_AformValues = !empty($objDecryptValues->_SformValues) ? $objDecryptValues->_SformValues : $formValues;

            //get module details from JSON/XML FILE in lib/system/pathJson.json(or)path.xml
            $this->_loadModuleDetails();

            //initialize the framework library files
            $this->_initialize();

            //get the plugin path
            $this->_getPluginPath();

            //load plugins direcotry js and css files
            $this->_loadPluginsDependency();

            //load commomonmodule object and handle commonMOdule and class Tpl logic 
            $this->_loadCommonModule();
        } else {
            if(!$sessionActive) {
                fileWrite('session is not active' . print_r($_SESSION, 1), 'sessionActive');
            }
            else if(!$this->_BcheckCSRFToken) {
                common::_setHeaderResponseCode(403);
            } 
        }

        if((isset($this->_IinputData['ssologin']) && $this->_IinputData['ssologin'] == 'enabled')) {
            $_SESSION['response'] = json_encode($this->_OResponse);
        } 
        else if (!$this->_BcheckCSRFToken && $this->_OResponse['session_state']) {
            common::_setHeaderResponseCode(403);
        } 
        else{
            $this->_addResponseHeader('json');
            header('Content-Type: application/json; charset=utf-8');
            $responeEncoded = json_encode($this->_OResponse);
            echo $responeEncoded;
            exit;
        }
    }

    /**
     * @description : Method to find the plugin path for the current module
     */
    private function _getPluginPath() {

        //Generate plugin path based on the module package name
        $this->_SpluginPath = $this->_SSecpluginPath = $this->_SpackageName;


        //If the module is not common then concatenate the plugin with the package
        if ($this->_SpackageName != DEFAULT_PLUGIN_FOLDER) {
            $this->_SpluginPath = PLUGIN_NAME . $this->_SpackageName;
            $this->_SSecpluginPath = SECONDARY_PLUGIN_NAME . $this->_SpackageName;
        }
    }

    /*
     * @Description loads the module details from the module name is available
     * @param 
     * @return 
     */

    private function _loadModuleDetails() {

        $_OjsonPath = new JsonPath();

        $_OjsonPath->_getModuleDetails($this->_SmoduleName);

        $this->_SmoduleDetails = $_OjsonPath->_AmoduleDetails;

        $this->_SpackageName = !empty($this->_SmoduleDetails['pluginName']) ? $this->_SmoduleDetails['pluginName'] : 'common';
    }

    /**
     * @Description function to get the customized package name mapped for this module call
     * @param 
     * @return 
     */
    private function _initialize() {

        //If package

        if ($this->_SmoduleName != 'loginPage') {
            $objBaseModule = new baseModule();
            $objBaseModule->_Oconnection = $this->_OdataBase->_Oconnection;
            $objBaseModule->_SmoduleName = $this->_SmoduleName;
            
            //$objBaseModule->_getPackageName(); //removed old override functionality
            $objBaseModule->_getOverridePackageName(); //addded new override functionality
            //if package count is more than zero overide package from module_package_mapping table
            if (($objBaseModule->_IpackagInputCount > 0)) {
                $this->_BclassOverride = true;
                $this->_SpackageName = $objBaseModule->_SpackageName;
            }

            //if application settings override is enabled then override with package name
            if ($objBaseModule->_BOverRidePlugin) {
                ### add single override values
                $this->_SoverRidePackageName    = $objBaseModule->_SoverRidePackageName;
                $this->_SoverRidePluginPathName = $objBaseModule->_SoverRidePluginPathName;
                $this->_BOverRidePlugin         = $objBaseModule->_BOverRidePlugin;
                
                ### add multi-level override values
                $this->_AoverRidePackageName    = $objBaseModule->_AoverRidePackageName;
                $this->_AoverRidePluginPathName = $objBaseModule->_AoverRidePluginPathName;
                
                
            }
        }

        //Fetch pathName, className,divName,scriptFunction
        $pathName  = $this->_SmoduleDetails['pathName'];
        $className = $this->_SmoduleDetails['className'];
        $divName   = $this->_SmoduleDetails['divName'];

        if ($divName != '') {
            $this->_OResponse['div_name'] = $divName;
        }

        $mainPath = $this->_config['path']['basePath'] . $pathName;
        $pluginPath = '';
    }

    /*
     * @Description function interface/configuraiton/css/js file for the plugin module
     * @param 
     * @return 
     */

    private function _loadPluginsDependency() {

        //include interface file inside module package folder
        pluginFileRequire($this->_SpluginPath . '/', "lib/interface/interface.php");

        //include config file inside the module package folder
        pluginFileRequire($this->_SpluginPath . '/', "config/config.inc.php");

        //Get css path based on corporate plugin name and module name 
        $this->_OcommonFunctions->_SpluginName = $this->_SpackageName;
        $this->_OcommonFunctions->_SmoduleName = $this->_SmoduleName;
        //Function call to get the CSS path
        $cssPath = $this->_OcommonFunctions->_getCSS();

        //Function call to get the JS path
        $jsPath = $this->_OcommonFunctions->_getJs();

        if ($jsPath != null) {
            $this->_OResponse['pluginJs'] = $jsPath;
        }
    }

    /*
     * @Description function interface/configuraiton/twig/css/js file for the plugin module
     * @param 
     * @return 
     */

    private function _loadCommonModule() {

        if ($this->_SmoduleDetails['type'] == 'module') {

            if (isset($_SESSION['groupId']) && $_SESSION['groupId'] != '' && $this->_SmoduleName != 'logout') {

                $this->_OResponse['session_state'] = true;

                //create object for common module class
                require_once "classes/class.commonModule.php";
                $moduleObj = new commonModule;
                //assign smarty, ajax, connection, config values to modules and tpl files
                //create twig object
                $twig = init();

                $moduleObj->_Otwig = $twig;
                $moduleObj->_OobjResponse = $this->_OResponse;
                $moduleObj->_SdivName = $this->_SmoduleDetails['divName'];
                $moduleObj->_Oconnection = $this->_OdataBase->_Oconnection;
                $moduleObj->_SpackageName = $this->_SpackageName;
                $moduleObj->_BclassOverride = $this->_BclassOverride;
                $moduleObj->_SpluginPath = $this->_SpluginPath;
                $moduleObj->_SSecpluginPath = $this->_SSecpluginPath;

                ### if application settings override is enabled then override with package name
                if ($this->_BOverRidePlugin) {
                    ### assign single level override plugin values
                    $moduleObj->_SoverRidePackageName = $this->_SoverRidePackageName;
                    $moduleObj->_SoverRidePluginPathName = $this->_SoverRidePluginPathName;
                    $moduleObj->_BOverRidePlugin = $this->_BOverRidePlugin;
                    
                    ### assing the mult-level override plugin values
                    $moduleObj->_AoverRidePackageName    = $this->_AoverRidePackageName;
                    $moduleObj->_AoverRidePluginPathName = $this->_AoverRidePluginPathName;
                }

                if (isset($this->_IinputData['formValues']) && !empty($this->_IinputData['formValues'])) {
                    $moduleObj->_IinputData = $this->_IinputData['formValues'];
                }

                //assign values to baseModules and call the function to get the module details from database
                $moduleObj->_SmoduleName = $this->_SmoduleName;

                //$moduleObj->_SmoduleAction = $moduleAction;
                $moduleObj->_getModuleData();

                //if template not found for the user show error msg
                if (($moduleObj->_IinputCount == 0) || ($moduleObj->_SerrorMsg != '')) {
                    if ($errorOn == 'YES') {
                        if ($moduleObj->_SerrorMsg != '') {
                            $this->_OResponse['error'] = '_getmoduledata Function Query Error Please check';
                        } else {
                            $this->_OResponse['error'] = 'Sorry, module is not provided to your group id... ' . $this->_config['user']['group_id'];
                        }
                    } else {
                        $this->_OResponse['error'] = $this->_ScustomerErrorMessage;
                    }
                }

                //Common module class method to require & create instance of classestpl 
                $moduleObj->_setModuleData();

                //if any error occur in the query it will show the error msg
                if ($moduleObj->_SerrorMsg != '') {
                    if ($errorOn == 'YES') {
                        $this->_OResponse['error'] = 'Query Error Please check ';
                        //$objResponse->assign('groupDiv5', 'innerHTML', $moduleObj->_SerrorMsg);
                    } else {
                        $this->_OResponse['error'] = $customerErrorMessage;
                    }
                }

                //stdBlockBlue.tpl template will load with data
                $moduleObj->_StemplateName = $moduleObj->_SstdTemplateName;

                $moduleObj->_displayModule();

                if (isset($moduleObj->_AserviceResponse) && !empty($moduleObj->_AserviceResponse)) {
                    $this->_OResponse['serviceResponse'] = $this->_Ocommon->doAjaxEncryption($moduleObj->_AserviceResponse);
                }

                if (isset($moduleObj->_StemplateDisplay) && !empty($moduleObj->_StemplateDisplay)) {
                    $this->_OResponse['content'] = base64_encode(gzcompress($moduleObj->_StemplateDisplay, 9));
                    /* $this->_OResponse['content']['groupDiv2']  = base64_encode(gzcompress($moduleObj->_StemplateGroupDiv2Display ,9));
                      $this->_OResponse['content']['groupDiv3']  = base64_encode(gzcompress($moduleObj->_StemplateGroupDi32Display ,9));
                      $this->_OResponse['content']['groupDiv4']  = base64_encode(gzcompress($moduleObj->_StemplateGroupDiv4Display ,9)); */
                } else {
                    $this->_OResponse['content'] = 'No views found';
                }
                //set new csrf token for use in next request
                $this->_OResponse['xctaa'] = $this->_setAuthToken();
            } else {
                $this->_OResponse['session_state'] = false;
            }
        }
    }

    /*
     * @Description display response to the browser
     * @param 
     * @return 
     */

    public function _getResponse() {

        if (isset($this->_IinputData['ajaxMethodName'])) {

            pluginFileRequire('common/', "classAjax/class.ajax." . $this->_IinputData['ajaxMethodName'] . ".php");
            $ajaxObject = new $this->_IinputData['ajaxMethodName'];

            //Set obejct for ajax class varibales 
            $ajaxObject->_Oconnection = $this->_OdataBase->_Oconnection;
            $ajaxObject->_IinputData = isset($this->_IinputData['inputData']) ? $this->_IinputData['inputData'] : $this->_IinputData;

            //Calling default ajax method
            $ajaxObject->_callAjaxFunction();
        } else {

            pluginFileRequire('common/', "classAjax/class.ajax.ajaxFileUpload.php");
            $ajaxObject = new ajaxFileUpload();

            //Set obejct for ajax class varibales 
            $ajaxObject->_Oconnection = $this->_OdataBase->_Oconnection;
            $ajaxObject->_IinputData = json_decode($this->_IinputData['input'], true);

            $ajaxObject->_Afile = $this->_getFileUploadData();

            //Calling default fileupload method
            $ajaxObject->_callAjaxUploadFile();
        }

        if (!empty($ajaxObject->_AtwigTemplateArray)) {
            $ajaxObject->_Aresponse['responseTemplate'] = $this->_getTemplate($ajaxObject->_AtwigTemplateArray);
        }

        $this->_displayResponse($ajaxObject->_Aresponse);
    }

    /*
     * @Description create/get connection object
     * @param 
     * @return 
     */

    private function _getConnection() {
        return dataBase::_createDBO();
    }

    /*
     * @Description get alert message witht he design
     * @param 
     * @return 
     */

    private function _getTemplate($templateArray) {

        $twig = init();
        fileRequire("classes/class.commonModule.php");
        $this->_OobjModule = new commonModule();
        $this->_OobjModule->_Oconnection = $this->_OdataBase->_Oconnection;
        $this->_OobjModule->_Otwig = $twig;
        $this->_OobjModule->_ATwigAlertOutput = $templateArray;
        $this->_OobjModule->_assignAlertMessage();
        return $this->_OobjModule->_SBSAlertMsg;
    }

    /*
    * @Description get request params passed from js
    * @param 
    * @return array|$_REQUEST
    */
    private function _getRequestData(){
        //sanitize the request input data
        $postData['name'] = $this->_purifyInputData($_POST['name']);
        $postData['stateData'] = $this->_purifyInputData($_POST['stateData']);
        return $postData;
    }

    /*
     * @Description get files array uploaded
     * @param 
     * @return array|$_FILES
     */

    private function _getFileUploadData() {
        return $_FILES;
    }

    /*
     * @Description  display response to browser
     * @param 
     * @return array|$_FILES
     */

    private function _displayResponse($result = array()) {
        //Display the response content
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode($result);
    }

    public function __destruct() {
        $cleaned = gc_collect_cycles();
    }

}

//Initialize the ajax class
$_Oroute = new route();
$_Oroute->_handleRequest();
?>