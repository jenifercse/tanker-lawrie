<?php
global $errorResponseArray;
$currentFileDirPath = rtrim(dirname(__FILE__), "/\\");
$applicationPath = substr($currentFileDirPath, 0, strrpos($currentFileDirPath,DIRECTORY_SEPARATOR)) . DIRECTORY_SEPARATOR;

set_include_path($applicationPath);
define('REQUEST_TYPE', 'webservice');
require_once $applicationPath . "config/config.inc.php";
require_once "common/auto_load.php";
require_once "lib/system/fileWrite.php";
require_once "lib/system/fileRequire.php";
require_once "common/include_database.php";
require_once "lib/system/pluginFileRequire.php";
require_once "lib/system/twiginit.php";
require_once 'lib/common/commonMethods.php';
require_once 'lib/system/authToken.php';
require_once "common/commonEncryptDecrypt.php";

//sanitize the data.
$_OauthToken = new authToken();
$inputData['data'] = $_OauthToken->_purifyInputData($_REQUEST['data']);

//decrypt the data.
$OcommonEncryptDecrypt = new commonEncryptDecrypt();
$inputData = json_decode($OcommonEncryptDecrypt->_decryptData($inputData['data']),1);

if(count($inputData) > 0){   
    
    fileWrite(print_r($inputData,1),"automationRetry","a+");
    
    //set login time in session.
    $_SESSION['logInTime'] = time();

    //check for corporate customization
    $_OcommonMethods = new commonMethods();
    $customizationValue = $_OcommonMethods->_initCorporateCustomization(2,$inputData['orderId'],'OBJECT');

    require_once "common/include_header.php";
    $twig = init($applicationPath);
    
    //showing the loader.
    showLoader($twig);
    
    $_OcommonDBO = new commonDBO();
    //set inputs
    $input['orderId'] =  $inputData['orderId'];
    $input['packageId'] = $_OcommonDBO->_select('fact_booking_details','r_package_id','r_order_id',$input['orderId'])[0]['r_package_id'];
    $input['contentIdData'] = $input['packageId'].':'.$input['orderId'];    
    $input['employeeId'] = $inputData['employeeId'];
    $input['emailId'] = $inputData['email_id'];
    $input['message'] = $inputData['message'] ? $inputData['message'] : '';
    
    //set user application settings info in session.
    $_OcommonQuery = new commonQuery();
    $_SESSION['userApplicationSettings'] = $_OcommonQuery->_getUserApplicationSettingsInfo($inputData['orderId']);
    
    //showing the itinerary.
    showRetryBooking($input,$twig);
}

//function used to showing the itinerary with retry button.
function showRetryBooking($input,$twig){  
    $input['bookingRetryFlag'] = 'Y';
    $template = itineraryDisplay($input,$twig);
    echo $template;
}

//function used to showing the loader
function showLoader($twig){
    $twigOutputArray['loaderContent'] = 'Please wait, we are processing your request....';
    $loadercontent = $twig->render('mailSearchLoader.tpl', $twigOutputArray);   
    echo $loadercontent;
}

//function used to showing the itinerary based on the package type.
function itineraryDisplay($input,$twig){
    
    //object declaration.
    $objClass = new commonDomesticAirItineraryDisplay();     
     
    //call the class function to initiate the call_user_func with parameter     
    $twigOutputArray = call_user_func(array($objClass,'_getDomesticAirItineraryInfo'),$input);
    $twigOutputArray['message'] = $input['message'];
    $twigOutputArray['showButton'] = 'N';
    $twigOutputArray['host'] = '../';
    $twigOutputArray['bookingRetryFlag'] = $input['bookingRetryFlag'];
    $twigOutputArray['retryInput'] = $input;
    
    //call send mail function  if the $this->_AtwigOutputArray is grater than 0
    if(count($twigOutputArray) > 0){
        $_SmailContent = $twig->render('domesticAirMailItinerary.tpl',$twigOutputArray);
    }    
    echo $_SmailContent;
}