<?php
$currentFileDirPath = rtrim(dirname(__FILE__), "/\\");
$applicationPath    = substr($currentFileDirPath, 0, strrpos($currentFileDirPath, DIRECTORY_SEPARATOR)) . DIRECTORY_SEPARATOR;

set_include_path($applicationPath);
define('APPLICATION_BASE_PATH', $applicationPath);
require_once "common/auto_load.php";
require_once "common/include_header.php";
require_once "common/include_database.php";
require_once "lib/system/pluginFileRequire.php";
require_once "common/restrictDirectAccess.php";
require_once "lib/system/authToken.php";

fileRequire('plugins/misc/personal/harinim/classesTpl/class.tpl.misc.makePaymentTpl.php');
fileRequire('plugins/misc/personal/harinim/classes/class.payment.php');
fileRequire('plugins/payment/corporate/harinim/classes/class.pgHdfc.php');

/*$_REQUEST['status']             = 'success';
$_REQUEST['txnid']              = 48;
$_REQUEST['amount']             = 2014.00;*/

$authToken = new authToken();

//sanitize the inputs
$recievedDataFromServer = $authToken->_sanitiseInputData($_POST);

fileWrite(print_r($recievedDataFromServer, 1), 'hdfcPaymentResponsePersonal', 'a+');

//update the payment status in pg transaction table
$pgHDFC = new pgHdfc;
$updateArray = array();
$updateArray['response_data'] = json_encode($recievedDataFromServer);
$updateArray['status']        = 'Y';
$pgHDFC->_updateTransactionDetails($_SESSION['transactionId'], $updateArray);
//$paymetRequest = $pgHDFC->_getPaymentRequestDetails($_SESSION['transactionId']);
//fileWrite(print_r($paymetRequest, 1), 'hdfcPaymentResponsePersonal', 'a+');
fileWrite(print_r($_SESSION, 1), 'hdfcPaymentResponsePersonal', 'a+');
$reverseHash = $pgHDFC->_generateReversePaymentHash($recievedDataFromServer);
fileWrite(print_r($reverseHash, 1), 'hdfcPaymentResponsePersonal', 'a+');
$paymentResponseCheckSum = $recievedDataFromServer['hash'];
$total_amount = (int) $recievedDataFromServer['amount'];
fileWrite(print_r($paymentResponseCheckSum, 1), 'hdfcPaymentResponsePersonal', 'a+');
if($reverseHash == $paymentResponseCheckSum  && $_SESSION['total_amount'] == $total_amount) {
        $responseCode = $recievedDataFromServer['status'];
        $paymentresponseCode = $recievedDataFromServer['status'] == 'success' ? 0 : 1;

} else {
    ### checksum value is wrong mark payment as failure //invalid status
    $responseCode = 3;
    $paymentresponseCode = 1;
}

$packageId    = $recievedDataFromServer['txnid'];
$recievedDataFromServer['moduleName'] = 'bWFrZVB6b1h4YXltZW50NQ==';

$makePaymentObj = new makePaymentTpl();
$payment        = new personal\payment();

$makePaymentObj->_OPayment = $payment;
$paymentTypeId = 8; //debit card - ebs payment type
//update response in payment_details table

if (!$payment->_checkPaymentDetailsUpdated($packageId)){
    
    $updatePaymentArray['updated']          = '1';
    $updatePaymentArray['payment_response'] = json_encode($recievedDataFromServer);
    $makePaymentObj->_OPayment->_updatePaymentDetails($packageId, $updatePaymentArray); 

    $paymentAmount          = $recievedDataFromServer['amount'];
    $makePaymentObj->_Otwig = $twig;

    $recievedDataFromServer = $makePaymentObj->_handleDebitCardResponse($packageId, $paymentTypeId, $paymentAmount, $paymentresponseCode, true);
} 
else{
    $recievedDataFromServer['error_alert'] = 'Payment details already updated';
    $recievedDataFromServer['status']      = 2;
}

$_ATwigAlertOutput = array();

if($responseCode == 'pending'){
    $recievedDataFromServer['status']           = 'pending';
    $recievedDataFromServer['packageId']        = $packageId != '' ? $packageId : $_SESSION['transactionId'];
    $recievedDataFromServer['response']         = 2;
    $_SESSION['bookingInsertion'] = $recievedDataFromServer;
    $twigOutputTemplate = 'payment_updated.tpl';
} 
else if($responseCode == 'success'){
    
    $recievedDataFromServer['status']           = 'success';
    $recievedDataFromServer['packageId']        = $packageId;
    $recievedDataFromServer['response']         = 0;
    $_SESSION['bookingInsertion'] = $recievedDataFromServer;
    $twigOutputTemplate = 'payment_success.tpl';
} 
else{
    $recievedDataFromServer['status']           = 'failure';
    $recievedDataFromServer['packageId']        = $packageId != '' ? $packageId : $_SESSION['transactionId'];;
    $recievedDataFromServer['response']         = 1;
    $_SESSION['bookingInsertion'] = $recievedDataFromServer;
    $twigOutputTemplate = 'payment_failure.tpl';
}
$response = $twig->render($twigOutputTemplate, $_ATwigAlertOutput);
echo $response;
header('Location:../index.php');
exit;
