<?php
function mappSetting($groupId,$moduleId,$templateId,$displayOrder,$displayStatus,$stdTplId)
{
	$objDataBase = new dataBase;
	$objDataBase->dataBaseConnection();
	
        
	$displayStatus = trim($displayStatus);
	$sql = "SELECT
				module_group_id
			FROM
				core_module_group_mapping
			WHERE
				group_id = $groupId
				AND module_id = $moduleId
				AND template_id=$templateId
				AND display_status ='$displayStatus' ";
	  
	 //To execute the query
	$result=$objDataBase->_Oconnection->query($sql);
	if(!$result)
	{
		fileWrite($sql,"SqlErrors","a+");
	}
        
        

	if ( $result->rowCount()<1) 
	{
            
		$templateInsert = "INSERT INTO core_module_group_mapping 
					(
						module_group_id,
						group_id,
						module_id,
						template_id,
						display_order,
						display_status,
						display_name
					)
					VALUES
					(	
						0,
						'".$groupId."',
						'".$moduleId."',
						'".$templateId."',
						'".$displayOrder."',
						'".$displayStatus."',
						''
					)";
		
		 
                $result=$objDataBase->_Oconnection->query($templateInsert);
                if(!$result)
                {
			fileWrite($templateInsert,"SqlErrors","a+");
		} 	
	}
	else
	{
		$row =  $result->fetch(PDO::FETCH_ASSOC);
		$moduleGroupId = $row['module_group_id'];
		$sqlUpdate = "UPDATE
						core_module_group_mapping
					  SET
						display_order = '".$displayOrder."'
					 WHERE
						module_group_id = '".$moduleGroupId."'";	
		 
                    $result=$objDataBase->_Oconnection->query($sqlUpdate);
                    if(!$result)
                    {
			fileWrite($sqlUpdate,"SqlErrors","a+");
                    } 						
	}
	
	$sql = "SELECT
				 group_id
				FROM
				 core_module_group_stdtpl_mapping
			WHERE
				group_id = '".$groupId."'
				AND module_id = '".$moduleId."'
				AND std_tpl_id = '".$stdTplId."'
				AND class_name = 'content12px' ";
    
	 //To execute the query
	 $result=$objDataBase->_Oconnection->query($sql);
        if(!$result)
        {
		fileWrite($sql,"SqlError","a+");
	}

	if ( $result->rowCount()<1) 
	{
		$stdTplInsert = "INSERT INTO core_module_group_stdtpl_mapping 
					(
						module_id,
						std_tpl_id,
						group_id,
						class_name
					)
					values
					(
						'".$moduleId."',
						'".$stdTplId."',
						'".$groupId."',
						'content12px'
					)";
		 $result=$objDataBase->_Oconnection->query($stdTplInsert);
                if(!$result)
                {
			fileWrite($stdTplInsert,"SqlErrors","a+");
			return FALSE;
		}
	} 
}		
?>
