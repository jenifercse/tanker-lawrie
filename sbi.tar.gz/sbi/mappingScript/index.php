<html>
	<head>
		<style>
			body{
				font-size:12px;
			}
			form{
				margin:0px;
			}
			div{
				margin: 10px;
			}
			span{
				width:135px;
				display:inline-block;
			}
			button{
				background:#CCC;
				border:1px solid #AAA;
				border-radius:5px;
				padding:3px 5px;
				color:#000;
				cursor:pointer;
			}
		</style>
	</head>
	<body>
<?php
//@ini_set("display_errors",0);
//Require Files
require_once "../config/config.inc.php";
require_once "lib/system/fileRequire.php";
$airlinesName = array("VX");
function getForm()
{
	$options = '<select name="fileName" id="fileName"><option value="">-Select-</option>';
	foreach(glob("lib/work/*.csv") as $csvFile) {
		$csvFileName = str_replace(".csv","",basename($csvFile));
		if(isset($_REQUEST['fileName']) && $_REQUEST['fileName'] == $csvFileName)
			$options .= "<option selected='selected'>".$csvFileName."</option>";
		else
			$options .= "<option>".$csvFileName."</option>";
	}
	$options .= '</select>';
	#$agentOptions = '<select name="agentId" id="agentId"><option value="">All</option>';
	$agentOptions = '<select name="agentId" id="agentId">';
	foreach($GLOBALS["airlinesName"] as $airlines)
	{
		/*if(isset($_REQUEST['agentId']) && $airlines == $_REQUEST['agentId'])
			$agentOptions .= "<option selected='selected'>".$airlines."</option>";
		else*/
			$agentOptions .= '<option>'.$airlines.'</option>';
	}
	$agentOptions .= '</select>';
	return '<form method="POST">
				<div><span>CSV File Name: </span><span>'.$options.'</span></div>
				<div style="display:none"><span>Agent Id: </span><span>'.$agentOptions.'</span></div>
				<div><button type="submit">Submit</button>&nbsp;&nbsp;<a href="http://'.$_SERVER["SERVER_NAME"].$_SERVER["PHP_SELF"].'">Cancel</a></div>
			</form>
			<table border="1">
				<thead>
					<tr>
						<th> Module Name </th>
						<th> Template Name</th>
						<th> Classtpl Name</th>
						<th> Template Type</th>
						<th> Display Order </th>
						<th> Display Status</th>
						<th> Group ID </th>
						<th> StdTemplate ID</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td> testModule </td>
						<td> testTemplate.tpl</td>
						<td> class.tpl.testTpl</td>
						<td> tpl</td>
						<td> 1 </td>
						<td> Y</td>
						<td> 102 </td>
						<td> 1 (stdBlockBlue.tpl)</td>
					</tr>
				</tbody>
			</table>';
}

if(!isset($_REQUEST['fileName']) || empty($_REQUEST['fileName']))
{
    echo "Please provide Filename. Example : http://".$_SERVER["SERVER_NAME"].$_SERVER["PHP_SELF"]."?fileName='FILENAME' ";
	echo getForm();
	exit;
}
else if(isset($_REQUEST['fileName'])!='')
{
	$moduleFile =  $CFG['path']['basePath']."lib/work/".$_REQUEST['fileName'].".csv";
	
	if(!file_exists($moduleFile)) {
		echo getForm();
		echo "Please provide Filename. Example : http://".$_SERVER["SERVER_NAME"].$_SERVER["PHP_SELF"]."?fileName='FILENAME' <br />";
		die("Sorry, File Not Found" );
	}
	
	$databaseNameArray = array($CFG['db']['dataBaseName']);
	

	if(isset($_REQUEST['agentId']) && !empty($_REQUEST['agentId'])) {
		if(in_array(strtoupper($_REQUEST['agentId']),$airlinesName))
			$databaseNameArray = array($CFG['db']['dataBaseName']);
		else
			die("Wrong credentials please contact administrator");
	}
	echo getForm();
	foreach($databaseNameArray as $databaseName)
	{
		$CFG['db']['dataBaseName']  = $databaseName;
		echo "Database : <b>". $databaseName ."</b><br><br>";
		fileRequire("classes/class.dataBase.php");
		fileRequire("mappingScript/moduleCheck.php");
		fileRequire("mappingScript/templateCheck.php");
		fileRequire("mappingScript/mappSetting.php");
		//Database connection
		$objDataBase = new dataBase;
		$objDataBase->dataBaseConnection();
		
		$file = fopen( $moduleFile, "r");
		//for error code
		$firstLine = true;
		$lineCount =0;
		$groupId =0;
		$stdTplId=0;
		$displayStatus ='';

		while (false !== $data = fgets($file,4096))
		{
			/*if ($firstLine == true) 
			{
				$firstLine = false;
				continue;
			}*/
			$str       = $data;
			$word      = explode(",",$data);
			$wordCount = count($word);
                        
			$moduleName     = trim($word[0]);
			$templateName   = trim($word[1]);
			$className      = trim($word[2]);
			$templateType   = trim($word[3]);
			$displayOrder   = trim($word[4]);
			$displayStatus  = trim($word[5]);
			$groupId        = trim($word[6]);
			$stdTplId       = trim($word[7]);
                        
			//function for module insert and get module id
			$moduleId = moduleCheck($moduleName);
			//function for templatechek and get template id
			$templateId = templateCheck($templateName,$className,$templateType);
			//insert mapping table
			mappSetting($groupId,$moduleId,$templateId,$displayOrder,$displayStatus,$stdTplId);
			//echo " Module Name ".$modulename." Tpl Na ".$templatename." Class nm ".$classname." Tpl type ".$templatetype."<br>";
		}
		echo "Values insert successfully<br><br>";
	}
}
?>
	</body>
</html>
