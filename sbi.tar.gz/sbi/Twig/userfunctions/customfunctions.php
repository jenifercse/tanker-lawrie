<?php
require_once APPLICATION_BASE_PATH."classes/class.customtwig.php";

$create_menu_string = new Twig_SimpleFunction('create_menu_string', function ($givenArray, $template, $stringVal = "", $parentSubMenu = 'N') {
    $customTwig = new customtwig;
    $response = $customTwig->createMenu($givenArray, $template, $stringVal = "", $parentSubMenu = 'N', '', false);
    echo $response;
});

$griddata = new Twig_SimpleFunction('griddata', function ($params) {
    $customTwig = new customtwig;
    echo $customTwig->createGrid($params);
});

$printArray = new Twig_SimpleFunction('printArray', function ($params) {    
    $customTwig = new customtwig;
    echo $customTwig->printArray($params);
});

$dumpVariable = new Twig_SimpleFunction('dumpVariable', function ($params) {
    $customTwig = new customtwig;
    echo $customTwig->dumpVariable($params);
});
$createQueryBox = new Twig_SimpleFunction('createQueryBox', function ($data) {
    $customTwig = new customtwig;
    echo $customTwig->createQueryBox($data);
});

$create_corporate_menu = new Twig_SimpleFunction('create_corporate_menu', function ($givenArray, $template, $stringVal = "", $parentSubMenu = 'N') {
    $customTwig = new customtwig;
    $response = $customTwig->createCorporateMenu($givenArray, $template, $stringVal = "", $parentSubMenu = 'N', '', false);

    echo $response;
});

$create_backEndMenu_menu = new Twig_SimpleFunction('create_backEndMenu_menu', function ($givenArray, $template, $stringVal = "", $parentSubMenu = 'N') {
    $customTwig = new customtwig;
    $response = $customTwig->createMenuBackEnd($givenArray, $template, $stringVal = "", $parentSubMenu = 'N', '', false);
    echo $response;
});


$quickmenu = new Twig_SimpleFunction('createQuickLinkMenu', function ($params) {
    $customTwig = new customtwig;
    echo $customTwig->createQuickLinkMenu($params);
});

$selectedquickmenu = new Twig_SimpleFunction('selectedQuickLinkMenu', function ($params) {
    $customTwig = new customtwig;
    echo $customTwig->_dynamicQuickLink($params);
});

$twig->addFunction($create_menu_string);
$twig->addFunction($griddata);
$twig->addFunction($printArray);
$twig->addFunction($dumpVariable);
$twig->addFunction($createQueryBox);
$twig->addFunction($create_corporate_menu);
$twig->addFunction($create_backEndMenu_menu);
$twig->addFunction($quickmenu);
$twig->addFunction($selectedquickmenu);
?>