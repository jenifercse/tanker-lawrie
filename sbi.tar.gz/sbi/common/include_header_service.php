<?php
ini_set("display_errors", 0);
error_reporting(E_ALL & ~E_STRICT);

require_once $applicationPath . "config/config.inc.php";
require_once $applicationPath . "lib/system/fileRequire.php";
foreach ($CFG['plugin'] as $key => $pluginName) {
    $path = $applicationPath . "lib/system/" . $pluginName . "FileRequire.php";
    if(file_exists($path)) {
        require_once $path;
    }
}

//Common Class object required files
require_once $applicationPath . "lib/system/getPath.php";
require_once $applicationPath . "lib/system/pluginFileRequire.php";
require_once $applicationPath . "lib/system/fileRequire.php";
require_once $applicationPath . "lib/system/pluginFileRequire.php";
require_once $applicationPath . "classes/class.dataBase.php";
require_once $applicationPath . "classes/class.common.php";
require_once $applicationPath . "lib/system/decryptValues.php";
require_once $applicationPath . "lib/system/JsonPath.php";
require_once $applicationPath . "common/auto_load.php";

$_OCommon  = new common();
?>
