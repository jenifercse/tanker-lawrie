<?php
if (!defined('AAFEAWFWCHECK')) {
    //header('HTTP/1.0 403 Forbidden');
    //file_put_contents('../QUERY_FILE/security.log', "Script accessed directly:" . $_SERVER['IP_ADDR'] . " REMOTE_ADDR" . $_SERVER['REMOTE_ADDR'] . " X-FORWARD_FOR " . $_SERVER['HTTP_X_FORWARDED_FOR'] . "\n\n", FILE_APPEND);
    //exit('Forbidden');
}