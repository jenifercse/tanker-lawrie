<?php
/*
  @Created on 	:   27-05-2017
  @Author       :   Taslim
  @Description  :   autoloader script to dynamically load class and classesTpl files under plugsin directory
 */

/**
 * autoload classes 
 *
 * @var $_SDirectory
 * @param string $_SDirectory
 * @func __construct
 * @func autoload
 * @return string
 */
class autoloader {

    private $_SDirectory;
    private $_BTypeFlag;

    public function __construct($_SDirectory, $_BTypeFlag = false) {

        $this->_SDirectoryName = $_SDirectory;
        $this->_BTypeFlag = $_BTypeFlag;
    }

    /**
     * autoload function 
     *
     * @param string $_SClassName
     * @return mixed
     */
    public function autoload($_SClassName) {

        $nameSpace = strstr($_SClassName, '\\', true);

        if ($nameSpace) {
            $_SFilteredclassName = strstr($_SClassName, '\\');
            $_SFileName = $this->_BTypeFlag ? $nameSpace . '\\class.tpl.' . $_SFilteredclassName . '.php' : 'class.' . $_SClassName . '.php';
        } else {
            $_SFileName = $this->_BTypeFlag ? 'class.tpl.' . $_SClassName . '.php' : 'class.' . $_SClassName . '.php';
        }

        $_SFile = APPLICATION_BASE_PATH . $this->_SDirectoryName . '/' . $_SFileName;

        if (!is_readable($_SFile)) {
           // file_put_contents(APPLICATION_BASE_PATH . '/QUERY_FILE/autoLoadError.log', "File:" . $_SFile . " not included**\n\n", FILE_APPEND);
            return false;
        } else {
            //file_put_contents(APPLICATION_BASE_PATH . '/QUERY_FILE/autoLoadError.log', "File:" . $_SFile . " included\n\n", FILE_APPEND);
        }

        require_once $_SFile;
    }

}
#create object for class paths
$frameworkClasses            = new autoloader('classes');
//$commonClasses               = new autoloader('plugins/common/classes');
$authTokenClasses               = new autoloader('lib/system/authToken.php');

#travel Mode wise corporate classes
$airDomesticCorporateClasses  = new autoloader('plugins/airDomestic/corporate/harinim/classes');
$adminCorporateClasses         = new autoloader('plugins/admin/corporate/harinim/classes');
$miscCorporateClasses          = new autoloader('plugins/misc/corporate/harinim/classes');
$serviceCorporateClasses       = new autoloader('plugins/service/corporate/classes');

#travel Mode wise common classes
$airDomesticCommonClasses  = new autoloader('plugins/airDomestic/common/classes');
$adminCommonClasses         = new autoloader('plugins/admin/common/classes');
$miscCommonClasses         = new autoloader('plugins/misc/common/classes');

#load files from the corresponding paths
#air corporate autoload
spl_autoload_register(array($airDomesticCorporateClasses, 'autoload'));
spl_autoload_register(array($airDomesticCommonClasses, 'autoload'));

#misc corporate autoload
spl_autoload_register(array($miscCorporateClasses, 'autoload'));
spl_autoload_register(array($miscCommonClasses, 'autoload'));

#admin corporate autoload
spl_autoload_register(array($adminCorporateClasses, 'autoload'));
spl_autoload_register(array($adminCommonClasses, 'autoload'));

// mobile service file autoload
spl_autoload_register(array($serviceCorporateClasses, 'autoload'));

//spl_autoload_register(array($commonClasses, 'autoload'));
spl_autoload_register(array($frameworkClasses, 'autoload'));
spl_autoload_register(array($authTokenClasses, 'autoload'));
?>
