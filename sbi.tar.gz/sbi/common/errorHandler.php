<?php
/*
  @Created on 	:   27-05-2017
  @Author       :   Taslim
  @Description  :   invoke error handling when fatal or parse error occurs in application
 */

### throw error and send mail on error
require_once "classes/class.errorCall.php";
new errorHandle();