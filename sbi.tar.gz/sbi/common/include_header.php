<?php

/* * *****************************************************************************
 * @File		Common include header file
 * @author      	Taslim
 * @created date	2016-04-08
 * @updated date        2016-06-02
 * **************************************************************************** */
ini_set("display_errors", 0);
//error_reporting(E_ALL & ~E_STRICT);
error_reporting(E_ERROR | E_PARSE);

/* * Include config file */
require_once $applicationPath . "config/config.inc.php";

/* * Include application file include function */
require_once $applicationPath . "lib/system/fileRequire.php";

/* * Include framework related files */
foreach ($CFG['plugin'] as $key => $pluginName) {
    $path = $applicationPath . "lib/system/" . $pluginName . "FileRequire.php";
    if (file_exists($path)) {
        require_once $path;
    }
}

/* * include twig templating system */
fileRequire("lib/system/twiginit.php");

/* * get module file path */
fileRequire("lib/system/getPath.php");

/* * create database connection */
fileRequire("classes/class.dataBase.php");

/* * framework methods for executing database queries */
fileRequire("classes/class.commonDBO.php");

/* * class files initializes framework */
fileRequire("classes/class.framework.php");

/* * class file get the module path details */
fileRequire("lib/system/JsonPath.php");

/* * class decrypts the module name and form values */
fileRequire("lib/system/decryptValues.php");

/* * class file containt portablity function */
fileRequire("lib/system/portability.php");

/* * class containts framework related common functions */
fileRequire("lib/system/commonFunctions.php");

/* * frameowrk function to include plugin files */
fileRequire("lib/system/pluginFileRequire.php");

/* * class for handling application menu */
fileRequire("plugins/misc/corporate/harinim/classes/class.listMenu.php");

/* * Initialize frameowrk object* */
$_OFw = new framework(INDEXNAME);

/**
 * 
 * Load application override plugin name for overriding class files based on corporate
 * to achieve corporate customization through corproate name namesapce in classes
 * 
 */
//$_OFw->_initiateCorporateCustomization();

/* * Initialize the twig object* */
$twig = init();
$_OFw->_OTwig = $twig;
?>
