<?php

/*
 * @functionName    :   _setSessionTime
 * @description     :  To check the session time
 * @params          :   none
 * @returnType      :   none
 */

function checkSessionTime() {

    //Check Session is created or not
    if (isset($_SESSION['logInTime'])) {
        //For only developer login, session is free : developer group id is 6
        if($_SESSION['groupId'] == 6)
        {
            $_SESSION['logInTime'] = time();
            return true;
        }
        $currentTime = time();
        $logoutTime = strtotime('+' . LOGOUT_TIME, $_SESSION['logInTime']);
        //destroy the session 
        if ($logoutTime < $currentTime) {
            unset($_SESSION);
            session_unset();
            return false;
        } else {
            //Reassign the login time to current time
            $_SESSION['logInTime'] = time();
            return true;
        }
    } else {
        return true;
    }
}

?>