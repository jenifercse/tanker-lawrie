<?php

	$user = 'agencyautofe';
	$hash = 'infi@123';
	if (!($_SERVER['PHP_AUTH_USER'] == $user && $_SERVER['PHP_AUTH_PW'] == $hash)) 
	{
	    header('WWW-Authenticate: Basic realm="Please enter username and password to access  the file download"');
	    header('HTTP/1.0 401 Unauthorized');
	    echo '<h1>Unauthorized Access</h1>';
	    exit;
	}

?>
