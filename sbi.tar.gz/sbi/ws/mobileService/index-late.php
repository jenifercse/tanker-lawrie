<?php 

$applicationPath = rtrim(dirname(dirname(__FILE__)), "/\\") . DIRECTORY_SEPARATOR;
$indexPos = strpos($applicationPath,"ws");
$applicationPath = substr_replace($applicationPath,'',$indexPos);
require_once $applicationPath . "/config/config.inc.php";
require_once $applicationPath . "/lib/system/fileRequire.php";
require 'vendor/autoload.php';
require 'plugins/airDomestic/corporate/harinim/config/config.inc.php';
require 'plugins/misc/corporate/harinim/classes/class.commonQuery.php';
fileRequire('common/auto_load.php');
fileRequire("lib/system/pluginFileRequire.php");
fileRequire("plugins/service/corporate/classes/class.userAuth.php");
fileRequire("plugins/service/corporate/classes/class.search.php");

$app = new Slim\App();




$app->any('/', function($request, $response, $args) {
	$O_mobileService  = new mobileService();
	if($request->isPost()){
		$dataArray = $request->getParsedBody();
		//print_r($dataArray);exit;
		$O_mobileService = new mobileService();
		if(isset($dataArray['serviceToken']) || 1==1){
			$verificationStatus = $O_mobileService->_verifyToken($dataArray['serviceToken']);
			if($verificationStatus == 'SUCCESS' || 1==1){
					//assign the module name array

					$O_request = new $dataArray['module'];
					$responseData = $O_request->_getServiceResponse($dataArray['data']);
					//echo $responseData;
					return $response->withStatus(200)->withHeader('Content-Type', 'application/json')->write($responseData);
					//header('Content-Type: application/json');
					//echo json_encode($responseData);
					/*$defineModule  = array('userAuth','search','itinerary','payment','misc');
					//checking the condition 
					if (in_array($dataArray['module'], $defineModule))
					{
						$O_request = new $dataArray['module'];
						$response = call_user_func_array(array($O_request , $dataArray['method']), array($dataArray));
					}
					else {
					    $response->write("Module Name not found");
					}*/
			}
			else {
					$response->write("Invalid Token");
				 }
		}			
		else {

				if(isset($dataArray['userName']) && isset($dataArray['password'])) {
					$response = $O_mobileService->_generateToken($dataArray['userName'], $dataArray['password']);
				}
				else {
					echo "INVALID REQUEST";	
				}
			}
	}
	filewrite('response'.print_r($response,1),'mobileService','a+');
	return $response;
});
$app->run();


