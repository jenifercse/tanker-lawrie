<?php 
### Get Application path
$applicationPath = rtrim(dirname(dirname(__FILE__)), "/\\") . DIRECTORY_SEPARATOR;
$indexPos = strpos($applicationPath,"ws");
$applicationPath = substr_replace($applicationPath,'',$indexPos);
define('REQUEST_TYPE','webservice');

### require neccesary framework files
require_once $applicationPath . "/config/config.inc.php";
require_once $applicationPath . "/lib/system/fileRequire.php";

### include autoload for slim framework
require 'vendor/autoload.php';

### include framework files
fileRequire('common/auto_load.php');
fileRequire("lib/system/pluginFileRequire.php");
fileRequire("lib/system/twiginit.php");
fileRequire("classes/class.setCorporateSetting.php");

#### get required template files 
fileRequire('plugins/service/corporate/interface/iConfig.php');
fileRequire('plugins/service/corporate/abstract/class.serviceTemplate.php');

$app = new Slim\App();

$app->any('/', function($request, $response, $args) {

global $CFG;
$CFG['mobile'] = 'Y';
 
    ### create object
    $O_mobileService  = new mobileService();

    if($request->isPost()){
        $dataArray               = $request->getBody()->getContents();
        $O_serviceEncryptDecrypt    = new serviceEncryptDecrypt();
        $requestDetails             = $O_serviceEncryptDecrypt->_serviceDataDecrypt($dataArray);
        $CFG['mobileMailId'] = $requestDetails['mailId'];
        filewrite('ENC --> '.print_r($dataArray,1),'mobileServiceRequest','a+');
        filewrite('DECODED --> '.print_r($requestDetails,1),'mobileServiceRequest','a+');

        if(class_exists($requestDetails['module_name']) && $O_mobileService->_verifyToken($requestDetails['jwtToken']) == 'SUCCESS') {

            filewrite('DECODED --> '.print_r($requestDetails,1),'test','a+');
            
            $setCorporateSetting = new setCorporateSetting();
            $settings = $setCorporateSetting->_getCorporatePluginName($requestDetails['corporate_id']);
            fileWrite('Override Plugin Name-->'.print_r($settings,1),'test','a+');
            ### create object of the method class if exists
            $O_moduleObject             = new $requestDetails['module_name'];

            ### assign data to class member
            $O_moduleObject->_InputData = $requestDetails['data'];

            ### apply b2c default value assigning for b2c customization
            $O_moduleObject->_applyCustomization($requestDetails['appType']); 

            ### invoice business logic
            $O_moduleObject->_invokeMember();

            ### return response
            $O_moduleObject->_getServiceResponse();

            ### encrypt the data to passing through API
            $encryptedData = $O_serviceEncryptDecrypt->_serviceDataEncrypt($O_moduleObject->_Aresponse);
            //assign the module name array
            
        } else {
            ### class does not exist return failure response
            $O_moduleObject->_Sstatus   = 'N';
            $O_moduleObject->_Aresponse = '';
            $encryptedData              = $O_serviceEncryptDecrypt->_serviceDataEncrypt($O_moduleObject->_Aresponse);
        }
        
        if($requestDetails['module_name']!='search'){
            filewrite('module_name -> '.$requestDetails['module_name'],'mobileServiceResponse','a+');
            filewrite('Response -> '.print_r($O_moduleObject->_Aresponse,1),'mobileServiceResponse','a+');
        }
        $jwtToken = $O_mobileService->_generateToken($requestDetails['fcmKey']);
        fileWrite(print_r($jwtToken,1),"jwtToken","a+");
        $CFG['mobile'] = 'N';
        $CFG['mobileMailId'] = '';
        $response->write($O_mobileService->_returnFinalResponse($encryptedData,$O_moduleObject->_Sstatus,'',$jwtToken));

    } else {
        $response->write($O_mobileService->_returnFinalResponse("Only Post method is required"));
    }

    return $response;
});

$app->run();
