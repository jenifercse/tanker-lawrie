<?php ob_start(); ?>
<?php

/* * *****************************************************************************************
 * @class		SAP request file for balmer
 * @author      	Vijaykeerthi R
 * @created date	2017-10-14
 * @Modified date       
 * @args                string|method  - method name posted 
 * @args                data|json      - json array containing details (emailId & CorporateId)
 * ****************************************************************************************** */
$currentFileDirPath = rtrim(dirname(__FILE__), "/\\"); //home/Staging/AgencyAutoFrontEnd/ws/
$applicationPath = substr($currentFileDirPath, 0, strrpos($currentFileDirPath, DIRECTORY_SEPARATOR)) . DIRECTORY_SEPARATOR;

require_once $applicationPath . "config/config.inc.php";
require_once $applicationPath . "common/include_header_ws.php";
require_once $applicationPath . "lib/system/fileRequire.php";
echo $string = file_get_contents($applicationPath . 'view/corporate/ongc/html/common/ssoThankYouPage.html');
exit;
