<?php

$currentFileDirPath = rtrim(dirname(__FILE__), "/\\"); //home/Staging/AgencyAutoFrontEnd/ws/
$applicationPath = substr($currentFileDirPath, 0, strrpos($currentFileDirPath, DIRECTORY_SEPARATOR)) . DIRECTORY_SEPARATOR;
### include framework files
### unset applicaiton type already set in personal for loading corporate application

setcookie('wsauthtype', '', time() - 3600,PRODUCT_ROOT_NAME,DOCUMENT_ROOT,TRUE,TRUE);
setcookie('wsAuthType', '', time() - 3600,PRODUCT_ROOT_NAME,DOCUMENT_ROOT,TRUE,TRUE);

define('FORCE_CORPORATE_APPTYPE', true);

require_once $applicationPath . "common/include_header_ws.php";
require_once $applicationPath . "common/include_database.php";
require_once $applicationPath . "common/include_database.php";
require_once $applicationPath . "classes/class.autoLogin.php";

### create database object
$O_login     = new login();
$O_listMenu  = new listMenu();
$O_AutoLogin = new checkWSAutoLogin();

#### check and load necessary variables and application settings
$groupId = (isset($_SESSION['groupId']) && !empty($_SESSION['groupId'])) ? $_SESSION['groupId'] : 6;
$menuListArray = $O_listMenu->_getMenuDetails($groupId);
$stateCreation = $O_listMenu->_createStateFile($menuListArray, $groupId);

//take previous session data and use the same in corporate booking also

$sessionData = $_SESSION;


#### set session data from existing session
$O_AutoLogin->_Arows['details']['group_id']   			 = $sessionData['groupId'];
$O_AutoLogin->_Arows['details']['title'] 				 = $sessionData['title'];
$O_AutoLogin->_Arows['details']['first_name']	 		 = $sessionData['firstName'];
$O_AutoLogin->_Arows['details']['last_name'] 			 = $sessionData['lastName'];
$O_AutoLogin->_Arows['details']['corporate_id'] 		 = $sessionData['corporateId'];
$O_AutoLogin->_Arows['details']['corporate_name'] 		 = $sessionData['corporateName'];
$O_AutoLogin->_Arows['details']['agency_id'] 			 = $sessionData['agencyId'];
$O_AutoLogin->_Arows['details']['account_id'] 			 = $sessionData['accountId'];
$O_AutoLogin->_Arows['details']['user_type'] 			 = $sessionData['userType'];
$O_AutoLogin->_Arows['details']['user_type_id'] 		 = $sessionData['userTypeId'];
$O_AutoLogin->_Arows['details']['r_employee_id'] 		 = $sessionData['employeeId'];
$O_AutoLogin->_Arows['details']['email_id'] 			 = $sessionData['employeeEmailId'];
$O_AutoLogin->_Arows['details']['fact_employee_id'] 	 = $sessionData['factEmployeeId'];
$O_AutoLogin->_Arows['details']['r_level_id'] 			 = $sessionData['levelId'];
$O_AutoLogin->_Arows['details']['mobile_no'] 			 = $sessionData['mobileNo'];
$O_AutoLogin->_Arows['details']['sync_corporate_id'] 	 = $sessionData['syncCorporateId'];
$O_AutoLogin->_Arows['details']['sync_personal_id'] 	 = $sessionData['syncPersonalId'];
$O_AutoLogin->_Arows['details']['sync_agency_reference'] = $sessionData['syncAgencyReference'];
$O_AutoLogin->_Arows['details']['SAP_id'] = $sessionData['corporateCode'];

$O_AutoLogin->_setUserSession();
$O_AutoLogin->_setMenuState();

//if user is valid set uniqueauthorization token for the user
$autoToken = new authToken();
$autoToken->_setAuthToken();

#### redirecto to index page
$O_AutoLogin->_relativePath = true;
$O_AutoLogin->_redirectPage('index.php');