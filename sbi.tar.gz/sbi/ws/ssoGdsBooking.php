<?php ob_start(); ?>
<?php
/*
 * @class		Offline request file from backend for gds pnr booking
 * @author      	sivaprakash
 * @created date	2018-03-26
 * @Modified date       
 */
$currentFileDirPath = rtrim(dirname(__FILE__), "/\\");
$applicationPath = substr($currentFileDirPath, 0, strrpos($currentFileDirPath, DIRECTORY_SEPARATOR)) . DIRECTORY_SEPARATOR;

require_once $applicationPath . "config/config.inc.php";
require_once $applicationPath . "common/include_header_ws.php";
require_once $applicationPath . "lib/system/fileRequire.php";
require_once $applicationPath . "common/include_database.php";
require_once $applicationPath . "classes/class.autoLogin.php";

$basePath = rtrim($CFG['path']['sitePath'], "/\\");
$rootServerPath = substr($basePath, 0, strrpos($basePath, DIRECTORY_SEPARATOR));
$_Arequest = $_POST;

fileWrite('Request Params:' . print_r($_Arequest, true), 'gdsPnrBooking', 'w+');

// to set cookie data for menu details from agencyAutoBackEnd 
$objAutoLogin = new checkWSAutoLogin();

//check orguid validation
$objAutoLogin->_Oconnection = $_Oconnection;
$objAutoLogin->_SloginType = 'sso';
$objAutoLogin->_IinputData = json_decode($_Arequest['data'],true);
$objAutoLogin->_corporateId=$objAutoLogin->_getCorporateDetails($objAutoLogin->_IinputData['corporateName']);
$authenticationKey=$_Arequest['authentication'];
$jsonDecodedloginDetails = json_decode($_Arequest['loginDetails'],true);

unset($_SESSION['hideMenu']);
// check the auth key generated validation are same        
if ($objAutoLogin->_authenticateBackEndUser($authenticationKey, $jsonDecodedloginDetails)) {
        try{
            $objAutoLogin->getMenuForBackEnd($_Arequest['menu']);
            $objAutoLogin->_setCorporateAppSettingsInSession($objAutoLogin->_corporateId);
            fileWrite('Request Params:' . print_r($_Arequest, 1), 'gdsPnrBooking', 'a+');
            //Set session inputs
            $_SESSION['loginType'] = 'Offline';
            // require frame work intiliaze file            
            $menuArray = $objAutoLogin->setApplicationMenu($CFG['plugin'],$logoPath="");

             if($_Arequest['method'] == 'gdsPnrBooking'){
                $_Arequest['data']=json_decode($_Arequest['data'],true);
                $_SESSION['loginName'] = 'ssoGdsPnrBooking';
                // set request data for gds pnr booking fetch details    
                $_Arequest['data']['PNRDetails']['serviceName'] = 'getGDSBooking';
                $_Arequest['data']['PNRDetails']['requestId'] = $_Arequest['data']['PNRDetails']['pnr'];
                
                $_SESSION['gdsPnrrequest'] = $_Arequest['data']['PNRDetails'];
                $_SESSION['gdsRequestData'] = $_Arequest['data'];
                //unset($_SESSION['backEndMenu']);
                $objAutoLogin->_redirectPage();
            }
            else {
                $objAutoLogin->_redirectPage('logout.php');
            }
        } catch (Exception $ex) {
            $objAutoLogin->_errorMsg[] = $ex->getMessage();
            fileWrite(print_r($_Arequest, 1), 'gdsPnrBookingError', 'a+');
            fileWrite(print_r($objAutoLogin->_errorMsg, 1), 'gdsPnrBookingError', 'a+');
        }
} else {
    $objAutoLogin->_errorMsg[] = 'Invalid auth key unable to login';
}

fileWrite(print_r($objAutoLogin->_errorMsg, 1), 'gdsPnrBooking', 'a+');
echo $string = file_get_contents($applicationPath . '/view/corporate/ongc/html/common/directAccessError.html');
echo '</html>';
exit;
